
const AMYRAX_VERSION = '1.11.11';
const AMYRAX_UPDATE_REPO = process.env.AMYRAX_UPDATE_REPO === 'off' ? '' : (/^[\w.-]+\/[\w.-]+$/.test(process.env.AMYRAX_UPDATE_REPO || '') ? process.env.AMYRAX_UPDATE_REPO : 'AmyraxVPN-Main/Amyrax-Panel');
const AMYRAX_RESTART_CODE = 75;  
let amyraxRestart = null;  

const AMYRAX_CONFIG = {
  brand: "Amyrax Panel",
  product: "Amyrax Panel",
  subscriptionName: "کاربر اصلی",
  channelUrl: "https://t.me/AmyraxVPN",
  sponsorName: "",
  sponsorUrl: "",
  publicPort: parseInt(process.env.PORT || process.env.SERVER_PORT || '8080', 10) || 8080,
  panelPath: "amyrax",
  dataDirHint: "/data",
  uuid: "",
  panelToken: process.env.PANEL_TOKEN || "",
  domain: process.env.DOMAIN || process.env.RAILWAY_PUBLIC_DOMAIN || "",
  forceHost: process.env.FORCE_HOST || "",
  publicBaseUrl: process.env.PUBLIC_BASE_URL || process.env.SUB_BASE_URL,
  subBase: process.env.SUB_BASE || "",
  forceHttps: process.env.FORCE_HTTPS === 'true' || amyraxOnRailway() || !!process.env.REPLIT_DEPLOYMENT,
  allowLocalHostLinks: false,
  sniHy2: "www.google.com",
  massProxyUrl: "https://www.gstatic.com",
  enable: {
    hysteria2: false,
    vlessWs: amyraxOnRailway(),
    vlessWsTls: false,
    vlessHttpUpgrade: !amyraxOnRailway(),
    vlessGrpc: !amyraxOnRailway(),
    trojanWs: true,
    trojanGrpcTls: false,
    trojanWsTls: false,
    trojanHttpUpgrade: !amyraxOnRailway(),
    vmessHttpUpgrade: !amyraxOnRailway(),
    vlessHttpUpgradeTls: false,
    vmessHttpUpgradeTls: false,
    trojanHttpUpgradeTls: false,
    vmessGrpc: !amyraxOnRailway(),
    vmessGrpcTls: false,
    trojanGrpc: !amyraxOnRailway(),
    vlessXhttpTls: false,
    vlessXhttpStream: !amyraxOnRailway(),
    vlessXhttpStreamTls: false,
    vlessGrpcTls: false,
    vmessWsTls: false,
    vmessWs: true,
    vlessXhttp: !amyraxOnRailway(),
    reality: false,
    shadowTlsVless: false,
    shadowsocks: !amyraxOnRailway(),
    wireguard: false,
    tuic: false,
    socks: false,
    httpProxy: false,
    argo: false
  },
  reality: {
    target: "www.microsoft.com",
    targetPort: 443,
    shortId: ""
  },
  shadowTls: {
    sni: "www.microsoft.com",
    password: ""
  },
  shadowsocks: {
    method: "aes-256-gcm",
    password: ""
  },
  wireguard: {
    port: 51820,
    serverIp: "10.66.66.1/24",
    clientIp: "10.66.66.2/32",
    mtu: 1420
  },
  tuic: {
    port: 8443,
    congestionController: "bbr"
  },
  argo: {
    domain: "",
    auth: "",
    localPort: 8001
  },
  singBoxVersion: "1.11.15",
  xrayVersion: "25.3.6",
  cpuLimitPercent: null
};

const fs = require('fs');
const path = require('path');
const os = require('os');
const net = require('net');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const { pipeline } = require('stream/promises');
const express = require('express');
const axios = require('axios');
const zlib = require('zlib');

// BEGIN PANEL UPDATES
function createPanelUpdates() {
  const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
  const zlib = require('zlib'), vm = require('vm'), Module = require('module');
  const { spawn } = require('child_process');
  const REPO = 'AmyraxVPN-Main/Amyrax-Panel', RESTART = 75, CHECK_INTERVAL = 60 * 60000;
  const VERSION = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
  const normalize = value => VERSION.test(String(value)) ? String(value).replace(/^v/, '') : '';
  const newer = (a, b) => {
    if (!normalize(a) || !normalize(b)) return false;
    const x = normalize(a).split('.').map(Number), y = normalize(b).split('.').map(Number);
    for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i];
    return false;
  };
  const issue = (code, message) => Object.assign(new Error(message), { code });
  const readJson = file => JSON.parse(fs.readFileSync(file, 'utf8'));
  function atomic(file, value) {
    const temp = file + '.' + crypto.randomBytes(5).toString('hex') + '.tmp';
    try { fs.writeFileSync(temp, JSON.stringify(value), { mode:0o600 }); fs.renameSync(temp, file); }
    finally { if (fs.existsSync(temp)) fs.unlinkSync(temp); }
  }
  const crcTable = Array.from({length:256}, (_, n) => { for (let i=0;i<8;i++) n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0; });
  function crc32(data) { let n=0xffffffff;for(const b of data)n=crcTable[(n^b)&255]^(n>>>8);return (n^0xffffffff)>>>0; }
  function unzip(buffer) {
    const bad = () => issue('PACKAGE_INVALID', 'بستهٔ به‌روزرسانی معتبر نیست.');
    if (!Buffer.isBuffer(buffer) || buffer.length < 22 || buffer.length > 32*1024*1024) throw bad();
    let end=-1;
    for(let i=buffer.length-22;i>=Math.max(0,buffer.length-65557);i--) if(buffer.readUInt32LE(i)===0x06054b50 && i+22+buffer.readUInt16LE(i+20)===buffer.length){end=i;break;}
    if(end<0 || buffer.readUInt16LE(end+4) || buffer.readUInt16LE(end+6))throw bad();
    const count=buffer.readUInt16LE(end+10), offset=buffer.readUInt32LE(end+16), size=buffer.readUInt32LE(end+12);
    if(!count||count>512||buffer.readUInt16LE(end+8)!==count||offset+size!==end)throw bad();
    const files=new Map(), names=new Set();let pos=offset,total=0;
    for(let i=0;i<count;i++){
      if(pos+46>end||buffer.readUInt32LE(pos)!==0x02014b50)throw bad();
      const flags=buffer.readUInt16LE(pos+8), method=buffer.readUInt16LE(pos+10), crc=buffer.readUInt32LE(pos+16);
      const compressed=buffer.readUInt32LE(pos+20), length=buffer.readUInt32LE(pos+24), nameLength=buffer.readUInt16LE(pos+28), extra=buffer.readUInt16LE(pos+30), comment=buffer.readUInt16LE(pos+32);
      const local=buffer.readUInt32LE(pos+42), mode=(buffer.readUInt32LE(pos+38)>>>16)&0xf000;
      if(pos+46+nameLength+extra+comment>end||flags&1||![0,8].includes(method)||length>16*1024*1024||compressed>32*1024*1024||mode===0xa000||buffer.readUInt16LE(pos+34))throw bad();
      const name=buffer.subarray(pos+46,pos+46+nameLength).toString('utf8');
      if(!name||name.includes('\\')||name.includes('\0')||name.startsWith('/')||name.includes(':')||name.split('/').some(p=>p==='..'||p==='.'||p.endsWith('.')||p.endsWith(' '))||names.has(name.toLowerCase())||/^(node_modules|\.git|\.review|amyrax-data)\//i.test(name))throw bad();
      names.add(name.toLowerCase());total+=length;if(total>96*1024*1024)throw bad();
      if(local+30>offset||buffer.readUInt32LE(local)!==0x04034b50||buffer.readUInt16LE(local+8)!==method||buffer.readUInt16LE(local+6)!==flags)throw bad();
      const localNameLength=buffer.readUInt16LE(local+26), start=local+30+localNameLength+buffer.readUInt16LE(local+28);
      if(start+compressed>offset||buffer.subarray(local+30,local+30+localNameLength).toString('utf8')!==name)throw bad();
      let data;try {data=method===8?zlib.inflateRawSync(buffer.subarray(start,start+compressed),{maxOutputLength:Math.max(1,length)}):buffer.subarray(start,start+compressed);}catch{throw bad();}
      if(data.length!==length||crc32(data)!==crc)throw bad();
      if(!name.endsWith('/'))files.set(name,data);else if(length)throw bad();
      pos+=46+nameLength+extra+comment;
    }
    if(pos!==end)throw bad();return files;
  }
  function npmCli() {
    const candidates = [process.env.npm_execpath, path.join(path.dirname(process.execPath),'node_modules/npm/bin/npm-cli.js'), path.resolve(path.dirname(process.execPath),'../lib/node_modules/npm/bin/npm-cli.js')];
    try { candidates.push(require.resolve('npm/bin/npm-cli.js')); } catch {}
    return candidates.find(file => file && file.endsWith('.js') && fs.existsSync(file)) || '';
  }
  async function installDependencies(directory) {
    const cli=npmCli();if(!cli)throw issue('NPM_MISSING','ابزار نصب بسته‌ها در این هاست پیدا نشد؛ از فایل نصب استفاده کنید.');
    await new Promise((resolve,reject)=>{
      const child=spawn(process.execPath,[cli,'ci','--omit=dev','--ignore-scripts','--no-audit','--no-fund','--engine-strict','--fetch-retries=2','--fetch-timeout=20000'],{
        cwd:directory,windowsHide:true,stdio:'ignore',env:{...process.env,npm_config_cache:path.join(directory,'.npm-cache')}
      });
      const timer=setTimeout(()=>{child.kill();},240000);
      child.once('error',()=>{clearTimeout(timer);reject(issue('INSTALL_FAILED','نصب بسته‌های نسخهٔ جدید انجام نشد؛ پنل فعلی حفظ شد.'));});
      child.once('exit',code=>{clearTimeout(timer);code===0?resolve():reject(issue('INSTALL_FAILED','نصب بسته‌های نسخهٔ جدید انجام نشد؛ پنل فعلی حفظ شد.'));});
    });
  }
  async function getBytes(url, {headers={},maxBytes=32*1024*1024,timeout=60000}={}) {
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
    try {
      const response=await fetch(url,{headers,signal:controller.signal});
      if(!response.ok)throw issue('NETWORK','دریافت به‌روزرسانی از GitHub انجام نشد؛ دوباره تلاش کنید.');
      if(Number(response.headers.get('content-length'))>maxBytes)throw issue('PACKAGE_SIZE','بستهٔ به‌روزرسانی بیش از اندازه بزرگ است.');
      const chunks=[];let size=0;
      for await(const chunk of response.body){size+=chunk.length;if(size>maxBytes){controller.abort();throw issue('PACKAGE_SIZE','بستهٔ به‌روزرسانی بیش از اندازه بزرگ است.');}chunks.push(chunk);}
      return Buffer.concat(chunks);
    } finally {clearTimeout(timer);}
  }
  class Manager {
    constructor(options) {
      this.current=normalize(options.current);this.entry=path.resolve(options.entry);this.dataDir=path.resolve(options.dataDir);
      this.home=path.join(this.dataDir,'.amyrax-updates');this.file=path.join(this.home,'state.json');
      this.repo=options.repo===undefined?REPO:options.repo;this.enabled=!!this.repo;
      this.env=options.env||process.env;this.install=options.install||installDependencies;
      this.download=options.download||(asset=>getBytes(asset.browser_download_url));
      this.fetchRelease=options.fetchRelease||(async function(){
        const headers={'User-Agent':'AmyraxPanel/'+this.current,Accept:'application/vnd.github+json'};
        if(this.env.GITHUB_TOKEN)headers.Authorization='Bearer '+this.env.GITHUB_TOKEN;
        return JSON.parse((await getBytes('https://api.github.com/repos/'+this.repo+'/releases/latest',{headers,maxBytes:1024*1024,timeout:12000})).toString('utf8'));
      }).bind(this);
      this.onRestart=options.onRestart;this.inFlight=null;this.job=null;this.stopped=false;
      this.checkInterval=options.checkInterval||CHECK_INTERVAL;this.checkError='';this.lastAttempt=0;
      this.available=null;this.checkedAt=0;this.loadError=false;
      try { if(fs.existsSync(this.file))this.readState(); } catch {this.loadError=true;}
      try { const cached=readJson(path.join(this.home,'release.json'));this.available=this.release(cached.release);this.checkedAt=Number(cached.checkedAt)||0; } catch {}
    }
    ensureHome(){fs.mkdirSync(path.join(this.home,'versions'),{recursive:true,mode:0o700});}
    readState() {
      if(!fs.existsSync(this.file))return {schema:1};
      const state=readJson(this.file);
      if(state.schema!==1)throw issue('STATE_INVALID','اطلاعات به‌روزرسانی قابل خواندن نیست.');
      for(const target of [state.active,state.previous,state.pending])if(target&&(!normalize(target.version)||!/^[0-9]+\.[0-9]+\.[0-9]+-[a-f0-9]{12}$/.test(target.id)))throw issue('STATE_INVALID','اطلاعات به‌روزرسانی قابل خواندن نیست.');
      return state;
    }
    saveState(state){this.ensureHome();atomic(this.file,state);}
    directory(target){return path.join(this.home,'versions',target.id);}
    prune(state){
      const versions=path.join(this.home,'versions'),keep=new Set([state.active?.id,state.previous?.id,state.pending?.id].filter(Boolean));
      if(fs.existsSync(versions))for(const item of fs.readdirSync(versions,{withFileTypes:true})){
        if(item.isDirectory()&&!item.isSymbolicLink()&&/^\d+\.\d+\.\d+-[a-f0-9]{12}$/.test(item.name)&&!keep.has(item.name)){
          const target=path.join(versions,item.name);if(this.inside(target,versions))try{fs.rmSync(target,{recursive:true,force:true});}catch{}
        }
      }
      const backups=path.join(this.home,'backups');
      if(fs.existsSync(backups)){
        const entries=fs.readdirSync(backups,{withFileTypes:true}).filter(item=>item.isDirectory()&&!item.isSymbolicLink()&&/^\d+\.\d+\.\d+-[a-f0-9]{12}$/.test(item.name))
          .sort((a,b)=>fs.statSync(path.join(backups,b.name)).mtimeMs-fs.statSync(path.join(backups,a.name)).mtimeMs);
        for(const item of entries.slice(3)){const target=path.join(backups,item.name);if(this.inside(target,backups))try{fs.rmSync(target,{recursive:true,force:true});}catch{}}
      }
    }
    capability(){
      if(!this.enabled)return 'بررسی به‌روزرسانی با تنظیمات این سرور خاموش شده است.';
      if(this.loadError)return 'اطلاعات به‌روزرسانی قابل خواندن نیست؛ از فایل نصب استفاده کنید.';
      if(!this.env.AMYRAX_SUPERVISED||this.env.AMYRAX_NO_SUPERVISOR==='true'||!this.env.AMYRAX_UPDATE_HOME||path.resolve(this.env.AMYRAX_UPDATE_HOME)!==this.home)return 'برای آپدیت با یک دکمه، پنل را با راه‌انداز پیش‌فرض اجرا کنید.';
      if(this.env.RAILWAY_SERVICE_ID && (!this.env.RAILWAY_VOLUME_MOUNT_PATH || !this.inside(this.dataDir,path.resolve(this.env.RAILWAY_VOLUME_MOUNT_PATH))))return 'برای آپدیت ماندگار روی Railway، یک Volume به پوشهٔ داده‌ها متصل کنید.';
      if(this.env.REPLIT_DEPLOYMENT && !this.env.RAILWAY_VOLUME_MOUNT_PATH)return 'در این میزبانی از استقرار مجدد مخزن استفاده کنید؛ فایل‌های برنامه ماندگار نیستند.';
      if(!this.env.AMYRAX_DATA_DIR&&!this.env.RAILWAY_VOLUME_MOUNT_PATH&&this.inside(this.dataDir,os.tmpdir()))return 'پوشهٔ داده‌ها موقت است؛ مسیر ماندگار AMYRAX_DATA_DIR را مشخص کنید.';
      if(!npmCli()&&this.install===installDependencies)return 'ابزار نصب بسته‌ها در این هاست پیدا نشد؛ از فایل نصب استفاده کنید.';
      try {fs.accessSync(this.dataDir,fs.constants.W_OK);}catch{return 'پوشهٔ داده‌ها قابل نوشتن نیست؛ دسترسی هاست را بررسی کنید.';}
      return '';
    }
    inside(file,base){const r=path.relative(base,file);return !r||(!r.startsWith('..'+path.sep)&&r!=='..'&&!path.isAbsolute(r));}
    release(raw){
      if(!raw||raw.draft||raw.prerelease||!normalize(raw.tag_name))throw issue('RELEASE_INVALID','نسخهٔ منتشرشدهٔ معتبری پیدا نشد.');
      const version=normalize(raw.tag_name), name='Amyrax-Panel-v'+version+'.zip';
      const url='https://github.com/'+this.repo+'/releases/download/'+encodeURIComponent(raw.tag_name)+'/'+name;
      const asset=(raw.assets||[]).find(a=>a.name===name&&a.state==='uploaded'&&a.browser_download_url===url);
      return {version,tag:raw.tag_name,url:'https://github.com/'+this.repo+'/releases/tag/'+encodeURIComponent(raw.tag_name),asset:asset&&/^sha256:[a-f0-9]{64}$/.test(asset.digest||'')&&asset.size>0&&asset.size<=32*1024*1024?{name:asset.name,digest:asset.digest,size:asset.size,browser_download_url:url}:null,raw};
    }
    async check(fresh=false){
      if(!this.enabled)return;
      if(this.inFlight)return this.inFlight;
      if(!fresh && ((this.checkedAt&&Date.now()-this.checkedAt<this.checkInterval)||(this.lastAttempt&&Date.now()-this.lastAttempt<60000)))return;
      this.lastAttempt=Date.now();
      this.inFlight=(async()=>{try{
        const release=this.release(await this.fetchRelease());this.available=release;this.checkedAt=Date.now();this.checkError='';
        try {this.ensureHome();atomic(path.join(this.home,'release.json'),{release:release.raw,checkedAt:this.checkedAt});}catch{}
      }catch{this.checkError='بررسی نسخهٔ جدید انجام نشد؛ اتصال سرور به GitHub را بررسی کنید. اطلاعات آخرین بررسی حفظ شده است.';}})();
      try {await this.inFlight;}finally{this.inFlight=null;}
    }
    status(){
      let state;try {state=this.readState();}catch{this.loadError=true;state={};}
      const reason=this.capability(),latest=this.available?.version||'',hasNewer=newer(latest,this.current);
      const packageReason=hasNewer&&!this.available.asset?'فایل نصب معتبر این ریلیز آماده نیست؛ صفحهٔ ریلیز را بررسی کنید.':'';
      const operation=state.operation||{phase:'idle'};
      return {ok:true,current:this.current,latest,newer:hasNewer,disabled:!this.enabled,canApply:!reason&&!packageReason&&hasNewer,
        reason:reason||packageReason,url:this.available?.url||'https://github.com/'+(this.repo||REPO)+'/releases',checkedAt:this.checkedAt,checkError:this.checkError,
        operation,rollback:state.rollback||null};
    }
    start(){
      this.firstTimer=setTimeout(()=>this.check().catch(()=>{}),8000);this.firstTimer.unref();
      this.timer=setInterval(()=>{if(!this.job)this.check().catch(()=>{});},this.checkInterval);this.timer.unref();
    }
    stop(){this.stopped=true;clearTimeout(this.firstTimer);clearInterval(this.timer);}
    phase(phase,version,error=''){
      const state=this.readState();state.operation={phase,version,updatedAt:Date.now(),...(error?{error}:{})};this.saveState(state);
    }
    begin(version){
      const reason=this.capability();if(reason)throw issue('UNSUPPORTED',reason);
      const state=this.readState();
      if(this.job||state.pending||['downloading','installing','restarting','testing'].includes(state.operation?.phase))throw issue('BUSY','به‌روزرسانی در حال انجام است؛ منتظر بمانید.');
      if(!this.available||!newer(this.available.version,this.current)||normalize(version)!==this.available.version)throw issue('VERSION_CHANGED','نسخهٔ پیشنهادی تغییر کرده است؛ دوباره بررسی کنید.');
      if(!this.available.asset)throw issue('PACKAGE_MISSING','فایل نصب معتبر این ریلیز آماده نیست.');
      const release=this.available;this.phase('downloading',release.version);
      this.job=this.apply(release).catch(error=>{this.phase('failed',release.version,error.code?error.message:'به‌روزرسانی انجام نشد؛ نسخهٔ فعلی حفظ شد. دوباره تلاش کنید.');}).finally(()=>{this.job=null;});
      return this.status();
    }
    async apply(release){
      const target={version:release.version,id:release.version+'-'+crypto.randomBytes(6).toString('hex')},directory=this.directory(target);
      try {
        const bytes=await this.download(release.asset);
        if(bytes.length!==release.asset.size||'sha256:'+crypto.createHash('sha256').update(bytes).digest('hex')!==release.asset.digest)throw issue('DIGEST_MISMATCH','فایل دانلودشده با ریلیز یکسان نیست؛ پنل فعلی حفظ شد.');
        const files=unzip(bytes),required=['index.js','package.json','package-lock.json'];
        if(required.some(name=>!files.has(name)))throw issue('PACKAGE_INVALID','بستهٔ نصب کامل نیست.');
        const code=files.get('index.js').toString('utf8');
        const manifest=JSON.parse(files.get('package.json')),lock=JSON.parse(files.get('package-lock.json'));
        if(!code.includes("const AMYRAX_VERSION = '"+release.version+"';")||manifest.version!==release.version||manifest.name!=='amyrax-panel'||lock.version!==release.version||lock.packages?.['']?.version!==release.version)throw issue('VERSION_MISMATCH','نسخهٔ فایل‌های بسته با ریلیز یکسان نیست.');
        new vm.Script(Module.wrap(code),{filename:'index.js'});
        this.ensureHome();fs.mkdirSync(directory,{mode:0o700});
        // The standalone entry embeds its assets and runtime. Only code and manifests are needed.
        for(const name of required)fs.writeFileSync(path.join(directory,name),files.get(name),{mode:0o600});
        this.phase('installing',release.version);await this.install(directory);
        if(this.stopped)throw issue('CANCELLED','به‌روزرسانی متوقف شد؛ پنل فعلی حفظ شد.');
        const backup=path.join(this.home,'backups',target.id);fs.mkdirSync(backup,{recursive:true,mode:0o700});
        for(const name of ['auth.json','state.json','users.json','traffic.json','custom-configs.json']){
          const file=path.join(this.dataDir,name);if(fs.existsSync(file)){fs.copyFileSync(file,path.join(backup,name));fs.chmodSync(path.join(backup,name),0o600);}
        }
        const state=this.readState();state.pending=target;state.previous=state.active||null;state.rollback=null;
        state.operation={phase:'restarting',version:target.version,updatedAt:Date.now()};this.saveState(state);
        if(!this.onRestart)throw issue('RESTART_UNAVAILABLE','راه‌اندازی مجدد در این اجرا آماده نیست.');
        this.onRestart();
      }catch(error){
        const state=this.readState();if(state.pending?.id===target.id){delete state.pending;this.saveState(state);}
        if(fs.existsSync(directory)&&this.inside(directory,path.join(this.home,'versions')))fs.rmSync(directory,{recursive:true,force:true});
        throw error;
      }
    }
    supervise({config={},args=[],stdio='inherit',startupTimeout=180000,settleTime=15000,healthCheck,onEvent=()=>{}}={}){
      let child=null,stopping=false,startTimer,settleTimer,healthTimer,selected=null,trial=false,rollingBack=false,probing=false;
      const clear=()=>{clearTimeout(startTimer);clearTimeout(settleTimer);clearInterval(healthTimer);startTimer=settleTimer=healthTimer=undefined;};
      const checkHealth=healthCheck||(()=>new Promise(resolve=>{
        const req=require('http').get({host:'127.0.0.1',port:this.env.PORT||this.env.SERVER_PORT||config.publicPort||8080,path:'/healthz',timeout:2000},res=>{res.resume();resolve(res.statusCode===200);});
        req.on('error',()=>resolve(false));req.on('timeout',()=>{req.destroy();resolve(false);});
      }));
      const event=(type,extra={})=>onEvent({type,...extra});
      const rollback=(reason)=>{
        if(rollingBack)return;rollingBack=true;clear();
        const state=this.readState(), failed=state.pending||selected;
        state.active=state.previous||null;state.previous=null;delete state.pending;
        state.rollback={version:failed?.version,at:Date.now(),message:reason};
        state.operation={phase:'rolled-back',version:failed?.version,error:reason,updatedAt:Date.now()};this.saveState(state);
        event('rollback',{version:failed?.version});
      };
      const choose=()=>{
        const state=this.readState();
        if(state.active && !newer(state.active.version,this.current)){state.active=null;state.previous=null;this.saveState(state);}
        if(state.pending && !newer(state.pending.version,this.current)){delete state.pending;state.operation={phase:'complete',version:this.current,updatedAt:Date.now()};state.rollback=null;this.saveState(state);}
        selected=state.pending||state.active||null;trial=!!selected;rollingBack=false;
        if(!state.pending && ['downloading','installing','restarting','testing'].includes(state.operation?.phase)){
          state.operation={phase:'failed',version:state.operation.version,error:'به‌روزرسانی ناتمام ماند؛ نسخهٔ قبلی اجرا شده است. دوباره تلاش کنید.',updatedAt:Date.now()};this.saveState(state);
        }
        if(selected && !fs.existsSync(path.join(this.directory(selected),'index.js'))){
          if(trial){rollback('فایل‌های نسخهٔ جدید کامل نبود؛ نسخهٔ قبلی بازیابی شد.');return choose();}
          state.active=null;state.rollback={version:selected.version,at:Date.now(),message:'فایل‌های نسخهٔ ذخیره‌شده در دسترس نبود؛ نسخهٔ نصب‌شده اجرا شد.'};this.saveState(state);selected=null;
        }
        return selected?path.join(this.directory(selected),'index.js'):this.entry;
      };
      const run=()=>{
        let file;try {file=choose();}catch{this.loadError=true;selected=null;trial=false;file=this.entry;event('state-error');}
        child=spawn(process.execPath,process.execArgv.concat([file,...args]),{cwd:selected?this.directory(selected):process.cwd(),stdio:stdio==='inherit'?['inherit','inherit','inherit','ipc']:['ignore','pipe','pipe','ipc'],windowsHide:true,
          env:{...process.env,AMYRAX_SUPERVISED:'1',AMYRAX_DATA_DIR:this.dataDir,AMYRAX_UPDATE_HOME:this.home,AMYRAX_BOOT_CONFIG:JSON.stringify(config)}});
        event('spawn',{child,version:selected?.version||this.current,trial});
        if(trial){this.phase('testing',selected.version);startTimer=setTimeout(()=>{rollback('نسخهٔ جدید در زمان لازم آماده نشد؛ نسخهٔ قبلی بازیابی شد.');child.kill();},startupTimeout);}
        child.on('message',async message=>{
          if(message?.type!=='amyrax-ready'||!trial||rollingBack||normalize(message.version)!==selected.version)return;
          if(settleTimer)return;
          const running=child;if(!await checkHealth()||child!==running||rollingBack||stopping)return;
          clearTimeout(startTimer);
          healthTimer=setInterval(async()=>{if(probing)return;probing=true;const healthy=await checkHealth();probing=false;
            if(!healthy&&trial&&!stopping&&child===running){rollback('موتورهای اتصال نسخهٔ جدید آماده نماندند؛ نسخهٔ قبلی بازیابی شد.');running.kill();}},2000);
          settleTimer=setTimeout(async()=>{if(!await checkHealth()||child!==running||rollingBack||stopping){if(!stopping&&!rollingBack){rollback('نسخهٔ جدید آماده نشد؛ نسخهٔ قبلی بازیابی شد.');running.kill();}return;}
            const state=this.readState();if((state.pending||state.active)?.id!==selected.id)return;state.active=state.pending||state.active;delete state.pending;
            state.operation={phase:'complete',version:state.active.version,updatedAt:Date.now()};this.saveState(state);trial=false;clear();this.prune(state);event('ready',{version:state.active.version});},settleTime);
        });
        child.once('error',()=>{if(trial)rollback('نسخهٔ جدید اجرا نشد؛ نسخهٔ قبلی بازیابی شد.');});
        child.once('close',code=>{
          clear();if(stopping){event('stopped');return;}
          if(trial&&!rollingBack)rollback('نسخهٔ جدید با خطا متوقف شد؛ نسخهٔ قبلی بازیابی شد.');
          if(rollingBack||code===RESTART){if(rollingBack)this.prune(this.readState());run();return;}
          event('exit',{code:code==null?1:code});
        });
      };
      run();
      return {stop:signal=>{stopping=true;clear();child?.kill(signal||'SIGTERM');},get child(){return child;}};
    }
  }
  return {Manager,newer,normalize,unzip,crc32,installDependencies,REPO,RESTART};
}


// END PANEL UPDATES
const PanelUpdates = createPanelUpdates();

// BEGIN NETWORK SUPPORT
function createNetworkSupport({ axios, Logger }) {
  const net = require('net'), http = require('http'), https = require('https');
  const dns = require('dns').promises, crypto = require('crypto');
  const botDomain = value => /(^|\.)apps\.bot-hosting\.cloud$/i.test(host(value));
  const edgeDomain = host => botDomain(host) || /(^|\.)(up\.railway\.app|replit\.app)$/i.test(host || '');
  function host(value) {
    let input = String(value || '').trim();
    if (!input || /[\s\\@]/.test(input)) return '';
    if (net.isIP(input)) return input.toLowerCase();
    try {
      const parsed = new URL(input.includes('://') ? input : 'http://' + input);
      if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) return '';
      return parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
    } catch { return ''; }
  }
  function publicIp(value) {
    let ip = host(value);
    const family = net.isIP(ip);
    if (family === 4) {
      const [a,b,c] = ip.split('.').map(Number);
      return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254)
        || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168)
        || (a === 100 && b >= 64 && b <= 127) || (a === 198 && [18,19].includes(b))
        || (a === 192 && b === 0 && [0,2].includes(c)) || (a === 198 && b === 51 && c === 100)
        || (a === 203 && b === 0 && c === 113));
    }
    if (family === 6) {
      ip = new URL('http://[' + ip + ']').hostname.slice(1, -1);
      if (/^::ffff:/i.test(ip)) {
        const tail = ip.slice(7), parts = tail.split(':');
        if (net.isIP(tail) === 4) return publicIp(tail);
        if (parts.length === 2) {
          const packed = (parseInt(parts[0],16) * 65536 + parseInt(parts[1],16)) >>> 0;
          return publicIp([packed >>> 24,(packed >>> 16) & 255,(packed >>> 8) & 255,packed & 255].join('.'));
        }
        return false;
      }
      return /^[23][0-9a-f]{3}:/.test(ip) && !/^2001:db8:/.test(ip);
    }
    return false;
  }
  const publicHost = value => {
    const name = host(value);
    if (!name) return false;
    if (net.isIP(name)) return publicIp(name);
    return name.length <= 253 && name.includes('.') && !/(^|\.)(localhost|local|internal|test|invalid|example|replit\.dev)$/.test(name)
      && name.split('.').every(part => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part));
  };
  function configuredOrigin(value, config = {}) {
    const input = String(value || '').trim(), address = host(input);
    if (!address || net.isIP(input)) return '';
    const secure = config.forceHttps || edgeDomain(address);
    const parsed = new URL(input.includes('://') ? input : (secure ? 'https://' : 'http://') + input);
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.port === '0') throw Error('DOMAIN must be a hostname, IP or HTTP(S) address with a valid port and no credentials, query or fragment.');
    return input.includes('://') || parsed.port || /:\d+(?:\/|$)/.test(input) ? parsed.origin : '';
  }
  function origin(config, name) {
    const learned = config.learnedPublicOrigin;
    const related = learned && (host(name) === host(learned) || (config.forceHost && host(config.domain) === host(learned)));
    const explicit = config.subBase || config.publicBaseUrl || (related ? learned : '');
    if (explicit) {
      const parsed = new URL(explicit);
      if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash) throw Error('PUBLIC_BASE_URL must be an HTTP(S) URL without credentials, a query or a fragment.');
      return parsed;
    }
    const address = host(name), ipv6 = net.isIP(address) === 6 ? '[' + address + ']' : address;
    const secure = config.forceHttps || edgeDomain(address);
    return new URL((secure ? 'https://' : 'http://') + ipv6 + (secure ? '' : ':' + config.publicPort));
  }
  function linkEndpoint(config, name) {
    const address = host(name);
    let publicUrl;
    try { publicUrl = origin(config, address); } catch {}
    const related = publicUrl && (host(publicUrl.hostname) === address || (config.forceHost && host(config.domain) === host(publicUrl.hostname)));
    const edge = edgeDomain(address) || (related && publicUrl.protocol === 'https:');
    const override = process.env.LINK_PORT;
    const port = override ? Number(override) : related ? Number(publicUrl.port || (publicUrl.protocol === 'https:' ? 443 : 80)) : edge ? 443 : config.publicPort;
    const tls = process.env.LINK_TLS !== undefined ? ['true','1'].includes(process.env.LINK_TLS) : edge;
    return {host:address, port, tls, sni:config.forceHost && config.domain ? config.domain : related ? host(publicUrl.hostname) : address};
  }
  async function discoverIp(options = {}) {
    const request = options.request || axios.get.bind(axios);
    const controller = new AbortController();
    try {
      return await Promise.any([
        ['https://api.ipify.org?format=text', value => value],
        ['https://ifconfig.me/ip', value => value],
        ['https://1.1.1.1/cdn-cgi/trace', value => String(value).match(/^ip=([^\r\n]+)$/m)?.[1]],
      ].map(async ([url, extract]) => {
        const response = await request(url, {timeout:3500, maxContentLength:4096, signal:controller.signal, responseType:'text'});
        const ip = String(extract(response.data) || '').trim();
        if (!net.isIP(ip) || !publicIp(ip)) throw Error('No valid public IP');
        return ip;
      }));
    } catch { return ''; } finally { controller.abort(); }
  }
  const failure = (code, message) => Object.assign(new Error(message), {code});
  async function addresses(name, lookup = dns.lookup.bind(dns), allowLocal = false) {
    let timer;
    try {
      const result = net.isIP(name) ? [{address:name, family:net.isIP(name)}] : await Promise.race([
        lookup(name, {all:true}),
        new Promise((_, reject) => { timer = setTimeout(() => reject(failure('DNS_TIMEOUT','پاسخ DNS به‌موقع دریافت نشد.')), 4000); }),
      ]);
      if (!result.length) throw failure('DNS_EMPTY','برای این دامنه هیچ IP پیدا نشد.');
      if (!allowLocal && result.some(item => !publicIp(item.address))) throw failure('PRIVATE_ADDRESS','آدرس عمومی به IP خصوصی یا غیرقابل‌مسیریابی اشاره می‌کند.');
      return result.sort((a,b) => a.family - b.family);
    } finally { clearTimeout(timer); }
  }
  function probe(url, ip, challenge, proof, websocket = false, options = {}) {
    return new Promise((resolve, reject) => {
      const started = Date.now(), secure = url.protocol === 'https:', key = crypto.randomBytes(16).toString('base64');
      const target = new URL(url);
      target.pathname = websocket ? '/Telegram=@AmyraxVPN' : target.pathname.replace(/\/$/, '') + '/.well-known/amyrax-connectivity';
      target.search = websocket ? '' : '?challenge=' + challenge;
      const transport = secure ? https : http;
      const request = transport.request(target, {
        agent:false, family:ip.family, rejectUnauthorized:true,
        lookup:(_, options, callback) => callback(null, options.all ? [ip] : ip.address, ip.family),
        headers:websocket ? {Connection:'Upgrade',Upgrade:'websocket','Sec-WebSocket-Version':'13','Sec-WebSocket-Key':key} : {Accept:'application/json','Cache-Control':'no-store'},
      });
      const timer = setTimeout(() => request.destroy(failure('CONNECT_TIMEOUT','اتصال به آدرس عمومی در مهلت بررسی برقرار نشد.')), options.timeoutMs || 6000);
      let settled = false;
      const done = (error, value) => { if (settled) return; settled = true; clearTimeout(timer); error ? reject(error) : resolve(value); };
      request.once('upgrade', (response, socket) => {
        const expected = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
        socket.destroy();
        if (!websocket) return done(failure('WRONG_ENDPOINT','ورودی پنل پاسخ معتبر به بررسی اتصال نداد.'));
        if (response.statusCode !== 101 || response.headers['sec-websocket-accept'] !== expected) return done(failure('WS_INVALID','پاسخ WebSocket معتبر نیست.'));
        done(null, {latencyMs:Date.now()-started});
      });
      request.once('response', response => {
        if (websocket) { response.destroy(); return done(failure('WS_UNAVAILABLE','ورودی عمومی اجازهٔ اتصال WebSocket نمی‌دهد (HTTP '+response.statusCode+').')); }
        const chunks = []; let size = 0;
        response.on('data', chunk => {
          size += chunk.length;
          if (size > 4096) response.destroy(failure('PROBE_RESPONSE','پاسخ بررسی بیش از حد بزرگ است.'));
          else chunks.push(chunk);
        });
        response.once('error', error => done(error));
        response.once('aborted', () => done(failure('PROBE_ABORTED','پاسخ بررسی اتصال ناقص دریافت شد.')));
        response.once('end', () => {
          let body; try { body = JSON.parse(Buffer.concat(chunks).toString()); } catch {}
          if (response.statusCode !== 200 || body?.proof !== proof) return done(failure('WRONG_ENDPOINT','این آدرس به همین پنل نرسید؛ دامنه، پورت و تنظیمات هاست را بررسی کنید.'));
          done(null, {latencyMs:Date.now()-started});
        });
      });
      request.once('error', error => done(error)); request.end();
    });
  }
  class Diagnostics {
    constructor(config, options = {}) {
      this.config = config; this.options = options; this.secret = crypto.randomBytes(32);
      this.result = {state:'pending',checkedAt:null,checks:[],message:'بررسی آدرس عمومی پس از راه‌اندازی انجام می‌شود.',iranReachability:'unverified'};
    }
    proof(challenge) { return crypto.createHmac('sha256', this.secret).update(challenge).digest('hex'); }
    snapshot() { return this.result; }
    async check(name, engines = {}) {
      const config = this.config;
      let url;
      try { url = origin(config, name); } catch {}
      const key = url?.origin || String(name);
      if (this.pending?.key === key) return this.pending.promise;
      if (this.result.endpoint === key && Date.now() - Date.parse(this.result.checkedAt) < 60000) return this.result;
      const run = async () => {
        const checks = [];
        const add = (id, state, message, extra = {}) => checks.push({id,state,message,...extra});
        if (!url || !publicHost(url.hostname)) add('endpoint','error','آدرس عمومی معتبر تنظیم نشده است؛ آدرس پایهٔ واقعی پنل در PUBLIC_BASE_URL یا IP و پورت ورودی تخصیص‌یافتهٔ میزبان را وارد کنید.');
        else {
          add('endpoint','ok','آدرس عمومی از نظر ساختار معتبر است.');
          try {
            const ips = await addresses(host(url.hostname), this.options.lookup);
            add('dns','ok','آدرس عمومی در DNS پیدا شد.',{addresses:ips.map(item=>item.address)});
            const challenge = crypto.randomBytes(16).toString('hex');
            let response, used, lastError;
            for (const ip of ips.slice(0,2)) {
              try { response = await (this.options.probe || probe)(url,ip,challenge,this.proof(challenge)); used = ip; break; }
              catch (error) { lastError = error; }
            }
            if (!response) throw lastError;
            add('panel','ok','آدرس عمومی به همین پنل رسید.',response);
            add('tls',url.protocol === 'https:' ? 'ok' : 'warning',url.protocol === 'https:' ? 'گواهی HTTPS و نام دامنه معتبرند.' : 'اشتراک با HTTP ارائه می‌شود؛ برای افزودن آسان در v2rayNG دامنهٔ HTTPS فعال کنید.');
            try {
              await (this.options.probe || probe)(url,used,challenge,this.proof(challenge),true);
              add('websocket','ok','ورودی WebSocket برای کانفیگ‌های WS در دسترس است.');
            } catch (error) { add('websocket','warning',error.message + ' برای کانفیگ‌های WS، میزبان باید مسیر اتصال را با WebSocket عبور دهد؛ بازشدن پنل به‌تنهایی کافی نیست.'); }
          } catch (error) {
            const tlsError = /CERT|TLS|SSL|SELF_SIGNED|UNABLE_TO_VERIFY/.test(error.code || '');
            add(tlsError ? 'tls' : 'panel','error',tlsError ? 'گواهی HTTPS معتبر نیست یا با دامنه مطابقت ندارد؛ گواهی و دامنهٔ هاست را بررسی کنید.' : error.message,{code:error.code || 'NETWORK_ERROR'});
          }
        }
        add('engines',engines.singbox || engines.xray ? 'ok' : 'warning',engines.singbox || engines.xray ? 'حداقل یک موتور اتصال فعال است.' : 'موتور اتصال هنوز آماده نیست؛ گزارش نصب موتور را بررسی کنید.');
        if (url) {
          const endpoint = linkEndpoint(config,config.forceHost || name);
          const publicPort = Number(url.port || (url.protocol === 'https:' ? 443 : 80));
          const sameHost = endpoint.host === host(url.hostname);
          if (!sameHost) add('link','warning','آدرس اتصال با آدرس پنل متفاوت است؛ دسترسی IP یا هاست جایگزین باید جداگانه آزموده شود.');
          else if (endpoint.port !== publicPort || endpoint.tls !== (url.protocol === 'https:')) add('link','warning','پورت یا TLS کانفیگ با ورودی پنل متفاوت است؛ LINK_PORT و LINK_TLS را بررسی کنید.');
          else add('link','ok','آدرس، پورت و TLS کانفیگ با تنظیمات ورودی هماهنگ‌اند.');
        }
        add('iran','unverified','دسترسی از اینترنت ایران باید از همان شبکهٔ کاربر آزموده شود؛ بررسی سرور وضعیت فیلترینگ اپراتورها را تأیید نمی‌کند.');
        const state = checks.some(check=>check.state === 'error') ? 'error' : checks.some(check=>check.state === 'warning') ? 'warning' : 'ok';
        this.result = {state,endpoint:key,checkedAt:new Date().toISOString(),checks,iranReachability:'unverified',message:state === 'ok' ? 'آدرس عمومی و ورودی اتصال از سمت سرور بررسی شدند.' : 'موارد گزارش‌شده را پیش از تحویل اشتراک بررسی کنید.'};
        return this.result;
      };
      const promise = run(); this.pending = {key,promise};
      try { return await promise; } finally { if (this.pending?.promise === promise) this.pending = null; }
    }
  }
  return {host,publicIp,publicHost,botDomain,edgeDomain,configuredOrigin,origin,linkEndpoint,discoverIp,Diagnostics,addresses,probe};
}


// END NETWORK SUPPORT
const NetworkSupport = createNetworkSupport({ axios, Logger: null });

// BEGIN UPGRADE SUPPORT
function createUpgradeSupport({ fs, path }) {
  const previousPanel = 'knight', previousDirectory = 'bk-data';
  return {
    prepareEnvironment() {
      for (const [oldName,newName] of [['BK_DATA_DIR','AMYRAX_DATA_DIR'],['BK_SUPERVISED','AMYRAX_SUPERVISED'],['BK_NO_SUPERVISOR','AMYRAX_NO_SUPERVISOR']]) {
        if (process.env[newName] === undefined && process.env[oldName] !== undefined) process.env[newName] = process.env[oldName];
      }
    },
    panel(value) { return value === previousPanel ? 'amyrax' : value; },
    cookie(cookies) { return cookies.amyrax_session || cookies.bk_session || ''; },
    expiredCookie: 'bk_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0',
    requestHeader(req) { return req.get('x-amyrax-req') || req.get('x-bk-req'); },
    redirect(req,res,next,panelPath) {
      const url = req.originalUrl;
      const assets = '/' + previousPanel + '-assets';
      const panel = '/' + previousPanel;
      if (url === assets || url.startsWith(assets+'/')) return res.redirect(307,'/amyrax-assets'+url.slice(assets.length));
      if (url === panel || url.startsWith(panel+'/') || url.startsWith(panel+'?')) return res.redirect(307,'/'+panelPath+url.slice(panel.length));
      next();
    },
    dataPath(directory) {
      const source = path.resolve(directory);
      if (path.basename(source) !== previousDirectory) return source;
      const target = path.join(path.dirname(source),'amyrax-data');
      if (path.dirname(target) !== path.dirname(source) || source === target) throw new Error('Invalid data migration path.');
      const oldExists = fs.existsSync(source), newExists = fs.existsSync(target);
      if (oldExists && newExists) throw new Error('Two data directories exist. Set AMYRAX_DATA_DIR to the store you want to use.');
      if (oldExists) fs.renameSync(source,target);
      return target;
    },
    previousDataDirectories(cwd,app,tmp) { return [...new Set([cwd,app,tmp])].map(dir=>path.join(dir,previousDirectory)); }
  };
}

// END UPGRADE SUPPORT
const UpgradeSupport = createUpgradeSupport({ fs, path });
UpgradeSupport.prepareEnvironment();

const EMBEDDED_FONTS = {"Plasma-Circle-Dots.ttf":"AAEAAAARAQAABAAQRFNJRwAAAAEAAI0AAAAACEdERUYEAgSqAACNCAAAADpHUE9TYaJhgwAAjUQAAAAgR1NVQtCv59QAAI1kAAAEik9TLzKAGnViAAABmAAAAGBjbWFw88Ug0gAABVwAAANSY3Z0IKfLpBQAAAkcAAAASmZwZ22DM8JPAAAIsAAAABRnbHlm1AhbfgAACxwAAHkoaGVhZPrUxBQAAAEcAAAANmhoZWEKjgRoAAABVAAAACRobXR4nsABrAAAAfgAAANkbG9jYRQPMcQAAAloAAABtG1heHABhwGlAAABeAAAACBuYW1lFzs2VgAAhEQAAAFecG9zdM46bp0AAIWkAAAHXHByZXDat8KTAAAIxAAAAFcAAQAAAAEAAAq0FvlfDzz1AAAH2gAAAAC36iviAAAAAN7PTqv92fyuBy4IBwAAAAMAAgAAAAAAAAABAAAEnfzDAAAHwf4X/woH1wABAAAAAAAAAAAAAAAAAAAA2QABAAAA2QCoAAkAQAADAAIACABAAAoAAACNAHkAAgACAAMDMQO2AAUAAAV/BRoAAAEgBX8FGgAAA48AZAIIAAAAAAQAAAAAAAAAAAAgARAAAAAAAAAIAAAAAE1aNzMAAAAA/vwIbvoWAAAIbgXqAAAAQQAAAAAD7QV/AAAAIAADA+0AfgAAAAAB3wAAAGQAZAG2ACsDvQAeAl4AJwJzADMDhABAAx8AJQGdACgC6QBJAaYALwN+ADACvAAlAfQAGgOpADUFKQA3BHsAQQPmADADugA2A+j/2wPo/+ADdgA+AagAUAJ4ADUBywAqAdMAMQJVAEECIAAmAxIAGQMPABkDIwAtA6AAxgAfAAAAHwAAAB8AAAAf/08BzwA/AdUARQMPAC4DDQAoAd0AHwHMAB0BkwAeAasAJgJgACoAZv/0AfQAGwIFADkB9AAbAdEAOQGtADgBsgAiAdEAGgGaACcBwwAsAX0AFQAA/1MB9AATAeT+FwHyAC4AAP7kAAD+jwIoACsB9AAaAg8AGwIWAC8B9AAgAhMAHwJEADEB9AAaAAD+1AAA/0UB9AAgAAD+3AK8AA0B9AAZAfv/7AHAABIB8gAHAw0AEgMZABEBugAPAecADQQ6ABUD5wAUAd//8wHZ/+YBxAAWAfQAGQT1AA8FVQANAdj/7gHc/+8E+AAQBU4ADgHc//MB2//vBPcAEgVTAA4B3f++Adv/ywT0AA8FWAANAdn/xgHg/9IDQAAZA5EAFgMp/9MDK//QA0YAGQORABYDMP/aAyj/zQM4AA0DkQASAzf/3AMs/9YDRAAZA5cAGQM5/9wDMf/WArQAIQLgAB0CpQAKAs0AEAIT/90CJ//RAhv/5gIl/9ECD//HAiL/xwe+ABwHwQAaBWD/9gVw/+oHsAAOB7wAEgVa/+0Fb//vBwUAEgczABMEhf/yBKH/8gb7AA4HOQAZBIX/8ASY/+oETQAVBJUAGgQ8//AEZv/xBGgAHASOABoEPP/wBGb/8QL4AAwDKgAVArf/8wMP/+8C/wASAywAFQLF//gDFv/1BYsAGAXbABwDDv/qA3v/6gRfAB0EwwAfAxL/7wNl/+0FGgBFBPwAEALG/9sC4//uBQwANgT/ABACvP+tAt7/uAQsABQETAAUAff/8AIN/+8D8wASBBwAGgNF//IDrP/sBE8AHAReABwB2//zAd//8wMNABADEgAUAvYADANYABMECv/wAn7/1AL9/8IDUAALBAUABwPiABMB5f/tAd3/8AOG/88Dg//JA37/7QON//MDgQAVA4oAIQOIACUDrQAfBDwAEwPcAA8HMQAbAgoAnwAAAAMAAAADAAAAHAABAAAAAAJMAAMAAQAAABwABAIwAAAAbABAAAUALAAAACEAJQA6AD0AWwBdAHsAfQCrALcAuwDXAPcC2QYMBhsGHwY6BlIGaQZ+BoYGmAapBq8GwAbMBvkgDyAZIB0gOiIZ6BjoLftZ+337i/uV+6X7//xi/fL+kv6U/qD+sP7c/uj+7P7w/vz//wAAAAAAIAAlACgAPQBbAF0AewB9AKsAtwC7ANcA9wLZBgwGGwYfBiEGQAZgBn4GhgaYBqkGrwbABswG8CAMIBggHCA5IhnoGOgg+1b7evuK+477pPv8/F798v6B/pP+lf6h/rH+3f7p/u3+8f//AAH/4//g/97/3P+//77/of+g/3MAIf9k/0n/Kv3/+iD6EvoPAAAAAPmu+eH56fnr+gT6AvoH+f35HuAW4A7gDN/x3r8YMBgYBQkE9QT5BR8FIwTNAAAC5QHMAAABzgHSAdQB2AHaAAAB2AABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEgAegAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHIAAAAAAHYAAAAAAAAAAAAAAG4AAAAAAEwATQBPAFEAUwBVAFkAWwDHAGMAZwBrAHMAdwB7AH0AfwCBAIUAiQCNAJEAlQCZAJ0AoQAvAKUAqQCtALUAuQC9AMMAwQDVAMkAMAAxADIAMwA0ADUANgA3AEkASwBGAEcASgDHAMgAwQDCANUA1gAAAQYAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwQAAAAFAAAGBwgJCgsMDQ4PEBESExQVFhcYAAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaABsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHwAAAAAAAAAAACgpJichAAAAAAAqKwAAANgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADYAAAAAAAAAEABACx2RSCwAyVFI2FoGCNoYEQtQBcODg0NDAwLCwoKCQkICAcHBgYFBQAAAY24Af+FRWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhEswIBRgArswQDRgArsQEBRWhEsQMDRWhEAAAAAFkAdwDgAJEAmwBqAW4D3wLCAvgCKALaAyAD21wSXBJcElwSXBJcElwSXBJcElwSXBJcElwSXBJcElwSXBJcElwSXBIAFAAWAAAAAABAAEAAQABAAGoApgDKAOwBDgEmAUQBUgFuAXwBogHAAfgCUgKKAtgDDgMyA1YDtAPmA/oEGgQ6BHwEvgTmBRIFKgVkBWQFZAW4BgoGKAZGBnoGrgbGBt4G/AcwB3wHiAeeB94H9AgCCCYINAiOCLoIwgjKCNII2gjiCOoI9Aj+CQoJggnsCn4K4AtKC1ILygvUDGYMyAzSDPwNKg1eDZANyg5EDr4O+A8yD5IP7BAuEH4QmBCyEPoRRhGEEdASPBKsEwQTbBPKFCwUkhUAFW4V3hZuFtYXOBeUF+IYOhjAGUYZsBokGnYayBr6GzYbmBv6HDwciBy2HOgdJh1oHYgdsh3iHhweoh8yH6YgKiCkIS4h7CK6I6QkniUCJWglrCX0Jmom4Cc2J5An4igkKGoosikUKWYpvCoUKloqkiq6KuorQCuIK8AsAixsLNgtMC2MLjIu6i+oMCgwajC0MOYxGjFsMcYyCDJMMoAytjLOMuwzODOOM9g0IDRmNLQ08jVANZo19DY+Noo2+DcsN5Q4ADhAOHo4xDkeOWA5nDnqOjI6gDrIOvQ7GjtaO5Q8ZjyUAAIAfgAAA28EnQADAAcAVkAgAQgIQAkCBwQCAQAGBQIDAgUEBAAHBgQBAgEDAAABAEZ2LzcYAD88LzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAAACEloYbBAUlg4ETe5AAj/wDhZMxEhESUhESF+AvH9jAH3/gkEnftjfgOhAAAAAgCnAAACCARNAAUAFQAAARsBBRsCIy4BPQE+ATsBHgEdAQ4BAegUDP6fEQ2WAz1JBFQ6AzxKBVMBUAG7AUIm/pb+rP6XBVM4BTxLBVI5BTxLAAAAAwCt/6AENgOUAAMAEwAjAAAFJwEXAyMuAT0BPgE7AR4BHQEOAQEjLgE9AT4BOwEeAR0BDgEB0+oCH+tXA0BOBVg+Az9OBVf9ZANATgVYPgM/TgVXYKUDT6T9MgVXPAY/TwZWPAY/TwG9BVc8BUBPBlc7Bj9PAAAAAQAA/twCGQRfABIAAAEnLgInJjU0EjcXBwYHBhUQFwFbMjODaQkBeKf2JGk8JfL+3CoqpfGdExSOAWfgiix+sGx+/vbpAAAAAQAA/twCGQRfABEAABMnNhE0LgIvATcAERQOAge/v/MBR14kJfcBHgpohDL+3MLqAQ4Ce8+bLCyK/oD+rxay8aUqAAADAKQAQAPGA3AAAwAHAAsAAGUnARcDATcJAQM3EwE2gwKPhHr9WHYCqP36AfEBlcsBwsz+TgGb0/5l/skDLwH80QAAAAIAZgB1AzwDXwADAAcAAGUDJRMlAyURAUgFARUF/goBAtZ1AukB/RfrARUE/uoAAAEAKP84AXUBEwAPAAATIgYHFRQXBzM3Nj8BNCYn1EViBVhF2VgHAQFYRgETWEYGZDyX/xMVB0ViBgAAAAEA5AGrAu4CmQADAAATNSEV5AIKAavu7QAAAAABABkAFwFQAU8ADwAANyMuAT0BPgE7AR4BHQEOAbADQ1EFXEADQlEFWxcFWz4GQlIGWj4GQlIAAAH/p//NAtED6gADAAAXJwEXm/QCNvQzqwNyqwACAKwAggMgAvYACwAXAAAlIiY1NDYzMhYVFAYnMjY1NCYjIgYVFBYB5oK4uIKCuLiCHywsHx8rK4K4goK4uIKCuO8sHx4sLB4fLAAAAQB+AAACPQRHAA0AACETLgEvAQUWFxYVFxEXAjwBAiUUFP6QLhUHBg4CdmLWTUwnsMFFBt/+mQIAAAAAAQCZ/+ID6ARSACEAAAUkJxEnNCcmJyUXHgEXMzI2PQEnAiclFx4BHwEVFA4BKwECVv6dCwYHFC4BcBAQJAg0DxIFIAsBPAkIFQkDSn1NfR4cAgFn3whDwLEnPz+4XhQMBSkBEi4vP0C4XBsOT6FtAAEA6v/kBa8EYQA5AAAFJREnNCcmJzYlFxYXMzI2NScXNCY0Ji8BJiclFxYfARUzMjY1JyYnJRcWHwEUBw4BKwEiLwEHBisBAqj+kgYHFS4+ATMQLg4lDhIBAQEBAQ4PBAElEhIOAy4PEhEVCgE8CRMTA1ElZDr6GBcHBSkuZhweAWjfCEPDrgYhP7efFAwRAQIBBAkKYGkRMFBRiBgHFQ2Pry4wP5PBKXhyND8JAwMVAAAAAAEApf/hBLAEpwAeAAAFJREvASYnJRceARc2PwI+AjcTBw4CBwUDIxchAnH+hgYHFTABdQ4PIwoLFRQSEl+uiUwsLHZkDwFTAgIC/cAfHwF05k7Htik4OKpbYkVFGRlKSxv+hwIBDBgUZ/6WAgAAAAACAET/uwPUBNcAGAAwAAAFIyImJyY1ND4CPwEnARYSFxYVFAcOAQcDMjc2NzY1NC8BJiMiBg8BBhUUFhcWFxYBghBloBcSEUdSHx5aAWrUtgsEExOQZL5aShcPHht5GiADJxlgFAUZFB4oRX1taFYpl5xeFRReATOx/n6yNzJyXGOBCAGbEQUNGyohGnEXAx15GhwFJhgSBAMAAAABAGT/pgP5BKUAHAAABRM/ATY3JQUnND4BPwElBg8BFB8CHgEfAQMXBAHkqnsmRIb+5f7CAS5JHh3+oIIKAQcGGRhZPSPQGAEzWgELrTJckfzFCRlYZSQkyt+dIyYaGykpdDcf/sUMnAAAAAAB/9v/zwQGBIIAEQAABTc2PwE2NyULAQUWHwEWHwICrC05TAMud/6wrOD+sXcuA0s5LRoxn8nJCIDju/4/Ah274oAIycmpBwAB/3z/nAOnBE8AEAAAFyU2PwE2PwElFxYfARYXBQPL/rF3LgNLOS0BeC05TAMud/6wrGS74oEHysigXJ/JyQiA4rsBwAAAAAAC/7L/zgLNBLQAJwA7AAAFJicuAScjIicuAScmNTQ3NjU0NxIlHgIXFh8BFQYVFB8BFh8BBgUDNjc2NTQvASYjIg8BBhUUHgEXFgFlBxEJCQZCREFWUwsIAQIJJAFceI5FCwcCAQcCCRMNCw7+s1lhGBEQSBATFhE5DAMaExcyGWozezsZJXs/LiQNCyUlOksBRAUDeqdJMB4eI3JVZRVlb14rBEMCzwITEBkUD0QNE0gPEAMYGQICAAAAAAIAUAAAAV4CbQAPAB8AADMjLgE9AT4BOwEeAR0BDgEDIy4BPQE+ATsBHgEdAQ4B0wM6RgRQOAI6RgRPOAM6RgRQOAI6RgRPBE82BjlHBU42BTpHAV4ETzYGOUcFTjYFOkcAAAACAOQA8gLuAxsAAwAHAAA3NSEVATUhFeQCCv32Agry7u0BOu7tAAAAAQAY/4IBkgUAABMAAAUzNSMiJjURNDY7ATUjIgYVERQWATNfKigiIigqX4OYmH7dIyADPiAj3Yd7/IZ7hwAAAAEA3v+CAlgFAAATAAAFMjY1ETQmKwEVMzIWFREUBisBFQE9g5iYg18qKCIiKCp+h3sDenuH3SMg/MIgI90AAAABAVL/gAMgBP8ALwAABTM1IyImNTQ3NjU0Jic1PgE1NCcmNTQ2OwE1IyIGFRQXFhUUBiMVMhYVFAcGFRQWAsFfKigiCg1EQ0NEDQoiKCpfg5gRDjNAPzQOEZiA3iMgFFBcKkleDAMMXkopXFAUISPdh3w0X0ofKSbiKScfSl80fIcAAAABAVL/gAMgBP8ALwAABTI2NTQnJjU0NjM1IiY1NDc2NTQmKwEVMzIWFRQHBhUUFhcVDgEVFBcWFRQGKwEVAbGDmBEOND9AMw4RmINfKigiCg1EQ0NEDQoiKCqAh3w0X0ofJyniJikfSl80fIfdIyEUUFwpSl4MAwxeSSpcUBQgI94AAAACAAAADgLcArYACgAVAAAlNyc3JwcGFRQXNwc3JzcnBwYVFBc3AjqUwc+G0EA0AYiUwM+H0D8zAQ6D08GRwT5TSjwB0YPTwZHBPVdIOwEAAAIAAAAOAtwCtgALABcAAD8BFzY1NCYvAQcXBwU3FzY1NCYvAQcXB6K/ATMDPNCGz8EB278BMwM80IfPwA7RATtIBlQ6wZHB04PRATxKBFM6wZHB0wAAAAACAGoAegM0A0gAAwAHAABlATcBBScBFwJj/hDLAfD9/cECCMJ6AhC+/e+zxwH6yAADAMYACAL2AwMAAwATACMAABM1IRUFIy4BPQE+ATMyFxYdAQ4BAyMuAT0BPgEzMhcWHQEOAcYCMP7gAy03Az0pMB8bAz4rAy03Az0pMB8bAz4BBfj3/gQ9KwMtNyIfKwMtNwIoBD0rAy03Ih8rAy03AAAAAAEAAAAAAM8EqQAKAHlAMwELC0AMAAEJCAMCAAAKAAEGAwMEAgIDCAcICQYAAAEKCgAFBAEHBgQDBAgHCgYFAAEGRnYvNxgAPzwvLzz9PAEvPP08hy4IxA78CMSHLgjEDvwIxAEuLi4uLgAuMTABSWi5AAYAC0loYbBAUlg4ETe5AAv/wDhZEwcnNyMRIxEzJzfPXBc8eR+UOBcETF4UPPvCBFs5FQAAAAH/TwAAAB8EqQAKAHdAMQELC0AMAAUJCAYEAwgJBgkKBwYGBwQDBAUFBQYHBgYHAgEBCgADAgQKCQcBAAABBkZ2LzcYAD88Ly88/TwBLzz9PIcuDsQI/AjEhy4OxAj8DsQBLi4uLi4ALjEwAUlouQAGAAtJaGGwQFJYOBE3uQAL/8A4WTMjESMXByc3FwczHx95OxRfXxQ5lgQ+PBReXRU5AAAAAQBkA50BsQV4AA8AAAEyNjc1NCc3IwcGDwEUFhcBBUViBVhF2VgHAQFYRgOdWEYGZDyX/xMVB0ViBgAAAQBkA50BsQV4AA8AAAEiBgcVFBcHMzc2PwE0JicBEEViBVhF2VgHAQFYRgV4WEYGZDyX/xMVB0ViBgAAAgAAA50CvAV4AA8AHwAAEzI2NzU0JzcjBwYPARQWFyEyNjc1NCc3IwcGDwEUFhehRWIFWEXZWAcBAVhGAXJFYgVYRdlYBwEBWEYDnVhGBmQ8l/8TFQdFYgZYRgZkPJf/ExUHRWIGAAACAIwDnQNIBXgADwAfAAABIgYHFRQXBzM3Nj8BNCYnISIGBxUUFwczNzY/ATQmJwKnRWIFWEXZWAcBAVhG/o5FYgVYRdlYBwEBWEYFeFhGBmQ8l/8TFQdFYgZYRgZkPJf/ExUHRWIGAAEAHwAOAbUCtgAKAAAlNyc3JwcGFRQXNwETlMHPhtBANAEOg9PBkcE+U0o8AQAAAAEAHQAOAbMCtgALAAA/ARc2NTQmLwEHFwfAvwEzAzzQh8/ADtEBPEoEUzrBkcHTAAEAcgAAAb8B2wAPAAAhMjY3NTQnNyMHBg8BFBYXARNFYgVYRdlYBwEBWEZYRgZkPJf/ExUHRWIGAAAAAAIAJgAAAXMDFgAPAB8AABMyNjc1NCc3IwcGDwEUFhcTIy4BPQE+ATsBHgEdAQ4Bx0ViBVhF2VgHAQFYRg8DOkYEUDgCOkYETwE7WEYGZDyX/xMVB0ViBv7FBE82BjlHBU42BTpHAAAAA//v/7oB+ARxABkAHQAtAABBJzMTJT4CPwEDDgIPAg4BDwEUHgIzFyU1BRMjLgE9AT4BOwEeAR0BDgEB9wICAf7WDVhoJydAeptUEBAMDBcBAQgaNCxHAT/+wZkDPUkEVDoDPEoFUwF1AgE/WhIVCgIBAS0MNTsWFScmd0UhImNiRGkiSQL+RQVTOAU8SwVSOQU8SwAAAAABAdwAAAJXAaAAAwAAISMRMwJXe3sBoAAC/u8E3wCqBmgAAwAHAAADJyUXBSclF5kvAUMv/nQvAUMvBN9Us1QxVLNUAAL+XATV/+0GsQAWACcAAAM3Njc2NTQnJi8BJiMiBwYPAQYVFBcHJzcmNTQ+Aj8BJw4CFRQXw5AMBw0JEzUCHBsZGDMZAQsfYzFbDwIaIQ0NJDg7FQQE1aoNEB4eGRgzGQELCRQ0BR0cLy1gYRAvJAQqMx8HBkoUS1MlLxoAAAAAAv7v/K4Aqv43AAMABwAAAyclFwUnJReZLwFDL/50LwFDL/yuVLNUMVSzVAAB/u8E+ABhBf8AAwAAAyclF+IvAUMvBPhUs1QAAf6oBK7/5QY9ABMAAAM3NjU0JyYnJiMiBwYPAQYVFBcHqnoVEBo5ExMiHzASAQYsVgSuuyEqIR8xEwURGTcFFRQ4MWsAAAAAAf84/OAAqv3nAAMAAAMnJReZLwFDL/zgVLNUAAH/UgTAAPYGCAA3AAADNzY3Fjc2NzYnJicmJyYHBg8BFxYXFg8BJy4CJy4BBxUGDwEXFhcWFRYGDwEGLwEHFxYXFjcyFBkyGRIgPx4XBQIEBRQfCAgmJhgMAgILIQIECQsDCwQBBigmBgQHDAEGBhgMAxVWHAMUID0CBMUFCyASBQsgGSkMDRk0TQEDGx0pGwsPBggECx0cChkBAQEBExUKCxEhBQULAgUCC2AUgxIYJgQAAAL/QgRCAJ4FngAPABsAAAMjLgE9AT4BOwEeAR0BDgEnMjY1NCYjIgYVFBYTBkpbBmVGBkpbBmVFGSMjGRgjIwRCBmVGBkpbBmVGBkpbdyIZGSMjGRkiAP///uME1QBVBdwABgAz9N3///64BLH/+gZEAAYANBAD////UwSBAK8F3QAGADcRP////ucEhwCiBhAABgAw+Kj///3pBLD/sgaMAAYAMcHb////SASVAOwF3QAGADb21f///uT/EgBWABkABwA1/6wCMgAA///+j/7aAEoAYwAHADL/oAIsAAD///7/BJQA3AabACYANubUAAcAMwAQAJwAAv9SBMAA9gbkADcATQAAAzc2NxY3Njc2JyYnJicmBwYPARcWFxYPAScuAicuAQcVBg8BFxYXFhUWBg8BBi8BBxcWFxY3MhE3Njc2NTQnJicjJiMiBwYHBhUUFwcUGTIZEiA/HhcFAgQFFB8ICCYmGAwCAgshAgQJCwMLBAEGKCYGBAcMAQYGGAwDFVYcAxQgPQJVBwMGDBImAg4NFxYhDQUfPATFBQsgEgULIBkpDA0ZNE0BAxsdKRsLDwYIBAsdHAoZAQEBARMVCgsRIQUFCwIFAgtgFIMSGCYEAQqCCgsLFBgVIg0EDBEnDhEoIksAA/7UBGkAuQa5ADcAOwA/AAADNzY3Fjc2NzYnJicmJyYHBg8BFxYXFg8BJy4CJy4BBxUGDwEXFhcWFRYGDwEGLwEHFxYXFjcyEyclFyUnJReSGTIZEiA/HhcFAgQFFB8ICCYmGAwCAgshAgQJCwMLBAEGKCYGBAcMAQYGGAwDFVYcAxQgPQI3HAEcHP64HAEcHAV2BQsgEgULIBkpDA0ZNE0BAxsdKRsLDwYIBAsdHAoZAQEBARMVCgsRIQUFCwIFAgtgFIMSGCYE/vRKakoJSmpKAAAD/0UErAD2BvQANwBNAF4AAAM3NjcWNzY3NicmJyYnJgcGDwEXFhcWDwEnLgInLgEHFQYPARcWFxYVFgYPAQYvAQcXFhcWNzIDNzY3NjU0JyYvASYjIgcGBwYVFBcHJzcmNTQ+Aj8BJw4CFRQXFBkyGRIgPx4XBQIEBRQfCAgmJhgMAgILIQIECQsDCwQBBigmBgQHDAEGBhgMAxVWHAMUID0CCWAHBQkGDSMBExIRECERCRVBIT0KAREWCQgYJScOAwSxBQsgEgULIBkpDA0ZNE0BAxsdKRsLDwYIBAsdHAoZAQEBARMVCgsRIQUFCwIFAgtgFIMSGCYEAQhxCAsNGhEQIhEBBwYNIxoPHx5AQAseFwMeIhQFBDENMjobGhEAAAAAAv70BOoArQbHADcAOwAAAzc2NxY3Njc2JyYnJicmBwYPARcWFxYPAScuAicuAQcVBg8BFxYXFhUWBg8BBi8BBxcWFxY3MhcnJRdyGTIZEiA/HhcFAgQFFB8ICCYmGAwCAgshAgQJCwMLBAEGKCYGBAcMAQYGGAwDFVYcAxQgPQILHAEcHAWEBQsgEgULIBkpDA0ZNE0BAxsdKRsLDwYIBAsdHAoZAQEBARMVCgsRIQUFCwIFAgtgFIMSGCYEmUpqSgAAAAP+1ARpALkGuQA3ADsAPwAAAzc2NxY3Njc2JyYnJicmBwYPARcWFxYPAScuAicuAQcVBg8BFxYXFhUWBg8BBi8BBxcWFxY3MhMnJRclJyUXkhkyGRIgPx4XBQIEBRQfCAgmJhgMAgILIQIECQsDCwQBBigmBgQHDAEGBhgMAxVWHAMUID0CNxwBHBz+uBwBHBwFdgULIBIFCyAZKQwNGTRNAQMbHSkbCw8GCAQLHRwKGQEBAQETFQoLESEFBQsCBQILYBSDEhgmBP70SmpKCUpqSgD///8PBP8A7AcGAAYAQBBrAAL/UgTAAPYG5AA3AE0AAAM3NjcWNzY3NicmJyYnJgcGDwEXFhcWDwEnLgInLgEHFQYPARcWFxYVFgYPAQYvAQcXFhcWNzIRNzY3NjU0JyYnIyYjIgcGBwYVFBcHFBkyGRIgPx4XBQIEBRQfCAgmJhgMAgILIQIECQsDCwQBBigmBgQHDAEGBhgMAxVWHAMUID0CVQcDBgwSJgIODRcWIQ0FHzwExQULIBIFCyAZKQwNGTRNAQMbHSkbCw8GCAQLHRwKGQEBAQETFQoLESEFBQsCBQILYBSDEhgmBAEKggoLCxQYFSINBAwRJw4RKCJL///+1AWYALkH6AAHAEIAAAEvAAAAA/9FBMAA9gcIADcATQBeAAADNzY3Fjc2NzYnJicmJyYHBg8BFxYXFg8BJy4CJy4BBxUGDwEXFhcWFRYGDwEGLwEHFxYXFjcyAzc2NzY1NCcmLwEmIyIHBgcGFRQXByc3JjU0PgI/AScOAhUUFxQZMhkSID8eFwUCBAUUHwgIJiYYDAICCyECBAkLAwsEAQYoJgYEBwwBBgYYDAMVVhwDFCA9AglgBwUJBg0jARMSERAhEQkVQSE9CgERFgkIGCUnDgMExQULIBIFCyAZKQwNGTRNAQMbHSkbCw8GCAQLHRwKGQEBAQETFQoLESEFBQsCBQILYBSDEhgmBAEIcQgLDRoRECIRAQcGDSMaDx8eQEALHhcDHiIUBQQxDTI6GxoRAAAAAAL+9ATqAK0GxwA3ADsAAAM3NjcWNzY3NicmJyYnJgcGDwEXFhcWDwEnLgInLgEHFQYPARcWFxYVFgYPAQYvAQcXFhcWNzIXJyUXchkyGRIgPx4XBQIEBRQfCAgmJhgMAgILIQIECQsDCwQBBigmBgQHDAEGBhgMAxVWHAMUID0CCxwBHBwFhAULIBIFCyAZKQwNGTRNAQMbHSkbCw8GCAQLHRwKGQEBAQETFQoLESEFBQsCBQILYBSDEhgmBJlKakoAAP///twFtwDBCAcABwBFAAgBTgAAAAEADQAAArwDqQAWAAAzAzcmNTQ/Aj4CNxMHDgIHBRMHF11QTRMCAwsKRo11lScoaFQKAUdMAgIBVBJUZR8hIRoaV2g2/rwKCyQqFhX+ugEBAAAAAAIAfQAAAlgFVwAFABcAACEbAQUbAQM3Njc2NzYzMhcWMzI+AT8BAwIOFg3+chIPRw4GJRcrCgwkMjcqCDg8DQoOAegCCyr9yP6LA+6+MiMXCQITFgcoEQH+9gAAAv/TAAAB+wXzAAsAHQAAISMuAScTJQMUFjsBATc2NzY3NjMyFxYzMj4BPwEDAfurir0JDgF5DCccPf3YDgYlFysKDCQyNyoIODwNCg4DtIsDIC/9VR4oAwa+MiMXCQITFgcoEQH+9gAC//IAAAGQBpcABQAbAABhGwEFGwInNyY1ND8CPgI3FwcOAgcfASMBZRYV/mISDwkqKQoBAgYFJUs+TxUVNy0FricBAecCjiv9Rv6LBIu1CTAsFBMTDg4tOBysBQYTFwsLrgAAAv/yAAAB+waXAAsAIQAAYSMuAScTJQMUFjsBASc3JjU0PwI+AjcXBw4CBx8BIwH7q4q9CQ4BeQwnHD3+ISopCgECBgUlSz5PFRU3LQWuJwEDtIsDIC/9VR4oAwa1CTAsFBMTDg4tOBysBQYTFwsLrgAAAAAD//P+kALgBagAIQA4AE4AAEEDNz4BPwEjIicuAScmNT8BNTQ+AjcWFxYfAREGBwYHBgMyNzY3NjU0LwEmIyIGDwEGFRQWFx4BAyc3JjU0PwI+AjcXBw4CBx8BIwEyXSpicxgY0ENAV1MLCQEDEEihj71YPgsDH69FRCsCLSULBw8NOw0PAhIMLgkCDAkgjyopCgECBgUlSz5PFRU3LQWuJwH+kAE8CRIfCgoYJXs/MiYTShExjpZlAgKkdY0x/mDkVyMTDgL4CAMGDRMQDTcLAQ46DQ0DEgwJAwIktQkwLBQTEw4OLTgcrAUGExcLC64AAAAAA//x/nUDAwWUACMAOQBPAABBAzc+AT8BIyInJicmNTQ3NjU0NxIlHgQVMwMjBgcGBwYTMjc2NzY1NC8BJiMiBg8BBhUUHgEXAyc3JjU0PwI+AjcXBw4CBx8BIwEwXitichkY0ENAmB4IAQIJJAFcaYVLIQYmBiAer0hBKxArJAoIDg06DQ8CEgwuCgIWDooqKQoBAgYFJUs+TxUVNy0FricB/nUBPAkSIAoKGEGeLyQNCyUlOUwBQwUCXoyMYAH+YOVWIxMOAvMIAgcNEhENNwsCDjoNDwIRFAICLrUJMCwUExMODi04HKwFBhMXCwuuAAAAAAP/8v3uAZAEdQAVABsAHgAAUyc3JjU0PwI+AjcXBw4CBx8BIwMbAQUbAQMnFj4qKQoBAgYFJUs+TxUVNy0FricBGhYV/mISDwoFA/3utQkwLBQTEw4OLTgcrAUGExcLC64BxgHnAo4r/Ub+iwEHbmAAAAAAAgAA/eQB+wSRAAsAIQAAYSMuAScTJQMUFjsBASc3JjU0PwI+AjcXBw4CBx8BIwH7q4q9CQ4BeQwnHD3+nyopCgECBgUlSz5PFRU3LQWuJwEDtIsDIC/9VR4o/ES1CTAsFBMTDg4tOBysBQYTFwsLrgAAAAACAE7+4gRtBN8AJQA7AABBIiYnAyUTFxYzMjcvASY1NDc+AT8BEwcOAQcXFhUUBwYHBgcFBgEnNyY1ND8CPgI3FwcOAgcfASMBrXTKCxYBIgshMjxRT0eTIBlP0VJR4TExfzGuSRYjKWye/vYY/tQqKQoBAgYFJUs+TxUVNy0FricB/uKekQIkDv4+BQkgaMsuMCkrdaUsLP6XGBlKKLJSXzM4Ui1sGScDBAy1CTAsFBMTDg4tOBysBQYTFwsLrgACAGT+aQRMA/gAFQA4AABBJzcmNTQ/Aj4CNxcHDgIHHwEjAyInJiMmJyY1NDY3NjcFAxcWHwEyNxcnEyERIxYVFAcGBwYBViopCgECBgUlSz5PFRU3LQWuJwFbJCMpKL5DPwUcFAcBNUQRKzoQMzgEc2EB2EERhFduSwIHtQkwLBQTEw4OLTgcrAUGExcLC678FgICEWJbgQmXk3JhH/5cBhQGASgInAEG/mAwK35jRgwJAAAC/6wAAAGQBXUAEgAoAABzIxEzMjY9AS4BJyUXFhIXFRQGASc3JjU0PwI+AjcXBw4CBx8BI3nNQBYZCS0QAWkTEicGpP7uKikKAQIGBSVLPk8VFTctBa4nAQGgHRMFRuE5RGZm/uh9A3ShA4S1CTAsFBMTDg4tOBysBQYTFwsLrgAAAAAC/8AAAAHGBREAHQAzAABhIyImJw4BKwETMz4BNTQvASU3MhYXFhcWFR4BFzMBJzcmNTQ/Aj4CNxcHDgIHHwEjAcY+L08ZLldPUgQYGRoLEwEJQAQLCQYRCgEQDCn+JiopCgECBgUlSz5PFRU3LQWuJwEjJCgfAaABJBYdYo8lBgQjHXBbSQwPAQGAtQkwLBQTEw4OLTgcrAUGExcLC64AAv/yAAABkAR1AAUACAAAYRsBBRsBAycWAWUWFf5iEg8KBQMB5wKOK/1G/osBB25gAAAAAAEAAAAAAfsEkQALAAAhIy4BJxMlAxQWOwEB+6uKvQkOAXkMJxw9A7SLAyAv/VUeKAAAAAACAJz+wAV3A3kAIAAsAAApASImPQE+AT8BBQYHFRQWMyEyNj0BLgEnJRcWEhcVFAYBMjY3LgEnDgEHHgEEYf1RcqQFHA0NAWgdEhoVAZUVGgkuDwFpEhInBqT+GjdKAgFHNzZKAgFHoXMDfN1ISEVlggUTHR0TBUfgOUVmZv7ofgNzof7ASDY3SQMBRzc2SgACAGT+wAXHA28AIwAvAAAhIyInBiMhIiY9AT4BPwEFBgcVFBYzITI2NTQnJiclFx4BFzMBMjY3LgEnDgEHHgEFxyRsRlVz/VFypAYbDQ0BaB0SGhYBlBUaGxIPAWkLCh0Mkf0IN0oCAUc3NkoCAUdTU6FzA3zdSEhFZYIFEx0dExSjbDhFRUXTcv0gSDY3SQMBRzc2SgAAAAL/rP7NAZADeQASACYAADMjETMyNj0BLgEnJRcWEhcVFAYDMjY3NjU0JicmIyIGBwYVFBYXFnnNQBYZCS0QAWkTEicGpEQoTAsCNDUMDChLCwI0NgsBoB0TBUbhOURmZv7ofQN0of7NNDYMCyhLCwI0NQwLKEsMAgAAAAAC/8v+zQHGAxQAHQAxAAAhIyImJw4BKwETMz4BNTQvASU3MhYXFhcWFR4BFzMDMjY3NjU0JicmIyIGBwYVFBYXFgHGPi9PGS5XT1IEGBkaCxMBCUAECwkGEQoBEAwp9ChMCwI0NQwMKEsLAjQ2CyMkKB8BoAEkFh1ijyUGBCMdcFtJDA8B/S00NgwLKEsLAjQ1DAsoSwwCAAQAnP3TBXcDeQAgACwAOABEAABhISImPQE+AT8BBQYHFRQWMyEyNj0BLgEnJRcWEhcVFAYBMjY3LgEnDgEHHgEnMjY3LgEnIgYHHgEXMjY3LgEnDgEHFBYEYf1RcqQFHA0NAWgdEhoVAZUVGgkuDwFpEhInBqT+pjdKAgFHNzZKAgFHuTdKAgFHNzZKAgFHsTdKAgFHNzZKAkihcwN83UhIRWWCBRMdHRMFR+A5RWZm/uh+A3Oh/sBINjdJAwFHNzZKAkc3N0kCRzc3SfNINjdJAwFHNzZKAAQAZP3TBccDeQAjAC8AOwBHAABhIyInBiMhIiY9AT4BPwEFBgcVFBYzITI2PQEuASclFx4BFzMBMjY3LgEnDgEHHgEnMjY3LgEnIgYHHgEXMjY3LgEnDgEHFBYFxyRsRlVz/VFypAYbDQ0BaB0SGhYBlBUaCS4PAWkNDSIMkf1iN0oCAUc3NkoCAUe5N0oCAUc3NkoCAUexN0oCAUc3NkoCSFNToXMDfN1ISEVlggUTHR0TBUfgOUVHSNdz/SBINjdJAwFHNzZKAkc3N0kCRzc3SfNINjdJAwFHNzZKAAAABP+s/d4BvAN5ABIAHgAqADYAAHMjETMyNj0BLgEnJRcWEhcVFAYTMjY3LgEnDgEHHgEnMjY3LgEnIgYHHgEXMjY3LgEnDgEHFBZ5zUAWGQktEAFpExInBqRNN0oCAUc3NkoCAUe5N0oCAUc3NkoCAUexN0oCAUc3NkoCSAGgHRMFRuE5RGZm/uh9A3Sh/stINjdJAwFHNzZKAkc3N0kCRzc3SfNINjdJAwFHNzZKAAAE/8v93gHGAxQAHQApADUAQQAAYSMiJicOASsBEzM+ATU0LwElNzIWFxYXFhUeARczAzI2Ny4BJw4BBx4BJzI2Ny4BJyIGBx4BFzI2Ny4BJw4BBxQWAcY+L08ZLldPUgQYGRoLEwEJQAQLCQYRCgEQDCmBN0oCAUc3NkoCAUe5N0oCAUc3NkoCAUexN0oCAUc3NkoCSCMkKB8BoAEkFh1ijyUGBCMdcFtJDA8B/StINjdJAwFHNzZKAkc3N0kCRzc3SfNINjdJAwFHNzZKAAAAAwCcAAAFdwQXACAALwA9AABhISImPQE+AT8BBQYHFRQWMyEyNj0BLgEnJRcWEhcVFAYBPgE9AS4BIw4BHQEeATM3PgE1LgErAQ4BHQEeAQRh/VFypAUcDQ0BaB0SGhUBlRUaCS4PAWkSEicGpP1ANkUESzY3RQRKNfE3RQRKNQM2RQRLoXMDfN1ISEVlggUTHR0TBUfgOUVmZv7ofgNzoQMNBEo0AzdFBEo1AzZFCQRLNzZFBEo0AzdFAAADAGQAAAXHBA0AIwAyAEAAAGEjIicGIyEiJj0BPgE/AQUGBxUUFjMhMjY9AS4BJyUXHgEXMwE+AT0BLgEjDgEdAR4BMzc+ATUuASsBDgEdAR4BBcckbEZVc/1RcqQGGw0NAWgdEhoWAZQVGgkuDwFpDQ0iDJH8GjZFBEs2N0UESjXxN0UESjUDNkUES1NToXMDfN1ISEVlggUTHR0TBUfgOUVHSNdzAWMESjQDN0UESjUDNkUJBEs3NkUESjQDN0UAAAAAA/98AAABkAS9ABIAKgBCAABzIxEzMjY9AS4BJyUXFhIXFRQGAzI3Njc2NTQnJicmIyIHBgcGFRQXFhcWJTI3Njc2NTQnJicmIyIHBgcGFRQXFhcWec1AFhkJLRABaRMSJwak8RARNRoSBA8sHyIQETQaEgQPLB4BChARNBoSBA8sHiIQETUaEgQPLB4BoB0TBUbhOURmZv7ofQN0oQOBBA8sHiIQETUaEgQPLB8iEBE0GhI7BA8sHyIQETQaEgQPLB4iEBE1GhIAAAAAA/+lAAABxgRUAB0AMQBFAABhIyImJw4BKwETMz4BNTQvASU3MhYXFhcWFR4BFzMBNzY3NjUnJicmIwcGBwYVFxYXFiU3Njc2NScmJyYjBwYHBhUXFhcWAcY+L08ZLldPUgQYGRoLEwEJQAQLCQYRCgEQDCn+YhE2HxoBCSkiLBE2HxoBCSkiARkRNh8aAQkpIiwRNh8aAQkpIiMkKB8BoAEkFh1ijyUGBCMdcFtJDA8BAZQBCCkiLBE2HxoBCSgiLBE2HxogAQkoIi0RNR8aAQgpIiwRNh8aAAAAAAQAnAAABXcE8wAgACwAOABEAABhISImPQE+AT8BBQYHFRQWMyEyNj0BLgEnJRcWEhcVFAYBPgE3LgEjDgEHHgEHPgE3LgEnDgEHHgE3PgE3LgEjDgEVHgEEYf1RcqQFHA0NAWgdEhoVAZUVGgkuDwFpEhInBqT+LzdHAQJKNzZHAQJKuTdHAQJKNzZHAQJKsTdHAQJKNzZIAkqhcwN83UhIRWWCBRMdHRMFR+A5RWZm/uh+A3OhAwYCSTc3RwJJNzdHBAJKNjdHAQNJNzZI8QJJNzdHAkk3N0cAAAAEAGQAAAXHBOkAIwAvADsARwAAYSMiJwYjISImPQE+AT8BBQYHFRQWMyEyNj0BLgEnJRceARczAT4BNy4BIw4BBx4BBz4BNy4BJw4BBx4BNz4BNy4BIw4BFR4BBcckbEZVc/1RcqQGGw0NAWgdEhoWAZQVGgkuDwFpDQ0iDJH9EzdHAQJKNzZHAQJKuTdHAQJKNzZHAQJKsTdHAQJKNzZIAkpTU6FzA3zdSEhFZYIFEx0dEwVH4DlFR0jXcwFcAkk3N0cCSTc3RwQCSjY3RwEDSTc2SPECSTc3RwJJNzdHAAf/ggAAAZAFlQASAB4AKgA2AEIATgBaAABzIxEzMjY9AS4BJyUXFhIXFRQGEz4BNy4BIw4BBx4BBz4BNy4BJw4BBx4BNz4BNy4BIw4BFR4BFz4BNy4BIw4BBx4BBz4BNy4BJw4BBx4BNz4BNy4BIw4BFR4Bec1AFhkJLRABaRMSJwakBzdHAQJKNzZHAQJKuTdHAQJKNzZHAQJKsTdHAQJKNzZIAkqqN0cBAko3NkcBAkq5N0cBAko3NkcBAkqxN0cBAko3NkgCSgGgHRMFRuE5RGZm/uh9A3ShA6gCSTc3RwJJNzdHBAJKNjdHAQNJNzZI8QJJNzdHAkk3N0ftAkk3N0cCSTc3RwQCSjY3RwEDSTc2SPECSTc3RwJJNzdHAAT/qgAAAcYFNwAdACkANQBBAABhIyImJw4BKwETMz4BNTQvASU3MhYXFhcWFR4BFzMDPgE3LgEjDgEHHgEHPgE3LgEnDgEHHgE3PgE3LgEjDgEVHgEBxj4vTxkuV09SBBgZGgsTAQlABAsJBhEKARAMKak3RwECSjc2RwECSrk3RwECSjc2RwECSrE3RwECSjc2SAJKIyQoHwGgASQWHWKPJQYEIx1wW0kMDwEBqgJJNzdHAkk3N0cEAko2N0cBA0k3NkjxAkk3N0cCSTc3RwAEAOH99AQPA+sAFAAfAC0AOQAAZTY/AQMnJi8BIgYPARM2MzIfATM3ATY3AwcXBw4BBxUBEwE3AwcGBw4BFRQWFyUyNjU0JiMiBhUUFgLjJRzraGfEqiMyWRsbMYwPVjk0AQL+0e2lYwMBOWqmKgF19/66smMDiWtUVCZ5Af81S0s1NktLwR8c5QFeDpQJARUPD/6JESUhAf4dDIsBTAEBEyuJXL79ygEYAQavAUwBK1hFumItwmviSzU2S0s2NUsAAAAAAwCT/coEJwPGAB4AKgA5AABhIyImJwYFIzU+AT8BJy4BIwYHAzc+ATMyHwETBgczAyImNTQ2MzIWFRQGASUuATU0Njc2NzYzEwcBBCdrW4EKsf7eRiulajkLLE5BHH0xGBdbQbjPnm8SVY+yNktLNjVLS/6I/wBQT1dRc4EBAmOyAUZ3W8ERvVuMKhMGHiMCDwF2Dg4dmwT+zAlK/U1LNTZLSzY1S/7d2kW1X2a5QmAjAf60r/77AAIApP7hBBAD3wAdADEAACEjETM+AT8BJyYjIgcDNzYzMh4BHwETBgcGBw4CEzI2NzY1NCYnJiMiBgcGFRQWFxYBFFU9YpIpKFY6RA6KMRtDaw1WuW2YghJkTUIjhsiiKEwLAjQ1DAwoSwsCNDYLAaAIHg4NOiYRAXYQKQNGUgX+tAlZRlEtb1f+2jQ2DAsoSwsCNDUMCyhLDAIAAAIAb/7hA9cDxwAkADgAACEjIiYnDgEHIxEzPgE/AScmJyYjIgcDNzY3NjMyHgEfARMGBzMBMjY3NjU0JicmIyIGBwYVFBYXFgPXTVqCCj7orUYuYpIpKDUiMSIeD4cxGxozKjgMVrhtnm8SVHD+ZShMCwI0NQwMKEsLAjQ2C3hbRYMLAaAIHg4NIhYJBhABdhAQDQwERVIE/ssIS/1BNDYMCyhLCwI0NQwLKEsMAgAABgDh/fQEDwPrABQAHwAtADkARQBRAABlNj8BAycmLwEiBg8BEzYzMh8BMzcBNjcDBxcHDgEHFQETATcDBwYHDgEVFBYXATI2NzQmJyIGBxQWJzI2NzQmJyIGBxQWFz4BNzQmJw4BBxQWAuMlHOtoZ8SqIzJZGxsxjA9WOTQBAv7R7aVjAwE5aqYqAXX3/rqyYwOJa1RUJnkCQSAtASshISwBK28hLAErISAtAStrISwBKyEhLAErwR8c5QFeDpQJARUPD/6JESUhAf4dDIsBTAEBEyuJXL79ygEYAQavAUwBK1hFumItwmsBSishISwBKyEhLAErISEsASshIC2SASsgISwCASohISwAAAUAk/3KBCcDxgAiADEAPQBJAFUAAGEjIiYnBgcGByM1PgE/AScmJyYjIgcDNzYzMh4BHwETBgczASUmNTQ+ATc2NzQzEwcBNy4BNT4BMx4BFQ4BJy4BNT4BMx4BFQ4BFy4BNT4BMx4BFw4BBCdrWoIKHCWl7UYqpmo4NCIxIR0OizEbRGoNV7htnm8SVY/+C/8An1SmahsdA2OyAUZ/HycBKR4eKAEpox4oASkeHycBKSYeKAEpHx4nAQIod1sdH4oMvVyKKxMhFgkHEQF2ECkDRlIE/swJSvwq2o3NYrmKKwsIAf60r/77gwEpHh4oASkeHigCASkeHycBKR4eKIYCKB8eKAEpHh8nAAAEAKT98QQQA98AHQApADUAQQAAYSMRMz4BPwEnJiMiBwM3NjMyHgEfARMGBwYHDgIBMjY3LgEnDgEHHgEnMjY3LgEnIgYHHgEXMjY3LgEnDgEHFBYBFFU9YpIpKFY6RA6KMRtDaw1WuW2YghJkTUIjhsgBFzdKAgFHNzZKAgFHuTdKAgFHNzZKAgFHsTdKAgFHNzZKAkgBoAgeDg06JhEBdhApA0ZSBf60CVlGUS1vV/7XSDY3SQMBRzc2SgJHNzdJAkc3N0nzSDY3SQMBRzc2SgAAAAQAb/3xA9cDxwAkADAAPABIAABhIyImJw4BByMRMz4BPwEnJicmIyIHAzc2NzYzMh4BHwETBgczATI2Ny4BJw4BBx4BJzI2Ny4BJyIGBx4BFzI2Ny4BJw4BBxQWA9dNWoIKPuitRi5ikikoNSIxIh4PhzEbGjMqOAxWuG2ebxJUcP7aN0oCAUc3NkoCAUe5N0oCAUc3NkoCAUexN0oCAUc3NkoCSHhbRYMLAaAIHg4NIhYJBhABdhAQDQwERVIE/ssIS/0+SDY3SQMBRzc2SgJHNzdJAkc3N0nzSDY3SQMBRzc2SgAAAAADAOH99AQPA+sAFAAfAC0AAGU2PwEDJyYvASIGDwETNjMyHwEzNwE2NwMHFwcOAQcVARMBNwMHBgcOARUUFhcC4yUc62hnxKojMlkbGzGMD1Y5NAEC/tHtpWMDATlqpioBdff+urJjA4lrVFQmecEfHOUBXg6UCQEVDw/+iRElIQH+HQyLAUwBARMriVy+/coBGAEGrwFMAStYRbpiLcJrAAAAAAIAk/3KBCcDxgAiADEAAGEjIiYnBgcGByM1PgE/AScmJyYjIgcDNzYzMh4BHwETBgczASUmNTQ+ATc2NzQzEwcBBCdrWoIKHCWl7UYqpmo4NCIxIR0OizEbRGoNV7htnm8SVY/+C/8An1SmahsdA2OyAUZ3Wx0figy9XIorEyEWCQcRAXYQKQNGUgT+zAlK/Crajc1iuYorCwgB/rSv/vsAAAAAAQCkAAAEEAPfAB0AACEjETM+AT8BJyYjIgcDNzYzMh4BHwETBgcGBw4CARRVPWKSKShWOkQOijEbQ2sNVrltmIISZE1CI4bIAaAIHg4NOiYRAXYQKQNGUgX+tAlZRlEtb1cAAAEAbwAAA9cDxwAkAAAhIyImJw4BByMRMz4BPwEnJicmIyIHAzc2NzYzMh4BHwETBgczA9dNWoIKPuitRi5ikikoNSIxIh4PhzEbGjMqOAxWuG2ebxJUcHhbRYMLAaAIHg4NIhYJBhABdhAQDQwERVIE/ssISwAAAAQA4f30BA8E1QAUAB8ALQA5AABlNj8BAycmLwEiBg8BEzYzMh8BMzcBNjcDBxcHDgEHFQETATcDBwYHDgEVFBYXATI2NTQmIyIGFRQWAuMlHOtoZ8SqIzJZGxsxjA9WOTQBAv7R7aVjAwE5aqYqAXX3/rqyYwOJa1RUJnkBqTVLSzU2S0vBHxzlAV4OlAkBFQ8P/okRJSEB/h0MiwFMAQETK4lcvv3KARgBBq8BTAErWEW6Yi3CawUGSzU2S0s2NUsAAAADAJP9ygQnBK0AIgAuAD0AAGEjIiYnBgcGByM1PgE/AScmJyYjIgcDNzYzMh4BHwETBgczATI2NTQmIyIGFRQWAyUmNTQ+ATc2NzQzEwcBBCdrWoIKHCWl7UYqpmo4NCIxIR0OizEbRGoNV7htnm8SVY/+0zVLSzU2S0uS/wCfVKZqGx0DY7IBRndbHR+KDL1ciisTIRYJBxEBdhApA0ZSBP7MCUoCDEs1NktLNjVL+h7ajc1iuYorCwgB/rSv/vsAAAAAAgCkAAAEEAUJAB0AKQAAISMRMz4BPwEnJiMiBwM3NjMyHgEfARMGBwYHDgITMjY1NCYjIgYVFBYBFFU9YpIpKFY6RA6KMRtDaw1WuW2YghJkTUIjhsg+NktLNjVLSwGgCB4ODTomEQF2ECkDRlIF/rQJWUZRLW9XBAJLNTVLSzU1SwAAAgBvAAADzQTrACQAMAAAISMiJicOAQcjETM+AT8BJyYnJiMiBwM3Njc2MzIeAR8BEwYHMwEyNjU0JiMiBhUUFgPNQ1qCCj7orUYuYpIpKDUiMSIeD4cxGxozKjgMVrhtnm8SVGb+CzZLSzY1S0t4W0WDCwGgCB4ODSIWCQYQAXYQEA0MBEVSBP7LCEsCS0s1NUtLNTVLAAABACEAAAKtA+QAGQAAMycDJS4CLwETHgIfAhYXFhUUBgcGBwZ2UwIBdhFugjAxVJfAaRQTExIOCgowNGCaAQGQcRcaDQIBAaEeUlIbHDs8Wj1AHoBQTCY9AAAAAAEAQAAAAxYD5QAcAAAhIyInJicGBwYjJwMlLgIvARMeAh8CHgEXMwMWLTUyKC9gcWpRXQIBdhFugjAxVJfAaRQTDw8eAUobFiMyERABAZBxFxoNAgEBoR5TURwcLzCWVgAAAAACACEAAAKtBQAAGQAlAAAzJwMlLgIvARMeAh8CFhcWFRQGBwYHBgMyNjU0JiMiBhUUFnZTAgF2EW6CMDFUl8BpFBMTEg4KCjA0YJosNktLNjVLSwEBkHEXGg0CAQGhHlJSGxw7PFo9QB6AUEwmPQQASzU1S0s1NUsAAAAAAgBAAAADFgUAABwAKAAAISMiJyYnBgcGIycDJS4CLwETHgIfAh4BFzMBMjY1NCYjIgYVFBYDFi01MigvYHFqUV0CAXYRboIwMVSXwGkUEw8PHgFK/iE2S0s2NUtLGxYjMhEQAQGQcRcaDQIBAaEeU1EcHC8wllYCYEs1NUtLNTVLAAAAAQA0/qwCWAMpAA8AAAE2Ezc0Ji8BBRYVFA4BDwEBeNMMASEWFv6iMS9EGxz+rNMBZz9261JRQreUerx8Hh4AAAEANf6KAqUDBwAVAAAJATc+ATc2NTQmJyUXFhczAyMiLwEGAXj+vRsbRRgWAi8BXhsaEVQGRQ0LAjD+igECHh58Ylh0D5WvQmVlnf5gBgHpAAAAAAIANP7KAlgEdAAPABsAAAE2Ezc0Ji8BBRYVFA4BDwETMjY1NCYjIgYVFBYBeNMMASEWFv6iMS9EGxzlNktLNjVLS/7K0wFnP3brUlFCt5R6vHweHgOoSzU1S0s1NUsAAAIANf6KAqUENAAVACEAAAkBNz4BNzY1NCYnJRcWFzMDIyIvAQYBMjY1NCYjIgYVFBYBeP69GxtFGBYCLwFeGxoRVAZFDQsCMP7rNktLNjVLS/6KAQIeHnxiWHQPla9CZWWd/mAGAekEFks1NUtLNTVLAAAABAAr/rYCWAVQAA8AJwA/AFcAAEE2Ezc0Ji8BBRYVFA4BDwETMjc2NzY1NCcmJyYjIgcGBwYVFBcWFxYlMjc2NzY1NCcmJyYjIgcGBwYVFBcWFxYnMjc2NzY1NCcmJyYjIgcGBwYVFBcWFxYBeNMMASEWFv6iMS9EGxx2EBE0GhMEDyweIhARNRoSBA4sHgEKEBE1GhIEDiweIxARNBsSBA8sHpYQETUaEgQOLB4jEBE0GxIEDywe/rbTAWc/dutSUUK3lHq8fB4eA4oEDyweIxAQNRoSBA8sHiIQETQbEjsEDyweIhARNBsSBA8sHiIQETUaEtIEDyweIhARNBsSBA8sHiIQETUaEgAAAAQAK/6KAqUFCgAVAC0ARQBdAABBATc+ATc2NTQmJyUXFhczAyMiLwEGATI3Njc2NTQnJicmIyIHBgcGFRQXFhcWJTI3Njc2NTQnJicmIyIHBgcGFRQXFhcWJzI3Njc2NTQnJicmIyIHBgcGFRQXFhcWAXj+vRsbRRgWAi8BXhsaEVQGRQ0LAjD+mhARNBoTBA8sHiIQETUaEgQOLB4BChARNRoSBA4sHiMQETQbEgQPLB6WEBE1GhIEDiweIxARNBsSBA8sHv6KAQIeHnxiWHQPla9CZWWd/mAGAekD3gQPLB4jEBA1GhIEDyweIhARNBsSOwQPLB4iEBE0GxIEDyweIhARNRoS0gQPLB4iEBE0GxIEDyweIhARNRoSAAAAAAH/Rv7JBtkDeQBOAAABISIuATU2PwEFBgcGBxUUFjsBMjY1NCcCJyUXFhczPgE9ASYvATc2OwEyFxYXFhUXHgEXMzI2PQEuASclFxYSFxUUBisBNSYnDgErAQ4BAd7+rVmTWQkRGQFnDg4MBhoW8BUaGB8PAWkNDBAZGhoHCgqYmhYFBwUIChICARAMGhUaCS4PAWkTEiYHpXLNVTAuVlA+JNH+yXK/dH2n4FA0oXwzBRMdHRMIyQEAPURgYYoBJRgDW0JCFhULEztyMzEMDwEdEwVG4ThFZmb+6H4Dc6EBBkApHoivAAAB/3H+0QcuAxMAWgAAASEiLgE1Nj8BBQYPARQWOwEyNj0BJwInJRcWFzM+AT0BJi8BNzY7ATIeBBUXHgEzFz4BNTQvAT8CMhcWFxYXFBceATsBEwciJicOASsBIiYnDgErAQ4BAgj+rViUWAkRGAFnCxERGhXwFhoZIA0BaA0NEBAZGgcKCpmZFgUCBgcJCw4BARAMExkaDBIu20MGBggLEwMBARAMKQI+L08ZL1ZQWy9PGi5WUDYm0P7Rcr51fafgUCqrtBMdHRMFzAEINURjY40BJRcEW0JCFhUDECVDZicnDBABAiUXFWePBx4GCxE/fGERDwsQ/mABJCMoHiMkKB+FqgAAAAAD/zgAAASWA3kAEgAyAFEAAGEjETMyNj0BLgEnJRcWEhcVFAYhIyImJw4BKwETNz4BPQEmLwE3NjMyFhcWFxYVHgE7AQEiJw4BKwERMz4BNTQvATckMzIWFxYXFhceAhczEwOAzT8WGgotDwFoExInBqT+9iMvTxkuV09SBBgZGgcKCpmaFgULCQkNBwEQDA7+D2QzLlZQUhwaGgwTLgECGgQHBAcLEwMBARELKQMBoRwTBUfgOURlZv7ofgN0oSQkKR4BnwEBJBYGWkNCFhUEISZlOUYMEP5fRygfAaABJRgTaY8HJAMIEz5qcxAbDwH+YQAAA/8VAAAEsAMUACEAQABfAABlIyImJw4BKwETMz4BPQEmLwE3NjsBMh4EFRceATMXASImJw4BKwERMz4BNTQvAT8CMhcWFxYXFB4BMxcTBSMiJicOASsBETM+ATU0LwE3NjsBMhYXFh8BHgE7AQLFIi9PGi5WUFIFGBkaBwoKmZkWBQIGBwkLDgEBEAwN/hAvTxkvVk9THRkaCxMu20MGBggLEwMCEAwpAgOfPi9PGi5WUFIdGRoMEi7/HAMGDAwUAgIBEAwoASMkKB8BoAElFwRbQkIWFQMQJUNmJycMEAH+YCMkKB8BoAElFx9ejwceBgsQQXljERsPAf5hASQjKB4BnwIlFxVnjwckF0R2aCALEAAABf9G/skG2QUyAE4AWgBmAHIAfgAAQSEiLgE1Nj8BBQYHBgcVFBY7ATI2NTQnAiclFxYXMz4BPQEmLwE3NjsBMhcWFxYVFx4BFzMyNj0BLgEnJRcWEhcVFAYrATUmJw4BKwEOAQE+ATcuASMOAQceAQc+ATcuAScOAQceATc+ATcuASMOARUeATM+ATcuASMOARUeAQHe/q1Zk1kJERkBZw4ODAYaFvAVGhgfDwFpDQwQGRoaBwoKmJoWBQcFCAoSAgEQDBoVGgkuDwFpExImB6VyzVUwLlZQPiTRAdI3RwECSjc2RwECSrk3RwECSjc2RwECSrE3RwECSjc2SAJKNjdHAQJKNzZIAkr+yXK/dH2n4FA0oXwzBRMdHRMIyQEAPURgYYoBJRgDW0JCFhULEztyMzEMDwEdEwVG4ThFZmb+6H4Dc6EBBkApHoivBHwCSTc3RwJJNzdHBAJKNjdHAQNJNzZI8QJJNzdHAkk3N0cCSTc3RwJJNzdHAAAF/3H+0QcuBTwAWgBmAHIAfgCKAABBISIuATU2PwEFBg8BFBY7ATI2PQEnAiclFxYXMz4BPQEmLwE3NjsBMh4EFRceATMXPgE1NC8BPwIyFxYXFhcUFx4BOwETByImJw4BKwEiJicOASsBDgEBPgE3LgEjDgEHHgEHPgE3LgEnDgEHHgE3PgE3LgEjDgEVHgEzPgE3LgEjDgEVHgECCP6tWJRYCREYAWcLEREaFfAWGhkgDQFoDQ0QEBkaBwoKmZkWBQIGBwkLDgEBEAwTGRoMEi7bQwYGCAsTAwEBEAwpAj4vTxkvVlBbL08aLlZQNibQAaA3RwECSjc2RwECSrk3RwECSjc2RwECSrE3RwECSjc2SAJKNjdHAQJKNzZIAkr+0XK+dX2n4FAqq7QTHR0TBcwBCDVEY2ONASUXBFtCQhYVAxAlQ2YnJwwQAQIlFxVnjwceBgsRP3xhEQ8LEP5gASQjKB4jJCgfhaoEfgJJNzdHAkk3N0cEAko2N0cBA0k3NkjxAkk3N0cCSTc3RwJJNzdHAkk3N0cAAAAACf84AAAElgVGABIAMgBRAF0AaQB1AIEAjQCZAABhIxEzMjY9AS4BJyUXFhIXFRQGISMiJicOASsBEzc+AT0BJi8BNzYzMhYXFhcWFR4BOwEBIicOASsBETM+ATU0LwE3JDMyFhcWFxYXHgIXMxsBPgE3LgEjDgEHHgEHPgE3LgEnDgEHHgE3PgE3LgEjDgEVHgEXPgE3LgEjDgEHHgEHPgE3LgEnDgEHHgE3PgE3LgEjDgEVHgEDgM0/FhoKLQ8BaBMSJwak/vYjL08ZLldPUgQYGRoHCgqZmhYFCwkJDQcBEAwO/g9kMy5WUFIcGhoMEy4BAhoEBwQHCxMDAQERCykD4DdHAQJKNzZHAQJKuTdHAQJKNzZHAQJKsTdHAQJKNzZIAkqqN0cBAko3NkcBAkq5N0cBAko3NkcBAkqxN0cBAko3NkgCSgGhHBMFR+A5RGVm/uh+A3ShJCQpHgGfAQEkFgZaQ0IWFQQhJmU5RgwQ/l9HKB8BoAElGBNpjwckAwgTPmpzEBsPAf5hA1gCSTc3RwJJNzdHBAJKNjdHAQNJNzZI8QJJNzdHAkk3N0ftAkk3N0cCSTc3RwQCSjY3RwEDSTc2SPECSTc3RwJJNzdHAAAACf8VAAAEsAU8ACEAQABfAGsAdwCDAI8AmwCnAABlIyImJw4BKwETMz4BPQEmLwE3NjsBMh4EFRceATMXASImJw4BKwERMz4BNTQvAT8CMhcWFxYXFB4BMxcTBSMiJicOASsBETM+ATU0LwE3NjsBMhYXFh8BHgE7AQE+ATcuASMOAQceAQc+ATcuAScOAQceATc+ATcuASMOARUeARc+ATcuASMOAQceAQc+ATcuAScOAQceATc+ATcuASMOARUeAQLFIi9PGi5WUFIFGBkaBwoKmZkWBQIGBwkLDgEBEAwN/hAvTxkvVk9THRkaCxMu20MGBggLEwMCEAwpAgOfPi9PGi5WUFIdGRoMEi7/HAMGDAwUAgIBEAwo/Wc3RwECSjc2RwECSrk3RwECSjc2RwECSrE3RwECSjc2SAJKqjdHAQJKNzZHAQJKuTdHAQJKNzZHAQJKsTdHAQJKNzZIAkoBIyQoHwGgASUXBFtCQhYVAxAlQ2YnJwwQAf5gIyQoHwGgASUXH16PBx4GCxBBeWMRGw8B/mEBJCMoHgGfAiUXFWePByQXRHZoIAsQAa8CSTc3RwJJNzdHBAJKNjdHAQNJNzZI8QJJNzdHAkk3N0ftAkk3N0cCSTc3RwQCSjY3RwEDSTc2SPECSTc3RwJJNzdHAAACADX/DwcUA5AAMgBAAAAFISIuATU2Nz4BPwEFBg8BFBY7ATI2NTQmJyYnJRc+ATcWFxYfARQHFQcGBwYjISInDgEBJyMmJyYjIg4BByEyFwKv/stZk1kEAwkVBwcBZw4OERkW0hUaDgkdEgFpDlzlhb1POgMCHw0mSCw//n45NS/EAxlBAQsYFSsIP4U7ARsuKPFyv3QqK23DQD9QNKG1Eh0dEwh0Tf1IRI1TkgcCqn6Sa3hhARdBIRYSdI8CSGcTJBwHOyYgAAL/6P8PBycDkAA1AEEAAAUhIi4BNTY/AQUGDwEUFjsBMjY9AScmJwInJRceARc+ATceAx8BFTMRIyInDgEjISInDgEBLwEmIyIOAQchMhcCYf7LWJRYCREYAWcLEREaFdIWGggGCh4QAWgCAgYFXOWFaIJEGQEBYhxgQBtUO/5/OTYuxQMZQSQVKwg/hToBGjEl8XK/dH2n4FAqq7QTHR0TBT06TQEFQEQVFUEiU5IHAWKTkzMzAf5gPhklEnSPAkhnNxwHOyYgAAAAAAIAAP/+BIIDkwAdACoAAAUiJicGKwERMwMlFz4BNzIeAh8CFRQHDgEHBgcTLwEmIyIOAQchMhcVAfw+dyZGaHNJNwE1H1vnh2mCRh0CAQIcARgaQm4vQiQVKwg/hToBGjIkAiwkTgGgAWFDqmqJBmCRkzMzKw98XAMrHEYDAVVnNxwGPCYfAQAC/+gAAASwA5QAHgAtAAAhIyYnBgcFIicmJwYHIxEzAyUXPgE3MzIeAh8CMwUnNSYnJiMiDgEHITIXMwSwG1U9NGT+eT46PSZDa3NJNwE1H1vnhwRmgUccAgEBR/7qQgsZFCwHQIU6ARswJQECNy4GBRQXJUsFAaABY0KpaogGX5KTMjMLRWYBEiUcBzsmIAADADX/DwcUBJ0AMgBAAEwAAAUhIi4BNTY3PgE/AQUGDwEUFjsBMjY1NCYnJiclFz4BNxYXFh8BFAcVBwYHBiMhIicOAQEnIyYnJiMiDgEHITIXATI2NTQmIyIGFRQWAq/+y1mTWQQDCRUHBwFnDg4RGRbSFRoOCR0SAWkOXOWFvU86AwIfDSZILD/+fjk1L8QDGUEBCxgVKwg/hTsBGy4o/ko2S0s2NUtL8XK/dCorbcNAP1A0obUSHR0TCHRN/UhEjVOSBwKqfpJreGEBF0EhFhJ0jwJIZxMkHAc7JiACFEs1NUtLNTVLAAAAAAP/6P8PBycEnQA1AEEATQAABSEiLgE1Nj8BBQYPARQWOwEyNj0BJyYnAiclFx4BFz4BNx4DHwEVMxEjIicOASMhIicOAQEvASYjIg4BByEyFwEyNjU0JiMiBhUUFgJh/stYlFgJERgBZwsRERoV0hYaCAYKHhABaAICBgVc5YVogkQZAQFiHGBAG1Q7/n85Ni7FAxlBJBUrCD+FOgEaMSX+hDZLSzY1S0vxcr90fafgUCqrtBMdHRMFPTpNAQVARBUVQSJTkgcBYpOTMzMB/mA+GSUSdI8CSGc3HAc7JiACFEs1NUtLNTVLAAAAAwAA//4EggSYAB0AKgA2AAAFIiYnBisBETMDJRc+ATcyHgIfAhUUBw4BBwYHEy8BJiMiDgEHITIXFQEyNjU0JiMiBhUUFgH8PncmRmhzSTcBNR9b54dpgkYdAgECHAEYGkJuL0IkFSsIP4U6ARoyJP5hNktLNjVLSwIsJE4BoAFhQ6pqiQZgkZMzMysPfFwDKxxGAwFVZzccBjwmHwECDUs1NUtLNTVLAAAAAAP/6AAABLAErAAeAC0AOQAAISMmJwYHBSInJicGByMRMwMlFz4BNzMyHgIfAjMFJzUmJyYjIg4BByEyFzMBMjY1NCYjIgYVFBYEsBtVPTRk/nk+Oj0mQ2tzSTcBNR9b54cEZoFHHAIBAUf+6kILGRQsB0CFOgEbMCUB/mQ2S0s2NUtLAjcuBgUUFyVLBQGgAWNCqWqIBl+SkzIzC0VmARIlHAc7JiACH0s1NUtLNTVLAAAAAAP/OP/9A3EEkgAkADAANAAAQTEwFgYHOAExDgMHIwUGJyYnBisBAzMDJRE2NzY3Nh4DBy8BJiMiDgEHITIXASE1IQNuAwoTARg1Vz4B/oVEQDwnRWgVFC0WAUtBU26BaINGHATPQSQVKwg/hToBGjEl/on+dgGKAapXfT4DLDgrAgUCFxYlTwGhArg5/kxELj4FAWCSk2VQZzccBzsmIP50lgAAAv9S//8D6ASSABsAKAAABSchAzMDJRE2NzY3MzIeAh8BFTMRIyInNQYHEyc1JyYjIg4BByEyFwEAHP5+EC0WAUtBU26BBGWCRhwCAmAbYEE9ZC5BJBUrCD+FOgEaMSUBAQGgArk5/kxELj4FX5KTMjMK/mA/ATgEAVZmATccBzsmIAAAAv84//8DcASSAB8AKwAAFyImJwYrAREzAyURNjc2NzMyHgIfAxQGBwYHBgcTLwEmIyIOAQchMhfqPncnRWgpLRYBS0FTboEEZYJGHAICAQEJEwsoQm4uQSQVKwg/hToBGjElASslTwGhArg5/kxELj4FX5KTMjMrGyNrPiArRQQBVmc3HAc7JiAAAAAC/1P//wPpBJIAIAAtAAAFIicmJwYrAREzAyURNjc2NzMyHgIfARUzESMiJzUGBxMnNScmIyIOAQchMhcBBT47PCdFaCktFgFLQVNugQRlgkYcAgJgG2BBPWQuQSQVKwg/hToBGjElARQXJU8BoAK5Of5MRC4+BV+SkzIzCv5gPwE4BAFWZgE3HAc7JiAAAAAE/zj//QNxBN4AJAAwADQAQAAAQTEwFgYHOAExDgMHIwUGJyYnBisBAzMDJRE2NzY3Nh4DBy8BJiMiDgEHITIXASE1IRMyNjU0JiMiBhUUFgNuAwoTARg1Vz4B/oVEQDwnRWgVFC0WAUtBU26BaINGHATPQSQVKwg/hToBGjEl/on+dgGKmjZLSzY1S0sBqld9PgMsOCsCBQIXFiVPAaECuDn+TEQuPgUBYJKTZVBnNxwHOyYg/nSWA0hLNTVLSzU1SwAAA/9S//8D6AToABsAKAA0AAAFJyEDMwMlETY3NjczMh4CHwEVMxEjIic1BgcTJzUnJiMiDgEHITIXAzI2NTQmIyIGFRQWAQAc/n4QLRYBS0FTboEEZYJGHAICYBtgQT1kLkEkFSsIP4U6ARoxJc82S0s2NUtLAQEBoAK5Of5MRC4+BV+SkzIzCv5gPwE4BAFWZgE3HAc7JiACXEs1NUtLNTVLAAAD/zj//wNwBNQAHwArADcAABciJicGKwERMwMlETY3NjczMh4CHwMUBgcGBwYHEy8BJiMiDgEHITIXAzI2NTQmIyIGFRQW6j53J0VoKS0WAUtBU26BBGWCRhwCAgEBCRMLKEJuLkEkFSsIP4U6ARoxJdM2S0s2NUtLASslTwGhArg5/kxELj4FX5KTMjMrGyNrPiArRQQBVmc3HAc7JiACSEs1NUtLNTVLAAAAA/9T//8D6QTVACAALQA5AAAFIicmJwYrAREzAyURNjc2NzMyHgIfARUzESMiJzUGBxMnNScmIyIOAQchMhcDMjY1NCYjIgYVFBYBBT47PCdFaCktFgFLQVNugQRlgkYcAgJgG2BBPWQuQSQVKwg/hToBGjEl2jZLSzY1S0sBFBclTwGgArk5/kxELj4FX5KTMjMK/mA/ATgEAVZmATccBzsmIAJJSzU1S0s1NUsAAAABAKj91QOEA+AAKgAAQScmJyY1ND8BNjc1Njc2PwI+ATc2NxYXBwYHBgcFBgMjMxUhIgYVFBcFAkf/eR0KKgMPEwEMDhERFhV0a1mFKSsrgVtHFQF3AQEBAf6FBQUDAT/91dprkzAuYV0GHh2SSEJUNzYeHlYqJBnQ0AEGEg4achz+kAEIAgcD/wAAAAH/5v3WAxQDjgAhAAABJyYnJjU0Njc2NycmJyY1ND4BMwUVFA8BMxEhIgYVFBcFAYX/TigqVFQFBVIpDQQzeE0B5ghsnv40BQcFATv91tpDWFxiZLhFBgJqPlIXFTRwUgT5ExHM/l8HBgUD/QAAAAABADkAAALnA+QAFQAAKQERMzY3NjE3Njc2JRMHDgIHBQMjAuX9VCICLA8TFDSDAQlVMTGCbhEBdgICAaCSiTAbHCllNP5fAQINGhdx/nAAAAH/QgAAAnEDmAAdAAAhESM3Nj0BJSIGBwYVFBcWFyMRIDY3NjcXHgMzAnGfbAn+GUx5HRUEGmKnAQweFjUVAwMOGioeAaDXERP5BFJCLTQWF5k9/mADBxEwBwgWFw8AAAIAqP3VA4QE1AAqADYAAEEnJicmNTQ/ATY3NTY3Nj8CPgE3NjcWFwcGBwYHBQYDIzMVISIGFRQXBQEyNjU0JiMiBhUUFgJH/3kdCioDDxMBDA4RERYVdGtZhSkrK4FbRxUBdwEBAQH+hQUFAwE//m02S0s2NUtL/dXaa5MwLmFdBh4dkkhCVDc2Hh5WKiQZ0NABBhIOGnIc/pABCAIHA/8E50s1NUtLNTVLAAAC/+b91gMUBOgAIQAtAAABJyYnJjU0Njc2NycmJyY1ND4BMwUVFA8BMxEhIgYVFBcFAzI2NTQmIyIGFRQWAYX/TigqVFQFBVIpDQQzeE0B5ghsnv40BQcFATvQNktLNjVLS/3W2kNYXGJkuEUGAmo+UhcVNHBSBPkTEcz+XwcGBQP9BPpLNTVLSzU1SwAAAAACADkAAALnBOsAFQAhAAApAREzNjc2MTc2NzYlEwcOAgcFAyMBMjY1NCYjIgYVFBYC5f1UIgIsDxMUNIMBCVUxMYJuEQF2AgL+QjZLSzY1S0sBoJKJMBscKWU0/l8BAg0aF3H+cAPqSzU1S0s1NUsAAv9CAAACcQTrAAsAKQAAEzI2NTQmIyIGFRQWAREjNzY9ASUiBgcGFRQXFhcjESA2NzY3Fx4DM9U2S0s2NUtLAdGfbAn+GUx5HRUEGmKnAQweFjUVAwMOGioeA+tLNTVLSzU1S/wVAaDXERP5BFJCLTQWF5k9/mADBxEwBwgWFw8AAAAAAwAKAAAFagTNACYAPABIAAApASImNT4BPwEFBgcVFBY7ATUmNTQ+AjczMh4CHwMUBgcGBwMyNzY3NjU0LwEmIyIGDwEGFRQeARcDMjY1NCYjIgYVFBYDnP2FcqUGHA0NAWgdEhoV5AYISqaSBGaCRhwCAQIBCRIretY3LAoIDQ48DA4DEwstCQMWDyM2S0s2NUtLonZ73khIRWaBBRMdAiAuGW6qeAZilZY0NCoaImo+kAcBdAsCBwwUEA01CgIOOwwMBBMUAgJUSzU1S0s1NUsAAAADAAL//wXcBMQAKQA+AEoAAAUnISImPQE+AT8BBQYHFRQWOwE1JjU0PgI3MzIeAh8CMxEjIicGBwMyNzY3NC8BJiMiBg8BBhUUFhceAQMyNjU0JiMiBhUUFgOyHf2Ec6QGHA0MAWkdEhoV5gYISaeSBGWCRhwCAgF6G2NCKVDPMykfAQ48DQ8CEwstCAINCRsyNktLNjVLSwEBoXMDfN5IR0RmgQUTHgMfKxpwqngGYZSVNDQL/l9DOQUBcwsIHxIONQoCDzsMDgITCwkCAkxLNTVLSzU1SwAD/4YAAAKbBNcAGQAvADsAADMhEzM1JjU0PgI3MzIeAh8DFA4CBwMyNzY3NjU0LwEmIyIGDwEGFRQeAgMyNjU0JiMiBhUUFub+oAI7BghJp5IEZoFHHAIBAgEJJU9D0DMpCwcODjwMDgMTDCwJAxYaFzZLSzY1S0sBoAIgLhluqXgGYZaWNDQqGiJqfFUEAXQLAgcMFBEMNQoBDzsNDQMSFAICX0s1NUtLNTVLAAAAAAP+o//+AkQE1wAcADIAPgAAFyInIRMzNSY1ND4CNzMyHgIfAjMRIyInBgcDMjc2NzY1NC8BJiMiBg8BBhUUHgIDMjY1NCYjIgYVFBYpFhX+pQNOBghJp5IEZoJGHAIBAXobY0EqT88zKQoIDQ48DA4DEwwsCQMWGxc1S0s1NktLAgIBoAIgLhluqXgGYZSWMzQM/mBDOgUBdAsCBwwUEQw1CgEPOwwMBBMUAgJfSzU1S0s1NUsAAAAEAB3+zwRMBRQANABLAF4AcQAAQSEiLgE1Nj8BBQYPAQYPAhQWMyEyNwciJyMmJyYnJi8BNTQ+AjcyHgEXFh0BFB8BFA4BAzY3Njc2NzQvASYjIgYPAQYVFBYXHgEDNjc2PQEuASsBBgcGHQEWFxYzNzY3Nj0BJicmKwEGBwYdAR4BMwK+/qNYlFgPFQ4BAAIBBgYCAxQZFgGYCAdYPTsBKSEmFjcGAhJNqJF8iTsGBAIBa7R1MScLBw0BDjwNDwITCy0IAg0JHl02IR4GTDAJNiEeBickMfc2IR4GJyMvDDYhHgZMMP7Pcb910ndUMQcKGhkRF9UTHgMBFRAcIS91PxUULpWqeAaGuk5AGl5/fxRzvnEC3wIJAwYNEhEONQoCDjwMDgITCwkCAlIGJyQxCTY/BigkMAk2IR4UBigkMAk3IR0GJyQxCTY/AAX/u/7PBHMFFAATACcAKQBnAH0AAEE2NzY9ASYnJisBBgcGHQEWFxYzNzY3Nj0BJicmKwEGBwYdARYXFjMBIxMhIi4BNTY/AQUOAQ8BBg8CBgcVFBYzITI3IyInIyYnJicuAS8BNTQ+AjcyFhcWFQcWFTMRIyImJw4CAzY3Njc2NTQvASYjIgYPAQYVFB4CAew3IR0GJyQxCTYhHgYoIy76NyEdBickMQk2IR4HJyQw/rAB3P6kWZRYDxUPAQACAwMHAwIDBwYFGhUBmQcHVz47ASkgJxYgGgICEU2oknuJHigBAYsVKDgZD26najEnCggNDjwNDwISDCwJAxYdBAAGJyMvDDYhHgcnJDAJNyEdFAYnJC4MNiEeBickMQk2IR78nf4ecb9003dUMQcUDRwOGiI+SCgFEx4CFQ8dIS5FWRYVFS6VqncHhl1+ghULJv5gGhdln14C3wEKAgcMFBEMNgoCDzsMDAQTFAIAAAAABv+GAAACmwTeABkALwBCAFUAbwCFAABzIRMzNSY1ND4CNzMyHgIfAxQOAgcDMjc2NzY1NC8BJiMiBg8BBhUUHgIDNjc2PQEuASsBBgcGHQEWFxYzNzY3Nj0BJicmKwEGBwYdAR4BMwMhEzM1JjU0PgI3MzIeAh8DFA4CBwMyNzY3NjU0LwEmIyIGDwEGFRQeAub+oAI7BghJp5IEZoFHHAIBAgEJJU9D0DMpCwcODjwMDgMTDCwJAxYaeTYhHgZMMAk2IR4GJyQx9zYhHgYnIy8MNiEeBkwwhf6gAjsGCEmnkgRmgUccAgECAQklT0PQMykLBw4OPAwOAxMMLAkDFhoBoAIgLhluqXgGYZaWNDQqGiJqfFUEAXQLAgcMFBEMNQoBDzsNDQMSFAICUgYnJDEJNj8GKCQwCTYhHhQGKCQwCTchHQYnJDEJNj/8IgGgAiAuGW6peAZhlpY0NCoaImp8VQQBdAsCBwwUEQw1CgEPOw0NAxIUAgAAAAAE/q3//gJEBNoAHAAyAEUAWAAAVyInIRMzNSY1ND4CNzMyHgIfAjMRIyInBgcDMjc2NzY1NC8BJiMiBg8BBhUUHgIDNjc2PQEuASsBBgcGHQEWFxYzNzY3Nj0BJicmKwEGBwYdAR4BMykWFf6vA0QGCEmnkgRmgkYcAgEBehtjQSpPzzMpCggNDjwMDgMTDCwJAxYbaDYhHgZMMAk2IR4GJyQx9zYhHgYnIy8MNiEeBkwwAgIBoAIgLhluqXgGYZSWMzQM/mBDOgUBdAsCBwwUEQw1CgEPOwwMBBMUAgJOBickMQk2PwYoJDAJNiEeFAYoJDAJNyEdBickMQk2PwAAAQDgAAAFvAS3ACkAACkBIiY9AT4BPwEFBgcVFBY7AQMmNTQ3PgE/ARMHDgEHFxYXHgIVFxQGBP78+XOkBhwNDAFpHRIaFfuMFCZf31NT0zQ0iTaJCAcaOCgBaqFzA3zeSEdEZoEFEx4BFygmNDBoliko/h8RETggZQUGFDM9IZY/cgAAAQDYAAAF5gS3AC4AAGEjIiYnDgEjISImPQE+AT8BBQYHFRQWMyEDJjU0Nz4BPwETBw4BBycWFxYXFhczBeYVMT8fFlYo/UBypAUcDQ0BaB0SGhYBCowUJ1/fU1LUNDWJNggFCxA0Jxu8JSEgJqFzA3zeSEdEZoEFEx4BFyglNTBoliko/h8RETghBgEJEEw9HgAAAAH/mwAAAnkEuAAdAAApARMzAyY1NDc+AT8BEwcOAQcfARUWFx4CFRcUBgHe/dgBhIwUJ1/eU1PUNDWINogQCw4aNSUBWgGgARYoJTUwaZYpKP4eERE3IWQLAQkKEy40HK5AWgABAAAAAAMQBLgAHwAAISMiJicOASMhETMDJjU0Nz4BPwETBw4BBxceAxczAxAVMT8eF1Up/iiwixQmX99TU9M0NYg2BwomKSILvCYgICYBoAEXJyY0MGmWKSj+HhERNyEGCTQ9MQsAAAIA4AAABbwFKQApADIAAGEhIiY9AT4BPwEFBgcVFBY7AQMmNTQ3PgE/ARMHDgEHFxYXHgIVFxQGATc+AjcnDgEE/vz5c6QGHA0MAWkdEhoV+4wUJl/fU1PTNDSJNokIBxo4KAFq/WsnJnR7MIdDb6FzA3zeSEdEZoEFEx4BFygmNDBoliko/h8RETggZQUGFDM9IZY/cgM/KShzbB6cTP4AAAAAAgDYAAAF5gUpAAgANwAAQTc+AjcnDgEBIyImJw4BIyEiJj0BPgE/AQUGBxUUFjMhAyY1NDc+AT8BEwcOAQcnFhcWFxYXMwKpJyZ0ezCHQ28DChUxPx8WVij9QHKkBRwNDQFoHRIaFgEKjBQnX99TUtQ0NYk2CAULEDQnG7wDPykoc2wenEz+/CElISAmoXMDfN5IR0RmgQUTHgEXKCU1MGiWKSj+HxEROCEGAQkQTD0eAAAAAv9zAAACeQVQAB0AJgAAKQETMwMmNTQ3PgE/ARMHDgEHHwEVFhceAhUXFAYBNz4CNycOAQHe/dgBhIwUJ1/eU1PUNDWINogQCw4aNSUBWv1VJyZ0ezCHQ28BoAEWKCU1MGmWKSj+HhERNyFkCwEJChMuNByuQFoDZikoc2wenEz+AAAAAv/PAAADEAUxAAgAKAAAAzc+AjcnDgEBIyImJw4BIyERMwMmNTQ3PgE/ARMHDgEHFx4DFzMxJyZ0ezCHQ28DDhUxPx4XVSn+KLCLFCZf31NT0zQ1iDYHCiYpIgu8A0cpKHNsHpxM/vwZJiAgJgGgARcnJjQwaZYpKP4eERE3IQYJND0xCwAAAAH/CP6/AwAEawAdAAABMjc2NxMDBRMRBisBIiY1NzY3JQcOAQcGBxQeATMBd4tqjAQEDP6HDA0PxxYZEREL/pkHBxQKAwRZk1n+v1h5ugFhAsAr/a7+eQkeE7SuJlE/QMRsKyp1v3EAAf/6/rcEPwRkAB8AAAEhIi4BNTY/AQUGBwYPARQWOwEyNxEDJRMzESInIw4BAmj+1lmTWAkRGAFnBAQKEAsZFscQDAwBeQxOSQUEINX+t3K/dH2n4FAPGUikdRMdCQGHAlIr/T3+XwGQugAAAQAKAAAB+wRsAAsAADMjETMyNjUDJRMOAauhMxwnDAF5Dgm9AaAoHgJbK/zWi7QAAf+3AAAB9ARjAA8AACEjIicGByMRMzI2NQMlEzMB9ENZQVNsoTMcJwwBeQ1NPDoCAaEoHQJSK/09AAAAAv9K/rsDIAOeABkALwAAEyUTPgEzFzU0NzYlFhcWFxUUBwYHJyInJicTMjc2NzY1NC8BJiMiBg8BBhUUHgEXvv6MFAErH45AYQEFvkw3AiAweuNDPyUc7yskCwcPDTsMDgMTDC4JAhUP/rsLAqEfKQQKnoPEBASvgpVqdmGPBAEYDxQBPggCBg0TEQ03CgEOOgwOAhMUAgAC/2b+rwN0A5kAIQA4AAATIRE0NjsBNTQ+AjczMh4CHwEVMxEjIi8BBg8BIicmJxMyNzY3Njc0LwEmIyIGDwEGFRQWFx4B2f6NKx6OEU2okgRlgkYcAgJOFDwpESlZ7j07JRzYMykLBw0BDjwMDgMUCy0IAg0JG/6vAqIeKxQvlal4BmGVljQ0Bf5gMxhFBwYVDhMBRAsCBwwSEg01CgEPOwwOAhMLCQIAAAAAAv+c//8C4wOfABkALwAABSInJicGKwERMzU0PgI3MhcWHwEUDgIHAzI3Njc2NzQvASYjIgYPAQYVFB4CATU9OzwnRmcRXBFNqJK9UTsGBAklTkTPMykLBw0BDjwNEAETCy0IAhYbARQXJE4BoBYtlKp3B6x+mHgianxVAwFzCwMGDRIRDjUKAg48DA4CExQCAAAAAAL/+P//A8wDnwAcADAAAAUiJicGKwERMzU0PgI3Mh4CHwIzESMiJwYHAzI3NjU0LwEmIyIGDwEGFRQeAgGPPnYmRWcRWRJNp5Jpg0YcAgEBkRFvRypezzMpHw48DQ8CEgwsCQMWGwErI00BoBQulap3B2KVlzQ0Cf5gWU0HAXMLCSARDTUKAg48DAwEExQCAAL/3f7gBAIDjgAgACwAAAEyPgE1NCcmLwEFFhMXFRQGKwEiJjU3NjclBwYHFB4BMxMyNjU0JiMiBhUUFgJ0b7RrBBggDP6YES0IGhbwFRoREQv+mRgRCViUWFI2S0s2NUtL/uBxvnMTKPX1W0RG/nk8BRMdHRO0qypQ4Kd9db5yA65LNTVLSzU1SwAAAv9y/t8DzwOCACUAMQAAASEiLgE1Nj8BBQYHBgcGBxUUFjsBMjY9ASYnAiclFxYXMxEjDgEBIiY1NDYzMhYVFAYCCf6uWZRYCREZAWYMDwQCBwUaFfEVGgMELBMBaQ0NEVRLKcz+qjVMTDU1S0v+33K/dH2n4FAupyAfSCgFEx0dEwUVJwF/TkRnaJH+X4ChA6JLNTVMTDU1SwAAAv+sAAABkASWABIAJgAAMyMRMzI2PQEuASclFxYSFxUUBgMyNjc2NTQmJyYjIgYHBhUUFhcWec1AFhkJLRABaRMSJwakpyhMCwI0NQwMKEsLAjQ2CwGgHRMFRuE5RGZm/uh9A3ShA5U0NgwLKEsLAjQ1DAsoSwwCAAAAAAL/ywAAAcYEQgAdADEAACEjIiYnDgErARMzPgE1NC8BJTcyFhcWFxYVHgEXMwEyNjc2NTQmJyYjIgYHBhUUFhcWAcY+L08ZLldPUgQYGRoLEwEJQAQLCQYRCgEQDCn+vChMCwI0NQwMKEsLAjQ2CyMkKB8BoAEkFh1ijyUGBCMdcFtJDA8BAaE0NgwLKEsLAjQ1DAsoSwwCAAAAAAL/8/6QAuADkwAhADgAAAEDNz4BPwEjIicuAScmNT8BNTQ+AjcWFxYfAREGBwYHBgMyNzY3NjU0LwEmIyIGDwEGFRQWFx4BATJdKmJzGBjQQ0BXUwsJAQMQSKGPvVg+CwMfr0VEKwItJQsHDw07DQ8CEgwuCQIMCSD+kAE8CRIfCgoYJXs/MiYTShExjpZlAgKkdY0x/mDkVyMTDgL4CAMGDRMQDTcLAQ46DQ0DEgwJAwAAAAL/8f51AwMDeQAjADkAAAEDNz4BPwEjIicmJyY1NDc2NTQ3EiUeBBUzAyMGBwYHBhMyNzY3NjU0LwEmIyIGDwEGFRQeARcBMF4rYnIZGNBDQJgeCAECCSQBXGmFSyEGJgYgHq9IQSsQKyQKCA4NOg0PAhIMLgoCFg7+dQE8CRIgCgoYQZ4vJA0LJSU5TAFDBQJejIxgAf5g5VYjEw4C8wgCBw0SEQ03CwIOOg0PAhEUAgAAAAL/EgABAfMEKgAXAC0AADcjIiYnJjU0PgI/AScBABMWFRQHDgEHAzI3Njc2NTQvASYjIgYPAQYVFB4BFxMNUoESDw45QxkYSQEkATIWAw8Qc1KNLSULCA8OPQ0QAhMMMAkCFg8BZVhWRiB5fkwREUsBAP76/qgtKltKUGgGAXoIAwYOExEOOQsBDzwNDgIUFQIAAAAC/0P//wKoA7YAHAAwAAAXJyYnJjU0PwI+AzMWFzcTFxUzESMiJwYHBgMyPgE3NC8BJiciDwEGFRQXFhcW8e55KxwBAQICHEaDaFM++Q0Bei9nRic8O1wMGxYCCC0LERMNPA0NBwspAQYFkVtvDhsbNDSXlWIDFjD+Li4W/mBOJBcUAXkCFBATDDwOAgo1DRAUDQYDCwAAAAMAK//IBCoEMQAmADUARwAABSIvAg4BDwERMzQvATQ3Njc2MzIXPwEXMxUWHwEWFxYVFAcGBwYBNzY3FycXLgEjIgcGDwEFMjc2NTQvASYnIg8BBhUUFxYC9x0fL+gnoj1zSAIBDwoqJC4KMga+dgEqJ9g7JSURHEVa/a00HB/iAhEyeS0bDhYMKQH0Kg8TCzUMERINNAwLEzgIDlASFwQBAaEjGidXXDggGwd+j2kBJSjZSkpPWTxAZVJqAc00HAIQAgI7ThgkF1QyCQ4VDgw9DQENNQ0REAwVAAAB/m7+uwFEAw0AHwAAAyUuAS8BFhcWOwERIz4BPwElAyMRMzI3NjUVHgMXZQEkGxgHBQVKExlJuwwcCwr+rUXARFAcEQMYHx4K/ruCNFo1WEAUBAGgSYApKVL+k/5gLRoXXlNzSScIAAP+wAABAfMFaQAUACwAQgAAQyc3LgEvAjU0PgE3FwcGHQE3FwcDIyImJyY1ND4CPwEnAQATFhUUBw4BBwMyNzY3NjU0LwEmIyIGDwEGFRQeAReQfR8ZJAkKAgkmKZgPUp14AVANUoESDw45QxkYSQEkATIWAw8Qc1KNLSULCA8OPQ0QAhMMMAkCFg8DYYkcHToUFA8FDzVVN28PUh0CS4QB+8FlWFZGIHl+TBERSwEA/vr+qC0qW0pQaAYBeggDBg4TEQ45CwEPPA0OAhQVAgAD/0P//wKoBa0AHAAwAEcAABcnJicmNTQ/Aj4DMxYXNxMXFTMRIyInBgcGAzI+ATc0LwEmJyIPAQYVFBcWFxYDJzcmNTQ/Aj4CNxcHDgIHHwEjF/HueSscAQECAhxGg2hTPvkNAXovZ0YnPDtcDBsWAggtCxETDTwNDQcLKXgnKQgBAgYGJks/TBUVNy0GriUBAQEGBZFbbw4bGzQ0l5ViAxYw/i4uFv5gTiQXFAF5AhQQEww8DgIKNQ0QFA0GAwsCR7UJJzUUExMODS42G60FBhIVDA6uAQABAE7+4gRtA+oAJQAAASImJwMlExcWMzI3LwEmNTQ3PgE/ARMHDgEHFxYVFAcGBwYHBQYBrXTKCxYBIgshMjxRT0eTIBlP0VJR4TExfzGuSRYjKWye/vYY/uKekQIkDv4+BQkgaMsuMCkrdaUsLP6XGBlKKLJSXzM4Ui1sGScDAAH/3/5pA8cBwgAiAABBIicmIyYnJjU0Njc2NwUDFxYfATI3FycTIREjFhUUBwYHBgG3JCMpKL5DPwUcFAcBNUQRKzoQMzgEc2EB2EERhFduS/5pAgIRYluBCZeTcmEf/lwGFAYBKAicAQb+YDArfmNGDAkAA/+s/sYBoQN5ABIAIQAvAABzIxEzMjY9AS4BJyUXFhIXFRQGAz4BPQEuASMOAR0BHgEzNz4BNS4BKwEOAR0BHgF5zUAWGQktEAFpExInBqS1NkUESzY3RQRKNfE3RQRKNQM2RQRLAaAdEwVG4TlEZmb+6H0DdKH+xgRKNAM3RQRKNQM2RQkESzc2RQRKNAM3RQAAAAP/y/7FAckDFAAdACwAOgAAYSMiJicOASsBEzM+ATU0LwElNzIWFxYXFhUeARczAT4BPQEuASMOAR0BHgEzFz4BNS4BKwEOAR0BHgEBxj4vTxkuV09SBBgZGgsTAQlABAsJBhEKARAMKf6bNkUESzY3RQRKNfE3RQRKNQM2RQRLIyQoHwGgASQWHWKPJQYEIx1wW0kMDwH9JgRKNAM3RQRKNQM2RQEESzc2RQRKNAM3RQAAAAQAXwAABAEFggALABEAFAAiAABhIREhMjY1AwUTDgElCwEFGwEvARcBNzY3NjcyFjMyNjczAwKx/gMBjxwnDAF5Dgm9/e84RAFmJREMBQb+ICcNKRorLnk2LD8PCjEBoSgdAqwv/N+KtU0BoAIvBf2o/sDiXlcC97sxHRQDQh4P/voAAAIAGQAAA+QFggAUACIAACEjIiYnBgchETMDBRMzMjY1AwUTMwE3Njc2NzIWMzI2NzMDA+QjJ0UdVnP+BEhOAWYnCBwnDAF5DCb8NScNKRorLnk2LD8PCjEpG0EBAaACfgX9hygdAqwv/TwCwrsxHRQDQh4P/voAAAQAiQAABAEGOgALABEAFAArAABhIREhMjY1AwUTDgElCwEFGwEvARcBJzcmNTQ/Aj4CNxcHDgIHHwEjFwKx/gMBjxwnDAF5Dgm9/e84RAFmJREMBQb+cScpCAECBgYmSz9MFRU3LQauJQEBAaEoHQKsL/zfirVNAaACLwX9qP7A4l5XAuG1CSc1FBMTDg0uNhutBQYSFQwOrgEAAAIAOwAAA+QGOgAUACsAACEjIiYnBgchETMDBRMzMjY1AwUTMwEnNyY1ND8CPgI3FwcOAgcfASMXA+QjJ0UdVnP+BEhOAWYnCBwnDAF5DCb8ficpCAECBgYmSz9MFRU3LQauJQEBKRtBAQGgAn4F/YcoHQKsL/08Aqy1CSc1FBMTDg0uNhutBQYSFQwOrgEAAAQArv4WBAEEkgALABEAFAArAABhIREhMjY1AwUTDgElCwEFGwEvARcTJzcmNTQ/Aj4CNxcHDgIHHwEjFwKx/gMBjxwnDAF5Dgm9/e84RAFmJREMBQZlJykIAQIGBiZLP0wVFTctBq4lAQEBoSgdAqwv/N+KtU0BoAIvBf2o/sDiXlf8q7UJJzUUExMODS42G60FBhIVDA6uAQAAAAIAbf34A+QEkwAUACsAACEjIiYnBgchETMDBRMzMjY1AwUTMwEnNyY1ND8CPgI3FwcOAgcfASMXA+QjJ0UdVnP+BEhOAWYnCBwnDAF5DCb+jicpCAECBgYmSz9MFRU3LQauJQEBKRtBAQGgAn4F/YcoHQKsL/08/Fi1CSc1FBMTDg0uNhutBQYSFQwOrgEAAAMArgAABAEEkgALABEAFAAAYSERITI2NQMFEw4BJQsBBRsBLwEXArH+AwGPHCcMAXkOCb397zhEAWYlEQwFBgGhKB0CrC/834q1TQGgAi8F/aj+wOJeVwABAG0AAAQMBJMAFAAAISMiJicGByERMwMFEzMyNjUDBRMzBAxLJ0UdVnP+BEhOAWYnCBwnDAF5DE4pG0EBAaACfgX9hygdAqwv/TwAAQCy/zkE0QRBACUAAAUiJicDJRMXFjMyNy8BJjU0Nz4BPwETBw4BBxcWFRQHBgcGBwUGAhF0ygsWASILITI8UU9HkyAZT9FSUeExMX8xrkkWIylsnv72GMeekQIkDv5IBQkgXssuMCkrdaUsLP6XGBlKKLJSXzM4Ui1sGScDAAAB/9/+aQPHAcIAIgAAQSInJiMmJyY1NDY3NjcFAxcWHwEyNxcnEyERIxYVFAcGBwYBtyQjKSi+Qz8FHBQHATVEESs6EDM4BHNhAdhBEYRXbkv+aQICEWJbgQmXk3JhH/5cBhQGASgInAEG/mAwK35jRgwJAAT92f//BM8GegBAAEQAewCPAAABIicmJyYvAj8BMzIXFhcWFRYzMjY1PAEnNz4BPwEyFhcWFxQWMzcyNjUvATcyHgEVFxQGBwYHBg8CIicOAQcDJxcHAScmJyY1ND8CPgM7ARYXNxMXFTMyNjUDJRMzMjY1AyUTDgEHIyInBgcjBisCIicmJw4BAzI+ATc0LwEmJyIPAQYVFBcWFxYBfAYFFRAvCwYJKTACAwMGAwcCBwsYDAkJGgsPAwQFBwIBCQ8LBgYJXwUGDQEDBw0bDBULJBcPDRkWDA9aCv207noqHAEBAgIcRoJlBFM++gwBQRwnDAF6DE8dJgsBeQ0JvIuzWEJGWAEOHBw+HSBDLSd3XAwbFgIILQsREw08DQ0HCykEtwECCBs7I00JCQoXEh8QCAQPAQJAAwMGAwMGEx8TBQ4BDAUmKRQVPw8MDCMTHxAIAgECEQ0LAQEIuAO0+jwGB5Bbbw4bGzQ0lpViAxUw/i0uFSgdAlIr/T0oHgJVJ/zgi7QDPDEJAgkTMyQsAXoCFBATDDsOAgo1DRAUDAcCCwAAAAEAnwKpAWwDZwAIADZADgEJCUAKAAACBQcCAQVGdi83GAAvLwEv/QAxMAFJaLkABQAJSWhhsEBSWDgRN7kACf/AOFkBFCMiJjU0MzIBbGcrO2ZnAwhfNSpfAAAAAAAIAGYAAwABBAkAAAAUAOQAAwABBAkAAQAkAAAAAwABBAkAAgAIACYAAwABBAkAAwBIAAAAAwABBAkABAAuAAAAAwABBAkABQByAEgAAwABBAkABgAqALoAAwABBAkABwAUAOQAUABsAGEAcwBtAGEALQBDAGkAcgBjAGwAZQAtAEQAbwB0AHMAIABCAG8AbABkADoAVgBlAHIAcwBpAG8AbgAgADEALgAwADAAVgBlAHIAcwBpAG8AbgAgADEALgAwADAAOwBKAHUAbgBlACAAMQA1ACwAIAAyADAAMgAyADsARgBvAG4AdABDAHIAZQBhAHQAbwByACAAMQAzAC4AMAAuADAALgAyADYANAAzACAANgA0AC0AYgBpAHQAUABsAGEAcwBtAGEAQwBpAHIAYwBsAGUARABvAHQAcwAtAEIAbwBsAGQAVQBuAGkAcQB1AGUARgBvAG4AdAAAAAIAAAAAAAD8cgA8AAAAAAAAAAAAAAAAAAAAAAAAAAAA2QAAAQIAAgADAAQACAALAAwADQAOAA8AEAARABIAEwAUABUAFgAXABgAGQAaABsAHAAdACAAPgBAAF4AYACpAKoA8AC4AQMBBAEFAQYAtgC3ALQAtQC+AL8BBwEIAQkBCgELAQwBDQEOAQ8BEAERARIBEwEUARUBFgEXARgBGQEaARsBHAEdAR4BHwEgASEBIgEjASQBJQEmAScBKAEpASoBKwEsAS0BLgEvATABMQEyATMBNAE1ATYBNwE4ATkBOgE7ATwBPQE+AT8BQAFBAUIBQwFEAUUBRgFHAUgBSQFKAUsBTAFNAU4BTwFQAVEBUgFTAVQBVQFWAVcBWAFZAVoBWwFcAV0BXgFfAWABYQFiAWMBZAFlAWYBZwFoAWkBagFrAWwBbQFuAW8BcAFxAXIBcwF0AXUBdgF3AXgBeQF6AXsBfAF9AX4BfwGAAYEBggGDAYQBhQGGAYcBiAGJAYoBiwGMAY0BjgGPAZABkQGSAZMBlAGVAZYBlwGYAZkBmgGbAZwBnQGeAZ8BoAGhAaIBowGkAaUBpgGnAagBqQGqAasBrAGtAa4BrwGwAbEBsgDDB3VuaTAwMDAHdW5pMjAwQwd1bmkyMDBEB3VuaTIwMEUHdW5pMjAwRgd1bmkwNjBDB3VuaTA2MUIHdW5pMDYxRgd1bmkwNjQwB3VuaTA2NEIHdW5pMDY0Qwd1bmkwNjREB3VuaTA2NEUHdW5pMDY0Rgd1bmkwNjUwB3VuaTA2NTEHdW5pMDY1MgdnbHlwaDU2B2dseXBoNTcHZ2x5cGg1OAdnbHlwaDU5B2dseXBoNjAHZ2x5cGg2MQdnbHlwaDYyB2dseXBoNjMHZ2x5cGg2NAdnbHlwaDY1B2dseXBoNjYHZ2x5cGg2NwdnbHlwaDY4B2dseXBoNjkHdW5pRkM2MAd1bmlGQzYxB2dseXBoNzIHdW5pRkM1RQd1bmlGQzYyB3VuaUZDNUYHdW5pMDYyMQd1bmkwNjIyB3VuaUZFODIHdW5pMDYyMwd1bmlGRTg0B3VuaTA2MjQHdW5pRkU4Ngd1bmkwNjI1B3VuaUZFODgHdW5pMDYyNgd1bmlGRThBB3VuaUZFOEIHdW5pRkU4Qwd1bmkwNjI3B3VuaUZFOEUHdW5pMDYyOAd1bmlGRTkwB3VuaUZFOTEHdW5pRkU5Mgd1bmkwNjdFB3VuaUZCNTcHdW5pRkI1OAd1bmlGQjU5B3VuaTA2MkEHdW5pRkU5Ngd1bmlGRTk3B3VuaUZFOTgHdW5pMDYyQgd1bmlGRTlBB3VuaUZFOUIHdW5pRkU5Qwd1bmkwNjJDB3VuaUZFOUUHdW5pRkU5Rgd1bmlGRUEwB3VuaTA2ODYHdW5pRkI3Qgd1bmlGQjdDB3VuaUZCN0QHdW5pMDYyRAd1bmlGRUEyB3VuaUZFQTMHdW5pRkVBNAd1bmkwNjJFB3VuaUZFQTYHdW5pRkVBNwd1bmlGRUE4B3VuaTA2MkYHdW5pRkVBQQd1bmkwNjMwB3VuaUZFQUMHdW5pMDYzMQd1bmlGRUFFB3VuaTA2MzIHdW5pRkVCMAd1bmkwNjk4B3VuaUZCOEIHdW5pMDYzMwd1bmlGRUIyB3VuaUZFQjMHdW5pRkVCNAd1bmkwNjM0B3VuaUZFQjYHdW5pRkVCNwd1bmlGRUI4B3VuaTA2MzUHdW5pRkVCQQd1bmlGRUJCB3VuaUZFQkMHdW5pMDYzNgd1bmlGRUJFB3VuaUZFQkYHdW5pRkVDMAd1bmkwNjM3B3VuaUZFQzIHdW5pRkVDMwd1bmlGRUM0B3VuaTA2MzgHdW5pRkVDNgd1bmlGRUM3B3VuaUZFQzgHdW5pMDYzOQd1bmlGRUNBB3VuaUZFQ0IHdW5pRkVDQwd1bmkwNjNBB3VuaUZFQ0UHdW5pRkVDRgd1bmlGRUQwB3VuaTA2NDEHdW5pRkVEMgd1bmlGRUQzB3VuaUZFRDQHdW5pMDY0Mgd1bmlGRUQ2B3VuaUZFRDcHdW5pRkVEOAd1bmkwNjQzB3VuaUZCOEYHdW5pRkI5MAd1bmlGQjkxB3VuaTA2QUYHdW5pRkI5Mwd1bmlGQjk0B3VuaUZCOTUHdW5pMDY0NAd1bmlGRURFB3VuaUZFREYHdW5pRkVFMAd1bmkwNjQ1B3VuaUZFRTIHdW5pRkVFMwd1bmlGRUU0B3VuaTA2NDYHdW5pRkVFNgd1bmlGRUU3B3VuaUZFRTgHdW5pMDY0OAd1bmlGRUVFB3VuaTA2NDcHdW5pRkVFQQd1bmlGRUVCB3VuaUZFRUMHdW5pMDYyOQd1bmlGQkE1B3VuaTA2NEEHdW5pRkJGRAd1bmlGQkZFB3VuaUZCRkYHdW5pRkVGNQd1bmlGRUY2B3VuaUZFRjcHdW5pRkVGOAd1bmlGRUY5B3VuaUZFRkEHdW5pRkVGQgd1bmlGRUZDB3VuaTA2NDkHdW5pRkVGMAd1bmlGREYyAAAAAQAAAAAAAQAAAAwAAAAAAAAAAgAHAAAAPwABAEAASwACAEwAzAABAM0A1AACANUA1gABANcA1wACANgA2AABAAAAAQAAAAoAHAAeAAFhcmFiAAgABAAAAAD//wAAAAAAAAABAAAACgAmAGgAAWFyYWIACAAEAAAAAP//AAUAAQADAAAAAgAEAAVmaW5hACBpbml0ACZsaWdhACxtZWRpADRtc2V0ADoAAAABAAIAAAABAAAAAAACAAMABAAAAAEAAQAAAAIABQAHAAkAFAAcACQALAA0ADwARABMAFQAAQABAAEASAABAAEAAQC2AAEAAQABASAABAAJAAEBzgAEAAcAAQImAAYAAQABAl4AAQABAAEC3AAGAAEAAQMOAAEAAQABA7wAAgA8ABsAVwBdAGEAZQBpAG0AcQB1AHkAewCHAIsAjwCTAJcAmwCfAKMApwCrAK8AswC3ALsAvwDFAMsAAQAbAFUAWwBfAGMAZwBrAG8AcwB3AHsAhQCJAI0AkQCVAJkAnQChAKUAqQCtALEAtQC5AL0AwwDJAAIAOgAaAFgAXgBiAGYAagBuAHIAdgB6AIgAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMYAzAABABoAVQBbAF8AYwBnAGsAbwBzAHcAhQCJAI0AkQCVAJkAnQChAKUAqQCtALEAtQC5AL0AwwDJAAIAXAArAE4AUABSAFQAVgBaAFwAYABkAGgAbABwAHQAeAB8AH4AgACCAIQAhgCKAI4AkgCWAJoAngCiAKYAqgCuALIAtgC6AL4AwgDEAMgAygDOANAA0gDUANYAAQArAE0ATwBRAFMAVQBZAFsAXwBjAGcAawBvAHMAdwB7AH0AfwCBAIMAhQCJAI0AkQCVAJkAnQChAKUAqQCtALEAtQC5AL0AwQDDAMcAyQDNAM8A0QDTANUAAQBYAAIACgA2AAUADAAUABoAIAAmANcAAwC4AMQAzQACAE4AzwACAFAA0QACAFQA0wACAFoABAAKABAAFgAcAM4AAgBOANAAAgBQANIAAgBUANQAAgBaAAEAAgC3ALgAAQA6AAEACAAGAA4AFAAaACAAJgAsAEgAAgAwAEkAAgAxAEsAAgAyAEYAAgAzAEcAAgA0AEoAAgA1AAEAAQA2AAMAAAACABIAdgAAAAEAAQAGAAIAEABMAEwAAABXAGQAAQBrAHYADwB7AHwAGwB/AH8AHQCBAIEAHgCFAIoAHwCNAJIAJQCdAKAAKwClAKYALwCtAK4AMQCxALIAMwC5ALwANQDBAMYAOQDJAMwAPwDVANYAQwACAAIATQBaAAAAogCiAA4AAgAeAAwAOwA8ADgAOQA9ADoAQABBAEIAQwBEAEUAAgAEADAAMQAAADMANAACADYANwAEAEYASwAGAAMAAAACABIAggAAAAEAAQAIAAIAEgBMAFAAAABXAFoABQBjAGoACQB1AHYAEQB5AH4AEwCHAIgAGQCLAIwAGwCPAJAAHQCTAJwAHwCfAKAAKQCjAKgAKwCrALQAMQC3ALgAOwC7ALwAPQC/AMAAPwDDAMUAQQDNANAARADTANQASAACAAgAUQBWAAAAWwBiAAYAawB0AA4AdwB4ABgAfwCGABoAiQCKACIAjQCOACQAkQCSACYAAgAKAAIAPwA+AAEAAgAyADUAAA==","Vazir-Bold.woff2":"d09GMgABAAAAAKPoABMAAAABYSgAAKN9AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoE+G9BQHIsuH4FyBmAAiX4IXgmabREICoOxVIL/XguIKAABNgIkA5A8BCAFyz0HoVYMgRhbuUKRAeqGSZkTQfVc3VXl7XbHjsxYwm6xvdsGn7WjTPyBErnppsB5AEF/Nfqy/////9+QNGJsuyHbPfAIIhGqWFZBVKKCDWWGguJOoc+QCcnBDo4KCgUyBpjV4tBhLDiHCXMWhQvECkSWCtsefW0kVKzhIzuIbEvm8IkONWQwtuCwZx0GhYzqyA1jvM8Y9nxA7anh/HRCD43CgSsOYcVkGN1+4FW+qsOX2Tc+p2lg5j3eC92WeM4nHD9+zlAsUVFRCjM6pGmerjY1stkdfTnx/HoRmQ8tujOh0L3HwdRkbMlDgrgUJDFBEq7QCYyLGmZYmcgh+iO6FRP9Cg5CFUz6IBgZ3nS5wcQQk9rzpI96+4s9ujWZq09tblrChQhmUgs7bGRs4/xeyDHlW6Hn/83VgpXf6S61d2/ZMjA2RtY+Yp14YkVVnS/8h+9I/9wB2YvNNikxPkb4AiCyND/Pz+3PfXsLxqgxJoKARAraIBvgxEJQvqRSaXyMBhMVEYtoi2phhJhUCEYRPToNYgbp/M9ZEFi2ZYFlkIGEZpTh0Qfk6i7pUoaLLl2KEqi9ukr87301Pefce9/7HwA5YooIG4iFuArcVYz4+gpczYiiEhbUcKAv5wQHsKjdFK5UOlWxdh0r1649wM+tf2SPHqwYa5awAMaiWTSD3ogRNSKVaBWwQBAVUDEaBcSowLjQ84y+My++/84DGU4wAejMRS/9jXXsw4ht/oMnjkzqm1dkLkzUU91izhyoocpQx1HYCbd8wPDf4ze+19kn2051RTmPavcdiEuhCinaHikTJKwR8Flbgzkbg/FEsr9c3AtdAIyA1M/vt1BXUlH+B9WMsgGyA/TgkOy7e4TdoHRU1ClqddXI4dYPk+t/dA6YPgQeJVaRtzX4N8PEAIAx7mqAxN/j9tre/U0v+BmDcAohHEKRsMD96yz/CHdn/ljrI6ouwBXWqfLSimzvLfEB2tI0XwlL3i6IYAhBUYfhedqPfvdcmTvP9u/br772vlgyw2YQTVApyUMidEIiFTqt8HKMmmkKf4hG2EZLL4qhzDxSFb3ZEMMxwjYQ1rVnA/MMOUzgv0NsGYyfr+bqq2C/dQe+xfARSBDbnQAjJlVdDIxnzWe8L+m3t+QfI85ICBqCeRALolXdyIUVP+37pyVC1nL2AakAIOylynVet68g6FcIBPE4+kWHkd3NnmhRm3T3rmivLGclBF5T21km72fvhx1LSwICmgL/5VgmB6yoRJnNwT7jfhldcm2dqXOFbbC7mWCNzunMjG15wHzivAACrkq1+laDRg0aLah1HGl3jzpLndXcPT6SzrrXvc//jCtkdaO6q2Ea3QAJdJMaEiBFN5wFAZIDgdIMAEJagNRMSFzHWa+ddU4654AGKYGgZoMDaZyhtMaZs8b9/ffp7fN17+c9jYXna+87+15avSf13qTLuHzhEYrg1H/82Zm/1H203ZTSJKp1W53BI1ESYVGaQWFMLNZhBH409ZNa57TmpLMGYAC50iGS3+xoJI/Xe6X560ovu1rZJ8lOKyyoo4NJaAAmORYEw/O/nyj+uNb0aT1nwgttyb+MQb5JFiEnJ9TE/P/WerPv1qsaPJ0zHeIOoIwwgDYuMpr8TNUffNN/PnCHqAO82EvAQqJjkISawKhVao1foeLsklB+lV/rFnr6teWTxX9EQnmhlDPFPTOUBI1cQBwcyGcdENMs6DuRPvOWrqP1L6JWf62IWLcbfY9tFGb7W7ptT4ZlkEHEkyAhhFxIReR47X/ZT/kMCUTqKEirrZsRfeNr3Pf97Ke8X6NJ7l6ZLhBhH+CAaNL2fb7u79UqLiSzrWenp7t2QEjIzP7dO7Ns6iCURPeMYxf9rqRznGU5Q+bnr4m2Tp2JZZnY90g5D9BfxfnGVX9SAwBffVifA+BbkXoxIIB1gFeRDcZqMKJBPOEJBJ7yHMQL4sFIoBREGZ8h8IUOEJ10QqCLARCDDIIxJF2QWGKBiS0zkMxlDiYL2YJkJzsw2cseJAc5gclZziC56H8weYkHUrdDYBp2AaTfWoEgPkYHgQMYgIERSDCIUEJBIIBV1QUJ5Gvw9efqSsokK3/KU6zSZKZQFSiKXJUqb3L1Se15rJqdSbmacjNDteSL4UDxRuYDY9AjHRRGPWHMqJd4YDmi/3ApDtOt60iOpkNwXmI+PC82ukNa8RQoMLsCcODX1tLsCuEq19NCgXkdpeDCBkAqHQQQWHrjZUdXSVGwq11FAAXR62h5dtD6aOCwQ8MaymyFcsV1FFDYepUoo8arcjWV3F89hGuroO86ybri9jwHPXs8d5fbVZUDUrGu8L/2FKB2t5Iyv1XxaRJk4JAEEBJeJ9rh+wQFOlIooMFmWBhiCgmuG599zyGOmDv4HTfIu1YDvrG+HgwBCDsuDvm0B8X7fWOPA+2/WkZgEiA2ogKCBQ0CFIRhgOzQOA6y/8cHkGkOFhAEKqim/hMJQHEmsANgTxTQF3b9+mHtID4gWskGiQQ0GGiwEW30MMQIUyyxxRlPvDiHNzfw4wHBRPIcZHErQSBTb3ogY09XQSbTzoOMNV1Kua7snMiqz0+92f55cl5/Vn/le7k2fWbDtC26Tb9LdD3mKLUJLs6qbGwrSE/fRXbW/YUHgyeUUU4lVdRQy0fq+MRnOvVbf/RX/7SoJS1r5VkV5h9zbYAbAtwc4LYAdwa4J8D9AR4K8GiAJwI8HeC5AC8GeAnAqwDeAPA2gPcAfAjgEyALbUdAZhY2IEuLcpDtSUuQ/ZfiILPO1yCzi2qQPh8CIDvYIkGGiLYg009x2rMdd38k593PbL1f5f9wxMufcSEQBnEKbU+rv9GynfJpCnSUHjbCFi9uEGzfn5cG8qoNBsmoxG+8L/85DUrYdeRen/PpW2H4Zj/Ai2LNubZKTatN2vdm1vDUzHH7beb/bDvvTumpPp/Oj9N8Ok/fGTlTZ+EsBcMomDDGSFigiQ4+lDDCjiCyqGNMRiwpTHlq0pS2+OdRQhOdmCQlI9wU5kPKU5sv+ZXW8DKQsczkT1aKE6gE0QYVXHjRjSmtrHIqqrzamprVvBa3snVd1I4GNLDhfdq4pjSreX3T4la2rt/a2Pb2dKgTneu/AX5xGk5fyCIXNexIi1vCeJNMOf3SlrOCla5qDWtZ1x4seJF7voSlLXsFe7fSVe/Tfqx5nevbyKa2sCUwIoUoTGQQBpRo8FBgwEaADDVGMrBQSDk1NNGGP48IJZoYksiASyEfKKeWL/yiFR4DjDHDH1bESVSSqEGChYs2RposOYqUq9VklnkWW2mdi+wwwEDDfWqcKWaZ5xuLrbTObzaKlO0gNe1lkCxKEsS/ooMU0H1A/O6Xgsxi4YGYLT2Qv+xBIJVvMMgmFpT6dy+NN1audb0qJuR+/YY9PvMZtfS+9XU0mL9VCXAThCHHFv8twoo9oNpaXK0J/b++Zm9PyDNI34i/KfGLo3pRoVT/9Q3bnr4kkBOvhb9hj0ctnhsgC/16W6rbUAlMj/ppYRZx3aMWZ4zsuUl84bBp2bN8aOEC75dnC6+XqOjGDH1eYilH7CKtm9poLeWgXLsGq973nwkWnRL7NuiFXuLS/ZaYNtR+HOsyNf/ufHvbUOkvRb1zzSh8zc89rrqQ4ioN7naP+OTQOU69LV5nqaa8jV3EvCRKiVBfsq5VjJ2NqrCo3VlmqqUguXgVAssQtNk06hnd1fxhD41qPQ50eqII+qNuhBDzBRh1S4ckF099RnUmNklisnIQ8Q1AoN84ZoIYWswtARAanQKxlHDwd+kFKSW0Q+MLgqD10PtiQAD7v64viGPIPV/SfJBSH8QgnMpjS7aISaIaBZQICJJA1YBASj2rs87DQYfOpBKUpJXU3l07U8hph1ZVEMjBkxQf79QfEkqLhyz6GmwnqCFcrr7kEjZHQy/2xyZ9n9VeEz9G6V2KlczFckuK/XoKrjcV1E6PWZNdbfEigPTyayGyaMat2fHPEYYAzykF+AEdKMNjBFUZyI7NchCPQ5rSHL+0oAVaxEd8aDUMw6Btmbp94dL7pO7ITTIwIfl61CeZn0jxy1GdLlc6NQ2/n9obv15xW851Nr/1U2PzRx1ZDRew7c7tPn/zLB/8rCqM2x8WprvUUxKuZlFl3BhiMpb7nnehzY3aI3aUxdkq3d9EaocpOlKNR/uNt7kstlq6UNMntbV6O11vn75/wlqXJU2CNKio/uSGWuhpnSAC9JhZr4sTb6/3gxmbZz9YCI+UD9NW0tZrVM1XutunFvWNNkmOjg9NW0VNk6gxSpvE6K/rwVldMzVm0xqk+wpUEnFKRrZJNjG2Vg6OqW1ShhPeYrGa7eyJlmBp29aD0cTf+vwY20IiQyhCxH2MCwPWpRmixtdlgJFr015H8IqRvkSIGH55iOPkMIeT6GBT2DDV/IWYU5nBYUq5OH8zel8+enyvSu2PR1gP3PfYDd3Xh6LioAoOeh7Gj9ap2E9xvbbZ/LsAKrnQg4GWc7S0kSxovgZGchWljSNmEf/Jdj4qtlTp/NVFZ05C2TuJiWzTvMl4bLyz7TILU1u8PGM69NRSW+iiTdYGf/WZqMIUl1DWlF/ywaiPK3XCvHkuoSOVXYYOUUl4IE16czNO+Hk0iZnN8i62Ri+uwu65XsSILnclfcW3xeyW23B89P5SKZOa6DR/2t+OWah4v63jfsyuFS7xdMicJvYxf0Zo07mdFbbrwjb+P9yseqN+g07pIFd27zMqu47bpqnzDkoCbOIPceJWOHecp2fGNUaYN9J6U5Rvc482xd67vChl/K263etRRYsHNivULXnsvGuVW2KBgGSpbUoQHmPqrxTdbekrwfr+tmorLrCVbNwwZ+pZOAWMNgzwH8vt3C+f+8iWCxLWeVdd2nrWdTy8bZQpmb/I9zJyDq4rs53SMw8nPLrDYsYUljrG/UC5f/e5kG0GXwlviAANZp+hR44Bc8qA56VUXpRt1SYxaY/lfby0zmmScEtiPUlJshQZMpvlBW+EvCnKwZWbPJCv0Ou8GeNt3l15D/kAilq4Cz58S2kKr6Tn+EVF9p3+cJcRYweYHjbosetyx03Xpx5z5V70UJAwsRKlypQj32vvlahIzbBRz2bqK6QpjsHbKnjpyqL6q7/DC+pCXaj+au9SkpokS0nGLZnhr+AryAk3yZUnX2FeYyxWF+pCjdZoX3lfyQdQ9IxrSGkKr+8VH8hS7nCXEWMHmC48WLC64w195V4aDwcstgZhYiVKlSlHvtfepwQjFZCaYaOezdTXqGkM3v4vuIO/H/sfkrj/Vgy+MRAksnhJj/bpqZ6DUJlBW5BFdhPSTzgBL7eOvQUNnD7MOutPzTK11eig3wtcDkkbHOBATH+f4oYd4xK++POIUKJJoIBqxpjhj0iIZp3pkpSGNn60mGKL6fog7BEEwSgKEFCqHGxqEvvqgoBwDWBYc7hOIxgmNbHaOgLicDl19EpZwqfYBmEw1UuO6Dv479EMGiI2Te/BFXGIgIbRWBgBBNe25alE6iuG0DGpkWugGZuw7TskWj+xqf8UovBLISA26BV3l+jEAS8WDI4JDGzYjD1iyoFoBiT/gDFBCIQCZGgwUEENDdaxkU1sQxc2ehiwA2NMOIg5FlhyGBvscMSPSJERBVGRIKIhCTFBPAUHSBgocIbbBEOADQM9VDCAiThiYwKV4rChNqILg73ViVGNsr9GMa5RDtQoljWKdY1iWyPY1RCONURkcSSw8ieFTogR/S2Bo1tdsKsPvRrDoDogTPhSH09n/AbGhpqApVdGEBFiHdrowAGRTfHoBhNLTjj8jxaBjCg0BUY1xH4Y4wCsAz9ERQYFVAiCBglidkL8gcZKwBgHYP3UCMvqgYhY+UmgQQhiRHfEaKxEnfwbRZeAMQ7ElnUG65AjX4KTfvaQMOEQNtjjLApgKw/AgenJ8wPkkQFYR2ysV5c5i0blm/TNCX39E3teXEuTZijg8j1K//vUrPtroW2oL6A38n1ac8w+xNf9sY3YNeRn1j7PR40Y5t8bxh2Mpg88buCB/E3Ws+XlKtW7hiRb3+9vs9R0Xq8Sx+OsCQB1V5ax8hXsXa+1Ejr+QtH4zI43xSqe1+nsOBi6LV2Stn0hFStZ4zunoYcyxuAyNNfbJerPfiOvhO7hBh1I3fals3eV2myDO3Z4ebaYsX7icj9J9bRJFmc5SX2Sqeva18tIP9+8s2otP1I59MM8HttPPvoqlep+PUdujWLZv/puVLfBbruZcrU4zj3v9/xziTG9jTjNDdKkpecDJ+Ji9f72YdWO+Wi0Uml4eTdum72sYXy2/oLKr+rygvYTiRq0fVFfvYt1hhXpvlM2UTuv4j2abDy9XB/8oNvO6W1OX89OzvMNlWc/3HRjzNNfb+YHgXBKSevjIbrh3EVT4nSmVaKaxMm75+maQG24RAa02yf5ojc2LQzV6pkYs3JaeoypHPOpk7kE9RVtHG1A7FW9LGmpL/H73V4NtTb93ZdKxYZBFb7RxwWymVeb8amn5Rk3JIxIfRZwIMEBnTKTMh+CIRy3YBhVCriti+JhEniEGB6tVHBihOIuDI8Rx1OIeJoEniGJZ9FsUPE8KbyA7pw1F2y4ZN01Nt30Wxtb3PIAtj1kw2N2PWfHS/a8Ysdr9v129kGSBQ4ynMJhRnZeFi7tr+xJedO7WeLe2G5sR4th5JlYPAwBIo69yNoXOUYRjwsRTy4hNlMJMkmKSZG+9lyy224om6DkZ4n3qU1PatuzLDEVtsRJfIvs8D3b+DW/V2MM7HDXtqFtg/UTB3F3Zz5XmL75foWa6qa3PbeeGe/QWT6zeX6fY0z8vUvXGc63iX9Nn5/lcyyN6uP5Zwk/+jH5zx/9zd/9w3/9z/+p2RnXHHvipU9840eZLvzz4sQee9MTAK8o8lbq/r3kI/nf6e7C8R8BTuDk/+vnt3gyyfP/fPUgXv/prxtvgbzPUgCsyxd/PhC8rB32fKsl1hU52sbWTngL74EoFVag/9TFx6GE+Q3+Q6WX6jN33AZCKcEv1k+A4clGndIZndMFXdIVXZOvbstfDxSoUEUqWk/1XDFKUIoylK08FeqdilVutXV+8YeNttpup1Oa0w7t0j5Na78Oykzm4qMjWgAD5wWvAN5NKau/jmXFr44yGIbIyls35KcAPVKwwhWnJKUpS1wV6I0+qNRKa/3kN3/ZrLV47tQezcpE/8kWDAHiuw+8/ONCJJMORjavIPOaIkQooRQmPLqRpJd+pBhuoczY37Iu67ru6J4eKkhhilWiUpWpHOXrtd6rRBXWWO9Xf9qklbrkaLdmZCxT2TzeGWIzBGgwWQsC118waj685H732r2kutyq+F152/BKNyBBZw0qbMcYr57W7+6F/2D5tnX6d+MVXkziUBGFyZpDqlqkslfKsVpl7bailu8LgvTVeFwHQpaICmMsDXbryscMbcdU7xccYtDQrvSnUM+gfjBdUC/+GXW3ThV5gPu45zwIksA6ackV/Agk+k8dHJJEFqU/gdqQoYdqdYxbtzylE3fiyrVLLjJ2y4kdOwhO+1gp1soOfMDT2EgcGPXEiJTlReMjmy4Gc/dJx6biPZm/MgkiCRRRTKkaQdAdbqtgiSk0TSb1i8NjiEPo7X3yvweATPPC6rWBjfe5o/o+X97r1wz06YsVNqQ9BMjPId9oc2c5VsP5S9XQFq7jd4RMnpH99c1az/jvWof/8OoR3vYBIpAn5RNA+x7v2L+Np9EBWyMRCBQcw3Bf1rov7+zM9mveXpinxruq5dnz/wPAfPuQArhgfwpAnNk8AfZvCv2XaG8Q4fo/kqBnAbfmBG/DFxKbHftPK8QNSuyD1URHFGu2iEAgCBBECIrtbnjTpZEkDBciS4MppllpjS32GG286eb4zlLr/GSDf18M/ShNWZd9uV5ulYflcXmNGrRiqpfay+oTYc+KqrpaVQR7BccUdlLYuW7Xy/VW/RLuDPdA1v0JW/j44Is3muvzcCImdpLn5QwPf/lvfRn3/ZZG8XvxAbr+WuL86mhOw6J+I+QbZ+mcTze1P9Zur2ar39O61V51WF0AEhfO5OcLb8Ed6KnQ4vXnyjyYwIlp07NmaJb8e36XsPwPs6gWa77661yv1XO55H2PPfjAfXde+UtjL/x7pEur//1ntWDRQPrlpYfu06ZJlSwZEi2a503xJgewH2+M18fr5XXyOniNvFS3yXm7SIbEee366VOXenlZQSqr87vzZ+e3Nq/HeXUyeU0tH3hHHi9J5STpLWpOfstYRpoiAMC4pBaa3EQua2EUoWURU2L/2F+gRGtTl6Wvm60bfoDOD05TmiUjKyfPVlBUUlZRVVPX4HB32wfW0t5v4UvVueZb7nIRXsLLeAWv4rWNV3njS2T5Lb/4OzjFPby7/8rv+/4f4EN8hI/xySb8BfYCGdMFV9x4/yKtTbiAJ0f5X6JcAbg3J6WMN17aAoCO56K2ahvH8dE6aUkT0Amc4gZRAPAYPDijDYBOJJLT3BQdd2zTEb6rw/8xmKBT799G7il5rZKkWGJLBK5KAAkhBu9vhR/HQ85zjwDuc41HPOBLUGnpvJBGjI0wPdM+qvLGM1w2uUD+PVjAuGU1XLnvs2R6a2NW2S68mrIN4qEODNj9B9XbpfjySTneZfAV58gPP0kt/ZeDK3InMnbeE0+Jo3Q9CPgxVCSwWuYVKZiCvxyR5099EFcaTAYUz9STmZ18Vi/e5SdHvPP4CUVf7rHNL5x/GUpjf5oykJjhna3P+k3olxjMkf9c/5Eix4lVy0z52KZoqkb7ru5IjYomxD0lrlNpUOVkK8eXb9I/LUyqRf8JwWI2TUbiErSdhLijs6IVGRiA3NLUrCToSCmkQDEF531Z1VKRI148pkVYB9wE+dyOX/gaIi22n2zlEzdcyNW/v0Uv/bYgz8caj1w6MRXzBkYvSswpQmSNaV8BSnrUg+oViZKk+gQEDyfS9VzL3zZEYWUNCcxzYkKTfzxY0s7OiIpVeuzqk8n00ijwB+GhtxSKZVrOrVAIE5fYcuQWMciNiql2NRQsoLI6+iINYTNgkjryhxIf6qdzg8OsDUqAMMX7+KB5pt6Jt4eekpIU2jjjB0F/RRUrAYykdoY6P7jUMKon3D1Oxd1YClBTRyX84yE3NypTishvEKUkSVbU2D3Twn86u83kr/w4IH3gWHdPX/qdt3VmZ4MCrT2XtHcKSQ1MuQkzSi2U5BdOTSLZEJBZy4riVPK9kf98NGW/uvJyxfXb7doQdQbyJtaY1IgqOCNZzJSL8VYtgCkdiYhtT2J8XdlkodD4mVJLAQMm3meb8URaAiJJ/W2MFzUf8EJ+8290Rv7Jd29ZxTQF5qOKFoUcqVNGUcoqRjnFKa8EspVIBSVRUclUUrHNIaLzp6VYds9UUJNo+OEdxfqyw5006X8Lj+le/39U15DnsqGBAYYBgQGFAYMBh4GAgYRBC4MOZgcCtEHjotRBeGKkUdDKWmnNKJGOtWGqdslIbqXV91OlBzCCBSOS1gQ/c29lTnLUF15ESqJ3BrJy7K2KEGcDfWoSKgPVHEB7dAhecd07YqGa54ydSeJ8zHqrKjK/AACnd7JWhjGS81NlDBqMeA8RR8b159GE+lpTcdpNJYk6S5NnFBqC7qA2BtEIkOHt/OeL5EcTdOyibHIK/TTqs9WHOHEOkaEOfm4D6RIqSlgXjenRLHcT0OQ57GIRQE1LJT+4ehrgGxypGj3pT3q0jN1PmpdzC9g6Jgu50VuV4WNBLh9lEd+E5FOEKk6FTGnKzpU/OWIR27L2DyUBW/Isw7TmhLKGiQmPhMG9jWjcgqIS78EQYcFSyNrBIM8SKTYDu0WCnmlsJOu9Sz3IiASFXIWkWTvfsNIpt0lDgAnBgt71bSKIoGV82O6B1mjEO/qSgScPv+sXbVOwvUQQDDgr0EVLseTu3s17onnxDYtlRFZxXeZVt3xZrUEcKuvSI3diisbq0o3oUWbn3Qc+cUfzR+Ny7v0E7+HcJ0s9wIXn6lEDr/swz7tNIFfNLqKjjgw03VnroUTlIYgNb6cKGtSyRjvxRJFbFrofZHf+fTECMMgDGPaYjaw5D5WgNx7R2W7MH2lEPt/gJuhlL0pCxecu3JbPaz2CW1qJYZUZr5bmcu8VBWTVyQnVruXrs5GuPx8yA0GNYW5UTXXdwJmLidJ81E36ZAJcbGArRE6OAFch8nzAJUgoRMkcASmFjk5r5gO4QCPDiLJ5AnKMKD8cIBQYUTFPQIlRo8wOF6mK3VE1R0BNIar7gEvRUIiaOQJaCkmbJ1zIvq2pkyegy0h6la3QZ0SDPAFDRodHmrlgGU/GJ51/C9R6gmBjqnC3Q6g2Ow3ZTnNDXhjSsh9silhpNtaaLZvKvcO2/I52hrQ3rB/6tB6OWg8nrYez1sOlXNHVkG6G9Tuk9fHQ+nhqfby0Pt7lij6G9DU81U8zX8exYrbGe5xa83gLQemaDek5SQAEKj4i23a1PROH/lr6AXD0OsC5nwRWnwis/AE48z4L/kFsv/ZwCC5r1CcshL0lU3p0IcG4tJDnTZej9eJ1Yq4IGsqxZcOIA6jTG2fIUVqp1LfZM1HelVf447M+A1474cYIjCUjg4aY7B3dTXzVqjdjEazvs5Xh0rW65dCiiMGndpSLx8QoVPsIH2Fe9/1N5DI23jhjnH+7IR8lEa+xivXz+rx9s/WI9zayUj2yfzTsipd61m0WzzC4LOYPmludBrKPe10cDDK4JHqRhDn3B1kmkIMEIrs5GcKyDOxSYelraQPYE/0urr4HzJ1xD70FAjFLeCQFi6U/PHXIZuh6Djg2wEyQWnClEuNeRaCUZLCICCSF/Wo/i0TP5sSbwrIFvTlrdQjwSFpPoqRnFFpJVDDQGqHYgVBobRNF8US7LnEtowxAYyc0GG7A93VikSAxneJ2ql+EZfwoa49a1Qpj0ku8ExewvjiXuEkqGJPfncn1/QpFOxpVXPeIvZ5sj3C8IVfFhS/GyA0mU1Otk5K2DQjRpmDZ+mL94twOgchjTulOyWHgzpKkamttAQDP4Gkn3wyat8nD9vLn+3hYe1w/4/7rlhT3Z8PtPbn11p58NqfsVNViY8F5K18kTi7KExJcWarZgxYH5B5CGEXdeuFNfjQJ6r1TiUdxs0UyssEGAkSwCxthB6BEz9bcDjc+G7Zvqkmh2JiFcmV3vzbckuoVedrVSecQ9+SZYiW6NL1Xj6KOthB4t4lSalZYEieohVK0r8rnZeeAhbKVQFL91YAuZK6kg63AtK2wc+eqoRBFgIOOITYsFsdXSqxDHIO/8I7cxx286yATiPR9rRmI1kBYvG7p56y9zS9B1u8OkaH6YLwfrMUStfrKV9J0DGm27kU3n1HGKcI6pjDxvo28v7d+sAOupBevVY+RR2LRGii1DM9y5cxgqz7YJBHMoQv409ZqHSjLBmOX0Mfyh82wbWjorPBFcngLQrF5jFwmH7HdmoDMJNNNSmejqUbYTGNhS2tkI2azQ0IHhahByuOkozUIrKJijvNE1HRB/DPFDivneRhYRuEIULCs69EpOEgbx+DiN6ee4v4cWgN96N1ANnCPrR7fy/lW5ex3cUpqLc9a7+uOQgotbddi4Q67Z07erYPk9IaBudHiqC4haVYCpwkTvb1qEcwniNZeZEg2sqV8z4+DOaIH8tBhyeIzLTXYKJaadhecroCY1/OhML3LFMxXuSO9BsxvZiYVJMvDMqAUu063OYTF3GF7oEqhmSRKN5rmeHNIYXdc2v5MZ/Cv9in5yWdWDmLJGKw7z5T253amntmLtMeODKyNdxjgo50ZpOmqYYmL9SOtNP1dqSPWrRAfagOmdXCGK2eH28VeEM/lnl4ybMZC3q2XryJdvBgBZZPPwXVENzRlGnHvqNB38mYKVDmh+pZtPKPtxJ7Y+J7qcLe0qJicauFMn+AJmtLsrUy+fYxtbsViO2szpH6oxflo8qaRRCF6sGqgqzxgLIUQpCGq5R7IYPjeUrMCNSb+G0x4CTr6MP+DNDfcDYeYuQEd1CDTtDtmAjuByzxhnscDaAS2Q6s9PlnkY5menc5IkkzYCfZkB/N9iYjo3BP/cfssZp0x2/CsDHlCcNUR5gVA9c7oBsmfd1rMOsLhzLsEjmzj/qKzHylV7lFuDkkbBJeL5GnvPMowzHxFlNbGvrBLHaJqRI9q2Ci62OKzZ1T/qJE6Smf5Bi8xFiVZ5KVlvTCnV1dO0WrI0S6NzgZqA/SyBCViRkq7SgYTCcw3CUqKq7SM2RisC7fAweO7RsLITUiTfgBUOtGrQAr4vJqbi6VBIVzRTLuOTOR5p2rQvaUJT3k9O5gfHlhWUi/2vQVW3S6P2ZTn7vUp1/7CmY7Dmyqnd0/i0x3n2k9kAKjku9rDJ/CjNXsROYwdSUD6It5HoG5aGfKbaUDxCr2Jho4RHtF14DAB3kLw5sR3Lkl83CsTxjnaLeThG6wQgsfLepQXCgUBXHQj5fC+roM22mzPYwflAyfnPHNuWYeCElGfA7PgphaXWhwnj6vwLT0qPTyzt+afTLJ5jMXp8dFlRfvxhPdZ9A21DE/ofWa/qcn9nHGldfwpmtQ8lFoWfQIOHw0wkT52Cg6bbhtduEoxgRQ6JtDQxdt6dKBzP91FIPvglydx7Ji2obh9Jv2FR/TRSR9Bk+04MY5vum+S2q2mZgpt7FYmkAb6DLCqbcemB6JpJGRmjMFVDXX11TwhCCZBpYwrcFlk4heXnRQyF4HqMitl73FC0Qtryn33gRF98up+AsJx31HGq5KOUJCu80SQAWhGewcpiEeBrfkhdum5cQVOUqbFNXwwrdAgSl+CZSzYZgkl9Sl+sINI8IWlB6Jv3kABgWLli1C5EESsJEkFUJyFJTKJDohByNMSgrwcOLQZED/hpX8xQEqhMDCEL6YVbvjs+drlNA9HzywFbFC7Cw6HRqJloI0dJ3zeLRt66RYtDHSxnIGxPaIUVcxABJhmZd27FvNlDoUXQuHQoLrhAfHEo3hkaIBwhCMsM0RZRp86g6nNZNFqXhE7d47VjAdNhQKI5UxvMzAL5k15VyqG6HiiEPbSezbwMUSM7ADp/lNP0K5BfZL1oRBu99xPQL8g0M/G3TAxBXDXB4MSpJUY8Bi09v6MtbgGQQFPGw8pybVYtICGV8Zgs2hlG2o25Y9IOxkWE588nBms9wMkQQ59FxHLIi0lQt7GbvbMVK4ZIZax/GcNHu5ey6AqzwXmhA1gCni0P35V8hSFBC2Bm6ceGGeTJZdp3lF7CnRZzPhLkSyQNrohzNI6hTBR5ryceA8/M5JyEPGi4Vaac/GrCuTkzRdG76SVetUtp1rUofO+5gxZO4QP9i7fY4bUETEl45FFpNRED+xN1gd+XVkEXBwiLJIkpOZwAT6Z6yhtKE4MgyL2BtXCbbxRFKRmK2/dyw5oEsuKCs1gY781tCQaXyF26jjUKszDe4G2OjsLvmVX1eLxgaD7lCalGBUdSzfYgmbZfM/hxXZiGTooMVv7B18I5Jy1PIbdeGP3FJcktS/JbPACF/gwNnmtKDaSUvw831SQzvtF4O6XlOWzQX7wlaRFF2PHtQ8kA30e0ILb1cAr3fqBFOSc23eQoklWFEkXlRnihdQ4qRR1Y4qxLko0UEUjABC5QBGp9Eg3b9psfuO7QyXAcKOGtTCHuUNsNSwEmSg+dELhO5UBh7gTAhSZQZkrjw6C3mVSAnDK8IIMywi3MYfy9Khwf57vHTwd44ks7CMVGTjDRO9dFCKVUZggEF32s5mTUWGuQdhfkqZcdNgmJ8vv+xaXpaN0E6Unt3+AXFFyYCdOyaaqriBXr9m662PpJFKw7w/LAPHpKBggQLsPLv3hnilTyKz4/ntBEoorSIVoPU/Ruqr7U2JBsspwWfpmi5F7MCMl4I1YaKbuyjztf7XCf0DR16/lzGMCQxaKBpcRlanIrxNF2S0Ve/unDJRWPg+EsNvxYUXN1s/YxjBDFrSeLBWeEeihqpp9Qo+c+AcjCjvDWz8bEoCWP2zK6NMhsWnhYyyXs7e3gcHATtnKLmGi3NAerGxHiZrVosgErpPUMcdzVevw+CSLBShLwO6msiFOrM5Mn1GIAn2G+3uXIprcFeQq/lnr3EJ3u8p8EdsBl0vngpLWWWENFZMdwdpcAQAwTZg6s0P1do7iGLIcHUEW4Mp1EZJ9HYPWmVOhao+iGpF/QxFtGL1KMNU73G+QUR+Ld5ktg0f6z4dN1v9zQS+W8cgnPCBbN+O3zArD7JNrZqBv0lYRuYptKFBCF4gGYrT5BaTg4ayO9beRzuZ0vxWMDyqt14kHgeq968CIkM5O86xVbEuUuRHbLWmdnDAQ+plJRGAuWyKKLBoHzw/PxS0FH1WuW2AmFtWCfCXXRQhbZ40AAPW9bPg7XnQDc662LLecYbY1ZL/3irX18dMkdkI7JecPQ8n1YY26qMK/wPJWwE1+PX8fn6MA4EqntuZOP0kP1vf2dnJUFtR4SPMsMn5bWKcMhhFKUTb0wn7lRHi/5U+sWXf1aWojKR5w40t9l7HnV014AkqGRq471+4GpiGn9j0S1QMZ/gbeFs2ShFQjMaZ4XkVk/d3DJZTF691pOThH78+w3Nd3v5lZqf8LpWCNr1heQ0QWuVo/M4HFYeLPy7/0FLh8MJjfyFlD6npxih7VawWtTsG4T4wpWKOmgnjfZI5CjACAbEqv9u3rY8BcXebK643tUPLVpDnDnAEAGqqqxQellvKwoRUYh8aT46gVq05PUkpUWNycU1M1h7hqPB6HQ9PQx08fcfl0PinVm+/84OCs9uLqUG59s+Cqq9M1Gee6UJmjFtSGBqnVaIonEAAG1efaqxi1PRRSd3aR8+F+wzim/UJ+TGmXFHHjrQioX1EVXWLZpQW+MtZ5M02BkZaARL4aji1Yy7vLGei6YMbTs31uMv69PVFBiD0zWVGEt+2pIdCDUKhSWsuC6lQtm2Ui3ZL7ZZXlMqK5M6B3vwxnb2NmJg38XZDF9cDaa02QviYX/tG4Bw4drd76QAwQgo/yxVn1zLTfdKHO+LS9sPPPBoxD3PG9+MstPbfj54+LSdHGza3qEnw/Puf3u2n89p8+KkLFm1XrlZ8EGUT34qcm9/UdGiqKvN22k+FSEqTxE7TKRmQh/iCKc/H/L264Bnp6YKE5Iqrto9brL46siSXGomVdeSvApPuXTZ1cDHCFfizqfYgvLHxWuF/YXyJWNeBz05+llwvlWWIWkd6kRS8MJO6VRzMYoijXsF+7/4hCrFZnA7tvNpwsi0mtJGowhVONKJ6ZCpPWTFyPz04d9/0VV1NNTRIREJ4DE2iy9H5Q/ZHgo9hTQoz6/cSmkBn3mpSV3AI31H5gGkQ5nc8DC/wHZ+R3Wha5cr7U7naLiXbTLFXkur9W1jcq1gCs8hsNYc6aWw9uww6di/gzRh3VJ7FseURNYq3v7gw801uTllcBsZYKvPrcskBsZ4JyKkNsjsEQ3VbhyPb+t0nUoYzDQiDFkQV5eIkCIPtT9lmCCQjFQmNS1x/caazCWJKJaNf+7vJuzpod8hADJzE8SaYvpJ0QNxDWGLO6cBWW0YYVomAbO5fzgSXCh0gajgAY1wil93+4/b/Ebz64nkR/6kNVKVDRauKwBbPyMjtxynZluVCuVKNvT1ZNiYzRdJQum1qv1Q5gIzPACR7d3NQhotNsfGsIUIMOt+WhYdllHCyYviCiPe2r94Ns8UZQ53GfPqzSDiudacILNeuFDsX06+DhQS12/lz3vpLMRCLY//zTBz643ARSslii1QYuKM/yPIVbzeQA1HZRhaDjRaA5gm3gIqhCFtpsH+4/duFb6IveDpG5zFxhsqQDkIg7cEFMqOdMV/SI7htqPRV44hCkIcNTNOx6T6HnwaYT7yPFkDUYbCy0R1UFaro8P7KriPQZ6+EbC1UkXulGpLsyoWvbxsA8POQT0GmHJW4+r4PMriXFpoUuNVrk4AJaaCOciDeKRhGNUv9XAvV2CvKipFcTAvtrWbSxa4B26sTEjEmom0NlF8KgXgqxEQ+Z7nTz8KL8XOUMVTaKH9bBf2D7BGxUycsI/2d6VKQOTiDU7707PlLTXcfG/1IyzOku1qoGjjaWTF4OwO/ZoYPXt4suME38NRCKQiphERqRd9YxL0zG4zm1ATQ17QRA1YanZmcNYaVOmdKPFJ3PBaKWo2ItjBMETjQESRSS0rC79PISriymjdYk2jSPZKiP5gpNHR27TFQ0gtH9U/kVvzy+QI9yfXZkc70MvmSGGh6iZwI86c7vweEmlo9P9W1O7qSloEK4kgo/6Pcyr6ARnOfswPxbnylM/apoccjN7NFj8nD6uxyT8cTnzhRihiSPwyoMFs1K1FWhdRk86T/Y1/sZCXV+xDPHRs9XNQ5/nsMDzFQJd5k6qalsFBykf1hwm4IuNwRqvTODuTuoXsGnBXp46+ZZAczJOPelCiBlove2VXK/XB4WoLriLNgF/PaMYA0KGb6anoQAM9znWl+YbwmXq3TPgYybxaFhgt6tBmp3XR7+FBd1Z8fC5ylkJN3+og4ovdZWubSCJ+hpir7JkoLB1F3NULCQUq/d445MEUxF+KkYwOEDqJKhkBU2Zfmd3VTRByWvVxuf7HGo1pl39QwDWSz6JFQCK5a8OFAfFxTuvlJ5hS6bgbY4PPLtOtA9FM8jdEOH+qVJF0Y+Z8bm6mb0s0Ahpz3PF2NIKymx6jkftvPq7z8pOroWMaKMBitPRPO7uY5XGI5IGMnvEpr1tYwfM6gT4c3B1DGBmtd9A0sdWRpvpAlV+GVJ9wxE095oyarD4x7DoVG2FFjtFJkfBF4Z2u14lIHCrrGraVg8j+MyVWG3An2xGN3vGfdiwvLDjVLHtQOICPV3c/u5K811C37I2LGhtz0pnq4m+a3TQ5rdGodnWMC1SV9kAUZt90gPsUzSZXELhEVJlOfNbOK7IpUJSxgyohi49B59v24MKB3WJHEjf7DtnlPC/MrYFt2S5ruDras6IGAeQcbHUeAmtSVHbMZ00b7Yljhk9NsyeOG73VXfmJV/HHXvI8/pUMvsDpHu+8oJtSJ5Qt3ARFmwhtw3ijrUq7bX6/3AYI35jAIge1s1uylbECbMuCUoxhzipNurB+oxjLr5qn6KviM3GF0Lo8ioIYTlBCOdaodGq4y6xC6GYDgJQhZGt+jnbtq5fXNK91Jh8XJFcBFnKrMVkRqb9xJcJ8lAcA5Kn0Td6X6gIOtPmVJOs3vsP4gkyPJlKdMuMtwwV9G7Rg+mnK+lRMvDactrKOtykMd5QePmSMmoN8aDj+s8AGlhp+l8w1+sDqBoCui0emFuDELxyMMWRfb1dS4x7XsacK3e3eGHRVts12vuW+QGCH3mqVOckuLlw1SwchwN9CGFflOoGV5mZcMNbW0sgzH+IGEreV3EqfU2YvFXRAzNY1JUyMjMgACz4ynY4QSW9w5EM9M+9hCL37QKyx4XA3xucaAtMnXQGXOMVn/zhXae8NxurdllJyBZRov8UKWyAGaBr8iAskvMg8SWasaBgqYs5WunYT/Z90fahhSIiz2tUTLEvumxrXLgSAxKQpizonpgsOOLecTwVlILz76VuJdEVRxOUaNcA5RNj9b9gwEZRusP/pNDzQExUjk8SOnDTcE6WOoHJsL46YrVlpnzd3j8/nrOu02buTlEDYR3QxYIi3Wdm90mqbIrRWGinOj7neFuzlk/L+/yeqFUoePlX8uC252gdl/6g0qqzyDyx5kF5MDDE7OORM0DBDSJOPyyXreo6E8x4fLAsNMbrqXBHDFN2hsOXygcOQahkGUT0CC1Wcwa7NikvEOAVrNymxUqAbYQOsoGFF48zW2DqvYjP3tgAnsHZznsmEKyhwUSfKGzTp4VNTVNxoG1ce6xCuJviTb18LYVYOjeXtCxd4SKxklhjkvGyVYN1qiRWitog3zdiwM4dFmrb8vHfrqqrPup1VdhyIn/hsvslpxQL9IPeZSL2QdBcrI82AzMNUdDqiaHxlUXK1jLdHm9jY2GYc4a6r3t2pQthXHGr5PVRSY8Gc8hMcxUXtTuB3WKIPl8OkU50qqfyT52M/AKXIqmyhSulD2hiYkqmsQ/bdSD3pbGMEKT90mGNAdPLRp1TTp2yRzOH8YJF4fqb8+52pD4kBepy9EP6TKP6uwD8lc2ZXQ0K3sKbtZJs8ONa+wIHpedZNKebi6Ukr3A0Lv9c4Yuh6ihsaNGAMCMK85QXUfGh8uoyQjkNdS8rEEyKKSAJVovmQgE6ZFxU0FsFqdmAo0qu8cahtnq0wM6V5MPSlByOrVC92L7orsavy3Ucz2Eq66+hkgKI+8fvyGNpD2E9/nxIHusnugb+IJogLBdUeBQ02IzHJ6lKWxajaYfHS2U4qfGSLQYY8ZnjrcAN1MQIjbiOcCPHoA115NfkO3Kyz3neNlBzhl+EPt05mrA93hhVquUSDsiF0JLVdKsAP7RlYuDf+XBz+u9IpnEalY6vKGO2k0LBnbxt8VJG1Xy08U7Ob+7f1wCEbYudC/xtBMJnpEWFKzM/7ReUlAh+R+vVVU3HYWeP6q72oX1O6O2oZztEvtdo3231KHGNiGvCJZEj0mXI5etPS1eOw/Fnu22I4e/3usimThYoTNoPvTT3m/78JPd33OhNOFp8yw/IyCbW7HZAUpclzlqQm0rYg9YDPRlVusKTqrr/bgfDB7LpOZa2mQerMFSpyNwwsaTkMh4ezV+Pid6XGMrLnWYTQxH/qrE2/1i7AWt61h8faV4VwNMHJX1UBmEIYpC/20ROn2NNkCXqjQ1RIWyjqjSoErZikTUDqntSoWkTqyceCrsw9d7ayH3FialFGFPFvrn5Z7zpCCd1ER0mVo9qqQaVZaoZKNKVJqamKpTjFqDLmH/gQ5xvCcT9WJ2X5gy7MPzfjnIi+eTUnZ/PTLB11T1J3NFvUnRBYLUHPV2jlE6qjMy+gvyVsWlGZbE5mRQm4RUcCpVJRLuyeB9QxyMbJX+2aP3Spj5wz8SmUETO0ctLp9OaCrljrxJLcxgRiYr52PwxSBsuFggBTvcvUggplfLKc+6C3qDg8PtAyHwaJSj2C+2DLx6HrUQ2qwawP4puWPeXd5dm9FAX7ekfHnK3VjwfPh8LDhloXzFUvpowylGnMQFuKjiACmH0Yf7LLuTu8/W15g9iqHGshWtPy5C2pkeYVooW5GKj1I24iQuwEW/suwjBerOME2s2bhFARnnAnJjmlgHk0y33cYr5xAzoeMlYFwuscipaDRgtNipuDcguoXEAFfTSsXZU2uUsCh+RLJ/StzCV9/Jb9Q31BA3W1vA5UUPYD2EBwH8qrQp0du2kVlReXmY0D4ifjv17+5O7WtmuDWVoGhzWCdNnYwgkWQIqnqJN8st4d1UbYXxX7Ip2rBuCwQGSzMVv0t7AAmXvrzQOC+VZONV/gKo2VyeTlVG0TjhqbFwi3BPZ/uR5NrqaUZ9UeLaHCmhV9dbt1QiA7zPxYSsNo2VF5Wlo4MFgDScghYFSd9Hw9Jkq9oK9jByy2dp7YXisQIiOJ2h1gjETbiGfQ0FyoklpccY5Zn7yUut+vWlMAyE36YIj6FqwrsiJAQWVHvXFEIfE8ZvitryZks8LN7gOYf8clIpmtrPs4eiBq7qnpE+8RGMVwfaeO5RRVM82+L4uWpz/L7G7kOqxVn7GL2lug32eZGuaaV5JrocQxIHWZjM8CwmLyUqAb3nHv73BHrsyd/9rJtpdWbJMg+jcBUnyzqmtPZQD+QXCw62ds/KK2uP67tGJQttldO5yON3A2qnPz5U5YL0bUdSFJBqhlyNJBHlqFhhRA6TBc6hi5TRHEGgNyLWm4wQXFgYwSHcLkJx0eYMUhGl+UBjoXRdR9EMrbholtZZJFtX2Ng8U0jOIBVuLs4VrGm0bqfl52+nNVn5a+zfbQQrhDJwTIwULAQrSCSwXCgLJ2YVl0X8ZEgt0GpSc00pqUVaramIxHtavjGmPDWh08VA6YlXWMdlJR1xB4qKBUdals1qKisPGlrXCX/szp9Jjzp0K9B2NPhT0C1RnnhVvTKymi6XIfEkaQxFEZobxwg1U2QKLN8NFCaFj75FSOH2JeCz8Hb8MP7PbLMBgqUi3ExFzEshsbfL3qvzhzhzLG9b3rdsKAI/Viq4EhRnK3tXveiUBzunnRB4FyNSmfKtEaOj5VEGpU4B2fRDOMcTDhSKRxtzp0jZRVuoNkvCqiweqoifmWL0PMwvdOU4gykw6+g8Ejk/aoVBv+ggOvhXe0YZPMSeH9xDaBYWZyma8HLjIilEQBZ2CZXSqqTkGsiUW75Xq/ZG08r1ShMrxU8UMb9A4Wp+/7KBSVbGMwuhA/YalymO+/Cx9wWb136t23vHAnPZ4TInC1h/9H3WGC7NzeinCPmOXBudCrUEFrjHXKDV33jlYXB9RLl2O+PZ94TlZ89qtFx86cRP0pDcO/l9cv+95yf8MA8D64KqW86q49vx3rm4JNiL6SB44HQSLLL0IBTZARC531svEpdaJMMFlJB0ikrB0f+XFmIZwvJiF3wf/AP4LLFj6cBVYQIMMVgWpQlnetztPGdXkWHMrTIuusNWrXzhUq47vLrrjqy3/3HO2JzWfmPORoPD+rlfzEv7bslX9mmOuZfjHTnwXC7fCpeNDv382tUG3SGyVTLU4gKIgIM0O3LiePjj6dTqr3l7D5r/W9/6nO/ThX/kDrmBjl9beeDw2x93P55/vh/PflrP6Zn6dAuI3BtfNtlxMOynOo4ODzhxZ7/0eXMQauih8VRRb8IhdMPA64wtM2lOO4w7jM7jM79mLh28IVraqtjvURTVgzRx2Tkw/tjE6xdHXux5sz1O5dVlOvp/v0eJCVoSgK+UVuIBJy5eKVXiYadfn7MA/L1p/Mcy6Z6OhgNJhSUHYtvLJdtrYuJDVYAAhDPm15bBpeJ12yY71jDUOVv12ObYA+Nj8iF7Pi7+tONGqVDolungPGiwALp0XYUwGLE3ZCjxRkhXQsSewSEzUVoogI/qPHFi/BqiVp86tS5S+3R+W6rrpvlnliVLwlJT8+mu2zhb09w2Hz7DE16SthLtXiT+NjqKNbwwrMLuVdfVJshHN354IbcHQFR+fpTRfkXc3yadLiyW7uivv8Jp9/hM42RAtoeriMRwI4uXgeJ44rRn5q914mvSPh0v3h77t4Q50ajGetCHwP0feBEtFxlLyqWbS9WIFr4lW3qEpfXmQR1cZ9imyO0RSrK1prbxE46uaYnOeFZOTgnPhUyrukrlA9npyjWDRedYdY3necvqk6cs+BiwYj41MjHeGDpwHSFZlTOAqYuaTW2wJQ6k5ciGlxSciWuQLA/poFYotEUxPVoCD5MuYxSFclmGkObdVPnU8RPH8ccPfdkkrXCaPt2iO7W6/Rq3sQnxlKw91XIaf3p5X8d6HXo6lp+GrSsETYmVkLlpJmR4WhGospvyFHjiQLHTMd53vwzy+nmNOE+9uw9OXVmLnjni+0fqttsHHmUG/+ulzB4vK6RCUJ3QmOWSiGeTvmTf9sZKwSc/Pp42TBMcvb7OCnZj4N0nBwHSlsFfpgHyNFfB0DOinQnoAOB+zIW/a3mm2HI42HHTnksvNe7fGWJeSDOBp0H0T3BQhP7Kb+Kx8dCncUumu/g5yh6ixUCvExvYnYvTjxAXtbOT5ak6qVaYCBNxFtdn7ogrypogVmdxBrOvxDhJxr5PiflfQv4KFm4+Us/UhWSsj4pLFibznwY0US8XrtygLs7qE0E8qxwBZ4Ch/mrTMxaPa4pWUi83wDh+VTEGFZktTWd17+pOj09OVBJjdH41wjjSApob9L+duA8YhCvqCzcxs1qO6ptXJV6oBlcnXmxefUS/OG+KVVvGXQ84+zhLCu7wI/BJKire6GNLBLN9bHiDihLPjWpmXC1ZuUGVr2tLdEHDAWdwEjpH7BWl563XlqxkXKqD8QJtJL2SxBRlxA/tGs5gCZgqEskQVM2PywlouaBZOiA5UYZqFl3rWH1EW1O7X96wNOFsQ/P+PKyBl5AKY6i6Wf8OxAwphEVxXVAXB2+iCIqFaMyrgt2DpC8kEfwTBRsXNmZlxA0U5KwiZ6AkHij7X7bTlHqZOOvBQpMnUxDVnHC1cuVGVUF2T9Ibj3znwIrkXX11JxJqKBUBpRhzUnjrPnRHkrq6tcnG+qOdZcif1FauTJh1R6gtTq/dTphB3XvxZBqlQ0uiG8JuvCBk9blYzgpJmroTn5lHmajaCdtNCxIe4fhhBKm09XYwE9SGm4Sz4JRgrlGXjJwbKYDCCkbmkD9vCiQMxKpLJ/dnZveRTFEiF8aL3HPBSXyetC6op5QcfNxXCfS/9h+1yohZ6+hikCC958z2OjliUsmvevCA4Ocs14ZY7piswDykQBtp8smUClUbLs1MWl+1H74/Lki45kQ0P5VX6ORB/C6/Ly5QOHIzmpMSO/EvjBUbPMRyXUQXbpCZFYuxqWbShupp2AFaEH/+I5aTRj/5fxiLwI2u419uX3VC19R8UtexahmuC6znX6pjjmubm09oCati9TBecDVNryezE4Iaq4civEBOcFWs0UBJ3IUoNCO85HMg/DsBdXGXi1at1xUYO+L/+A4DnFppbsfDu7jp1g3KohVxV5ph/KAqsl5JZIrTaB1H29MYUqaSTDIGVnPjuNHN9CslKzaorBm9Qm//yu8AsVXh3z/aWIaC9dqSVfTL4MIX2wxKcmf6ypMr0mhCg0TRV39447/gtFPBhkJG9zkYy8+lDS2sV6qDUV+xh7DBgb6GCL6X1q8/tkDFLBIJWI3lGZOx+UXbqDUZ7FY5jK1SG6QqLjVE8Ls8tCnFd5hcqkysVEuSGupStpELq/Yk1Vnj23n+oZ4GkR9Kp2dTwcMC98MLh8Hwnw71gcM2f/6JpfeOE9vg6mRcozF+fGHcnfFnGWElP1fdic/KoY6WHIOdIFT02OBKc+zEdzjLF+GQc+nh+qAFFihUiAnknl4yMB3sJ2B9vpZm5E+fP9SC+/ed33cb6v7nK8NYqh8HFXdKd1JH56AofnEQ+9GLk3HhoJ9fr89WaWvjjKDPd6vxnwRz3HHXjv20J1IdPJtIRx957femY/qfiYm3brswUmsBeEmmrgE+qLqapavIuknkg7cEJJOuquCDuoYlGQVg+uStIwilV3bs1Tz9xkxiBtGwKfdqrFc2Qnn0F1S61z6AVLwvAHb+5nuE0rugOAWUjlcJkv7MJhg351vOe58jp+iTBeAlGQz6SAHJW4yH+L6BiDJfETByXWg2eW1KaWO8FCP04UE4ZPKoFIuN/Abx40Tft8shjRqLGhlSTSeHz90hxqAjPaABXBRtR8sn+4CP1IA5JHQRtxEK64Zo4tuPqmTU1ozcFr7M623tsLvPcFbuIGnWCraS5yyDw9l5Pk9quw96tQrSisnLAItI9yKXTE1yWpoAznEe+IT4lFE780QW4bhu0/sx56dHuZvqy7ey8su2x1eXxY9mQchhvIenFXhGc47r023v2XzfEln8QZ7VepAri2/r7F/e00eUUSG2kDFPlS9fta0wsEIaty/eYplOkNKXrzYVVq+hJNPnrLmUvTGypf1QlFHVnJE0UV47xDcaAp7wwjLq4ZohnsGIGLF61eKgEFpQprTu8tucpOqkvUlB+CD1XnW1ep9j/WUZtdUr3DH8kuOfeJT09K8Ouh4FlksWLMlLky7ryTpBqhV0+TagCtjJGdhmNRRg4EVidJoPsbJalgTdz8NVYPTBFRH7RU1mTmd6uq5Pgb+IhOtnlPb35J6MrW84Re8uFY9bYWiwaMgQwUw0BtUPRUbVcLAV0SlBVREHLj0HkroEpjRR4Ld8hCQGVf9vBcYUmiYM+FaHERMQB/lEGz7B6Z5VeCIPHhkJpyjCwxXkn/3cxJdhGiE0BPeKeO+PEKTwjl4VU2tUNEcrNG301HzSoLHeSBpIzW9jaBSLoo3KmFrl+px0rYkkiSLyQtLpDYyQDCJXEkVKTVVbPnb5pT+f2HYvu0kzjGtXlVQmL8VMmkyYyeQlJRXtqmGspule1sTW9GeNncWUU+lb2ns2ZM1SLZZZ6oas9p70LZRTxRMVvqcuo6rVrzZlt/e+bqWmn8q2wT6ZieKEDMg7qI5Wvq1hTwGVzeDEcyUU0m4vKk6vSbTBxdxiuFyAKRCyyB4pP2W3o3VR2/vy8b8upgdhB0Qb/GY8ljwHtFcsTD86EXBJR+Es2TP5gZk24dV7ZUPyhaBJ3xn3ZS/Irx2gS9ri6TX9Z7lFUNmEb9/VAf7yKzAywa/ukmPzLj7b8HDu94vGIoX8VfjoTc2INlRWD9NzCWYui2kou0GqEDOinblrfNfJxZhojzgxh6/c0N0He/zzu4gov0GeJ7kjK+6F+4+pP0JdnnOZ2FyZzIxj0M04iQyTy2RiLBKJGUtnmLEyCdayihGe4HsmLGw/oBUeHmN/ICzsjD8bi83dJ/kkKftepvykTPnuP+eU/T4bNztWujQSqCTpgqN/I4W377kfdIOBtShllTjx0GRbPT5UEivUiIvLDdlqP1ClidmK9t7ZPRCB3RtxnU7Sa+kl4ARRNVjHIOjpiRL9faG/yqhkUAwmVkOkiFERmsqiZwpu+Hq9LAInCBBULibBJPDfCrBBse+gYedYpYrQ7JfcAIzaQl/xfxjLy2nXzgqCqECMP5Tbim9d6qqrnxcuWpS0Kz8v4OlFcF5UHwM4cSHLDsEKR+ejkRe3F8Jg1u0XkdHzo9YQk/OOWePoelwsPiWF3Q4zOm8lP8djeZEyx8jBOJ9116KOocdrGwL8XfLMSmJ7amYrTa0BDHjxKxU7ZOqgqtVtVEQqto8ASt7KgeBx/63pTYIC/w7h0NbbCw/+Bag22dBzZdIrLRwlkpTUjItSKRzt5YAT049WLMQBS/pmPKbPpFccYOjMawU2iqkrVDb5rne3ftpfAp3Y9/PKe3Hkpc9nPaZxrq6UJx0C70JYCl2+FbJ2VzAPo9Emi+FnH0pzPGGAVbR2ze3YSqlWV2ZnvuRKhdmppn8OyUe3OCPIkTqJQa957fnyyQp//Z/6ogK2wyL+qFo5+JcHIWSeEOb2lzT5xZ88UmmqohWnUjOeno3EUt71sA8BQlS00OGDVIxLflYkN08HFyrlCQnKZKFAlQx1qSVgYbKtGiiJpIEehMqwWKjkoCZy8+82I7fCJFUY/DiFMo4PenW8MjS08vgr7JAUo1LHRtyNAmfeA68fVIITidqwu3AlFRkopQgMSf/g4vK/0mE5CWIthkzih+07gkLYxWxzi4PlxEu0WDKaH/b9WzQCGkNDbfmPEJo/bsH/97xwATnwAnkjRhCKQvFDvW8oI6978kNQKEEI/nplFHQHFNoIhTdBoTuxYUM/TO9FvoRCXvzX3xe1G4p//sW7W+LAAUNB0uw4iHPPsRPWdPiqlfoZjhmy8HxS0S1S7PZmzi0E+fcbGcvQFBI5O2SJiDQPzyKRU8NmqH8c13mTaTcUcvCBw9rkoaLYcAW2vreKwj/YiMjhaTri3nT6CiByaoChy4M8/mvlLjm5NWyuKWW+9VC1re3QfEpz+EFKi0g+/Tcw16JlqEnsgY9oDL26X0c23U1rb1tIG92k+7XXoIWPsHv01YSHX//GntXQHG69UJd7XT3XURt6YEiFjmv1AbSWLAN0KjeAtwtEf9AW2QfBtmhVmjSK0udmV3ItNB5vMjEXg3VMEEgOApkA5OSxQP3wWJc2JZr/6NGlAamubo4MbZji7vVuSJnhe/vM/t5AGwdUgMW5ktY3nx11eo9UwXxf6XnX8P3zcKzcWnbTHY2e1C/qboxPnwQQZu4shg+Ut1Q/v+Hl4a52FU1VUA8EhQkJV9tyVgMRhzJtHXMJBYEmgh98lNEX0y8gm0WA3jfW68dv7prfY9cWhe0u7PoCXnR7EuMW5uYmQJUY34NGA04HWXwJNzD+l/iWhWHcZmbakWROVoJihnl9bbIl/xu/4mxVEwA++JgbKAgnk1Zvcm5He+6BwwyOg/7NSTKK19nkd5v/+xZLv7cRcSDr2M28wNXzF5YNJ7iVwhpDKmQDprOPaq4jzbkjKge7Telacmd2dj9nBlI+UhHyEnqYDHXbkWy8cJhSm1mIRNiwO3Yv+IbZ3YeiYOk4anwHC+/s5uIL6N95lVPL1wt/jpeS0Pes356bjnPYC+prm/af2H79yc8q+JJjnEaP744vPRh/6Le/ReFkvUgIqLV4ebRuyn8o1Pdlkj4hhyYDskKE6334U1uLdxKks5RNQLg37yA/fs6GFOha4wpKy9luxWRXtWclhRPOULhQN31JB9/SA/dzc49bNvhv8qiNs83gWca/g1Kkp4tThH77kem4fcC5AykJRkkRsDjei6Mv3ZjgluTQVm3CpeLjjXxL69/nr1xoqieg0YcgegUfHGaR59y5s58e1bnUUjhgpjwWoau9JDLe3984l+S2DL41rBHISXPrSgncKyDr7U/ZuAluXWjt4Fgjxi6eTDPBX4wyj93I98iqiAg9vSNiykDikvqTFRHJEdI9lfWXthxrO/CYN4Q2LtNmFROVdZio6AC+m8tWuoQeAOuKhMV4oi53JWDdw+0C7AHvDZVnTd5hbm6s064xcHL3W1CxzqpZ44NGH0CjvSLn1ixM2/1dETjXBQgGkSu+qNbz2XcXARq7gfykJYYJ+HOLDbDcOVcnDnLx1pHV8Oc7Ojduul3rl8RJ4tgVOn1Old2Ma4/iOxzqtdY/3e2MLvQp8alrAzzFDDovSk9YqSvwAcHbCEl8335g61s0ejcaDYAQK11bAyEbh3w7grhh9K8sgEoRyBpUiil4nr2Bw76btHnLdIrGqD1+KcuclQOhTf4O14RGh0107wbdeuIKsNepBET5Ykv5umSrtnK3bTTznWwR4Ps+kheY7zmee8ZrHIebRSI9TgCZWI1qg3pDP3RdvSdgAlbujOUWtvLcblyWi6WNRNj3iscx6bIEgIdJae69/zbjA3v07rwthT4I3HaIyYrJ3ll764eed/OZuV0Vocnezkbh1ua3EUGQNwf+U7/xY1JJNPszP7K2ddBrKMWbKooVi+OzKiM1SVNAPUJVanIQ/pVh8CLbiyq6hrAQE9VleBFOdEqyBki/k8CN9B8LdbFTRVQCfWAcL0+sud4xsGUOF4jGnEKjg4YyuYZ4p3R3X0FwvRG40mpYolyvrFZWjwpN6NyAvIAKxd6V8F0d8csg7zN7Ayf7a713rFsAjVboNXvxyM5Iq/fsxcM7P528prgiD25/EowTodLsEbgzHz2iXnudI/uY3qoN+yjiw91JMikyPYnp4kkTXIfFSkGDOhIjhxtcp8uxX9TkdFoGGqACgdw/Cq1wuHeRmzrF3XXmzSorYN1qvx4EYgSI6McLvc5Vvz0a+e2K7458rva4+gmFL8lu/Z0p96YgcDL8SKWmB6dy4AQqA6Aq+wbaijd2ObEWQFSZmBY0qvkncqr2JNK1owF+KvtNC7q6LAwJiSQFQVGmPE/fgWvBCl6qdH+UO6NEb0LcXE+FhHZ6Rvko+PwULzvOxHJIsa5G2zaEya2Tq8x2qV7POfZKTwptnV1USSj0fwF+AB8EUoCKg7csSYXIf39sS5BDfuefvB+R/hvNIzMSL4c8ympw3jGGit557ReG09iOaNA/1zKwIS81QenYA7c+eLTsHFg8MwceCk7zrmaFdHDXVbzp1q0LdHYTEB2BTc98Hv35NVgTpPSz13h2SZM/YpKRUrwywF6p3VHfivJOquI/+eiv2b8E/AfNbk/VRU2HBD2PEQuhEDdCYCV2OJYTaRg7zY+IKvRIGXyw/EGKRyEi4jRf6jnoAdvY4AHnLt9b4LcRTIL3nZHV0Gq7/ATbt86dvfOd4pq7fxPX5Ofn1vVrLyRy+Ow/b/eTjj67XDTe3rVzbdGNrmOZoasKC9ee4c8fnDuvmTIaNgZGSd+YCgj83t56vvHYsQ3jgy0tqPFV1BZU4BbbzUvPfkCjZ9Don/sP1zP2bmbi/MEgfZisqjMHue1QJOQi2fwmJwH6uwGQ7MBz6wLnhOdExgk0MC2sEIipqQkLefxk8Gcr4xze92rI059v/GXufBkTllP18dRXrN6uxtk87ljp4hBsX37tkQ4p+ZzzTDcavR+NBtoNnfU+x7ZeHQaCwTM7y9xAZ1iyXK4bHH9eDswdi1OMPZ2m6vydumo9eR58j+kYBGDlhFLs/7qft89R41Knt3uN7CW+9EJIVLICjLx7ayXsklHJVXGb1wo1iYD6Hfn4ijfIZRuB6ZX7ft3am0AK3BT9vQSzwzbTrSGUKNoQfBy4VBxYBDLjGsPuJi09nvKYfe7CuyuTscjY6CCx3g3YrL/i2ee445DFda+jFHl/Z03bwrPeZNX6pR9x+OADevHbhSO1x168wz/6BIIDPzTaZ56s9sLhKp/M4/6t4lj9Zez4i7eMf4P6zTgzLn9f63p5c9e9NzuKm++/NFP/fNVKdNKT4yAJue5ic8HsRjl70utiFnlVlZK81tEENGFGJk1MEUr44xMJ57F7rv3GVNUH4mSRj39zeV4fZGxs3HMtGrE25WdKWemakQhsdtaNq4exfzx/r1ThjNfqrSkpJrGEicagQ0NBH3GjSoo/rua3AOqozs8fp3+FIMD5rZ101dcIEPG5qpuZ9DUiivDF2XgiYv9ss+MMGysKSMmo81GFVyW+u8/VDDZuHYOvWh084uDEcXTc6EhyINmLvZXmUO+h7NWLW5DVyOrFLaubLRLhb4s2fbki8W8ev/EXIz7gSCq0eXiHk2swsy0r/UGWdDcyWZBdvvgv4ZnPcUTrNudTJ8KwfnW+yd2mTWjmDHV9a4v8sCL2RDcMlnoqDvU91574w2rOmFCxTL4EqIGJY798jhnnKJ9jrP6mgBQFsMg0cUi1AvjeGR4+JPFWAnugNMZulLQUvseUmmkenDRbdEIRmtWdlVD+wn+L32jIK4/tiiffvVOOK4KgyKQwJs2fg7gPXQUCmQbyUoW6xl85WOk5SXyZslYjInS7A53Kz8601MrQjxqhESpwFefpouCakBbfz8Mu3aG2sC9ENzeB02fs7NYPV0wJIZqgHO8SZ7asZ0xexP5lhUI88M9K8bLxSe7fYrkLZs/JDfYjLopYyI70zCzzQI4kJjOh9InvRmiSyxbcDgXA/l4aKH2sCIIgVaETVHPVg2WjdvMO5w+dZMz1raP5b5RAP74yfLZ0XZAJ0wXTpOlHBmrTn/DKEhTGSmXEnLOeNRe+Nufp01Jpt6s1PPhe+fm1YZq+d3d8wt28/12F8r3LJ5IeAmwxHkA8Kvj2VbWBo3yuvgZkQWbxJpSb214kFbt712SEKC4aMjWVWkgwJIHbHOEKyRY7KM/zx3ufLUF7E3d1MYcXAF8LF54jz5Frz7UTx+PBH4Hh6nOKIB7Rliqrt0wBOxtD1z6i85vyZVQ8D8+DDGWfADihw1g+jhfLLX5Q1UrbyIpi5UNr/u3OvrduCOHs6OPQQDiUsytzFxmd10oauhxkN67iYrSUlXbvr7ZCQC6H3Q/c+/Mv3A56meW/P2IvLK0oJX87Zc8epnJiCys/qkvbFZASOi3MdKO4OfvtI4OtJDM3JbtXKaMuyxx54Rs8nH/ZbuEZ1UUJ/wXTS01c99K/lcu2AsQpkoxbmjH1u69jd75V1xFzOK/+R8CQmmdU+JZTdAOoYWUEKyedO6hU4YYsF363PkcFl5GsvHTNwUa9ngxutdQshUkzPmXUwerMiCTzJHwy7U2aNe1tWh2c1vzWbDXTXKvdqVDdIyMsjmGCXYfqqBSK2e5qCoxOT4H9lEgJodzOT8T9jzExUoWNoVIFa3lyLVGtxpYlKtjY0qttMkUVqpRkS2WNGlfKJuha2ehShaaCKEreO9QarCZP7IeqJXFnpVBjShOZOmoY5KtX7jToHFJwX7l79/6C/FNItunlyvGsfy26q8nD19/sB723MCnteU5DJOsVHh8CjwR3BwxjRyJ9Z9b9lY7uxz8sj95ZevqnGefozqdp29Imrk+kePbkvre/7nVj8tZ+lM8f2XJNMRXiZLYZzpchqjXfFt7SfCUez+SoHKwD6h6MRlu54OtNxX5pgWya2OBQtnZiyGGQjuX5hp+jOA7CJ8IdyoKTjzk4bgCcuCNd54WdTbwduYW8vZ2t50Vd1m+FHAOSHajGoQPl8QYEpzAJWI7r/3FhdqM/dVTZ62IqVYIyMJ+a5X0S8em4rze/+RZvtNt00aF7x+iORTtGd7l2ZF5Y13WH35JQ47sH8XnAyY8kKIEqhcQy52TFqGqRSo3TY2KRWVJpGVYqLSfK1MjSRAUbWSrTlBEl0gqcVILMiT3tf7Y/Jzwsf+hkuCLs5ur88DDzsgN+8LMOU1xtfS1S6KXKZ2od8fRh0KXs036dwg691+j7Iq18Beo6ndRal7i1wNfkbT5KzXAdGSmlbs+pWZpglDUTU1MprRqsiDZmHR7ttVDpTJDJSwNJuAuSi8Q7NXjSSCQCozbQGsgbDasN7QgFsTM1uzVOrWmNS81eVIUA+Q5TR6xa3RZbgdSh2IcHKbZzoHjcx9HewAtwnztgONyn7cVx/kMmdljuzAwCcOLCX16r5+bg7KSuz+XZkvIcc1vkeE3F4orhyLb3+9v3De7rKx2hcaFZetrhhFxJD6pamp3PXxQ1qFCgByWLLPk10lYUzzqj6V6uOF9LBCSWZSxl1iGWiR3sgE3u5/QFgiP5fQmJCL2nZmncUW8ja8CQVxbLQc+V6MD4G8d+lAWmeTF675asvq2gARfZg7yvHQXHrc3Nx1TtA7wzVYFl7EMNPdPJw6/ZOgJVGWRlBcYHFVDlOlxCoj6OlhG0SFS1VWUUByuUH/+FA04fyYDTRwXA+WVyOIsi+rnI+82zEeY15umRhrevWxzxSXB99vvsECESFLX0VVj+9J+HqU/H/CJa7/jXiC92D53Q1xn7qTajsdLDw7rSZmOM9cf1XUPx4RpQtfiyqnDMUGccoNh0KaXu7talhFFNqTviSzj+R291GAdiY+vSSfFUbRSHSRJCudH4iAgGVEiWcOLV0ZSE9Bi2DlrJM54CDCGVbF1GTAJZE82JJ0lgQnREBD4IyiUJOUxtFDU+ncTWQWwc0nSMhbrSktNPMqF4Lqk+z7YWhPF4Et2lzNiBguzVpCyM3KMv+JFgFiqRJYsvxTjrVn3q1OFVfus88d/jvdrDSJ6N+//fpovpPORhLePxfyce3yphAl8e9Pji+U/NZ9lWczxb4042lde5v3pyjpmJrbpfl6gZPfY+vujclvdRVQub9jVn3u8suivWzy/kj+nflQ8r7r+uxv23aVe3X992ZVuE3z/9ibs3M3dVtQbrrhADzdEZNO3vg0r3+UR3Ec644DtnVX4mEQqTJhtL99ErDRug+lDM79smOF5SF3x+XqqJcG+hwbMXzoInuX19gA69Y1J5BcLKsINsq4vK62t68Sl/u/SGVZXGtrw6paFCFTEbnn7208dFZbV7BXWhEnR1U4nR15N+uEse5uZu9H8fud52VuLjWzit4MtkygDp1Rg3N4HDT0Kt0NLhCeEP9MfZlzz7LsbzAzxAR5fw4p1diEjS0Q07l+SjRrgJ5WSSNC6ATOET5cPfOMi+Knj/mkIF7DWLvHEtQHlae08GTQuwukHIvm0OYT6hpK6rdE/3t+m2KtuzQjJRFhsApZyG5l7ws2TjyVhHDVI3FdCJ9nlFTBZy5a7eR2baYrxh9lFubmL+utvWdsuQGI0+iEZr9nywLrq9NgSNPoFGh7q50WCM/g3T2appAzj6t+jAO6WNpU0v1qPRe9HoMdvKyQx/T1SeniVNwDo5CQuhK7J5pzaDH/HcA/PvULoInEpslnpOYR1ObkyhBr/kTd5JP39+SL1BlX3/r5smiz4J5zZhbnug6k8yUW5J7zeEzEMVqIedv+sWu1TYVyWB/fAzQg09lpyUlaCYZVB0Rt+b1Au/bdKg7HYjKSWuhPHZl8VM2un/r90Z1rr7wc3jOubGTFUQKvDuoKNLtDhnF6ZdiB3cG9p6zuQTX72HVlURqNPObdHOviwmZYSx6uCZdwd48BTsBD9E/l+v9Gp2jvuZ///xCyYsw+S14J4Rp5I1f52fj1tW1BUNwpZukj+SiimzA/6VAU0V9K3qJbi5ZYjopwJ4YlYCOPFmrIvbDoH6zP1yemN+KQZIUIJwc/Fj2aS6OFKtarV/eZAwhSOJ44CvU6MdPbuE3b9rZZxriA8K2QrqdQx0QztkIPVnJ2P4HHPiR2k24fy9sK4fLh28gGCbMfn4TsutBuukoSOurrB0O1bq9Z5WRqtYL/x5bnlkUsd8l1/VtplUnEcdAY6x/KuRNVcYPf+VJIn8a7ME6eMp4y2Py90csBrt8wor73saYZ3xpcfKz2BWHWzaSZBOUTcDjzF7DL7evWhMXkbPCE4mTRWX7zoFWJbkl/7AqODVWJnpjMMSpLenjE9GtG4qruu4g8uQCYSxZO6v7bgpZzSTJgRMCnLR3h4lSCyzhyL3bwlswoFTvvuTrbOLKCptG2NNScXuNI69N7iKisUk3cUi8AlFWVTsWywGo7T1omSua7TfOA7eENE+Y/IJ+WyTdeaHN/kNuOqoZOlyj5iAJAZAAveO/fPuqq9vAvLKtt22+xHdrIR6rnH/u+fW/QZyr44khEADKoADRxKNHVC5jxYflDz2A3qmSmhPmFB72CjccIaS7naldMwa0AMPckWkX/HavgPZjY7kPClX2SYd2+TkerHxJ79CPRUKlUf0jVV4vb0dt92lfKr46vR75c0UaEoRtaeeYe/u1dCzN4u67Tkz5udh+O1lBxBpqL1A39W9/KgGXjkr/4+0CiWT5HVzdENnk0IaphFb18uUVHVDY33jj35V+RR9xWmhS5QJarzazAvIMs0mo9flme911bjW0f69Xd0mDT+8tuY32NpQI3Avl3CcEm675CFBe1+az56q/2QCtKuWKpZCXPsTE6AhwajFBXndXZv/yPT36lytz2NJA4O8PHGiMCYo7uROo1BotFUhUla+YfVqr5B/qmSbZMKPf5FruuICKG0riStpi8Vik6m4qCSUcj6Ds1l5uVQLpfAVcHXax1U9FBMy4V0/quCxScsIAuSqdq2nrspqQPAv5V3+UckA3M9lTZ18VE5NtHeM5NjD8MfjT1x1b3KypDgW1YbM1/x5FC7v51kWN9PzzxsDPFd35um7AoMiPAfgjbLzA5wpcj50RmrR5invkK822ajUV+JrdElx4efhJWvfec91F5Iw6elJq6DWiR3C04OIA+U/71G+Bqgw4nllqZ3nttCrzar2CX3nYXUN5aKgys0cmKOFpxUJNcun+jOWaZ5EeKKudCZgPNywTkuG+3MHTPH9Pu9+p2M7K8d57H5UtZxJ02oqM0oA77jO2tUpot8+OOU8w5d3cTp3lIBphyIO/Tq8JqOJf7BA+aegFwD9LKATcp0bqRwFJi+uG+iA4Aj/7bxhFYm2ElsIOx7cW64DJMgOQJfbAf/KBgtPds12TYXc/WQM/1oFdZza0TGnrqZdASrgGm3527vXEdqlU0t/kFV7GWLUjlZmnuQ6mzco65TI5GvJbl8TtBzwCypHql3aTurNXvIH6c3hre3bo2ganw/hMkSoJpF3SB+zAtiVD0CnF7i/XVWstMqXIAj+swHfS1FQ5dZg79ktKSYWy92DSqWQMEkHLxqZssYzOIQpM/Sqr07ISA5bRsLo9PpRylw81yIQOa7jYcV146K7g7oDpbX3hTLhDrt0+3N7T8UsL7z1YDVgF6FJ0yeLemv2aCofyFihjIT6D3noK0VuUqRovQ+6pqlYp9Vq1MFbZP3c/engbt/o8tGeKCcj+dB+QOkNr/BdFXCGoNLnYTA0kPvKKkM+TRCKDgz08MBxQUEkae/bK79lhdYq0OCAyYGNg2Gk9SMbRgClUlAhAxHKlwT7SwGfViUHyUguo2E1EuLsTL0VDP7llCAzPnLdqD7JxheL6pvrf4PhKOeUoWnh/jodE9BdHDZrvxgPcjCrOX4+s7NpRdWRPi4UYQImbu9Cp9oV4Glply6J+1w9U2erI9A+ftgkcbXTjO/Fsx2TJImV8Z9DNDsYX7ednXRq0pdhwZnSSlcCOI6QZU1spyX+vQ14J8sPzPfcYAOJc995qkK7eXuOx+q9gdn/ux3v+ARwcv30CSKcpu4940icp6MiJRu1pnVBElTA3lBW/6miedGGQAXtJz2ZzCf6snmq59GmAeZvgN0qXiyvoG3PzuTUxz8xyWV9M8GnKPXv0Qcwjnaa8duJFrukiSJJ7F8Y+/mp1Y8H2MoYbo6EroiI0vYzfgdeHe+WZEb0LRt46g3y8dS5XKOslmPHnJ72rZAbckp4M+mtPc4Etknlp2yC9aZqla4CfrwQ5OaYsj6NFObgSrcPYbVeKUPap3OjLRXy3j8tU+QAFSpQGVHN5tE/BeGihXwe2hgu6sXSDmwiiJQjllyJK5nc9zke7wD00RJeYsw193zPpgBSebg8lO9U1vTD1BPhJ+FMQcs99+6qc1rbs8vyag/ZB3t99h/9l5PICR+LlqN5RLjRQrjPEiRTK6Ogg0ZdzSthkOfq1Xq9jBkY7eWpZyrifa1VRG6tIS4uh1yK3AjZMdn+1+yvXamjLNuuKhz0F0RfPJDab0IbQ9evXJ+Zt3RAm6ex2G11Jp13lPkm8tSGvgBc3voHXzwm/8aaIJNMmUuYVxMA+5//d2xkDTeQWQrwvU1nW4legB2VCAkbdwYoAdKDvK+YCP9K7K5d5waweWdTzt7J3NpBr4GJMnMaKOJtJ4JJ2StdNaeIHdyHqCRWN/yKAvZWtf4wgFZkhoIeFz5jmJ4+yueam90T18Yeb+tKsMbs+xvkkRlhjFxrb1+pwztrUvlQFWYX6hwm04fVhqUghKvIQRWNMaFNq270/O/am4pCY+Zgio+Twhzh3FK/DofEG6LPT6Y2O9ZG70+4aD/MXpwMl6wLrc5rjQwKc3IUIlHEE4ln8CiblqghYtNnDpXHU2KJX6dD0i3Bx1u86nq5gQKcCVTNAhmquqyDUGl6yGWYilxJgqkP69c26vVSk3hi5DGLTaKI3jABpgoJikJFRrNYKFVwOcEvrPw4eBzJq3T8RlVGE/pEuCAYbSpV6zKJzSSMAZ97lh5vu3LurLYNOHvxyun4xjhIRGzNuR1Zp3bUxEVU7GDxZTtaaDhUtJcdUYhgXBNUs6UmsGaqBlQD3XrJFmTbYgu0TdlANo+zlQ51asyGhEzSJ4LtH1uL7Zvtne1/tipoS8U/FVDlW8W7iv9V/IdTerTxX26Gz/6zNzkfP4WKnyxT+M3cCJNiONgCtaQ2WsYpi9ByiHmA8Kq7cy0bxGyl0WjyRjTL35dLupx2ZecV2YyjIw7YcZu8L7amt/fRo4A+JX4KOuNedAFiB+lH8WQ72tzVNXC3myr4gyFb0LXZ9VUxWMoV3dHd9fixX6eAuuEfPYYTAQHNw+Xu96+2PH6EobCJ5r/Jf3hLECgQfx0nJj2qKmSlp/H/dDZy7AbSA+TjQjQL5Ku2l7qPSxKf8jFe0yIFvT8deXlsUFCSz671JqWdGRjNCIjJutELedvpC43XirI83XZtcVnrWRnmiM5IRBUkJrJ+hveMJXwus8oX/yU449bmO8FcpTt3P1xFz4lsoCx+sfT1RP1iuVcl1AN0dIxHCPRwxNTyZ1okjHa8et/JcbsRn8jEGB9tQteHLPMAUR8sOlgXJYaxIcQ1lR3m+H8kmoXL+FZuSE00fI2Gsh+GvPpzEUi/cLZVdm7zRSaFsmj+CY/7+0oDYrJ2Cb1/TNHZA5Y177wFu7IIfrcxWyrD7LVTDz24YsjB+lRMdN84mO2AnVdd6/bcst2FEhU9J3hoaVZYbtOUfdPRRdQgb+sv4xW5/G088Vf3ezz/0C7r7HBGbnjTTmrxxooSum2Yo7pWP0c3AbVF5zO9tYB/R8W52Y4/OGuBljCuHFZbGC1M7gNqYeLYk0+EcS57gV05xu7w5f27A2apt+yhGPz9WZtZfXMg4Z1eROwtfAvZGdHgfW58j5H13s5ifv5+/v7hYW5BEfRnXxgBsZykWEjeL6dObVxUvzzGyAhdMof1cNzoSCLlksmwn756g8MDwhGgDDkNWecT7Hqyoq68juBy43wsnYieUfgkym8VlxeVXYXhA3xlSZf+I9LotIsWzXXC5fxwlVntbocA1qa22E2f/hff3WPIYG0GmIGui+wDzjkEpaTYh+2kHI0Sgkoy8q2212yBOwLuvzgqdn+sDl+vUVUiBUIbUqMi1Ou2aPGNGrUNJRDYUBo1oVF71VXL4JNJcTzdQX0chxKStek1luWcyw/veyTZsNL401Ap/U7r1psFI0D7dg20Di72VzirEMDh+Jm14fA40MsHkS1rWh6CX26uzd72q/dL9TCnO4ngFw8jF69Z/IBqXvPqqcg2OWV4mkcuzVB04rS6Tly6glzKuxbszlmFwawifQuGP73RysC66u/QAi1IHY3/fEgxjm7XAIt+9dWYRbh6n3K1K+EjIshQA+6Tm9nt3665M146N8p7nXmmzL3yacr2PDw6fzRE9vzs7+9Xxh0Ok2VkHhVk8lgEg4ZRGc7n2cJ1jBgDiyfKOiKLNzDpOJ2cXgxO4hSDFXSs7nAfdisxpgeL7icR+/1LpCkGKeIwDreWnFOf95Mip2BVjPe6mJJe4JNiPt+Sm39HaO2dto38tekQqMeyHT0c2LWksyk2yiKXV8eo4sshxgSa0ekGs4UIsbX2BlN3J1Kwlzda7BP+mFGrYbKND5PLt29trc5N0lcV4jXhW7ZEENsV9AZ0YNuhlAqwNSEpyUFpxaQF88xrWkalxWoWUV58gof/HwO23R5IuCFw0H3qcQx8rNLyumUSy2q//q3UjfLv4VVFXa1a8n5JUAxYUD9qVswJQR0ai2mjhEAW7WfcCY3lrmH113Rx0fRxiiJUt68efs7BBDM5LRiL4mqsbXjG2lFJO/xIkIatMya4JobCrBAHufGlZ6vTJ7otgyjb9k54vpYNc3XehLwVNmHBqJG2KT2hFlKGe8MOqiPGcyUciD0exk2XjPXTe/ksfmTokiD/zNn/e4aZkxE4rNvy2yoXj/r+CfqdDdwXzAdaucvRqpQAnCZzouiUh5FxsvyzBsWbS7iIv/BX/sbfuYEb0ZS41G79bzjwBc5n9UfD8/ZWyWA3MP6ndg8QMkU0dSOnLEcRHk5Bx32IT1NAXDxzGE1DzsWUQgtCrgqpGJFMy6giBGpdNxWu0X7aCnYTVvUNkcYJSEr0UDTjTCPGUYYOo8IdAPmX4N3ng+6LTDJaXxn91wzF9AdpwJIMoPFuKwHNx68HE2K+mXWW48qI5R8GE1fvzA8WNeBZa9pkBA/rHJrKE6uhSQgFW/MgiHWH7p7L9zV+djUH6qBhxnvGczD3OIO4SE9pW6Mv5VGN1LZwvzOOA9mPTMa0bfo8TuOU+zgQEwwacCYrtGazIJsodJuGmn+4LmrnNn0c6rhe+WPBCRR32jjPIq7xDeVVlUbcCPBDQ4RIqQpHCfOoqPxub9bKdFXpGGI1DQF44x7L4b2fjK5kotxR2Rhs2liofzHLHzq0WrFgyk3FVa/sMJVXvarBVC1ltWzFzl3DUtZUochS1lYhavBcTbxoHjaVi2c3ht05Znbd+PQ9lFhl0NqaJrXEBb4S1Jcn/yDHc3tch93/c5O2GjeWlx+E1v1jQ5ZzVxKQOTGcmpuirLvtcaGX5NxYq0+lHziJG/ePaxCRhcsm46w5Hs+cM3McKe91YQKrPHjhlJkTEeUMl0+A4sPGOhLyAODUMHBeRy5lZtdRY2FPQS4aBwkWndMo/XyrpxcFhi2v4nRfFarAGZI5UkeOtTC6S2vOwsv245aV9bGSZAfKcetLt/egmNwLr8XFStw45l5B7qrrQSnBK53FpUpaH+fpfC9v6Wwvuq8oB4QLXCCveJpCv63OFmVej/hR4eZNtBx2qjRfo03osIiRaQQzM0IvZczsUH09b8jDm3DONiMW/KuZGRGSUnp2hxIRJrm8JSrvkrynG37gMsJdf8nsvFZepdP7xipICKwu2erapa1m6awaZ9l73M3H0s02oa1rC8J63I0G0THUnO7OvXcU9jWVXXD71cbJVYXzZhgqGjfGZZApLD9TDeT+8+uh/H9GYYZI9g5qXjo9XVYLRZ6v3PVHGdp4+3zVMgsI9F9Q031PV8IaCVc10hp5UzAoI+06VlUv+ZmbqB+1fdiiYcpMMUTly/u7VOdrCN8/8//74Y8Hb9Zy8f+D7OmfBO08Ibl6SI9w9cfDTxX0f/5GAJ4FUVMZ822L3G9Q1KE7wuysKJyAeGJocUqLFm99SGbugj9pPIC8Z2ZgCeQnm4sj0DaJ72H5tHwaLN2qeKtNPqRDMSsnItMW43MrqqRDNKso4mBNuZIX1QHA3tPyIIOp+tkJY9DNJI9B69e3vmMxGDRifhLBG9ADMhb2oKd/vhs9CH4tubCB9r9whC+G1ECz27SWtz78WVG9EHlysGGJRuKXDrph2KnHEvg59PvvlYcu8WjOhDvN+i0+L58CyOdnLJx+pIm496MGEgsW0JbGhj22RG7KxDOazsxUdPs2j3M6BkM77vp5qoFYwy3gypygpi1bz2eZNgfTFdt+ZiLF707a0ojx3DnpynAE5JYalFjed5uJxZ4cygPTXu1plx2nFDZ+iPSDKXOElWdypbZgP9GWKRDTr3sXNgjaugwNm+NshtkzbGW74ntZp3MAcjzJANSFc/gFmnIMd5S9hp92F9mHoPOJjwmHHkfzPULjQ/E5gzAeHkFBPpzS1vxxLKQP+G4JeD9QZiKjvyv7YHepkqgFkbpnf5pKpsWZ827TxY0QmGhStVh+y6S8MVqohLlzE+I2EZuR7P7SNpXPOFwtzifeh+Ros4xk53CS95g/1oDG7hYMcLlPK6AB3DPyJiJJwW498S+E6N90B3vGrbLDWxRvAOd7W/zXvMWHzPWoL0CcmlwMR0RlN4Bb1Xx2dTRGbNOuZgGHtx7LLOxKb85EtFHz5xGNd+vrqhd06xItpRkyQDy8SUDrdDa6KZVYYsHnb3xFbdYx33K00S3NC0aOt5WiIUC4E7hAURMC6FcmSL+G50e1+CsOj8u1IrWWh9YyCWO5NATvWDZrO8NeIO7WeLEvT4+d1qkXl7KnRgC7CsVmgHoipv9tOiZEZNB1rtY86NvuBVZvNbtcnaaf2YxldTCNStpfjwG/edzS1kgxr0mbPSBrCQnkhpJEwLoWU1Wj527LvncRi/FQm3RzrCQ0RkBI1SD8kF1GFP6fvG87J1ZtXxYu0Rmi7TFgyzq7ss8wWczy7z/LZInIr5hpj2nW7ePSbCNcA3FUipYM7U61mce8sdJnn8QCNCbS7GBCZyKRuitfzUaikfmVcgp3enSi7siemaTW3Kp3ulsu3Zt8ZhksATAAs9RagPcAtGRFS1a0EAOx05ksG1jPs0Mnb2mkIxvM6J5fcQbOw89V2RwNMzuy6mppmGozBaAz/yEyy6n2SiYgAvwZX+jxVqjfsjePzZr9FF7JyxwatRJS3i9+YyFui39Qq8ScgxVy2rWGM1dphTdzi4/k+ws+nrdXC6m1dFBL53X1lZUDZ3Q+Nou0Mq/S2PGCW+X7VTRVv882doxDw3Zv3oqCk59vmt3biQb9T27MGCu4Vynzvp2uNIkVfDg5NfrGm1IMDo+wVUc8H3RJK9dj3ZE1u4k1A0HwRosr48jqfddqdGpelVmwVy2DEBbtJ02Q7GHunx5jh+xDszuhZSzUdQACNAFF6lidFgnR+NXYjdP5Yx0wPU3bR7N7lScCuVviFv/eEmexCdJ2uQqXdUKS7uXOjQ/jftRvTjfJ8322OK2TTOi5Z5vWaj/prjpTYUJtWrd3/dysDf4Lu5b/X/vbVessQSBKr78W8n9p/+t/SeDFBphpwpG6DQCnIHt0Q0sjvwgKFlh1c1MFQQSypgCcMMi+3NANCM26vam9Osk6EmiYyaTUbalR7jGJpSIGLQkNQdd/Ysb1X5kXP7zO+757eVMHI6XCyROwUA3KRZ/DQx4/BSBCDcIszhFhE1jY29v1/HA6lnmaQN+u65vaPiOGj4nah6RkqyHQxQaOnDw3MMMUwFGBlGKKiGH08K9bx926v6nTOmcZ46G7ODOd11C3GhEjroLUlCH1moj772ra263vzlvzaWaonhxlGBkQTTE0bjTL6KBubh/Xk0e+Ps9UXl067VZZ5GRiB2MAXTfSpG5sqgEBijMOjBQ4Q4QmUOhtfTnsuqsmiyJj9O8WD5oF0/BnkCBzgNA0YLl8zahdDeO8jbhCXbHHliKouo6akrQh1SjcwI4cNyKRTrqJ1AN3etTNbFHgrCE65XOQNoXZUYM7Jt2SbAf1vlV37JsdyiSBgPDUIqccaQ4gB/JsJDEQ8hrch97Xy/NxGlvBkcQuJ7qTnC5PUM6Ye7fBFN268TppIZB0jL/4GstH8phDSK7UaEjGDT2CWdLQelBHnbgYcuoenX8j4bxBuMylXNAbADYV4cwRodqlofZaVcPxLb6Sq1ZRvpbErVu6NAmlKrCaV/qSdMeMexM6pqGKA0trAbhfSQN3zSc4TtftBzG2jxrEI0iPSDhE9zbssXyPCCBAbbWqLqNrfCbnugzhItHN1eobERuAoqINpI6oJzXSxLaWr+Bvfcs/d7aPgQGzVAUEMGIGQ+4MJFAMeszvLPbhJmUNtLmIOcw9VeBnN9w9rArw5Od+0nz+OZoc0W/kzSIZ9CGxskXYMwSeTYmoIZSmUhMox+XcbTJ7P0GDvlEqldJx6S+fZ4K+Gwwul9ih1RU/5+ox0PGZst0s5hBvIW63dZXAPN4zTW4B5bL/hRInYt+aLEvD6JrTiEQ4jbU08+j6FhsZqaQp5iLhFv7TymWuje6WAG4JrzjqucOOD4UCY1DPeXXHcnlr58zqyRI6/UI9xYMAMABkwDfZysF1REhv0D1VGeVZ3gWsbHJ2Xvi6B/gtWDVkyZTmSAhPMeO5R7cEv2gvUIZzGTMB9kEKaCnrfC0C1OszK6AwyOZSusgnDulOWvjosaWoFGqUvZtRjBomDO51ZZB/vPflUPwgCTlK3uGJEcEFaF3VZgVgGctrJ2Fgj+UL0hjEmuUxD6GMSZx4dmRr9f3UACwomNSOmCaaNbC3hJ4sY6m/2kI6fIYwk0MaE6xvlVSEonZqjRCdctCrDUSZc/bTXUBKOBnIZLGcXy+7kaO9rZLxHAUACDW8IKijzE0h1NJdMn6DdRYJa5zNSB9CdBwpKaGmmZtOaZgRSwmYosVYMRscwWhDBplQyrc2ZZBtMYxUL4bMSTiiRzMmqVGc3mNwHa2AYQkxBZR4BnwfYw5xuzbwascugtOGZ5AUnTHR7BYHDLwm99MgtuDM811p8ZkGr17PJWkeeFvn6LJHShakl04mytiJyIlZl5JXuVGLkRKmcsgOlVtNDSfPwzzOWig4D1hgS+VWGyVx614B4QURpibW909iezYCgRgFZ7jhhgyG3G22m4MHw9lBBCE6izJKCK78hNtqg0NZJNF6TIEHs+VhqZFMoLsDHkvLnD1kv5U6aJRW3mRMdoLIJqY9xJS4emcS+/qRInJIstBJb17gkYxpHMD1+NfEaRLTMl+OGqZMpVSEhSXHVxo0iZR6pQPYloOIgNB9eXP2MgkPP4JIB3hsYr6BWtRISS9ERcKSwdvIsutzHxCtCJFtQgAirKFfNdn6grA0WWwxRUTzipwxzEmIB8GgAcMTjRWokqBqE4EIuNQ2sOMCHZcFDjcx0nT6hUAPpRoFkQRdQ501EkJ03UW/fSihGcMVUFMtZMSInDSeTdFloCoAHtQai1hEnC3ktDdJ3ToRcZHgOkJfx5asFjH0JJK6zB6UsJsWf8Q1dxR1Dd8ALmh4FHmdXQa8OKMA9o3cGg1FA9G6iB8HShABF9eJVgDYkFdOkUI5ygk1dxq93en4eBh7evMnKibWEglpgWiUzTkkJgLAoBhwSQB7CsNION6MqqkrWTNwAgv9gkOcOosYVd/Fg3fNYNeDKW5WVyzZbzoIcc4YoGMzc+b2mTXCvvMD3amsTWZmLEAVEBkjm+3cNl10qufWDNwkDWUNLw6PV2WlgVRtwhggcb62iAVP6zXcaPd6tF09BCf8XAwZCGNTaFSlwHEK4JrGOUeyQCIoStKziFoiU3CjYOBybHFZzIOw5bYkXDa80wzLMblpoxLOox6alIbeJjK8pKTINzPd8dE8rL6CmD0nn8t4q5ShDNRzLlSVo6WOqC+xkEPjeAFjCNFqmXlTN3Ya+Kaxf9EbXDaoxSCr8zqgakiqy8c00ZrUmzIeDl2MqFngjfZjsEgSHfpMwqZ6mM8U1iFGL/rauBGS6YwaYNSN/NTR1W6RUzgMthIkP/PFk5sBczoVg+RTMvAdoZzlsRvr5f12OvB4CAZiKtOmWFKj7DXGXgocCXuaBb23yt8GZT8UyCxyIy9ssxEQzjSVZTpHSuUUZSpPgffuXZ6vlxuAaTcU9Xxl9HLHbAagW0SyqCLJX0d2abgUla4EheQSKd331lrl5bk9ay73ikmxKP263W3p4R2gW2Qxnx925P9yUY8yUJ3zG0sEsxBZa+Gst4JP/738JGIn3N+Skl/bRk64IM438HW2UOryFqduEChyFA1yyeQ5FSK2c9v02zWnw+FPz+/fHd4Z3q5Z0zDIZd1dftDyZq6GYqZ5joiCpwWjUA5B2kwTZFLXwxZ4zOH+vF0XdOKz1+3THHB8uv1+xLr0wh10NOnpf9NbqN1qfAnsOdAuCa3rpyV48ssGdQM547NFvTsO2vNAYn5EJbSDhBB+h4OVFg3yrL62E/y9Yigbu57HnAbcr3sHsCkzYjAUTmSlCKa0Lh7dMqjD64g257Tilxo4pn5Ta5EA1WueqB+gqcHIMgDWmBOYW/BAUD4VbnJUAL6rPY8x8qAm8l0+d8orJ9OhQAS5ZEBQt6ckVXNAhhfpMT9uZ2yVzhYsjTH0xcw9aWpQvUXURCTchQXnHid+uuJWRlpRLpLqLGtvIlpHhgF90SFoIQR81zDwkpjXaBuxOPq7NQNeZ43NhUNc6AAQEQYgnK4x2s4Rpz1nUXCDc0CO3eJ5tJdeVZKPPRvLSnCj6x7wm9Cegu4OWJWBf3VndRO6gjhAThucA/boXGFO2y76d4AhPLmSCX1dDO3rcCXug1J2n2OwdwpRAY9fCwguDj1PowRM24YxTJdVZ3CnMfbE1LPUs/nHQZMgEjkc3yGDkRkzDqLLwp4Zcili/Sum/2kiAusHJVmfAgz6hkbbxJQAdHhOhC5j9gCzrnRk+nKKhODUVTcMTc9yxNGt6iQ7Bn3xoMVoGATs50zTfQ3u/05jyB4ptZOjxFIuCgytvMT1GBWtqrUy240s3wfzcPsmAh7+h9QmrdCOSbPx2DNcZOU2W/c0Hj4ngUOaPLS0WEaFwyYoinsl+m15BTsCMnLWNJbJitadSf9xxL9dL/ZRWQqwUky/FJUi0Fbb8jqJBkMwQonqzvmBsDqmE5hPbblIDGaGUdxu5/xqNQgY0UAw12Ewws9xJ9Xj1PeZHLjygI+mSNJLWXFNO16NQrWSYJkE5AYjLYYePtrXCpkLZ7yyWl2nCmO9Wx8P+7rwak8VUTXO3hSKTFySyBsX46FgMXJio3VJxjHotx7Ef7nu2JSmcBXFqtUk4u8FouZ2mUE48YxWtWup508lTyLvvXYMq05u1jabW7S29cBaNFSLACFEA7OVJrlcFa3WVirqcnRR9lWfRtCbS+zlYp2JVzRYpMLOjyDRDy27EeU2pqjh8PE0D2nRjJnXQKgwNAl+pxVf13SK2JTSgSzCVpQ/oczYywX7IrSmjO4rvJ/Wq1PPNo0fl6ib6j2hgu2mNyBXmvC0AK2uyOTDx6GHgs2Ia+WbJc1YMR8vzPvEhDYTWHGjVmnPIXDtd0nAW7eASzUMgmkOl19pmj6MsK0OnDx34jiOlawJSJs9DpWp1aWLGC0f0NfbwfZr3K0DHT8ngnn3aMotZ6lrWeIPcGi5lStmfvdyMl3DrU3QamedAATiUlPaA9PLfX6NaF/qJ3/eWlehR1AjcSVi2O7rTIfQnzXnulNxekRRANBHPMWtG1cX28X9PPZd7iQOuigNfmwTSc/i4BCPBxBvFxneegOjwY8LO5JLVSonz63Iku1SZoxKx/oCsunkErV6A8S3HquUTU7y6vrfVoeeRGUDT/06jLJzYPkbELr40mS6V4hK4PBF25fRp/+93aV7buVOCnT43oiScMUv8FnjE4yuYZJEeOytMJBquQjVIXDlK7gd2HJUru2TSPNK+y4t2dkz0lWzJkBYSN9Ne9TIZVjAKfx9pZgNgZpYDA1D927dqE/QGbmxqdSJjnKENiYXjrAV6uzGCNb1jrcByCB4KoBWI7PmzKQroiYJqLsEyxwpPCqnr83bmRgj8TncLxDKRereTdzGq5N7z0l5Cy3VoV0/6SsXi4zR+tGWvVHQN7fdQE0SZmlbUVYgIKIJo2it3JPgm25o3lwWsasz99HVqUXHOFAV6zJh0dDNu8/vRkQsaH34+ye0Qkhq9drG2Zrs6b7KlxW9XMvZ6c31o5PRw44yDiUOWTNXpBVmUjsCKCMqY8GOafJESjkJeKixxEClp5Z2GRgTFfBdIhlftZPGJq5cKRfFZb2AmOIbLo7KUfbvfhU2CcKeOqEee6iHD6xZZinXv5bsNvO9E3WZJdTOjfXG3UdDkJ3bCsR+B3GiW68NHWOe80pWYxIK0EHebB5GhHl5mZRjf8mo/jTwzGMfdc0R8FtBE+eFHX/zTRT6Qqpce2i9OVjd69qMSwL7KLm0cvLxojiqjTvlh+ho92Gu5IG6xsH2OX48OgLxJ+NZItFbA2VOR0LSgeenLmefuFk99oO0GIonzqL5XAJtIj5PH7MpD/U7N2mzqUKCCEfEzq1N9eq6qEVCddrwFucYRIALecC+Ivv3927iZvadT358Eze7ddtW1dnelLXb6LuxE0/uOL7DUNTpId2AjJwYN2bBBugrYYoF7gRIVN/gA2W32gcQkybjwKBJhHKsSJCxnh7Bme6+wC1nUZLrwnOr7v6GTP4zMrYLZvyElLyDpqjRQqAVDQElc0Ju0G5XuXbUHCjApCW0/aRf//zty+uXaxQwa3ydjl5gZmNWcNFk6oOqIeCqQU4h6hJVACSkNasb20fBuFzQUe3oEcknteOEDfV5ByRyXdf1KDuafMaXKFu5VeZ5nNxhipxmScLJb85otYopiuLodteH8oP+Yb+b+pZRASHdpvlbsdZXTSKZdZI2nW2fIwvKmBzWIQBzytmBpcWMidJgbplSjykWNex/+S/U/Xa97KdW4KaubHpoC8a08du6LE77Zo3UPKAUJYkWRa9jpBbtpixuZgtMnl4U7LS4JkRBK0G++8dBcJLQW/GDa3z9GTF+TNRA14ckC68hcyNTFoUDN6JWWSBsuCkaCm0uIc0W3sUHzloVB0Qwct8M3cvgci/0Ky28NtuU1VD3eMJGMQaj25QYTOQjjVjVTuRbYhZzGES984gebQxkm6mAKoczm2WbJjoNeCxahgHPJjn8Qi09BsK75zVmYoh2JXoQlhEcd6Rj0UQdZ9ZwTYVaImh0PJ1wh1YSWCaBWyoYoPun1Qx1eeytfzu8bSoULBLDHPq9OYqTi0CZpjOk1zmUMHUSDBYkrAZA8FM+XTJZWxrCHNfVBGzQQhgzuFTxipTO3Vll6eHV5uJJgJFL5/DUTuhRJzgesRYASNgZlFYoqpmWJxdqG3V9wb3reqWBEteGQO3uLRD+2oSW7LVGJpGRswaB64rz9U+i8wR+jZwGbteSQlM91TA5yyumwljAk2MEaFZh6GyMFyYEiBYAVFoJyUMwRhvezfcF8mynD85QdqzmUBjb6RZhqDZyYcP7mnw8L+1Yhga0ibI6OB3imjc0ZZcIDhLgbNass+Bkw5aW55XO7dhf+AuveDetYk57znZ+pFoX03Ey8NiiBCs6KxIrKyzP99ph2INbqcmnAvhWJZfDHuUJVS3l28ml4IVEwMsyuGu9U6vdZblsfoCi6QPVaAEqrYz90iWqPS3E2nVYY2rFmpGm7pId2+l5jqeKAwj2bY1oyvjV91/qqfNk3EH9zxucZSVCzE/qpvYDc2jhmisvL+AXdI/U9M4rNNjgitSmKBTVIX5o/c2lL97rd/uGc6QcLn1XB2f9Cit77Batldz3lDoBz1XohcvxGnvrghHWyGxkNA77ArAXl1egaRzqVed0VKfDbkbsgI9Q3sYMyBVSeCSfI+AIJxMmfCPAi2aqcuvGxdlyfjp0sik7RwVPnNajYOlcPeUsBEZDpLtJr6oXLIh0t0XmLWVSvW3lCz0rZuvBDU/GDfUXsSGHiF23CwH3Ve+XZ9Fmcu7owJ3cpoSy7Xc6HVXNoaHCXEk2bdtgsnj0sSqWFXfyeEOpIxJw3Z8dVWj3QKp6BXa02VlG0SVBG7YZn6v11WnHDKy/fX78oFGGvje1UCEj5XRJEWBTwbXRXr2owdRDtF2N3YG6wMvs9kbr08yry5K9nhIqjWicU6aq8k6r+eW4n/QYVVy0N9i1WEr5588eX16c1KlAJRWZOjYV3AyAnaw7OTP28o65uU9k5bw/hTreWc7GzpJ8eBqAc6HcmHWxZkinhLURuXj16MFpP+wzUqYIavfJ17F8zWh5Oj64DhQGca2hzsiVwjZ1s7ycbtcO24DgFOONnnjqe2POfHQDRpQBMpEbMYTNIAMxw2/fzpeXB1EUkVLLef+NqA4NQjx5CQin9y6Ywmi7bXyliSbHhVRBxFjmzy/WC7YidZ6Gv1pvOtVFs+w7K+hhtyGMLo4EnSUW/6774qS5yku7yQXXWbwacFJ6BHS/TEU+IR5G+O6KJlxET311a9QfOkGrN/N+0B+F9+2rSlhterH3M6ZFi/AlctNJCFMQhYS7NH2KQTTjdNiuhrGVtX7CTl8Xu3MKGootBEkA8l1Sb0/ptjkts5M5yuO7R59K7C7llGg8nNEb1PWidC/J6iKLic2UYiRFsJ3l6A1/YbOjKKMMsMU0ilPD81Zf6fKvpxuluLDrrs5/NbQXDvtBj4Iv3aYhq7PEKjQKcFY7Ty2mKlRtq9HHo39/fPpwdtyuLv/f/fP2dnJLOJ6p48pYEl3TOUFQ9HoFgX7s1RxIVeS+VsCwUeb6SekcIwruxNyn6LCAoYvE5Ui/fjWfsnJGGJVyP1IwM3kI999frioGue5kCS8k5xCw1HbBg/S32Ge+cRWHa7P5udKLYtxSwJ4SLZ58DIp5yE7H5kiWrsggMpuYFga4FcLTVxfipd3sOg4SV/nmM/XTWKLDTmuKUbSU6Qg+vEjwRGZwWhdx6C0YLFxs38Wv8PwKSHJT9GJSapOsJB+ngOd+9+ONJ3m1+25ZsczlFoor9oYu/V326voQ4gJN5bvYHZMaV5Q0mbrEWCcZHhuj3Ewl/MQVcTAuHr+hA696ruVqcToMHanLXNg3fYue3iQShyswQvWofzCd43CJp48vz4/75XyQm2kdhwAb24f8tJTQml4NOHnu26rYzGij1Zeeer9bkD31CnBmAmQe7Q1JAF7E8+/nO+N5GkK7flqX+taliMp2um+qxw3M1HM2jgeZ2hH1L64alTIG7ujWBqzQOSGSdWaDnFm2uXw4GeChG6C8QOP0c50h3sl4NA2Siftfif9vzt7SP0tPwN7aw+A/FFv7ibv/m0prNE2tb4oq3sCP8AbXv/Sz9dbZfzrk4I6+Hwf7f0mPzDCqyvmy9FjM2T1y19X/qWinobm72/zYJYeH/U89cnREfxy04oVHjH7qk+Nj/GO9Wm+83e7c3zReyHNz9R4Pc+f63De0ubm+vrq6oqKkxGrNzExJ0WiSk4XCoKDxDevXja0dHVkzPLR61coVywcH+pctXdLX29PV3trc0tyyeFG9hvN23i945XUpKaf87zzEIU6j610f/B/7RwtsqriIizxLEzdyozDwPd3Bgj5tyzRETdRURZYohuDoYHtrfTUdU0tNP21PecpOqWVlyDhGiTHQaYGb5SwSHldWe9PtTD1KuQ83f4c7cqCaRz7uapWlKFinZHwssH8WsS9joc+9C9MOMlXnMKg/B55DcLMoWTuyeHHTGWKknci7TTk1aLZA7JWxbnjiIqFxBBJAlH384Py0Xl5OtMnSmWjSoqt7XF9DPk6E0zbBmQskkynE4omPaaBNnmwmxZB40fbuEOk2uSSjHqILCftRsiL3zn8ckaLHsaQJzuo9jQxHY8RSn9z8JovtVpfn/7Y3ot0a/RNCfzuH4bm8GLOyxl+hL941Lvj+jDxrvNz7aAx5p4GeZxM0abyrbYaHvLNXND73+p72bHqxUd4+p6EoJtf49UIcjKH0a7C5WBQ+SGpR9smPpgj9VcXTpacbpXwOI6RLzPlW+2PGds4SE+aDERdfSTUs6aYThA8TsICJ0sAE4C6Sehw9qDH5hhBGgsOBzySDRbQG9eYpHEDD3qf/ESvpKSu0y1k00FN8Uveo+zyC5ovz2mWYG8CvMBekmJTAoSj62REdlLjVlBwYbJFhaY6byF9BZnJ4HfW1p/8lpEg8p6l8CHCGzyBAuBRNJGIJb0cTXVaQk51yJhaC+IUKEut/WvvKm14hOTxhDk/yM9rU4a43l+ttE5yNqbXKPVtx9Q6dBiWmVYA9KVqdMgj42Rumoo63dccqaAgahN6lyfb6jVjSMtGyGkVOuUhztJd8qe1zlKBOZW6Q8IVKS00CRwveanLXnUBop8M/zyVeTowEkmUVaFbi5YR25XbIo76VafJq+TibVD0HFd3pTVMi/pfZhXI9Bn1pZqTs3WRc7ocV2zNTTynFPbKkNAJWR56/LzzicXGea8g6QtToHORJIFFgRe4qgNAGnXqExlVycC+9nWTzFEEnCvMsWZmpKVKxv0o9y1CNGD5WtmgUe1FpBh2oipmEYDsKtFUK7ejargXImr1CuYwe5Jto9mJBtiatWqkwd0KKmbbkmIe2yJSMNWD50S1CY0OUBShzPg78LJJsl6dYclzsmxUQwLY9/vIfL3/kJKL3T2rQDP+7BUtesTi1HNqZXdkH4kgP6D9t0wdsfK/BjOuB88h8v5mtoRXgpIXn1vGAPYoQC4ETlWyKKOxzCKfksE8m7LCvXLMfqHkc0uGIruZQdClOtW+7XLMRhZOcKm4vx+F0th6PSNw9+jXFunX9VqMbdLQjnIBQwNsX0ZrUMUlXyCnN7dTDOrdwO3yH7Jo7zuOYqSXMiojwRi0ZK2SlTpjsmSL7VxX1k1n2vlbGKHtiFrXczYVkQ258UEwJmDEDFi3sN1283RmwMxDym2h6KMiS2RrG7I5bnA5NDOM2hmGBkXUiEyHsiSscMzlOGqPiYy+nTY4bbZzTcZXj4Y9hD7rrt1HiZdhuBVDbVwxBEMpu1gQdicCBEOc3tiQ2GglejinkRk7IfrYvxDee4RZluOUDzGIAhuHgm2Sw9w84tL1Y+2PuRxxOcZwbD7g/2wODcJfmRhzE1hbRsUU2WioeMc5DH8XEjvPIlHC1ce55GpciDsksxqOtwrJdxpH136NGWP6bq16JlT/mhMlxyTK4bMeQ9xYuuhG6dodAYPkP0B9l3K3Qfmv6/18I72Qsj9ZwwzNbYKRze0fWSzqgq18t/wLb3TlomTWjQcjuB6NtpeUcBmHvSWtnZKMH8MvbSms088QW70FvE6vKNq/Uod+yuqE1f2zaDGcFyVbgxIaVg7CnfLaPxyBa0c0KwIexMBKgJKATAf4G6PTB7eCO5C7kttCDeS5pUEX+EaclFtsosDlsoqzx+atqrMUuhjmQq1FPCTQfNcUz9iUFwl0bITuAcdvIKU5A5xKAnWOqsDiqfkVANTBZ/5KVIlzZx8ntcayN7A53DsMlggHMRwDA23uXsFUA3RSIR3hb08t+7SjknZKbEN2kOfltioeA1MUxK6ygJQz1EiPfwRnfEzdVF8MwRTficTUe90KT6BwlmhvA9CaOzIdaQuDYDbzsBIfClhAPQdaOE/wIh8OVUmV4th4CIw7Dtj42ycPDZ9GYZfBNIbiQooS33bi0Pozadw43HnbtptnkQ5ISB904R1jcRWd2wtH+q+R4gcf8MMTRniE3IOjImS0vLARbNbI1OmHEMjLTh4HaiL2SH8Ky+Bq1z1CbybqvtE+gheqBEEAJqhfOahCUNQeNKjQh0A9V9ub5inKeAuaPR6yFZgOWkXdabWPvRmufr2K12StwpM3i2AMn5166BxE76zWC9TfUuYjeCRjbP9g0xOwR8etI+GjINmE2st7fueK8fd58RQA7AWUa6qtofgiVssCVcwCPDsVBDE43S0YRlDOeRTKfzbajolt0jebEzyMH0GtPeWdeE4/LC6Njc0WlcfYwshlOJNKhWdFxk0K9KvEYGvZ7AGgNeBF6NX8YnDv0+fB5lb4o3kmsgV2tKPsCmSGSlOwhlWeqfzZJqRVc2rggqyViomL7U2g4g/sBtfBobgTNqwXAfDSH523YU1bHDePXYKsLTg951IcCh4hN7pfRfYB2Nzt/RG+zax9uD26TO45toxNjd6vTDABrvILaD0zsH/t8Vz0NMn9PkOGOv8DJENydAW6HJY41q1lcMOIwdiDAthMLk2bIYFwjkIeATts4CQkCwF4y3jfsWj88uCSIosnAJSaHKgkrkFMiLPW0rdDRzBbt1MaqpC5oE6e1R9oGcW1UW+BrU/+3Q16bgwAKAQDbfW0RhKBuiguDsikjAoxNZQtHV0TWbB5MSXBcFDw3r0tox/Fqr4QpPkhcolAP+qrEoBz0/Zs4Rge1TtdR+Dn4xL38fYUN36oT6gOVhvc/DIWzhiHXwlDBh4IJG6LxZkimp68LdhOP87UBp2Lk0hs/+gHJEYugyz4SlzB8cl0av7pBAKXYSlK9Ux0hl/3pCd24z55F6QaKzYwUB9PbCcHrNQy6bEJiNko8mzyQTUcezKRGFnLAfo169zVxRXylc8jkzOiuC8/Y6fDVW+KqpdNRe8QNgDQAoupkix8N3494qeddIx21/JHK4T7DEzKPspYAJccIh5aXFg+Qvszaxpm2cRIRye8ijFcG1reH9vEHAhiCXZjpscBABKBA96sqgS8BwABKRyCB2i13r8kA9i8jboBnLIfxDg7QcBxM/YpDAh2VgwiaqQWYuMAihVukxGNdHzvrUwt6YKlDQiGESmZ0TIycJ0hFV0+FSD/Mg9hnHIjs23BSyRQsYzLloxSk4hqtZEZLzwC4yR2TqbAFSRK85EdNditdyrhrBHRTmC45IU6h3m1BIxyAbwqd0QYiRF3OUQqVa5uKPWCMqJqAWfEU2T0GsDz8WSE5Jz3AcCE0U8cHAc73/L0iQ+yJJFTbCy2qoo+8Kl5mYLECvZIdLHJU+YuHCjyjUcn7rR1iDIS2M/UW0uhDKsxG1cyFCOEBKs2K0smZIL4GcEGJh+bgUgQvIfBvbIY+PoKysPI9ZKopjzmM4WpHlF1cPQWL+vfKlzugHrNa15cNgD0Zww4Q6wFqLKIY5jge11kqKBLF0wTUhKhmgBY2BwacDOxgzvTzqZAzVK52h4JiridVA7OisezEcJUYpvoI+ukce1SYzi65A0tka9ZBt8XMuGi+5cim9cOjbff8vDHThtltisIXPpe7afTZPZqNVXcAHP2vTBIhHXkPcPUEZ6RwHE/eW9xlYjLyIWvJgrfjkUCPge6L/BdxTZ8pXkVMnYpojaS5I87FkNXDC/CgawVNF2HX4J2s/p5GxkxPb5WO2MRpZASy/aEvm9ghGBomr8kfXRk8xiQPxx1nl38RxUI5yC+mjdnsnKVALlQWvy5G4MwHnxs2tR1+M551R4G29QTFIiRyZWSyLHs3lGTx7/ZgoDvkvsBBY6H2cLHPdL5sa3kvNfslH/xWGl2Ziqnz852BW6AvJH2uHhgIgIhcun0poxlQNQRbE/FgvwAA8NYibGmYQ3nZ1MZUD/mziJ3O6aUBpD4x5mRk0VqcHsm+WazEjc/d5lDKQPiWkQeCf+jwxlDQxxaafMJxHsPRZGElJJ5iDAfKk1mBtNWSwq+GyEBu+xBCzSmeZpk0TECIiD0UNttOKAu6mA/rVECw2wnSm8QBc9e62BCjsFE1cGhAasajTmO7JdJCCOCgUdrSI9AzvMNhIMidp+UF22u7q3Cq4OP6iepRmvccnC94VCe8duXKdZQw2IbxobcVxsVtDU1N+EV0ToQfjP0C/IijcBY2bOG83rIunT48Nj19XVB5iu5hImFvxRDleR+WY+JUok4Tla8Aj7q4j0Kx+DSrHIbBSmTLMNxUI88JH0SnbxPn2gcZFQ3T42twaJTpQTfusyc/iFp13dGIqbnIaipqqroSKjngB69iUpGSLU2lzRF8pkmOXkEJXaSZXTCTXBaPUTw4DpDK9DVtjE44adb8Cr0Tcaf4SufAmYdpdO+2ND6r0aZXbx16FdM7XAuhDYSJMn1jsAPYWqinCbXnkM1J7afBJEs/M8DM+smg9qjSf0krW0B3T0WWgeL6iMtRBmJienKoc2k7ef7xOxkooBQfSxwgXkA4Nrd+Kmh/6sHTNws/C/I9Fxg+Wm4wgE6SJsMg2fo0CPQ9lk6HmIEyReugx3BSN8DGqWObJ3SnQaJvP/caNjDadQ9kOD5gcVsiflHXhH4j8hjwxM5ta0lVLZiDhMzd1Mi0Q5eQUs3aID+uTy6Eu0HpggrErQR9K5cJQUsxk6awbkcTuyM9Qcf8GD6JtZvJMUzkoJvOji/1QjGYCTaoNQ1y0y8Gf1k4bOOkgRqdlqPcQqcmHBKFtA7ZCP1GNqQQtcvUEGVwQRLRuQHuTWsv+ygH13DUboEpopIX+GWDoKHydV+CJkTJYsyuBYbz2egmxWee0MUJA7vYyK5phqlOCWvzhAg390aVKNol1o4zktUBayKfBBtI6j1n2s/ElBaCrrFbzSFhH58CGleJcYKsntAnC2f/hz2KfJVIK0z50GYQQub4kqQlIoB11+n8vIzSqOtO9YAlNlaINGMf5LD7kqLBJHfPyjQDbS1C0E1IQs6m1lsM5y0vDGCpymXMHLAJthMRomozxA8yP8GMSVjGj0jzmZiPELRAXswFlvMaHo6ISBGlxcJpRAf5GpPcgTJIoNSaMOXm2IzslerFYc2Mq9iDdGOkundRvQqTenFqPgT1op3UBhO/hBsVSwJKQpMM0BwtMl2TImLJ5s8uPjDPi0tpmjrTLLJmdOW2GFwCDYGH0zI9jKhpEZpz0bldc9OMC9oA0US/x+bThN24psVp4iKllcZ7B6+UKjTeh8uB6mPkxIZyMFH/rVOqFiPZGumgVeisSG+RqOVPmFb6JOXcg1ou+jx1Mw34LtKlSZMDaDX9ObF8OtoKbxzuLxVx3/qcuhxHcaik1FfmFz/Vp82A9cw1TzS34DagWO50ad1AzaiS+NSzBzSI5JAmDwwJEaozUsWVLmhslXMYOhaoDzzgskSRRKPXAB1QgXcu7jNDIdk3TrZMwSaiSvQPFOWheTiGZmSKGOX8qjfWtvwQu5pASBcXTb0YqEeDIWVZYVwegv3LSBRIencPVeP+yXm6wTLochAvTLGN1u7kUhBCNzdQ0/5Cv82KQMriRCQT0CgVNANp9IKFVomjkJyhMnWM4QAdOEqdCarnWMy8EvtTetGlWmouPLI826F5CquRH1TdL7vKWJUMoJE+1DmI+BaTi3IFyo9JWaGia+iiJYg+PuxnGAAZ+4PsZVnYQ7x/8PxvtzUdkwql5aHSMvvcIBwZG6oHKSERkxvbOMFcT+C5VWYcLmaenVdaNy9t2RiDTTTcOZvNnJUFIhNYn7W1pxYRxEEulAxcyWVOgNuiF9dyYdxqEK/kiQ/bQ7U2tvqGXVIcIxJNGNAlVKKbh8A5XwACWoJLPKSKFkrF6bCa1ZEwJYJwSp2syfrg1A0XhciHDSnoNrYFlaBll2Bwap51Kbeu4vpfN1I54rpfE+CgDKCqoukKjL2dVbp8SSb6oNKrde6aVrhseKSo+94NBZS/6XKtWs8KatSlp14bZ+Z7nbf65layqgBy5AKbrLXBU0hEYUA7TRdD6HWMoD68EPMQujos2QWp6Pb3Y0E39axQ39Xd5lBWBHiz1T446Nnq5l71jds7RHnNvTe8k/SpUNyhEJgVtGTnoSlFCgMkW6dcJajYQNNrr6nU/C9oEkNmvYoSjF/QD61/D3cctp1/jRaYMEQAAvj/wV9VOCTix12KiGQI/yfYfnp7QTpJIsIDWrlDGDPM8pgoAqigk2liyGCeORZIEAma6aaNdjrg0UIX3RL/H60wEoE0YvXB7kj5OqAwipM0y01RVnXTdv14Mp3NVbnd6fb6g+FoPJnO5ovlar3Z7qIkzfJiqVyp1uqNZqvd6fb6g+FoPJnO5ovlar3Z7vaH4+l8ud7uD49Pzy+vb+8fn1/fP79/8owD/wrNXSIFpq46nPSGZUZUpzE7+7hNIulHpTPZXL5ALJbKlSqXz3OzhS5UUZgsy1q94ZC12p1urz8YjsaT6Wy+WK6trzY2t7Z3dvf2Dw6Pjk9Oz84vLq+ub27v7h+4kIqq6YZp2Y7r+UEYxUma5UVZ1U3b9cM4zcu67cd53c8L3/94vt6fLzE8fwv633lQVE03TGHZjutJHwYhiuIkzfKirOoGE8q4kG3XD+O02x+Op/Plers/zI9Pzy9v3r5ThDIuSrKiarphWrbjen4QRnGSZnlRVnXTdv0wTvOybvu/lemS+BcA6tdna0HdvhP1uuLwtaXd4IWSScaczLr62lL8yBoY+TSNL5FhrnRavfr2RRyXNEnLtfZtG73AVJk5Ob7/dI7w22uo/Yaun1bCBvJwpC7BuQ3aIB4XXxFSact2MmWACBPKuJBXuRyBF+QIE8q4kEpbtpOpAkSYUH56Ue5PnPTV5KY0tWlNbwY5FIAaNwsXF9YyX456MZpzwjLhleci0SVuNT3U3KLwk6zGM9qIFgsEVS0BW+NzEIIRFMMJOz1y8dxLEIIRFMMJkso716MXmnlf1V35DvX+dS2fFrubZURro9WFVNgVlveCtD+fCyLtiok56T7ndqWf6PGNwOvpch1JzHsZjX6hT5Z7aVf657Z6RG+w/5Fh5r2+QV7ZNel2t3lKbErtZt6KtupwPC6Xqmp4vqLrLmx+LWrc/u309lHH85x7RVh2S3vGTHXTpHgeH/MPwj7sinkaTrhp3kWz3G0+RXPcMV8AIRhBOd252yrPV4OEFNOJMGGUhXyk+zX8AcRhH7w5v768QdIQYcK4kEpbtpPpByDChDIu6AVlzu8PAAAAAAAASZIkSZKkJEmSJEmSmZmZmZmZmRlCAAAAAAAAAAAIIYQQQgghhBBCEBERERERMVw+5CinIUss6K2UC6qVVquf4qYnZXPVfY3NAVVfHeuxF2SxlUKQtSIchlrh4P3JVJ12dUc1FsNf3mqXOAjYyZerFuYx7Ts1j7TjvfpZXVZJ/27nqoRGC1MTPuHfPjHQ6FW+S/tci4OJHXple5Ljv//Z5jVogB0QdvtYq0JZ7VXL6bg/LyfmOzbyOC7uzT0gHi7SSlf5tra2dY3TsqlzvduCMELq6Av0spuWTXdjZWvjj4/pxN3DEZsmW8+gTT/NsESP3cY9g2/hnp0CTN4Dgte+4X6EAm/ERbQiWN1zP5AvfLsGYGgMJ79ThiJCxCjtLaokppcSuPD9ZN8AMAQYCd4NOHDKi7D7rUoo4FpHpjkBR5hNJeYIxRcUe7+bJYfdL051lefkKGKJ0TTeQ/7dt+CP34rJ4t9OdG+w+2I=","Vazir-LICENSE.txt":"Q2hhbmdlcyBieSBTYWJlciBSYXN0aWtlcmRhciBhcmUgaW4gcHVibGljIGRvbWFpbi4KR2x5cGhzIGFuZCBkYXRhIGZyb20gUm9ib3RvIGZvbnQgYXJlIGxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAuCgpGb250cyBhcmUgKGMpIEJpdHN0cmVhbSAoc2VlIGJlbG93KS4gRGVqYVZ1IGNoYW5nZXMgYXJlIGluIHB1YmxpYyBkb21haW4uIAoKQml0c3RyZWFtIFZlcmEgRm9udHMgQ29weXJpZ2h0Ci0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLQoKQ29weXJpZ2h0IChjKSAyMDAzIGJ5IEJpdHN0cmVhbSwgSW5jLiBBbGwgUmlnaHRzIFJlc2VydmVkLiBCaXRzdHJlYW0gVmVyYSBpcwphIHRyYWRlbWFyayBvZiBCaXRzdHJlYW0sIEluYy4KClBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkKb2YgdGhlIGZvbnRzIGFjY29tcGFueWluZyB0aGlzIGxpY2Vuc2UgKCJGb250cyIpIGFuZCBhc3NvY2lhdGVkCmRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSAiRm9udCBTb2Z0d2FyZSIpLCB0byByZXByb2R1Y2UgYW5kIGRpc3RyaWJ1dGUgdGhlCkZvbnQgU29mdHdhcmUsIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1lcmdlLApwdWJsaXNoLCBkaXN0cmlidXRlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIEZvbnQgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQKcGVyc29ucyB0byB3aG9tIHRoZSBGb250IFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUKZm9sbG93aW5nIGNvbmRpdGlvbnM6CgpUaGUgYWJvdmUgY29weXJpZ2h0IGFuZCB0cmFkZW1hcmsgbm90aWNlcyBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbApiZSBpbmNsdWRlZCBpbiBhbGwgY29waWVzIG9mIG9uZSBvciBtb3JlIG9mIHRoZSBGb250IFNvZnR3YXJlIHR5cGVmYWNlcy4KClRoZSBGb250IFNvZnR3YXJlIG1heSBiZSBtb2RpZmllZCwgYWx0ZXJlZCwgb3IgYWRkZWQgdG8sIGFuZCBpbiBwYXJ0aWN1bGFyCnRoZSBkZXNpZ25zIG9mIGdseXBocyBvciBjaGFyYWN0ZXJzIGluIHRoZSBGb250cyBtYXkgYmUgbW9kaWZpZWQgYW5kCmFkZGl0aW9uYWwgZ2x5cGhzIG9yIGNoYXJhY3RlcnMgbWF5IGJlIGFkZGVkIHRvIHRoZSBGb250cywgb25seSBpZiB0aGUgZm9udHMKYXJlIHJlbmFtZWQgdG8gbmFtZXMgbm90IGNvbnRhaW5pbmcgZWl0aGVyIHRoZSB3b3JkcyAiQml0c3RyZWFtIiBvciB0aGUgd29yZAoiVmVyYSIuCgpUaGlzIExpY2Vuc2UgYmVjb21lcyBudWxsIGFuZCB2b2lkIHRvIHRoZSBleHRlbnQgYXBwbGljYWJsZSB0byBGb250cyBvciBGb250ClNvZnR3YXJlIHRoYXQgaGFzIGJlZW4gbW9kaWZpZWQgYW5kIGlzIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSAiQml0c3RyZWFtClZlcmEiIG5hbWVzLgoKVGhlIEZvbnQgU29mdHdhcmUgbWF5IGJlIHNvbGQgYXMgcGFydCBvZiBhIGxhcmdlciBzb2Z0d2FyZSBwYWNrYWdlIGJ1dCBubwpjb3B5IG9mIG9uZSBvciBtb3JlIG9mIHRoZSBGb250IFNvZnR3YXJlIHR5cGVmYWNlcyBtYXkgYmUgc29sZCBieSBpdHNlbGYuCgpUSEUgRk9OVCBTT0ZUV0FSRSBJUyBQUk9WSURFRCAiQVMgSVMiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTCk9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gQU5ZIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLApGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5UIE9GIENPUFlSSUdIVCwgUEFURU5ULApUUkFERU1BUkssIE9SIE9USEVSIFJJR0hULiBJTiBOTyBFVkVOVCBTSEFMTCBCSVRTVFJFQU0gT1IgVEhFIEdOT01FCkZPVU5EQVRJT04gQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBJTkNMVURJTkcKQU5ZIEdFTkVSQUwsIFNQRUNJQUwsIElORElSRUNULCBJTkNJREVOVEFMLCBPUiBDT05TRVFVRU5USUFMIERBTUFHRVMsCldIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YKVEhFIFVTRSBPUiBJTkFCSUxJVFkgVE8gVVNFIFRIRSBGT05UIFNPRlRXQVJFIE9SIEZST00gT1RIRVIgREVBTElOR1MgSU4gVEhFCkZPTlQgU09GVFdBUkUuCgpFeGNlcHQgYXMgY29udGFpbmVkIGluIHRoaXMgbm90aWNlLCB0aGUgbmFtZXMgb2YgR25vbWUsIHRoZSBHbm9tZQpGb3VuZGF0aW9uLCBhbmQgQml0c3RyZWFtIEluYy4sIHNoYWxsIG5vdCBiZSB1c2VkIGluIGFkdmVydGlzaW5nIG9yCm90aGVyd2lzZSB0byBwcm9tb3RlIHRoZSBzYWxlLCB1c2Ugb3Igb3RoZXIgZGVhbGluZ3MgaW4gdGhpcyBGb250IFNvZnR3YXJlCndpdGhvdXQgcHJpb3Igd3JpdHRlbiBhdXRob3JpemF0aW9uIGZyb20gdGhlIEdub21lIEZvdW5kYXRpb24gb3IgQml0c3RyZWFtCkluYy4sIHJlc3BlY3RpdmVseS4gRm9yIGZ1cnRoZXIgaW5mb3JtYXRpb24sIGNvbnRhY3Q6IGZvbnRzIGF0IGdub21lIGRvdApvcmcuIA==","Vazir-Medium.woff2":"d09GMgABAAAAAMmEABMAAAABoZAAAMkXAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoE+G9AoHIsuH4FyBmAAiX4IXgmabREICoSySIPjJQuIKAABNgIkA5A8BCAFy1sHoVYMgRhbdnSRBJaH7SF4sWXTbQhguaa+bvkeo4ZtDHL79WYxc1Dq/cYKdswT2Dg8YPhmNPv/////f0FSkTGTwtKODQQZqop4/Q9ZgkzBA3IOVhYcWUOQkwyxUJwyFHVETMbJy8RlXhYjQuqpdg86TyxI0IrwBscGwS/G3PKKxsIVN7rPUO7pMc/PcaYhvd3UVGutXJIrIyZjczxkvJI7tmjCG/moGT/rcK+Npm3A8EFBIBC4IxDW7Ae0YIJ7ln0J84izFgzpOYroC3lnyZQgyZQsiRa4k179/fb7Goef/mRfq3m2neNabpH5RJq7lM8XI+9/I8SZxWKJvsjwwyxwM3fKfFiXwY07dku0s7Cm8mn9jer7gZvE6jayWHDsfNFoifPQzl66LeYmruRwOpHDO7ckpls/rf9fU2r8HBEJt9XyhN9P8990efrvRJaBsTGy3hHrxBNfVFWCEPeJPwuSX7CXJiX8CABnW0OwzrsPHi+ep6cmc6JedM+Y7Kmc7JnIhZyN6cmFYSYXYjOsLfnP++f//5hzYSPxjrADH90kh87RpVS9978r1lbHpv0th2BuDRgbG7C8dUGPqq3Z2IARKzJEqRQpA4uSEG0wMDEb7ffVN/71w+w36t8GCBj4D3Iyw2RSy99RTO7oASDwtiyt38+Kh2RkCWST7LoT+s++Mv7fXDmxWfv/UFqeSbKJ7avrGVdiTxLQ9mwW8cIHhLLgxJmtRqU7gQAzrJixZ15/I3X/6zQz/2X6jzQ7EeJK30Q177BwAZwbRdeZ9hC43DDMMWvNrHIdX6FhfGUl5ghyT2C9ul4qyoTVjLJhPztAHxySDz7CblA6KuoUtbpq5LD/fS19zzkXXndPS0aBzZJJHwg17m8gRaHxyDDuMLgmIK+yzGKfygqYVrjOGvkwZznaZcle6BniuOXA8b/8+cROslmCQ4g9H6llKenrEMHZFAhfndT5+JZCYIRYllEmShwnTwWCtdft4zDzNrWMsA2EWdl5A3rWJUc4VhWwTesDsAy/jOA83OK2UgqxiPn24xKZfs3eywdKAUkoFq7qoIzqy9Lu1CWtW6DgLVF4IQwHD8okVCMAdTJRMoH6wDxD7qN0BgEqjhl5h/L89/e/fcbf7764wCCu8azxAo30QsJn+Z+6MgTPWp2/jJJ5gXSIUG1RBXD6pOmP51kbfi6E7AlGk1GjegiPC32wwaxthl3qSuk+leS/TKbnKt0R2j58wtXuA7KC7UPbpmgiWSHuMpTTcnR3JbnlhA0BSbaMHCJnlyXNARcAXPwm3wUH2Q4bOOAQa2aK8Pi2c4KE9MF/OWzJVZqqNbO5ss+4P1H0lhwwHozEOV6OUTNN4Q/RCNto6UXh+f9T9V/AZ00pSSnWiBdh0W86B41tYwLWrAJjUbGn9LH1svbvTbVKfzcICaDIWVEzV0tJZ6Sz1BobJJo564LwMuOy7vf692/83wCB3w0S7CZHEEBpKVKcAQGSwwE4ugZAagFSs8vhzJbMuV2vdV4z5yRA0mhJzeyJXKs553zkTRBdkPsovCR1Nr4svyAILwwPnr7p720SWptLnaF55POS0napG9rktSY0GsfBgwYhJNKjzNfywz+1VtqefdMH3AccIuMAdViekXvdC7n5C3U7xxNgdIDypE1FpeJkInViRFwq/n/TXqnmLEB7DJCPkQmrFHzdp7fX4zsjuaQp8xt1Q+lMs/pFK1eYdBrGgwIYi1mm16m/PkfpVS4wTB3GTh22XqcuoyoZlQyCEBhKYAgoRaRJjWoX2Co7xEpKxB+Apr9PADxs478dEZXjwUieFAgGDifCbR3+kn4ktOJGczaK8P8b8tu5l5RgnxIRWeNhIuLO7y0jezvpYwM5jmEIwzAY12eEK4RQhSuMCbl7/3Xxt/d/KUlT5LCUYVKFa//2REfZrBTdnCXhOZvTQcXRPQzpyTJm/n/7tX1j7FsOPEESIIEwroc/12dD3eLeetVXmhULCBpCAikzmRn3954KtqW6mZ6IwMjPSXsF3kJM/eYr7s5s4V/7oH/fer/dLS+T1Lfl/WrdEBgn5aCK9DpSpWpQjQYIjcZAjy1CWrIF2i5+pB37oINohMOQA0M+/lqhEKZiFmZiHnZiH/biEA7iGM7iEi7iGr7iF7uyF4dyFD/u/4z/kHGBoAahABkT8ua5CSoEvgPcjLkkAlqD/Pmi6BhYURoPVaj1O1q+TPc1y0hjOtiBFvQ+FFr3tg10Vg0209+aJcKltmoAyCEMbol2IZESkyC8IzqokzxIffmSmueK3mGWAcsnJx4bp8ARu4Uy4L/WCyMG8cI+bYSJ7fmQaJ37PsXMHgWBg4V3n/YLBsEnN4gRJrjnU8zHrY4FhSfGBW26MI/vEUeY7kYMbfZsfSSI7UHu/gh27Hkvgqfj2WjxsSS78x3eKtgfMEXO+W97D+B7J9/rQkrxvUSIgUkiQEsYR9thcwGDGhNOAiTIU2OECOJ6245q6F3pAeWW8rHrZsafq7dFIJBAPnhJhkuMDBCAftSTUy+ZS5n/BpAYHpA8LCQMCngwTU4fMH3PkYApdMqDkCZMm79JORLYPAg8ADwaTkqusFY+YihKbej+VUEEsPAEiLlCkRodRizYceHFT7BI8VJkualUNZj1N/LB5J+KYCpsMWBemiFgym/hay4nqhuxxuI2b6l7Oa0rXfhLcy1it0VEN2l3335usbOZwTVPCLvwIjb/w7w9E9aL3B8evAqPjZs0ZcasJ+YsWLQdP+M8fsXv+BN/41/8v/6H8IBXB7wu4I0Bbwl4e8C7At4b8IGADwd8LOCTAZ8J+HzAlwK+GvCNgG8HfC/ghwE/CWbhtAHTtG3BbO1xMDWHBZjGgwZMqzEApn1Pg7E4kQCm4SwFE6LtwFQa4syNTTwqR0IqxVKkYvBtJ/yqitCGKLc/V6o1DGo5Zxx9LwY1rkoddvzEu2nfn71YsKYWCQydRXPqebBwH6/yomAVivuZog4peHTCYdBTs4QfL/vipE77DANmlRufOVKbBP8zuxnDMRbTsRDPYz224118iLP4EX8TgcAgKBD4ZEr25EmhlEjZVE6N1EuTtEqHdMur6Z+hGZ2JmZY5WZjlWZu3sj17sz9HcjxncylXciN3cz+P80ue56Cd2huFxRMrdCYURaDRuUIFp649eodhSAyeRGWwefxpHJECNdg8/v9IyFbb0RyfVMP8KiNFTT9TOr99/iQ4xQqyZjrekuElVTMdEn/sLwQag6ZA4zFhx0OIBFnKNOglMkuXq9gMNZq0SZOjULlat7Tr1W/EuFlLVmzYte/YF+f+j4F131Ky8oor6pqiUQlp6bmFFTrtusfew2KSMvJKqhraevqn5RSVpG2Csbb2gGG+GEC/FzUYGUcU6Ofx0mCa77ugr4sPrK4jP2CMLxKYJwusBfs09tXah/1s9C0BRNg+tSPXRI1l28H+LixkN5YY6gCj5+qedl7R8mjgiyIp864c+lbOSTkQEp+0cqPROYdVw+6k9XDhNYwP5nG17Y3k3G+/oJ573se+FTeQH8eLjWJuUSSwyDkChG6h+1W2u2Bk1RY0OwHxXbNtsvcCD/aqxsBeFs/bbC4u3zKcsI/XfvKdG6kcTFw5hn69Ozqkz75pvFvEMql5+N4+KkSXNE7LnZnDg6f7a3iOrsR/UBHMhdB3kbvqoKpfmv3x8Dy9HRZO/4+i8vxdZ9HWLmK2aMugpN6yWvSMz20UXpDT4yFvptM1BVs8geQfpJAwjVb74WaVfRQ631EPMkfTRuh5vhOC5qswLpo6Y9i99Hk0Z+JuZQwfTuGFABA2q4kOaGiamwFQG92CsWQ4/bn4AlMBe/ZpAahKzx4sPlRwvLwwwI6x7vkovgemNoAATtZbqhQxSKQTkTIwCAQJQCWlgnTWdzhxPOio1CmWSmziLLzWnJ4FfQYBHdzf7uNncU5C2HhmfrBg92QaWpcLQy54IEO9eL/qH5JWeye3jXq7P1Idu8UoLh9xayrFTrIMOHfEfrGVSQkw72ON0hVoXMGiHf08+Hus2hjgD23htusD3lAOexLhGLtM4iy+WYkf8cOruIAX4PcTgUCA18O0OC/s/Lueucm2yv4Ge5Yn/yrfN6LFpck77GtsWxt6sG2yfOCvxzdomndZX7Y1d4sN+Cub7oqzz/88iwvRvNgd9PrCj5vKfIz8iRt3SzgNt1p9fswmppZDpbR6W1WZO1nnIFwmNpGzt0SWwJ9zV3bwaWFaquZ2TN2KeocIlghtXAvvL7sML1yjvwDJF6phWp46Cu3ft/s+2Dw7bQZRST6yK9C6ZabmJ3vnqenhGZRTVYYoha2yCRE1fvRaagtW97S966aZYG2P2bt5VRNnFwynyMVVih5O9IwJZygxX83YHAglaEmvejWu+RW+tzHvV5oKCSHaViYq0+rxi7L2IQbotLTSahjvuGUcFSIWP5niIzt8I6SU4VhRgT5ybwVdnb1fwHHxHjbcQPmWvuR+U2uk6J/jWc0FOhN17wiwDAICg65fr1beWib2QtzuBsPvCyAl7o/AQO2eLGwkPzLrEUHkJsqsYdNDxkHWc5R29IpfuSq+RV/asMSUnrW6/hRsIsx2mbnpSkJS5XOySkuNKEd5NRNtTzpC7ZM7up8UxazPeWoB4rY3IJMk6lE2SYlQia3SmyT2mZS8K1zOLB/ZGf14P7e7I9CurZZ6Vo/ZL6Hw2cmVuDKmfQvwySpZrkKKembutDNF7KhiT6ZXRh7lC+zwdS45NbIxIx3l1nr8E0qFTKkDrmjsb3g2FN0lYK5kRAKI+y7OrmgkF6HxJZY+i7qWD9bKz6aZ7Gx0PLImlamb7aXFhCMRNqH4r38kz53u2pI3NCky+sa3W32cZ7nSbIhyVo6j0B6dlLaFa5fd3KFnmwQJbADUj+Q+735ZZDMyMiR976oxv2/69FmDjTK+WY0W+ZBcjx3Z6TknkeItpj9iVUTGuJ/Ecfb5J5sMbJh65OvIhYyXWNmihUOIrVZWfaPhZB6UJrs2cu4L708qTeNJ+3nJKwoqJpbsCn1A34iHT0lloEKdhoI2DCna9QDUBB6qjarfSWOrdoN+SS38z1oaeR/bKxY9BuLvtHmcYvWxUXGfkNZ9V3okm3yKqKOJFjro4R4DPGCUCc00Sy6ySWsZtBaTg1MQ3JkzdzlyfCiBmzbtctzwKd0qQuG22k+ywuuCB8CTv1KiTIW6Ghh5u2nTrly53/UgoybwsBhD0Niq3bpS7OHG7UN7xaLHQHyenkfJ+4oy+F3pa5LdYNI+UEQdTbTQQQ/3GOCBRjE0AZppllxkk9ZyZC05OEVbvOB/G3MuVlKtLX8Rg18JiEinLm9COyqjGsTjQbuxYt0B4wVsgLewijsHLJR3TAt/v24LI3VmUsrglwLbMBi+bNN8EgMfNmPDS+gXKI7Xu2vSB2d+OINQoCB1kcHevgGYgRyQgfCLHRLXmmC7TjmsHUgUa5/a+sZtmCDor5OZ8wFkreEbPF65NbFFASHdl9ozUF+gaarBDZE33NBACZaPYwokyOapkiblWr4n1PTXh0VjnW1PlveCar3AVu9XAnPRC4kYUKMJkv7v2pLgAAfSRw7iQAwLjwcfAYLEiJMmR4EiZSr06DNkxpwFa/acpCgNYoiBpJAMYiFt0IE2oLRrcglemi1UDUkBniJqyujQwC06PMuK6HlODp7W2qazPtKt6GGABVZ+u/WB/Trk5C9d5kgu6IIcnKJ+CorceklhvaO4jimvLciBXv0p7D6FILpOyMtLiRgVrKOzDumihwFWTgqqIAYDKWRgoVV0Kbs9IifoChkE+iAvltnxpS9biwl0Zx3TNXoYYNWELPIsGm6lBAmQg1PUKWLqOJWbGGJnIkz/5CxWIpt1E4RmwpYDl8AAxI0sKGD7+EsW68ThEpDjS/JD/e9OZfjmgQTfAxMaPcm97P0tfVgTq6/BUWa/Rtwt/nbreeedGOm66Cey187/4GWMfcyf80pHRDEuvqhxf1c+nXr5KbBk7VPpvEGx4vmsFzWhTPANJkOFCsbvBOCJrd3DoMiZfDm+wF1ZKBgW2pFre42cjiFOWohjxHHlgD7iT9q1diPpGSG8TePrW+i4+l4/0gpXk7xM0hM4EmIVY8ERsx4ZNdd+3hvUn36uuKY0PLGTwPYnoezyqo5dziHcXjftJyO+P6tk9TrRD7eG741czy0XzMT6TNiQfMPrPPbJ0J5nzT6wGYPlVnGWfS51zlv1EiWDK/v8lTehhtREY8h5i9fqyIJ1ZwZMl9WzftNqMrC8KzXpmDwttdMX9v5S257KwpLVgc+p7nqgL9rPHpESPdoc0DXZK1PlgAKuXT5j5vjfQZvjXDrgSz8zCgwWeA5a6pnzhegHZbnyOXS2NfKWz/BWLxFaW27jBtemEj7B/Nax7N711D4Nn1xgkX6x+CTjdnyBclndxDmesSWmmj53S3rjM8XKbJ3G7PaH8VldDlQwKdYZh4O2vOsZFWVov0/MaDq5rGfhLWQRIgeHHGoQ6kg0EGjWKvRjAIxBvBjCwrZaG210wOgiMIwH42hM4MUkPkwRxDR+zBDALCGssAOrzKHHTqwzj624MKf5AvbCIvYxhwPsxhF24Rh7cJxdOMFevA3n09xhe11ZI0eN7UvnjG9jByf7Ca+e5Y6BIccLszicD1HVhVB3Cn1SrJXhuKgwIqcwpiRT7K01FmH8RNbsRg+dn701x45FqsVF7Lebw0G3B4c1iIh5tNjiFlrgu+j4BndvkzIQ546Bg4GDc9UAoctbIZZTtZQ10FRXgzOz11PdyVkTV01fl1awSrw8QWvtOjXK9fG1Wl+TmVZ+KX6L4P7eRb/iy3yXn/Mbfsvv+AeiZZ4rQhJACmV0MMNha6/tIeCBZ90AxLvQxzpR9b/SQ9uv324Aoa/tfQpIvKOPtyuQXaX8c6kXgda7/6TAAGTFUgBAvI35tr8IvlmL376XBB4LLkKkKNJgwAJEoqoOxONpXIE8tj3aNiSd6RElRTAaM+CnrWsQvIhtfhcYHBoeHZsIIAQjKJphOUFSNMNyPN/puaXnqxub22dfsKX9mTU0NbvQfyCGgFKjD/A9xjC+ZuXyL84NQQ3g6yU+BaM4yYuyqpu26z05u/B0Zd1qV1XzK29sBxQCiQYNgK/QBGrWBqFbH2IDHqI0agydXXsYvPUekyNHLmn7JwvsOS4ZJVnRDdOyHdfz9ZuZX36xZrlD0PjCGdlefowUkICERYcdhIpfEGYe/A1flA43TadrE19sDwXfikeEGgsesvT41dR/Vm99Hv1bPhe/T/znz9MopKjQYVk0VaLJWo1j1R6Xh0zun3+6ffWV99Qcd7NCIIVvaw7SiH7Yw6cRMR8LIOWCGtc3lz4W7yEiNN7iAmOv7p9kn3e8eQVBjayfthAtRZ7ybya4wYAV1zeWJmHopdm4yi0NL+nkQTzn1ghXGdNwZoejULTvZMIe9lANTseqei/NqxWpVU3yhE3DQcjfDT621m1p6A6z9YmgNXrokbFYBVF3OGQVeWEEtr5TX9muQyYUH7tEPRcARnhMcPPVgTvfjwu7Vx3T9aqB/MyiwqdkfgAwfp74zTLcaGShOsWCEVbU20JkPF/0b96o/1M+rf9p36/eHR3foIHxHKMCiMcvm67f4ZXUQN4iQiIxKAQClYi9Et2jF1d81bfW9ACJEOvfxet6H7gjzdTrxZ7o0tvPP712eiJMvBb/sSDh2H8GAa8+Kte/fDKRiIhEx/5zSy7eaI7kTG7l14JIJJIESYm8XKlVXG0TS0Q7mSfblJ+W03razcAZOuNn2iyfDbNt9szhOTbn5sJ8OQv+ld2dTWAz2Vy2kO3HDmCHsyPZKnYNexZ7nL2BvYXjzMFziBwux4eTyXXkork4LpXL5HpyY7nZ3ALBBbyd5I+fuEb9eb3ruOtsSqijmS6Ori/+/fuxn+95/j3XxbEuoNvDrr5nOte3gpun3MgxCR8wlzlnT8R+3427v3esuINu2x0HZWz/zaEj+99T8pW4EPzz2tfR11nkUXu9VyeH13973vUMV/b/h9lYf9b39X5NHbPHqD1WmmeuGSYbeFAdiL//fBSXTjnhxx++/uqLjy+e3Jobe//h7Ghnewfg18sfLx64757sHu++2327u727tbu624I3nvN2Xs1B5Mh2kTvnYOzwQwAKLDDh3faH7RfbT1/7Zf00wXb4lBuHY3aMjOFxd3SNlnF92JdPueSnPM4PcQKCnTNJgR2TSGOFdwmID3CymxjzRzsMEqTIYJG/SP6TTAWHGg08WnToMWDEhBmLS1ixYceB02VcuGfbz0qQ0HwLL0OXkp1yL0WgSo06DZoTr9B9dRwzyHc0YsyE6fwbs8p3tWHLjj2HSfiLrQtXbtzd/5yOuyCUF2++QSUa8O6uB7dIfiEJEM8qLKRCmo+oEAzhEALi2fiLVwbgI3gKDFEgnl2pAAlBzQPbL4ia1eGJwQfx3OffJB8dHEEfDCEfCkEJYoIEkkO8+2/kHyVbiHQZMsXKkSXN0zMrXhU5aiO4Z+CRsmcy2nb0AuPPWx443zQ7NLleRsuoyfOecxN+iNICiJgODdj9h6Zdu9Q3n5TdHdaf4gJ53yPZ0n8zPGA4lYnznjAIXAY9ADCGmgTduqjJYAb+RaHMn/p6LGg4HVIX9RRmJ5/Vi3f54CF3Xn5n5p7co44dHXsylMKDaca66EFbqUN8qIj8pQAL5M/pj9ixOHA3ze2HOkJGktF+13dko60poSnB0y5IyknNFedO0r9gmGbP+0+FZDZLRnJmbvoIoej8vDUFGILS0kxnlY4UsylQ45DzPs2qwaxEvC3GrKhZwFUQz3bsQpwh1/IgxdQH3nkhu38/WfYy1NeU+VjjkUsnpmLewLkbRe4kYZDWcb6ChqoeoFqJtgyVFRA8lsizBcU+ywzVtPQMQOdUr6b/ZEhh/eXNVQNOHLgPZtIbS4HD8NgbiljVhrNtBEPk4stSWjxM5lLDTLkS/QZI0h375xSk6VGTNMj/RDyPplh+oKCuR7zAzfl7z0K3qHfi7bHHOT4KdwrPZhys6ae0AJ5PO4/qs5bqGf1Hiqb4tVcywCKC8piDfzIMc6mdv5YUkU8eMpCC1Ayye6ZFfg3sLn3f8qNmiN1j3T0NU86XIadvmIKW7twKDmWkFhhw42acLRTfSvHPIa0LKKzhRXJJyrOXPwPnQf/Uyx3z03b3COsfuBkz+jQ2mtI9NfS0EO2tW1BGMiCJgHqKcX1lh6Ui4PKZMpgChvQOX930JHINiKT2O7y8TN6BkE/+hwc+P1U7d6xmhIL2qmaUQiGJqUziqiAJVZKkqkhK1SStGiSjmiSrWrc2EJW3pK67ZypoSG+VQzONzRtbYx0/+7e2Vjt+36BzLLG7aEpeGVJcSEhBZVJUBSmpkpRVRSqqJlXVIDXVJHXVyveBtoiS/qmR4YpO9rzTI1Q73ldOkwNELC+t6fI6GQQYw4A5SWvSfi78LneCkyFjkSveuVLK2nFwWlRcG+pTE1Bsk80i7ufb4BXTIx2WwDKFnE9yNupey6HrF6KyyXeyVtoRxXyddEGLMesZAmfNjA3T3GjHuzWSLkny6qlzRykc/u6h0R4xXkPGtvPncbLjCTpxjezcFPqRaKxdfVxMHYPoYghS0jpMkyl22J/XUjXPAwlo8xjcwriLBlWS8mJCeuDJdmTNuSv9yYerN9xPzqvSQts6YQq5BJ2UUbWqVBXlsX0znj7nYcWZUCjNWN+lkkMe27aa8Jkk4JYyyyitOaGp0ZNJG5HAvUZ4trSilmxBE0PK0kfNFB5lFkgYBVGL2HoGyFjWJibUEIMnrTLISLvm3jrp0LxnjQAwggETU9eRE0PJ2uXJotqgFe/MJQdLcXkzpe3QtN1FMDRYt6RTQ/FU3BPTe1Q83fDYj6jJr6nf5AwLbxSofVw5JD1yJ6ZorSkDEarIzWc/9ok7Wn4u24KhX+Z5OObYyhfguGf3sC1f9zGPpZtCqYYDhVjkF8qmnZWeSbQrg2/YzhS0aGQNdekSxexZSH+ci/PfinEJBnGgDTu7lTXny0raG4tk+VbsVAqJrRy0Ou3Fp4Iw/pVVu7PKyx6127rii3SnH5De2BoFwC7FYbTW47HRkWxcDl1DQYNRLjVFyU0KsxbQ1ylb9OqYJa0MqUGGOzllRA0y2sMsK2NqkPFOTgE1pipSYTBPCoaC0DZOmQgFmdzBkDIVCjK9jVMa/B2Kf8gpVL/g8B8AoPzVCPeQuKJUEN0JilETliUFIQdr4QEAJYQSEQBQUggiAwBKCXV7vf6UfmpPyFGKN9PRlDvvJI6O8rB6Zxz3yRBGaAyDTIP0C6Eyd/xSlo5fYgW4Uza6I3sY5AgjdrZb40dRie1QVOI6FJX4DkUlgQKSGIbkRhjGkmCrkpLcoaSkdCgpqR1KShoFJD0MSUYYzsr02kWCQvRmLbVqNsbzW5Fcrxr5fK4UhkBwXXjIsF29H+mnjsQfRV7yMyKv9eeRmx8ZufWeS7zAt2dEHj7xEBoSbEQkCoIjIdPr4khFdEHWc8OIDygkiGDcBGEXl1EBS0E2VETvutD1AbCOESTVIjJYvBZCNCJDBcGimp/V+3B2BGwd8IwioKgYySqIempfAnluuN2yVkRRIfiACi8TLX7unz7TZcowEwx8FESQQLiM1RBk4jDBFxpRp/qYka0Luejo+MMbzNdlov49asSFHy9c7GBpI3CBqAyFL4zZSeDh0OWkCVnr6roUhKER9iPLmI06/P3/pnPgfPDN36i3qHEWpLmuhUzF4NCaFv/J17srrTTaVh9rlZwA2mx6jsTrtoAdSVu5twptAc/8QqEaVHTqfxG91KwsX0AQcKZa245aavNBy0lrH1icC3HeV+0a7tVZ+edADyWqw9/C/Taarg5Hih3A/wzYK9RmbM/hxdK0EsW8wmQDXYkYotay484wz2thFd2/DORDQAMC+E0lXj+rH2HYVCtiyBHzZqefW/RqrQWjaAl4A4DTBqBO6GMmCkRpOy/OlKa/ZwxDRcrFG0skmqGnxdbxmJC9SvnKlqre0lPr1HUQQb5uf9qyzw+zOjZ9pC1+IjowVhcJnO2J9rGlmbr5BvD6Md4uW0RhoTqui42tvXnGiuOcz1UYG5s2hzrl8Gy+Z1i2sP7PitoKrMPv//QpnYyGar5s5rDNRNcnfIzNN/juN+D2ZUbUPPgZOipUylaNQOhDJF/TLMnXT8CE49CE7TRmXbk45rrk/aasIIPotzItE2PKLEshnGRQBEopCQnmYutsgRAGBJbqO+6dT3PGEHULDvBoMqQX7NhILMcAwhFqAAof6878suJ+SqiZ5bU1e44IVU7NeEcRJWBu33BMmHBUHEU+44KHjKJ3TExLYVW6mJal7RToSm6UUNFDEYZ99JwkF3Vx9RMWjh4qyAhg5ACqsjNTARlFNHb0YSD8VuSouuQLu0ZS9Uwq2tqXhHBUSL+WXC4o1NSylUD4JPdlmZbuOqde6pnlep2W4RZ/Hu2LBqso1MsrMnaFWbXsiEFEjaA3T7PdgQBkgFpkJfIqqp8SYsZC7Rkbws9Y/WC0xYqSnVVaYmzfTa2mh5CeQ2MvLEyvh1Npw0vOhniN3Pfu81MuukkvGSsWhKPSMRhmF2Q3c81Mhgqrty4zbgiIhzekJYXq5KcuJRntYDO4PbS/EavCmiz6cAA7k+j1W/4Jb9Arl5ihkBIaQ4gW00SrXRneGrsjx7loVZyHJsZExsen9eyKmBKltj0ZaEqvATdsxxhqEfTsWmXom6pH/IlAj1jw+HH//Y5nGjuujQDABxAuQmuD9v61RiaWujV2hC42uxjjBsQX8/AQ+HKWpBajLz/o58w9cd+y7zuIP1NESEWM1QjNwpZ9nZ11k0bKHioHwS4bPdSaKiBr/Sk35vd1xIvmJgfSjuckej3TyCTiHZlYyrds1Mtpj1YDw6RWK9OilvWzBnhd3qpfjeZfY/kp9zJhLpq9GBIz16xZE+IF6mKN8IoGlk7dzgk6h0J2j8vNTnMPq6WAshkLYKkOpB1bQyao4MRJMRx99dDsptcOzYUsMXLO7QJghYuw3uudSZVcZovmgPADinuaexOePdv2xoMxtI1+TU6vBicSHqFEPtlbv3qIpdsLamqsfhUBzBrpZoaonLAKX4dyNX1Hp/CNwhutDAAZU/2LSmzxKIH15immJD0sKiPNjeZiTUiZhcetoqNpUe0LR+mlLBOTo1ySg5BfEiWtV7a+AMhGLpqGAAA01mExi6v7Iz+qqNYQZJGP6Xd1xh1WYH1MWLXV007gqp3GhraFmkttEbakx3JT9B7XOqz9ZlFLbnvSadAjQrlSHQhQ0DMmNpdQJgqcjSbHBxOgOp1HW0lYx1GhhJ3W3Vqz50I6q8eMrrvG8hHftUoBjOi5lPt11plWOyIKhXz0XCRtEaoMAmSlJBv1DATgwLl0wKeaTtJkbiXZp+9o6ZRTiirb85RbkAr6Lb16ziKsWZJVxAYfyoD/kVFsSR1sK2/KGI7cFHK5DRXyrWdAtkjQvYETkOyNsBm1JC1W0bcCamHLc79CJeTE7nouOGrs/n/AhZlZjqkq5CV75dkQAqMNTInKJMOuZlbLrejRFhIWW14yhE0bnCyTWTu6QWYPQlVH/YyCtnktk3PjUg4UytO4+2JSQUIT+43LHiCHnLk5J9t74CFenRL3TCwC4cjh0lN8izucIYWb0TEPuzCVSAmzLAkhuUKSmQdQM5dyqQgxXamMmyTqC01G/gtJFOp1oQiNDSKoH9MyzfDDpT7ql5Xf/NCEQCq0MDOZhoChU+wac997Fs+yepKB6RhFHyseWT9j7VtYlHhPO4bPxZYmR4knR4aYD9RsEIButN1CVLUNrs3Z51y1Q9Oq/NZujQpq7k6VI2Y/fNvSMW8yPkI+RgSbAxMfbagDySRtA80dWafBQNBmHjDL8ti0j4jEibksR/YNmGJyM+Oi57h1jTf4a43O6CE9VEPraVrTmw3EDnHrOiaMWYzN/SiEhJRlr5n1EjA7bWOXhwq+nGANT8NA1LNOeKnZBcUN8BZ3zrfuCF1pVVJJS4vNzWILoXp4Ac4m2nJmWTwHWfn8tih2Ua+cc7loyoF+riUVQB8dMgNnu6awU2cECdOVqMS1ktbGjam1I28y0IXzHdHIb87O9rz2qi2LtRpdJaem2KQSW8SJ0HBnZjimUbd6+A1/rMdYROckJBBMmtB101Cb67Rs+rskcpXSiIUortSYiI+my81Ey2ff5ACM6F48FYRPtQSfwHsbu1y/dmboOCrwZsaUtuFbPcmVrerlNaRNwK+0iAZzIrBaiOT0hZYaOuVAzXGEFv1d94s6rNT8W7mxJOo2e6cAJMMBTuWuIlMhLSU+y/hCHxuvotYmaZ46cpnsBbUucPIrLgqkWNhCeAMJM2NSaGi1yjg33sqgDpdtqF+eML+utf7zikD/XQZ439xAoLzg0AZtC5MwS7pGTepIS/cjzhiNuChTM2JPdrHdO3ZBMO4AxSZT4L92oRmgDwGsRRTI7hQrzK9J4C/xph5BFG9Wi8Gjeq+N6NYH2vutJjgMCZEWOkKmi2AYC4nF10rNIR5PHTy/ZCnRihGNJD30JoBKbnuOPzTfgKFOUxehtWaxEyzNzAOAyFDmdbGTTGQMq39FsV6DD6hFb81G0RmBR9W6SQVHraQI5+UK/d7g6WWRSlq26jlXP2beNSHgUG6NHq/7RVU8ZnkpbiYwEdBwyqkboZoQYQs+4IVRcW3bh1OfvhqrXPAJR4SXjbep29wOqZRRzAyL8iK3LU2WDionrtp3EaALmMi3r73G1/Hw0LrRB0XOVrq/cp3h8AVt31Y0awyWgoYnYZl3Ry2CRePzWAP1oD4ld5TUsloe6jhEAwdsxEk8hg9g8UPzwcsSi740k0O3E8uAnAavfZw6HYedU6Z61rQp/zg4Yfq08WTe20Uzi/rjXSy6pf1EqsFiMLiuGzABadgEf6cBDpYCeakERtkUQhuJMDRdnepawXihdv0ohyf/fVP5ce3WsmHJvKAyE3iDTrlEy11LDa3xSaB3F8DUIEWMiE1PTc/ELAfpYlUV7Uc7Kg83Mo+zEgxEytHC6wsmvMj+o3ytVa0MVm2CSrlUYkB2gplPtWw9W0LBdsyVD57v10htxcXTCgtkXhhM6boXBWbBNnOZTFXW9RqPn1jJG75QVNy/CDuN+HfapWNx1oktnuZme4nIMU1/kVn8YBHhWzyHwiWjnKSbNDKFbb6uaIAcsZyRUyF0n+RBxjer0Gbk9cvptZFsgJAZQbqc1BQYiftnUpNSFzcg2uJ+LlCEOcRQ5Fz05LJhylSYl25mfpw+T1a7SfA/oVH3cPCtK4P0Le4alZSLPM+pSOKb22jjYxEaF+xMqqMzLW5eb3pmLlHa7JUZ2fl/Ug7WAtEwFOWc9S5fp45nk64/SRrzbYcIKYW6FjpnAjF/KLhkEcJKQ2OPzIS9dmZ+nPKhiUtWT8nHsZB3C6giOh8yC17pFHIEagZiMI8HbwxnsysU2XHMBFaoZRqIJIOsoSGrTNYyGR3vLVa0yten7gufIlZhaxc3A3UmT6iF00QdqPD02QOdbuQeZJxQc6um8BwlJvzO4L2WKBJftoGZOooya6tF7PjsSOfopL/P3GTpKCyamt9in3xD1h4ZOgenVse1Cce73x8n83klvykSKpRsK6yocm5aZi/7oW1FIcV02lb+yyBWWy+N9YzZ93SdXnUKtvHCRcd7rAulOdHD9k7DU8gExEaai+ZRwd1J8jEpiVa1El90L8xVZwlJWM1l+DbzWUjKTudGm+797Ng/D4zlOF7Vw3jDmT7suU4gvsHZITYUS2HTMwv2Ay2UYQPYDsicWFpuh40LF6R8reiXNW6OuOUgph5qIYN3u103qWVb8scy8aL04aZ5cpeeMRZcS8W0qq9fAfo+nSvqimXyfi8D73xAsPg+ei3kf7HFUhZSsRshM/9Gu+Ot0+WqkFE9IceQ1qb1IfvhqVj2OlXdk5bAEPKs0UXPLS5SnjO4arTMH21y/56cWlGyyD560uusHBNEqzXOOswBq/Yjlz2ljlen6dZLv6NVZiMPt2RWVWl5yI2Dtr1M1QcAgNCh588IgfB6rz014vUldVyV4Y3pRZIpMw3GdsbfkXHrseWp2NXz64ruzr92mKdivuApw1ZHLj52DNMzz7vH6AebvVMhK5j5TlR4ZEqVW13NVyiPdmWwHHtL9S9I9s4ixF7cwnXT5o4iapjtEGdcug/0+E9fdQyCa7YpFrdRUPum4EZRjnKuc/NAcHjKUlRt8MLrM/lzKGl9bywTG3LsHHi3K0Wa7zXu5+IAPxgLQr6g6owHx+v1WOSS3SwCezp1vn0Bja9+ug4ICEb1kWG5nLdzaX4pydWZIrgn7sexgeJ3e2R68rA/YkCkw3nHuiYIzdBt5LLrziJjM4vso76wyeDDLxRQ9A3mlbcTlmU9LuEjKRSHiXa+OGyMvWfPRzErmvTTU2iFnn4M+xNPVm19VVvjiyOENoYqt1ymtcPVKvjysyzF57WCvrnT1pg0Xs4gI38uxdjyl0zU5AjlQ3O+L6BH7ogHO8+zRXioGrlp9zZ6csVzSaBw2Aa18Waj8CP+sm3D8i07uw8G44JoMP2UsU1v5pjy4OU008jsRapKDrwsMqyQi5kEXsf2UMsmCTt2lMBYktJ7FlRwrhuR5LDUo9W+5aHqFyefMQVMm3kJCs8gZaNudjFAPjnj6tfeVUqFI4HslLfFDFW4XxK41rDpLBayLpsVpfNqBH8k1XF3gxpaMofhgJg3nG6Zk4QOCztAITOfZU50Q3P5XRYoJaCa96EFDqP4LvoOwupxVVUkT4xhIVYg1lBXzWVzOLS2arWQJaPov/VShHy6cuLX73f9iFu5HV1TAAKTN1jDz2LKEl5zQOxzx4M4C62Nzw2g2KnyBiiYNewTiyJNx52WDtKOhBwhleEzC7nYWQdS1SFBTskYAJDkUpKk44Pllgah2gXQQfXwjSwLzdeQGcAAcvCafirUUItqKmRIzWzl0qUE7PwBGFRxqImw64qQpPwUERavpdO/kKpPOeHppUzwU6S0s7kK8U/uq4C2whJUZkGuoqQPwRtfRLALAsJFRiZH5CL98YG/7b9O/KFHOc+o7EAN9GzBqDCY6h/Wcxe64cxFDPWRlMo8BYfU08PDMlk9T4QquP0BPHljq2F9xM58einKWi2i1fbS5cSR51UZINZhoCWgtJbdEIiT6kjmkPbr+MtbGHKBOS08q6xQOSZhUmxxXngQrdQG/oiPkYwtbvpm1mDe6wEX5T7Y4xalgUNuHtmF6f83MQCAegMJGIyJzUGbNume7xRQVfX1qnLHYIOHskd2FxPmUUJv0lKn40uSljJDw59U38xvmRxAKRmpprxObiKTc4GjgRKaFi96K6FHGLnsKBwJHp3p4wW0M+3ESHfzEYam2O2lXOcRib04PgG2N5D597ayWpDl6jTiebrBooQ/oou4PGMTB1mxtGBjHR9r1a8FxuHDDzeZs/yLmYbiPRtzaobKK7e1NvvAem1s5g/uUEbEzjCu031Zj5hoMHZlWdAKMOSb2x/cstOewhvlf8JrBj5cIBGPHrAf4neWMGSR777PRS2fTmMi08h0B2xyE9jAz4lr05Z/QyfqrUqoL1uRNgddqMoNr36pDwYaCiY1rBO0zn43Bz2ADBJfaXL6xsRvfljlElgpneDpQgqn2YoF33b1a7Q/caVvyGsWJ1At8kY7aLfaOt0YSHIQf1iaahrqGWjI6ZF5RC2uLEgsoFq8JaZxMtxMeJDyo00FNTvsDNLPWAiuWC3kzbyJhigBACNnJDeQuMCfPeTWhEbIBFhqz4O2XZj+KwRcUo0M7WhrNwIhqWHZCSyoHwos7y6gJePwuIBEA6yXMHLRcEUFtPTXzstWpQuJsUinfNQn4QP6DjzAC7Amvp9WRUVe67rH19JAqaaR0WrFNi0+rph31/VMGCzTsCMJ6zzcxEqZRCCPc1Fuy+3wYqouU5NjJsZblrqYFCkqDW0rfm2P65qRhojKNUEH2zwt6SWhbmlb99ic9ERCBTjgVtSyb6q4QyCdf1MwZ1H9Up2FxLoJwlNNlxUNMRyPTembBPhn44u4VQaccFLitgh9kj5+VKlRAsP0aYSm3IVoEVPF6XTiFnfUvqBqEnpNTmKj0QqKmJEqrXXCt4Ao148HTvXm+JcnXs54cgH6XaUrBs+xYeP7To/DSHkzcJxZHsp10Q7CIqbTx8+uioYiizOVD7gl2qBndF6PcZg5QNKjEaeIFBJX/7cEw6Ex9HFehu8NrtS9SfptoJTssGVV/6rGr3cn1mL/myihwdNLkSjZIAtHGyYumOGSrOOOzjOC76qpvkELVbrefDE5NgKoHCWxvnFCSw5FYZKWQlI9xER8UiOs3stVpeIDk5ov3myqhXf3SgGjrTFZXwxDtR6mYy2yFX8L0EQAYrhigckF3yXpj1C2UvDGCPipn2azhNhJLuJoBaIa3qg44ikPQ6Kr/+zRwj3o/K7jvfm/LzLzFAl5fK57JCHbwq06mEao72fl9fuJLdvvFfBfjKNPKdg61og8ifETRFCWKfGhFSwzv4vxv7+fklp80eIK6/9+33k/kv7mt0SOmWwa3UUAvvJKb/pnmHz3IgYklgSuhTx55Wsu+Rv9dy2Grzu8wa8A4dNOtAOdLHulAA8npyVkgHnddfdCOY/l/l1MI7mIqWfriLqv4qjoS9vzMobZbhjdjjdUZ76EhlQ+WJM6GuYvVildCZWpbYnf5pc/gCIaz7ktx8el9zL6gzcRf/OLbScH7P4pOWKofGiqAPAm+d35QpncIGJfoavnNbudhPeNNEMTlXaWdqTFhLHaY94QgFeS0FRppCp0EKU+OA9VmnRH0KVvqBtFEC/fD4FEZHKAOLI3pp9fd4xSuq87NUK2RBHOJyU+HbaYVcTFbDicvqtIaxyWcBkDl+fHe981CjEJ84oRiaSOpG+T3C2+XcYKbgfXO+u9Cd6w9sP1OM+3tp78HuOCThHBbQA4rNSe/bGQAreTdx1SP8PucAC+Uo9xkreHbx1CJDiPcrFs+tvEO0P6AinfA0DorIJdt6oN6O8DUfrvq+Kty3c+1L3uq4aA0WuQLwJNsRRDKuaO0KNE4U5q9vLV9QpaRZU68L5jp5kac9MQFiyrvhLrkdua3KowIUCPVexWk4ymqu2Eho5d9SUj3fdlw7rrZFWq+xFfv+UfSxVfRXqphjx4jzb5tVvjhTfhO2Nox+7HPKbjgD4l/3a4ckxIsYJau05u9ut1GrLxg7bAuRKQAU6xMW4bWqMiknL7jftSEcf/F27wsfciH+l1n5F4ww++hGus8/zWDyPYraqdCu1E+NFVhelkxZERZqUQOWtJaKZMe9KmBFSRAi9/3OD3rVW4y8xTHyjnWSX8nGWxhdfPG3M+3eCKkvTGYychkwWmRgSDnW2uie+uYnMX+SbiENvhQuebPC61dqj/yWdsZjk5P3P612D+y9f3nFvn7TcNBzj0sgIFN8T7KUbwFQBMSZBtsaoz/bvifEXB5gBbv2TA9RiXVzNspU8gV9cuXbLWBwGzUmQkhLbct/pvoWVLKxY1PnNNfB3Q1nGoYHwZFnLKpy1Q+rv+jRHDvhEo2GvViqToB3tu8i/j20DHMm/62/VHLYzAHspkhYGh8UX6NW1De7/z0eTXKcbr+1j/NXPh860957PJb+dv7vN/mU9+trkd/3zqq5n3ZdoHtchEKbU7WLry7gjT8LrRdLkHAIccZhqDNwOz0vurY/LpMXnj4HaAQmyXdQcFiTXPxL/wZyytZnMK9fhQUWzG0ZFHx4woO8aO+hOPXtHPridEUVUQADxdpQSh9AiH9KXMLuRNpvcaZr7fMnoLttVe+qfJfbx/fKoMNxzN62Qcox+fjOTpNpsCwB4L0wRWZSeIJFKDqXOi7CTcKzg19IpYbTIdKRzWGPc0jY9qYdq1UMFatsRwBOb4NwdUyLPTlRpsq68RfgjA04qX1xWBejRGjjTYfuEYOtU7dzIz9Y5AMA2dFeVLWqZ2lNT7uX5+gQDM32maR+UaGfzvs7JEikPgBomLQOMdZ1Tst7GTSq/dOUv4aumL/9pwLRYL/4YAk3IAVLXhU1w1tTAYXWg1z9g3D9SYVDI5i2ezAazSKXKEa3bhW9czj5kfzUX71Jtf+W3W3Pa8+c0n57mm95/OCmDEORLQDKdyqWKic1gMdB5vqcnxhSJUPVgZfDmzm3I/oTszTkK8mKYAuEvxMyhevpc1KmyftHRaPF8eE03Z8Rp+KnyS5+UgFakGQxkXk3m9RlzU1XPuL2184cC84jcSuXLZvHEraOMGYfot5uRgt7rzo+yq1ecRVm6K3fzlgf1Ek5OrNQTy1RGwqIlblwqi4+XqN/tUq/uvJQqNuJasOw2FcgkkIPgHX7ssACoSApXSDkC1rVgm6zRLoSARvPJz8zOfXUmm2IadCJdKQuCXHJ0Hzd4lR1FSYfyPZBNg/YIXSiLCXRbUz5npdYg5NkolJRWAACiThBduGNOYAYdAn6WXKa8xDkFMfIYr6D7VEkhjRyPBgs/kdHk+VCILesWTSIOOtQJfzFz9w7fEksT0Y9PzuDUfNmY08ePgEJeHRjC8I/hszO4MbqYC1GXNajTuP1Knz4dBRtDbH9ikQFyc1R29ZVKo+wEMq+LXxI3SmGOoPVVhC8FNw88/XfFTW/uvASkFGlEINkbU8UYIQDirjnOYqqdEIzBdUl6QzkQFRJWOGkiVUSVVlhd5Ly2ylqfZ/90tYVXKxTTjUdRYlodEZpdnrYEniL66fSVpc7iN7ahMcfIfrzpiYkGAuaN2T5XuGhM4z7mj9AVkFoBIEhW9CJ8seCSIwd3tX0yxUuDeQ+MSmfuPQ6S9sfwGsWIpYESwZrye6NKH+jqAqs9Zc24qZUs1GnL/rLrtv/GZtIzhAyEZOAM3yNtqSGTM6Wl4TouZgcV8cGJInI+sRnjyjMCNikhZcP4Wrwc+HV94M+NhSwJ0Zkjcsv4PBARTlqlvBa1FwlMJsEhAHFpXioNJS+jHKCNGBESRw7gsDGBZaBA5g6URj8LV5szEbUSQQYB6n8gutUkDwiWG4ov6NUaqiBKaiWFpplFq42ZiMYC3oImgaoA7xjIlNIdbyJYu92vu9sYqaz/8lAehlJ3TkS299lxorsns4iyuQY2jPuJbdKZbCi17u1bzNKyZFoUM2cN4Ihowp4ilmi6m5GDT6lMawA5wZpJJxq3Ifao4MzDIqpoqw2RsxX9+vQMtwXWLMS9NC+Qfj168yNpD2xaaUCUhbJqfbIt31wDgSkLAsbVaJwP/52Zkxr3WyR1OjXAzTWMko49JrxaNG5NjsqcgAjBo6s8coiaoSgjssmBMchnbtPMs4pqVq02sUmdFQJDNimnbz8ynmQ3gdIyKNjlA4Km5jT7feCwINo22tZTO9lsfVcbkmPh8seVT3EbeTN8SK08NRQYfg+SWTXnYarmW4DyfBP058vvFflN0XLW+WU8TNBE2R5fBwcPsikw4WB5n/XBYwkocpInbZdetpyBg7EitBPOAw8KBRpJXX+CMZaozVWKmtcf9fv44cRs4DhTCyBHySm6amlT/QU8V0DW8d5tbYg45ObXBZw62iMLTbvZupbPaf9iy4xmRT39G4JOfahpTbm+LaZY93c7nhkZ6Gjz1/xr1L2JA9uxz25vgOnQ5I854BLUEHiVW9vzs6IijC2fjsarVGUwkVFkV26OxnSXR3O7kZZ6fn6IxSOIHRxDzc4JkqB+OZJF8+Kccmv6W4yEascp/X52wCT+4z6lztdrUUpRiDxnQc+6pxe6z2H8T4VEbxCIJcxhX5+ZsRBlpaZBa+Ebj5vg/6yQ3e2UV5yHr54AcLNXWy3fL6SUBD6BlYokIoL0wHo6eu/TTHwD+LMeRI7A9essKmC9/8bFtEtlGAVqCjV+QMEAiWvjJw/mBI3LvZaA7JoJhhpqFO8Hc+1+Pr3gZATcjP/OuKKX3quLKrllxb+c7ZTvTg692sCpEeJ6DEtMUmToFkg1TlnNiyd3LYWzumhxHP7dFaSry7sNXHkXFb/9ekmoM2lnYFxJXJ+vZsYF4kUmjY9KjiQYAjP8WrDdAsHuKUUV4SeROw04cPIXshwsbp6pRuugayorz+sc6DYpUWY+oo+zW9XOHejlUeNjXgOGSX/8jOoUor8azs4wfHtjo5MyMS8f/KtpYGWIsml3cPTTyd7/pJjLxfmHk2npTH9iXjuCV/l0EkADGK6KlrxY29LdDfKwlIOG0asUCitZcuj6W2/0NsTKM74iGLIB0jc7wDDWzZEYzEOGh5bWiZQaxapKvtuUFwMqNcq4siAu2JHpaaHGw8NDQFHs72qlJvfmycjU8CniWdDmVr+aBv3/41QGC7DW5Ot38xW8aXs8hvbxy2UjlBPbCLEbyOSFdE6EZcyzBPoQpN/LNwNRmaaSuXSP5+RetHuV0w0cgaqiKJh1BS5OWvoLdFbVsfulI5HCXFHhdoPBRlLgeTSndSJznkUiXo5OsvWYmkiluv+wFdXEjpmPCCqKkTXgWt2pLW0mp0WuOov/C9HR41WX4LTJzYqF3moQKu5ZO3fqyO5z2NLRVg0Dp4NhRlm8Nn+uPTWUFQimtE17ZWXV2iRoDZCq71CmYkXyUCLEK0mVEPb5usD8yu3YA1Gp3nuMcArBTHGIFzeuJRGFXbSF9yEL3Y6guRPJ4aUsOTbiEe9RFe7V9QqgPeCADmcpVAsLeyH596OGG49Rpap0gNBZUpLxO3zUAx1kEK0vVJQiFHqYG/jtbxaF5FkmO8Dd1zKXRY2hc+GwAmpt7gXtC0FCrk6CSYPB/7rvwfQOHGs41ZuRXV0fyWdxPSVvXqU+NrMDiS3768+/e1OZX7drYEYC68aXllv1jOYI3tnpYU4O42zPbOq8kQYicJAS7CHCF+EWC+Mm/FDgeR7B+TElcfoT9T9YRj1td3uZZWvYj/lwoVknDZcAwcAa/niqJ+EQPkxc8WAB05lMNspXYcyPz3W8Qgd+BWH3cIDaYhN+NDdAFpP0efwhTDRobbXd8LyAsH+io6aFcAC6cxaKEpNLyEKMoDBtCez3DnyZxh2AHEhNmf1tB32xdZ2fT89egksRRZixr2sClcb9K5ydNGG3ZG2AsORphMzk8KCxVlXRinTxIy3gmHDCdoVzdh4yRegYaX+AA95ZC5TvEOPXEYS5HCcJlcFk1BAjiYWr4aDME3Slvm/LBmn+ATEHIWFI2X0uKtWsSwEJHxMrYmtd8GwlrG3VMw0EyNMIzQqYVgSmDJphAp9rYSI90Iv1f7m6w+VLIVNYQnErTooMLL40d4/077zaOWwamUTSs0LLRDsLhUsZqk/buu0CWsl3wHfF5T00sBTPIqdUgU5dcnQwwMpKV+IGO7CTnciEI4Q1BbIlyhwLrPAsTd7AvcZ9/Bu5748Bo//79CyfibV7C27X+sBqgzvbPKCKegZ1h1ycMd+Le6y3r2yKOD5ixrGjkYYtfjmTdx89E3Nym5TvAo0d0ylDbEIRYGjtO5iG6X03B3QbcjLsEbDzRD8ml0psINALgM795wIitizNDk6LvmGBZufK8g4hXz47aUffMsvR9QpRaBcj631jPbIf8876nuvoph9bzn5obI43n4Bxg/bb5NgT6ClkrOmiDT485tBhaoOONyDwuqncDEco9NLl+pzpECdXfcp2crn6YoKRDCW73WilaUdLIGPSKOY5WRWPQRSDTMTmfr06VCsynTa9D86ANBID4aZRdmFqerSFCNgq8mjFlKv0DkrTT05PrlkeF/k/Vg645SnzSV14iUYE5Qo1iP2rQjA/jvD4y94ZenQXmGKJHx8EfmugWjbMZGQDL6f9oAEXMK3AtBaeDbSyP6eDjg5bwkMGqZTE33ns08RoZJ8chS0UXQLSchCn95IUn3GizpS0ChF1mFoMpHojHRk7v1z6m2phYjDrENX8GH1UZPuFbjK80p3htgfEyYb6LKAYPe1KgLAfFMN+s/rS4SzlhQxPt7Jetu7pXSYue8Rm3vUHv0IkbURNr1MIC2WaNs8G+JvwCYkA3NDHXnorLqaBzeN1dIUwbokPMOm3P7hdlR9yjiRG5CTMwhKWPSH1Ey+2Co8AdzjsjYL1JDtdfgzb1T84IhMJBAXvdKipOJIy08gfX5VbrIsDh1JvkdoWJnMysWkXiM244JLqAwRUrJjhdVMakflW1Xv1Ke8gatc+4fvHzdRUYyQtCgGyBb9VVDApDX5hxM2v6+FzjCSyZ9S8ZYeHhj4E0WpdqpewR67SBSG3uOdL5mvVzwoM+OkqlDlNWSMBdBLuxHdhHK4YApL0W2FAAJWQ3CZrJ07XodGEXf9itwa3oldaCW3Vyu72tI+3XJsOJ3mwc+2cfQjrTb+OBw8BuADZMZOxtFeIG6xgFWFw5AJC0QjxYCMA8B3fIaXde1pWTdqXejetWwfSQQ+La1wDoVn2/KoY9x4MFvrux56JnnLv7rvaK+2vrVlich+Mvst37BXpdKqV3zz/E3NUIfscL8xdfdZ7lfnEkOolURE8WHl7Uuh1XE74wLZWiPunYjdSyFTST62k8cQ0RnO0zIju8iyvLabhCA/YDPLuhsbH5/QM7cSSn8B+NP+feB5eSva7KT9Espc8fHz1wGwkkMsLZTkNhcgpdRVPZbTQNXatI1jO9E7HjmwBhDQFMGFw05Dj64HpuMiepBg8OALzYVbYxqWURmWeAOj7ek77aCFuiiJNZLKbU/bybPjLGN/tvmrAWyeJYmzdbzclN/kahgHDpNUfgBPHLhqFlR4bOBcWIikqfVqpy2rJZ6HLl8XiT6g2Tbpr5UUa0jrl8PnBqEEBdKiqyc7JzTezThO6ocwYSKZ47UGNgbd5cYk7+XfviOyZjnX+36l6HTYxBZrF2bz2REt0hIgjjm/0tycWWA1l65vLIW1mZ5Tcf8OA+vpwidKOaFrDpmQvnOzlt2SyA9fa2tXdUsW8G4G8pLmeGUqfLkat9uqpWz2Lq5GrFJc7Rsmors+PmivhExw+vVGhW5ErkTw8ep6ampJNsVBVN4+ujIRNjCzpoU+ZIff+bvXiZg15V/6p1IEm+w0HJTUu4QaU2FZ1faNiRTRujaQXhyaePewX/JjEn57mmPKOa5zUWGlBhZ9mZXwmhnARO/PMCToX7j3nTLt0FTf2z795zeZXJRMPBKa2139BvMzK50H+fMT742Dhri37e1Jb3sWSvTxSOOixavDVVukEoPvKoapnMqu16LKEXlDvi2wGAZCUAMAhAubwifkDEwXhbwr5cKmHnFVVFJdVeKGiM3Lh7+Y1wg1+FX2WU52HUYeYgWi/qbPCrrFuROxIpqKjTu1a0XVHvlIpfXu2VK5zOrDtG17YEplfpXbuRMtIs4XShV+5yCWuIegE34HGww/vVM/W1wgrj/qy65aJVflVR3odRh9nDaynpjJSP/lXh8WFpfPpIlLCiVp/3+9HRx49/wytCVDulEgJsXvmCrFU3+yqr8v2JbQMw3MAlnEmQ5D2UHIwtgIdBCUsJUJdot7zgZO/hJAEpaffP0T8xGW47Njqv/f8OtsX+/RiLJ4/TAcB2ADr2A3AQgP1H0GB4CrUa3107s0OmT2+ZuTBHsy1n4s7+wWItcvIyWUFSGIfxYA8AWDfkUzzQWNxBVpvASjPZu4oxKoR5G1ArX7DgU7jg1WM6v99hb2Q3RRmiDWmct9axkRGxlrfpnBiDzpuu2cjRuCOmqK/WKEr/0RD81olVx6y2eNX/NAj+qKR/klD1d5uosGh3umdYCG3udhKTz1dxN3WPtpHY2HhsYi2mBpuETZT6EYMVpCW2z0Q2F5OISeI6CIQcP4KaNzKPu0/hTrBDGQBAnPNpneA+HrTD1W8dNOobK5WVeJ3QnRhs1n17tXc1lkV5GElM1mhwjjEAHAAgm5XCSp05K5Ofx++ostOeec+Y4bebqWPF2uREOVGW5Xt08a9HF385SYq+ggfDUvKYhtgTl50Y6UUi+YWxku+oFce6eTGL6tEM1URVc/P04K4eWq47IzF83r4OtuF3tbs1nc/T2VXldqqVOnXcFRhQzYkvIpQVvpaznFbfULZ+/d6kxjq6MCpz94Q0AJsu6kpp3/6PEGynZ9LLqVIisvaVRx5SHmRY6aXDiHWnaFP1XbeYPjFshSLaWxNBY0SjvXRF+nVvo6KhZ2bUYIIeIhiOiSpYXrc3+BMM2OsBwGla4LEKgGkwnkfnXavrVfwrrfW+GwR/maPSncDhcABsBiBDLIdlpHokIHwq07hrtNIr8jJmGtNeUcqw0W0Righ5uiCH35lnJZspH35JyUPE8S4lBOJ2LLs5ojRSG96Avb9ye8r56q2RYCJZG0MYPaL564FlrL+AkJpVORDeXySICnt0B78CAOzCLF4277Y69XKF92hxz/Pn/9VgvKhScHo1PzFJGTQ/UEWxHMJavQNRua8+CSVcVVDZhA+iSqLn5Pln+kcmRiQw8hl5BSnAhSQK4bnms9JYaYHxw2rqrVbhdexjShcV3Iid2L6MK/3Fq1/orKtytOe3aB9k4g561aI4ITGEUBMGA6TuR2eHlOAqN7gwWOPR3IZyIUdqUwPwogJeHOoy20Ve1fVLAIwAAAGggCUfX+cYsisiLZ8bf6sz+/LhEpM/I7pQv0I16Jt73n8Z1D+dqOk0WSBSqhDy4wujeTNQ8MbKp+YrJ63wi5fyQvwwqTB23NQ9K5qNWhyY7X7ETD21cYHI25tED/GegdQeFN0/4h8j83d+3TAc48UIoXd0icpaFlRtSvGOOdU38Q6niHF+WT8U7cEdIUsx0c0ZotaV1YdT/i+cpKeh+joL1i5/b6W95diZR5WS4U9GvUj00MujB+Gqk9QrC3h5vGWjJOO3GfRX9p4zmq2eJs8gNfyk10IGi72Ekc7ICFeHa+yiD1El0YvzA57qqf6QS6KUUEtmyFnMmGj2yr8WMaf5JvgnJkSYI5q5TZwNOACWg7XPXJS+l94N1/TmJI8+clJlELQ7f8vMIJ3OKFmLksMWbIMW7bg7EBYe0byYM+rpTzJoVTQyBSa322WYGw8SN6UWsWWXvArZroqgEGpdi9IB7UZmddgQkZ3KZ1PkU2yHAzjNu8n73XdP2ZoOs01xwKLGqAoA1gAQkPiV5L4aAMDwe5Dp8WaS4uiDjEE5TemCcpoj9TjFFFHiUlR82KBhulvEVrgD7k3FZWhp5tS4WA4Bmo1a03Wqne7zkcceCBGtvBEJsakvLOg1ko0UO+d0dkU8LXki/zpNl8ZHKrY5aIOuVFBzsdJ5w/hFdC3sL/TwjFInaAwQ/TPyGUsNcsS3OgVP3/FdeLurLC4ND54cRHkZCmS+/EN+sjFNA0GcsGN9LEK/SsE92S3JpQAXmJJb2Xsz8zc2WXholDFOkpIAJKH7r60vH4/+baIvDRkgcVYvFa5v1zJP9OeuNUcGL9ty7WtsJ07raHLZx+49xkwVx/Wa5MQdiArcFJDpZiV3NoZaii0l0gGKjj7mZHNKcx/HxXbSKy/xihPya4Jqg5Z77r43NfW8wtF4xaCeXxV/Vuvu9yOM0+zQviDfk2WqI2pFzYXN/pP+213+wPxKmCTsCOxYvq0ujfXMWaF73G0rRxx7/teFOrcgqEtIpkfxN99tsh0i7nMFGq7MQOze1XOhyz2H7ezk9ZhevZfdf396HWKH1Xc+OdESu5p8wYzcbn8D6sylpbw93emoSVQ673RmBeM0BZ0/76HtItsEgDhnAPAmJptY87eOOND1i7AzR1/kTgm1FA71TTW+1hMLHb4llnkvIS9gFfES+InyYHlQNi2X2oCjLYm9ooxzeDD9wjgqMmx2Dw1FCdGGG5/SbWTEbPzslzLAERPlEyYR6v1KFN4q335l0poftK4lIrsofVHqzbie3Cq/Kl+jzWCVNIubR/JGJM2SlnjbtPfcfXV+A95J8DiMZ5FApcA8bIke5ktDziAQT+DYCF1TcX39eLMZc+/FZEvG6ViO+2KB/uICWW7IYio7PlijJpp95P9o8dT8nMwPz4Sls4tLXPVs7Al5PlUbErSulkVGavezWs0231ars8IinrRo1pR4FpvNOkdktu+6QWrN8xfcJyKtXBtn2z9ecT/o9srUCFTxS1bb1poUVirLS+m4CCw49w4PVgBwGp9rwEMArATgSXm2x4REfjIA1KcBcPwGtC397f6IzyJe0vEZqW1XOQVvTp0ImcTZApWzwvXL+ccon2RbstW7zXvW2oA1PLNiwsvSjbY633qfpap6TCF33whTFSVOEaWg8oSk4zjfkcrsLnH67T7LACtGFsv57z+9fTGJAqoVVdQz0plpM2bEsbNT0L5IPBsDeXf2zLXBaMzyusiSQADLAYEL8C4xqW0AfwIPGv+OohJN0un/1rM7cezEWXVR6mjwAUGTe8aL69xkXqos1PJIY2QyKiozKGnUT2bh9zouJ5XD3We5z4xvwRNe/7FGMSwNaG1MzMg8zhNOVS8G1ze+5iEp/svb50FZZuRL4X90CkTVrq3iJ2RsimD5rTOyhZah1ASg0NWTBoypsK4vA+pb1nMLQX1gSQmMQy1FxdFV/uh3Mojprxzi+SGz+kA9WBzZgZN0fF8+dIyVmTqAso/xt3m0xadZnVq/Wt++RYxMC0pMS7R7tnu2jdnXoqY9IS3hxpuM36JYuZvctc6P+z4uPs2jQ9L++KtdMyWDmh5Nj2XpWBm2WJaWFRlNS6dlNNuj3cvoGWLjSiUtKyEB7e2XhI6JZTF8KOmUDM5zbjuOzfe6fLyT4EaURwF7biM3OWO5X2Y0C+OOIIeGaApqwylSLV0VWsCIrketOPXTjnW4NlFyb2cie/3srGwpPgAVt+7F+3L1qSlLaSreyX5NY1h5wYyUN/0i6I6GC09kXumiTcK4yFz3EXqCOqInImp1H6ekQ1FmHpk4LvTxq30tgdR/s6RHIxyTaEQ6VeZL0gLkxly8FImuOm+9QNEH9b8UPZULgm5rChuSiUsrq1b8NVbznN0AuIyVjD9/yZXY35SV5Tm4khrmE7772ruy4au+Qb/ruHiGhB4/MgjKciXwTOK79j5pXmpaGa3gUlduqyhL+IAQwFVylRZPXCJ//w/vJFVQPiOP2axswCm8fm5L5atiuMkUrNmLgZ0IH1hZ7pubu/OVFuEhVsLPJUQwtlcRvMVsOzT5nJHdjZ5IfpHKkSPJkJxZVZhnSRPE8jMl6oB8WiGtVdfPqCArKeaCziTvNkNe/DWTYxBAoJCjdcsU42ue439ZxRMu0oKbC/VbuXjY3mkJ63rBsRav9MxIY6Y+qoRZwqyJqkRHlzB1UfFhRkkGmBZ9DICjAByOb6w3608cariIqE5npT/M1SQsvV9fNWpMPQzACQ7sjSbGDzFUaLMBfY1lKXdddzpqJ9rAYbaUcZWCRjzo4GbFanEDX5QxGzDRON4XiNWh0h1QAw99MSeYLMTUbifYfdDg8wUOvjEODgAIojC7sT5Edbc15ThVDOq39xyEGy3OuHSc1e0hl/fVe6+PKfEfYa2FjBKG1fUhd9Rfo893KQnuY9k453VN+2P327nf5nRj42tcAeECLXBl82p+cP8kZ+gLXAKgSlldBQbjBfBA6e4YlCwAi6sbJmHvub4ZELls7uKBRlcIfHBCj0x6Os6emqQwCGHeowxQhwoZKm66b9NEgq3PbLZa6Ukdn71ppwG1hXnI46a++yz3NMnNDtbNKAMtrG3zku43Fu+sIsb41CoSs4PguNA/ZNYT3NFsqz2tyc/Z29mdptt1N3xJKp188nams5ZC8wpuUNt4KmwYUe6dSyRpEQaox85Ij2N7faEypBDV3pHf/3bUNwp9RecrY0BwsMS4/ejpMdNtjBn5ycR9SxuXis5kqd+jE3weSc4bhuOhaABONo+lBQZcXFBXbgx/OlzooXf+ZmxPFKdwDgvLFrSnDGhqHQWglp5HzwvRhepMkil+j7BGq1BG/4k2OOI3AQBxXu8UfWVCPp/bJGDUcBFp51C3UEBOEoXqgmPp+ffIy+8aAwTOEYPFsNkklIwFH99qT4C5H+9tmFzbJ1tGEDVtqVncuvNfdJOTk4kYaAjXe7N+UsrD3g9po7yx7/ffedW4kRXcUCxuOwHqZBCo+KpT46ZMMzO328szxzNaH6Vj5vRiFTA1X8yHqd0UQLaFJyRan+1Z6NkdnI0+ehtxVHpbWO7M0TuZoYTtOGw0SSSLsHPDGMGHJRL4oe3+l3cIYg5MVn6ZHX5zSTITQ2hi5rPyw2KntELHTlGoIZXJ3N3NacbhtLlOnGIcf4XahHeAan58s+LXltkkyeJw/ZSQ+R0z724mPg4tj9l68WtMlN0eJ43H3z/vmy/+ftl20rqwvuGBz8n7e1jKo2yGNB8/NFoe9InU5OI9q1CYL1SqLXnPRy9nVok7xUXiQqW2ULT6nx8uwmL5/Mx/tyTO8YZqqTn/YItDTXjwVpadJ239S4P9Z4s+d58sTSn4f/RPoOVFba6+9JKXz8o7L2WdT6UO8/E8+IdkesrXv57sZ0+KI4v0tMiLyndIl137KPcEXz6MBz0ADGemUdQUbeJqc3Ii2UzctS/1XzRikJgcwKeYflG2Z/4FcQT/FQDIv8lmYQhkprF01JyZHxYbpksW2cUVtWbB93+oWEf8BAAOZdxkruV78rsVIw+V7lqY0O/83v7B4fs+zf4Tz+ZlzjPe3bO5vLnw2mOOoAd5gGTncfPwnHMtBDn7wAhH6Z2XdafBDRM2wy5JEofpw3TMPGbePWmmf5YtzBPph8W+D2689+v+SNGPi7aTy/WH7395o9CaBvvWSbjHX028cUwXo2BkSKqZNePFFo9+B+MeRn3JZsPx3Rh+xtx4sTR6gYx7e0d+YaxuEL95FPvXdWlRpjxnfqFxIBbY7cM6Moj6Azq3EpxKnfCtLFJgOBhYqU+OSx1hgRLmTqGWUOfgTdkY/E3f+oaDV6kDABw4tvO9dOAH2ugY+OOJiQkJuoKZfy8vpwbHeoJShQFy3b0A8UTkTXfrXVOr+DYZf+ZNaRJWNEQQ7ugY6/binjsuLCyfsGfZDt1TaVm8+Jk/WcbqshdpiXm5ZL2lC7amT6oJVlXeo+vFGyXpn7WvVzuNaMzLLGlKE+B12/CEE3iwEU0JSQ193G+xcfrmu6AFUtmz72i1f57hub1Cbg8k8sMdncz+alaGZ53i0KxxJLZjCLW8PEepGarQ50oYutB4hEdboSTXQ6FT6Ll53LxaYji2zCHPmSdfvKTQ5UoKJP97hkQSbSw3n2fqpMTK8+HJvRsksXj5I6phWVVWIl6Gk8cBPU6eSko+7rx8UeEuEsrdj3Q+fbYxNz+iddwcXpA6M5qrud9UJQ/2HZaPmXzy6ZUs4/ouABN4R2isaqRFqdrbsnfP6dNmJ71w4ajJnQNL5tQ3jI/gJkQhsfT8a+Qz7poASsx0dU+LiHT6YafcXeRyVyLq2bhrOzcMlv9lbN789V7sgqrN9Vcj+VMMov+6Hp4mLvs2321cAdeENyDZGHmMAoQZKeLf5MLDK1LB94Ky9bd95ya0mtDdxd1412/BLqu2S1LEYfpQXWvPCLeEIvWz9LjytDRDxqm70i8x+YfuPXlro/MRydy3tsSINrahFaGe/17NS1xT3yvzo9jzkw5vaGBn2g2Ag9x5qVKSTRyvWFPY4b/ObYtIKodb3am1+VVjuBEVdkMeNpE8ViQSk12+eqb8NqGpeL7hOy2RbD6/j6DOMNPO/egQrYjo0D9FEp7x59bMjDkjlEVQN3eE/VUjs57iHhRbuaqXeWqV3qKcTkygxdGFwoEDFznk6bebjjcJ7/t3xoo0rSmDaWGNjUXNeRG2Du+IuFDfe8dDfe6JCDMwdc0V4WePyWkZ9SMBvO9vXiJtbzm/q/qAeldRYrsqEn53L7DzeQ25B/2gcRqvCaSJ5rCUCmusacaOlFbueI8HB8KCZHj6LQL5hC8mOj2WpCJiR7LOMMVNW6uE9V2l+Palv1QcKmKqnuVi1hl93kYUr9V9paD4nMTzMQ+FsEpnzCm0EX2EvpQCxRswI2gDJQW/lHEERQt9KPTxx+R3ZcwBajH+IY0RvRxt/PH5x08lzJzg+Os0xbT96Ojz78/2lTDL0BwQ6Pfy+tvpNrc/eIz5X8qhRuFNrPV747dGq9vv3MZyaP4Xo+B3LBsL9UK9+XNqOMgVih540GXVjgMHL/1n4vZu793486AHlEPUOU4yeDYU7ufs5E36bBGVgBHnkXc7LaVfoPSKxq8o/Cus5wA6mR2woPSbGgAs7UA6cyZcUtXmw9D44WFyNJ6p7sLpEy8zZag2XDMf+vAl2SgQgD4ACvdtFP5qitVh9dvfCTtnaXxLGMAkqEoS5MT7Xr91C60bVPj1miTFKU1Ie15t0sGfUnJZcclAaUkC8/dB7iRBlUmi5AwCAIE9AiCJbKrbE9fMg1aUmaUDxZGXqbny8pWL088ydizWewo0NmJOyK+sWj279+h3RnPNCQoCAutBCUPjq/E7+rCMFYvVmX5lylABiTg0RKvVcO3RxLNMlFrm3p4c1EGa6rq2oS3gsglWX8NUZx4VDaUYCA8tSWIAIpGsJWtuTJ1eqNFCn8YGHU/vkTv0PGLfxG40T0jMsgCw2gEAE1lDUv+2x1Ic9srQu9u0s3FsbHxcIdeHyTe6bjTUi/oDidzDnLzk5JQUtYoXumbMC4ARCN5v4thGACDX8QCcTKo8uBzk9D8AHdNZUQf8wacforzWv6JR/Xgq0UHhdFT8tQgAgXORzP2PusO8/cqQRdJJ/XWWJ9FOsud75JHsZLuvzk+nlyq9bfhrECu4TOOC/OtAlZdREjzPMa6XIhDpUDI3UCJHL17nw3z33OdfN7m7UuXBg6ly3OTvv5bXrVSg427Yws5ywVWV264cBACyHA9c+rbccVW3fT73FrgY2LBzhWdWLoC/8eWmUH21z3W9tiUz8wsSGMFy8HkxjKGn69NeMK1gtnWQdpSeujWOIs0NHaC4vYr4x3sepQz+RihzGEerrljGhlpYWbzpwQXYt1as2JDGpr+3b6T99Vd8uwfHcIE5vSQYVfiG2eyrn5PlIG6kBxaflqkNSKKnsy87spMZ2oB5CxoiOaNZjazcWl7CnUuZ04po6eRkT21nSq1MTmWXuZ9pz0r45Kne4hvLsURKMrOQ8Z82tq9Fr0yzv1HTa66EWzKhuiFO7PffyDVW/Gd0ikyYF2prt3W7c5nRs4MAwEwAymaWAdAy2fm8BtE+hUfuhTML7yiIKQ0yeH9i7QGt7iTJY7Gr24PZFXzCwEcVL/ZqD+eRIrJxrWTZc25tSTpfy9cqpfAEwUt80eyiNaTcbGI2wRBgCPQ1+5pnAXDAAQD95HpI1i+5OWFINhvr8O+X4PhwMk8tlrz+JFcqo7gl01DldDPXyr//hkPjhEnxz5PqV+iIUyfaR+cvWDCtRSjQlnhhE/iaKLLCP4OaTq0SxTqr3J86MRShijBuCi+5rOk6OIJ9mVq1MkUrlME3ZFER777w+vy6yDfHsHzBWU4uplcwLVwb/94btQUyiy3EWIqY8TB7YH4khlyUpTvJud8uJ7uZafF/xujpSlw4kc+SvNG9L3nOV06FTV+xHeksEJY6QVtBT0frtJBTWtyxLweCQCtNTZ75K1fNHwQgwycQqs3hcCX90+dWh4bTZIneNd6uiVMM+o8f1ZnMOJQHFf+HpQykJ/csuWolAPQDQLKsPBgpTnaT84jV8H3bWg+NBNXSTKmphOn7iL94k1K6QtJhVjMMU+GJSMIbP3iVL2sq9gkpJ0bUF/lYRDHsfyfdsP9V1Yh2wRc20ltXY/Fw/2k0ec34gDciTKMC0wNOO02kzF+bfUD6QsdYky1X1/2zM6b53mlYG9vETzvOmHtbcspps5rKURfRkOgHQazNTUbOH+GMOW2kKme11XzALeD2OPE0Ywxm3kb28Bx6SGOa/HgKq83KBqYNkQuusL+Tff1ES5SvJmPjQ1tn7ujduUOnrDpHJr0Tx87Z3MMPJ3vx7eejaOtQG9eKKknXhoMsnk/eZqW5tYFwGpyXWx27DZPUXLbBYj5PEsFr6O/1z8yIcwKr+g+uekNFxdT1HOT0KQvOkK2Dl69LPKdfyOw6/M/6p2bkOf6evgOrX5PJq3C9t+KFZ8gYEffcD+LBh6AJbxAzgQkQq/6d+3Eh76bKb4ldIfMz7tUTPoEtGpVWePrlYzYLvWYURWbFm+zRIaOmptms9UXevp9qKpfMImLdsbpoABZ1wLTdA6Ea/nR37GOlkdP6WJI6YMnhr3OWhzoXB/9wzRGECHydqVSJyAkPxQDQhzLEB/E9ADMIG1HY53WJQrB4wzxom0tlRXal3ynbodS/bb2MnLrq7243viYxVucG8r/O4TXes5W/76Qi2MMxuaQknYEgqCA4xxoUSWEoz7jGtJF5buF/35kknfP1ofr5eL0+caJ5PNCvI2zyNTJESVYOyLzyWi1XTXYLDhOWNamKkKFKN1L265MUKckDX8urPG2ZP0tNz59xlHLGPC3uNJHy+YvFrtJNc/L4lCFSWahk3sqWepp4ZCRQ8c+OeFu5CeGehYOp62/LkQJNRXtQZVZCuNfjlWKu4uIGifx5kvM4UuUBkHLdAkAbCMIsaUzB/hYmKXixjXehR9iblAdH2JRU1XMOpTKQj52GyU8w+s49C1YlwPaXx2DfvV15weV991XP9b33mWCu0/H8cPjqgmUhBpC6Nn/l0cs1bBVjzt5Fl2dob/WqjXAIiXtJ9uOYLebpjEAAvkiZAkANSMGfob4rfIVMYEYMCqKPc1spxJrwGcCZE633bM34tYcpzrOwy30bS4u4buEArMdhnWUhv2sKsoRKl3PS8q9butVY1zMifKo+KJszeVl8ueytv9GNbS2h+s+6HMaxyeSp/MXfnfjNWDi8F9EHH631d+rsVw8638kQFAJBaAhfoFAQANPXKVvWX9gpf5mWRlf5BnqkbLM4O736/vu3oO2GeEdYKZTAnjLpL+yo9ievXCGehjPXKvw7d53MvpHsambN9sHMpgS+zq0BIOao/xxqG+q6Ww3bCQcAAXBh+XlAmDJgMkdn3dmeOo2uc5ekKKhK2r3IiB1kpSnRRFYmvrmkP7ynoDL07pLkUW9Ow9t1NnMCa3hRcEl/aOhhiXiLuGhtWPgSz0QUVed5PoIv7/MQUFXmgbUOuVeEJQKsf8A0d3ROX/6TmDoUddWb/uFVkvMk5vXPhra9YAOfbp9b75sWxuf05T6WNaHJq1/3DfVIzpGa1z8d3nGl6RcmnitfZ01ycXHJ2sDoGcwZiNOTPz3/cvLIJOv0hFgAJW5EskCcpt/b71Axl8Eapb8o6cUj6gQhW1wQT02glBfR9XRdprY8I1h4YmyeDY6MhXKAi7stVFBgIx5OTsH+46+RACxFmOeUzx4xI5YC4Oai+og2IyoQ5k9YFY/uXD3HB1YvAemi/g+biqhEpH7Dql1ugBX8uT6n11RSUtal7jkvR/LJU608e2avSznYxqoV155WVHjP22tPt4Df3XTVyzMUBcAQEMMHLa/QPxE7ObFhqW30C7so/xVY/87ov/rGNteJ/4wUXz9yZ+d/1trV4tLejs+HR3Oe/3cmk+f74q5VEHfyXKGwbFOiiTPw7FKebDYeKRXl/GL1Fc5zhfX2dfibhsoCfnEVSb270Z/XP5aP2G4PsTjDYUQ+H8sb57kzLbtk8pYLuTW4Dq1q7SF4pbcc/JRYDQvw+mb4knkLGeDVrCVD+pAE3yDBnzSBVVlzM99+seT74/5d7SN+u36za+8NvMt990c2WVARAuFMkDXD2PgIFuRBR0jvy13ipGEx6n6qfNiSLTzsmffVuAA+n09wDOEiiaZmV2yw4CbNr8JXsD5mxIR41mMRi/40b/kfIhbkENd9k49OUPIOiZOaQuOm9jLK1DSxSEnzY6jFSLxUHnJPhU4XuXd0jUfGvPscL3ZydoICh7S5UuuSdlPQAmioObxYFKpxnkapgOAppY9PtbrHtfNcZJtERycIi0XsvWAL1309X+dWwxidwTdQPKB/gHIaNkf3yIcKDw9U/ZGkOnb3ZPYpDgIUVuKIX2YKTg3N9vz/JDn0eZNnHxqALhDKevi0jTjFH1EVdI8k9Svi3lopSepHxD2Ry6SWIyTlAXe+STs5xzBxjk5BVLd3OIdIBweHH+zo4BjsNvrcas/IJ4Gk4KBENit4Hv4a62g53IAZpmmD4Bk5Tp2MdLxSHhnFGWXgA8XXa3AShdqPRsWlC51zJ9qZDLsMwsY8eFBcm5vGqvmH/kEJY/Ugt9+VHWocdMj0t9BMghlYa8qKycbwmo7CNceOFhbv5MhLzk3OzcvN9XOLc/NIkVHcduSfH57T/Cz1azSUpjOFbGqZCwqOolEk4mBPZw9o9IKlhg9RTSaTAolzxGBG8IBAdAciXgHYOpbBFv7KiGVoMfG0VU2lCwWq9ZH5JfEpjT5NPqJmn8XKJaTU5+G3qrZmZvXu6T2qF16jUdwl7mQ2h6y7D4cfCFRZD78Bh0M7sjdNKJEI8CMYv1ty0u9zFa37/rvu19sOzsU58TRpCFHp8KSIucSKiVxGDiO1xRmmHV7ovvpewTWqbqmHGcqAAQLamw7MHwp7922cGQvtf3btAWPFJh/EwNIUb7hZGe/Wwl2UvnEZu7DwtcQgUZaFL0eii2o88UCf0wPEMmt+6+LFo2BieZZ0Dn2HRkQJhLlVUeUvlm8kqYMokPrUyL+eXHcF4CLeL4e103W2OURPH8paCnL1LdNatvRmZXXrh3QPxccGFlectqiN5sfFxfM/yqj4tC08xWf6rOvLvAgqAoFAElZu/W8AwqQJegXhv8tU3MJOrU9M3d326ZGBindSumxX9c2l+mE7vhNKD16vhQjn4qcJL0kOrof5Qd22Qqja70/dCk0V/nujeHT7ty7U9UnH0ljeTp+bc27YzuuSjanHUnujEMXfmimVmWumB/+Trs4frvt6LpRwgvk4FWTQj/Qv1QEKCzHkm3qyT6DElCvA+nlMaHIINNRdMF2ivzY5eFM4DIbIwUBy1IQuDWHNQ3JXTr0rKZk1V70+5whXyIm5pl9vD13cvTL6JD3vMMi7Z92TrN2sEJwcsZ+ky9UkpCWbIDbMrmiEAccZx8uhmMdIjUKmfBtjg8wIDCoEm7z4cukqSMHxrHKTptO6JTKquDkaUXRlNxxbE2Cz/OF4NYTAuPtVSpUNcQaH01ob/dbTDcFmRVAhkPIag2F6oTUBIpMNUsTa6PM47nTX0H9M0vuUEDFO1n+CN6ikN75+FHYkrNobgP0AXDeUqGINktjsy8fJ4a6NgSqG3BJhSGDE+5X4Vee2DKvmRSI6vnSxNEOcbRFSPHEbFnN8jB2RiUi+/TSgtH9Lv9nrjEiutxF+AszWNPVUHbhxn0OWXw+MGXNt1yv6ZZByA3CBeeOu1/hlR65VHK8bmPl7gGJJkUesR6OHf12gdbOIOG7gqgYBZzT7svHevwn4IJ4EGmkoNN4BSqYkY1BUBCL8+C59G7mvN+/kCW2ldYZ5lQwAOwEIImzrubzl99lo9taZEJjlW1YpWq4k5ZBlEAvk+cH8Hm2PzVrOdIQSImlANoz/rjZ04VYNeVdgqmsdcqB3S1hMhHYcJxlezjxJG9aIFRn5OpoR7UXXLy9N8FyYlI92wLYRY1SJDRBpHABbAICAuF7MLPeDupm61i7lzpijkqH+oT4IWxHIJ5RKCnJFK2SiStn6tn0Z1kzrqadPltkCV58JD45h9A0LMwsc2tItvIyVGYs79LxmvzD4AbWbuGzA7qXdLTT+ivYzcDZBvopA3I13dD0C6UCUG5fyGKanqdyHaxwh7cAzJr9JjvgljtlcN7ZEjLNos3KsWog+1n6YtfKBxj7z2mvmzHNdvifUSfGu3q1Wr122B8tv382+7nbv6qHmvKD3GEzilTb00EUmhWbeVbk9MrmmtjWoPPfX+Q2Hd1GrIbOQladO4zlUh8ibFMz88O/EF1FJZHX28KxhFHSnR6vYKkcZvp1bAUnKmlF2OnZe/TYu4ZX7JU40tnIdc1UOOYTZE8z6K840WTAnKdjXc96W+DvaCSTCnRylSuJKubCjAeePwF+XKoabzgyvoIvgSWeHJu8f7QsuguDtgaURNDhlatN06rv0WouHD0WGcHw0RHkezogqjlBCdLWK+EonYsqCpzAIcxDexz49DrJJWbqWDeqDPcHahkhAIitWa8B8pqfqkmLtpwBKDokMRerkR67Cks4OvUSPcO6Zdh+AYV2wjzSX4Q+T3uhWyu9PmDx17XWNRyK2wCwVtoI0aTqEj4g0E+o531u5nxps5XJQdbkm+vlhVids3uFaQZSYL1fOLu7vda5Ie8AiORgmN9iK4aazw5Oi/c/DmaEVmHD9M6gL1HUPg3mHwhnh6sb0YUsplDUW9woRK6o4vix+dQe/tD5WZ3cwu13jazO69VFWOIp2MvmJRCxESYo0IivJ6uwt4XVbHvzJ0HmYD23FMjzNrpdI/1wU9PirfLoYjfhlU8Dz0pYABVYwA5VWlj+zdqKNuoSUi66Pki9PTBiggSEQmGFSuxI2dOM93WrXeESb2X1hYrAiZ5oHT+VB2aT5uaMbX3dJ3wOvxCYSEcgE5Ed2P5i1CEUVJ0y13i3m4TM6HcqUzEd1j5WLqYudecMPht/yYMW4xSeUfNhiZ87KfCQvqeKo94jSWPFqghI7Rx/iTpsd/lumerB711jurSeegQtWQyw2BzV9kgjmvGevXs97Osw/8itvfm7uoZLf1wx+51TvU12SssTfwxPdDT687Nc/Mqo+li0Bs1t+mSiDAOwCANp7qGVAe1zOGUt96Bqy8myNR1I7eYpbaj0AuxIX4B9Av1TvOzu8h9eNRRDwsqz0f58+Mp+CXUJf/j7234+ufN68Li+4Gg8MYB6RMRFaYl+Mwj8Q+RnygD/v4mKvGDW4QUz7MIlEQhqpD8BP8QA3ng9mf3fgC48ugBRzf5sv6s8cZ8+nV6zTI37z2o/+++QCl2fTFa3dEucwtq9Vh8AA4H3kvToTJ0wDd+7/eD9xcKu+Hqf18n7wGP4+TT2I/FMP8j/VLwD3d6gkN9LdjD2Bs2K1qZo0weGLrjrP7xwnrm5sQHYsh+zneF32jG5L2Av6QIruwzhHpqNUVpp+mykgP2cF7wTkcMRiN/lvbJfGbB+o3Hg5N3dn7bZC8SYs9ByvThinfRNJO4KOrn/OZXjEa9+YUnk23cc8OV/UcU5bfTv0zjm+A+BRF73Nk6Q+m+ZjKdO3n9P9VPTXOQ3hP+XCeJKRGG2kqqmq9GHd2tZL27lu4TnhgVVBVS4TpFOYNQBsAXg366zQuY9m1oUgYMlU2pmXwbkBBC4X5vzscHNhlH//AauNaoBCI//wSygsMEJIOXDQzjFDdPcmmkIkpCk3eSVQXrbgNtGU3OSU+HqMIa6gjhpfVBgfX3jw3yWRyJ2xqe43xxEjcrtnAaGPMpKMaPMsQLf7c5KlHSEMqO/sMFjrECVPpmWF9EGY2tw1lJLwf+ZbxLZsdd8Hd3KCv73cQCajlqC3OTrMHpk94uC4zf4f1qFrOOMHBpPxo6vMAUtp7q38/j9bZmY7/XIlKYeVEDvKsJz/Oi6toczKG5Hy14qBSbq05XO/14EbVI61jVv4yeqr5Ea+yhK5fo5uFxgHR15/BhJXyIVVkmK8HW9LcDi59nALsvupg3bzqBlxtwXcLXTo9WngbkhOPRLgrbBB1IV2Vgq0mEHyY3RsQDJEB+jR5JFS33tmG238hjUEfh27H4m0IpFxHEsQw/v/yEmPlMXGVcQrPRXOkGSab0f7+9/evflMybQUvZYs4fEBgeLsDEOoUiabKruCCTvdWl0qB11PkjcT4YGQc5nR/smBv6ikJSNI35794x+nb94m/Qh2lDR9d7cZakohZG240+/Yg3aL9B5kp3kbf1n091bYlZ6TlZxoP2/4uiBdQBJEVw/vXshW527lYd6yPI+nSFwoLi4B2R19c/ocJh1bBm4REi71JS/E8BfEF7RR4CAN2L0K0m6bnTaSW5feGiija/g9S8N3wyYYe9ynEk+ainY20RAXTw/AzlOw8sB6d7FmqwIxJ/fTWeDEMc5Vj0pdBFLhbAjtD89PVaSVMlJO0hXQC+4tbONFIFQfDR5bUrU6RkK2zKfM5NZCfwfzfx4eKqq+f2+JkhC3Mk8nyvYlKF0VrvXFYyx31xuCrwTCJJJSOkRLfGNrOzkhVJm5AsQF+D+W9S2UT5vm1x7tEYNphuB8pd5zPJeq3Of1anYbqfp0rXrrhGKzw8Y/j8QMP30dV0fFOs6zM7Fyby+LWXvUbsp6StznQ8NYDsYPD6LJCDanZMXSZU4/qXKkVeGmdLNDZv0S2Ztc4Qfd9154ynowKjivyefh50HGzJzMHEizuyip5asBSjt+5/lOlJRHmcR5I6BTbRg0GsP2Je/yyXVnrD2wr0TrOvk3UUGUJzT37/SxhD1tZJMt5Nut+Oruf4r6H/7jpNugE+xz84k3/j5Ab/8oDGY1FaLYYogKgtxYCg7UwjqdTkxMxdaZQJSTFJd7SYu12uJ61P+7z666+eTusjV5xxv9SdN8ilCQ+0N5N7TdW0XQENXJs8mkeEPAd176+bXzGNYyVw5HPQYOGhEVykWJiz7oRS0zXXRL7j5FbpuRj1IGOhYu6YWNIw/ujfej0iRrtOlADHW/487+pIDnUXw/hyRdkg7tCQjsiQ16vfDzQDQK4cBhJ4jSz6G7XwWH9ARi76+15WZznW8ZfvKlSP0L2Fu32JPMGzflbnxJLPYdqed8nv+MvW+T9XXSBaoHnbbyeIXNePuIbnRBnVSXfJ/Zg+p63wwZSWabTeEb0A4qW5Kl1gTEcYlfVl9Tqxe4hDISdMPutiY17mJb8cSjo4l5KtLXDUObPDwvkL3IeC4btXw5H3dzqhqF4wXy8QLAJ0AdF7Hj10SUqWblgl+5c3dMcVq1G73wjThvSL5AhM5mDcyCORgsvdzZq88tSVDd+eGilacbd22ffeECotnw04+pEQ73V8xOm0LPKcVHY4zsRYsImjsfkrODRWZdPygUyb/1CtVUrSZ92yiHIMG3G8qCRUiLsDMQjocHCrssyEWCaCa6+gTLz8Bi1bek38lJ41+MZA2nI+AkEipvWwPQAYBlcDgs9GAe3tG5AB7U4GxBrgGg8EbjohfmRi+18VnmTIJ7RW5+6oBaKH/nSq+UHwBsAuBPyX7Zwcj71uNF6MB3TD7nlxobgDaMt7/ppDyL7FNmtojRmOF5IG2fQ1bP25CYB11rGXOHrtVl1igcsmROVVtKrcyevYAF7kQ/YfiqlPNIciFUd2mYMkRYhmAwcVwYlKVWpW0h0XrML2azMxYwpW7bifM7bsdt28oZUQW9RFPbCeH6j1720P+xGVD8/uLOFCWt3mpOXJB+ramuv6xfx+NatueOn3TJW00RQTjENOfQ1A7CKTLNttt79Xh5gMOY19wiMX4VxmlxM1rWUMAr4OtilWFpamE+tHPVnFjGlTkro3IVbJYwx6N0ID+fhy3DRrJ/WxlYwmPwa0SFaKs1VCBHXmjO0ZB3ZkKTS2fYoJywyvS8zhrqv/GiNKUgX6XuHnnH3RymkxnlurB4S0mjWj3dM79A4R9KYEHEw1ypHtCwNUV/32NHD65Trs9oCGw6oNzKNrqCAErU/ibtoVf5adE2xWBqfcA/7mF8ZIau0y/VvhZXOFlF87+LfZG4cpV1xalqWeUiqTHyKiDddJ8KL4w7tP1FvtIETgI7y7y1dlVbW3ZOrmS/q90h0CzVhAEwCUCoeKgMz4ztugp01Z1Vv8jc+YQau6/TuUXuh7VOBkk6OVux5+UHfLt/mjZeGWcJtSjH2VccaM5WmMKKnvXuuzSqxvnRpU2BOwNB1RZMulSFw3oaZHSa+bxyk3ye93cysXhJO/82kRUUxZvIrktySnLKyqRmZpOVZLkp11m6nKzMzFJQgkv56a07zqAwXRTsD69e4y368/0VguTSAm9Ir0xDzPW4AF5eM6S/4we3x0EhLwieWiqK0NV8CWvn7hYyChp8Eev+kJ/dmKMnizdFjm/NpxtQgShDPo0AgL0DFEVFS7TYrZsBVbFGL+jevZewGw/SgN7dZgHCO+KvWFEKjNEclMXKYhbGLeA/3edWomnn7k+kKTquAl1cm2fJ6SlVgFQieNMyPDIkaj0h2KoQFTT6AvBSkP5MlaZP2ymbGvkI7VDkSs7rvqxCoX+If/0G/9v4q86bos4xi0afpmDlR9lTvyF/3T7liP9fhlZTGyToIffTHcc/fGwfPyn1TIsqjdSUa2Zwl2MNmM1ZEYs4DW5+pT9k9szAzID6uoPmMp1Mx87j5NWQgtH5KFb6zPn3jZ2jscVSKg2BlJMELqoKjIwNX7fCU4vDPxmZ6e1keGBM9sYItkz9MzH//4soa/SCMT7xmfzIV42NRJYwLNU+MjHmh6wNFC+xW5C4CwHogatTj1pOacJ7ZQdGXFCS5YepUuAe0Tvr7UqryfJNpXTlGFBHGKOcR70GqEUowxuvzQaMKiJWXcbM9+gKXqGNULkRnhD1+EIBNAhhjpEbx10320P+l9/enMcy2oVmfa6Bm1Od4fPYOAouN8I6VlAfIeTxruhK96nys2CzF3zcLn5BUPaLn7CsrLmspUXjIR+8beBmW7B+YYWkx2sPfqfGYaeFToMwxePUWJVCGumlDp7aHyt6UPD30vKo9iG5JfDENRpC5erx8JCK3oJey0q54oPiN/bPuXCuJkWggFRzNjA5eOGxoK9WOHV8+luIFqHroFZKpd5eSjrVdkPcdHBOEn6yXl2oWjMRJrnwEo3xv2FLpSkjI6ULXvw1qtpBohOF5TiRFFbLh29aCBH7+g2poLUPWdhekTmnj9DX0AeFJjo7ynn8VAia0U7W7FS4kkImJyeL1EE6PIe0KNicw+tV0CUbgmOBygfizGjxda4eWNi38p5IzdT0vn8/s9LetfDnduw6n902oTzm9qMe4ej7imFHXdQOxkYdHEnC40SjE1Pz+6f9HfLkYNVsb/auKmd8++5E1rE3/8wohh1xcVomUDFL/tqnRxRIyM3Vfrf0Iut48VLZlkFADld6/P8plGieqW46fX86iY0uVsTOi9qdi0anx9wLl5kWtaYZPvdpH1Nm+NebNkuzR2G1Di034229Lh8K/3hFGe4eW+pPFATAC2+vgQKLpZ2ezMHqBtZtup5Vm9uiFawqevfcifCfD1EPwFs27DePRZMzWAzxIRCooHSVAM7uNbvp+mxAT7CBb6u04S0LOZJeZ52xF34wGt76bLqOru8Uu0RXefA7pyTexarG6igf2ZnLtNZOniBN4c6TuKgUUv0cxlip/jZtviHhdgAgnFbpkNE4EDvLEFH/MjqyO/+6kGGaUebeFbwOQr42pl9WSqrW0JhZpjUW6Onhy2TC68/zwS1JVumi5FdDVMhbiYY0NBrvCCUj8lgozI20ps6xDT4IBMJ8nBveFFY/KndJOoLPHiWt92T3GVgNTMc+wCcHxuJRrHIYgZxP+KEzJQi1QVTqj/eqERqMxeiFes8ltbzFCv6YGJj8Vg79LAooTWT98M1dAiUJg0IeS545bebLqyI7LzRfmHeTtjrRx98Tapr2jSz0YxmRRssJdUGxkslkJ0ceAoHFxRyp6L2+VBuAvQCYfhLd3Wb4zr2C4kfHyHHcAcFlZk9zcHT09e3uRhMuLO7vTP5Wp/rJiC+fPUMnvjovJFRIdHeHOwIWwnFLuN8yRv6sKA2WjHRIDp1WGWiNQbGyiASyoxPFJQ+Divnz/SvUb8xxwO3k1PkIf+ek1o3GG6W8ep183zIO76iAS2hVkep75+DEgrP/mEFZrEidtk837aCffQrk7YwNHLbgsDMQ/qsnHxSEhVz9MGQZPinxGGkWswlV+d4LhS4nEshuLnD1rKdkETuvtjG03Tx6MPm2wA8/LsV3jHRCMiro73H7KTXdLIOiFpr3As/imZ6VpLE4cfXpH7I95QvFwYRyELjc4DhIIQ6sz+3P6fNGIIa8Qo/jtclKBZ2UdMLZP7bSFH8uQDFDAO5lKDQYvxZCOgKR0h5GjsuNjbckGlNEUDedq1CxCrldR1kqxJlgSMf7j+OkAH3YpdiUo8chsb/SOMLI5Bw0ChOZTdEGFjU1RyTv02patKhiGlCeuXKBe3i4vrRpfsfBjCG5K0rlrnlEM0/v/VxCJTCR09yKwst1w8/BmgK+TthwZ2kuNICTpxcRGcR0R4oIrQKTArO7ye/zYmgElYMw4GxXzYI2eQGTdDUkC+HoCAlV3vbZRNNlPTPKq6h5xxOIbmRG4wNZGXOGK2wM8QIvDp5AJ6NL4Q9c4pWJRdDpIwGyNX5+PzqFFDEpEEcjuQHvP4ZTAPRhZ43YppL48yxCX3DnAjHmoLwusW6jVWt0RnELjvnJLZG5ydVeHn5Bo8KeVatzgry8okXBjN3XOtndXM+V7JKHRpM/+RkNon+5NwfYTExIQiK4EAbkqvdXf8VXboPh5V1rDvfgn0/Bi/s2e31Bb9LrWwosJogvaDMPT1Lnz2J2i4coD96pOXqcDkfXBcyJgDSQ3GrU5UDe3rQcu6d9shOOrQ6YHQ5plHt6JZB8y/F7D+8Fdu5ieTHHQIZSMb/SVG8irigXy8Q+IS7Y4GWOh2yFrtfIg0TYZB5tklne5xICt4YXmRMgr8LX1Us/NIeHEiJ4FUF34nDcadPLOoOwYCrrFnNlRfnNZXXsU33Mche68BCJrS3nbrhbU7CSEZOKFP2yWEZZ/Zz5PKJ3uh3I6LfYL09DtU1N8FgXPq6+BhEtPwYHmz5EaX1NDwLb6tQ7G2U4ZF5182PvwpLKnzO3nvm12XF2fKFNi43FWF2scPnbz7zekcsGln8R1WsB2JpjmK5tgrAW6x7tkJDQELFILG6MjGC9jn25txvm1hzUGVZniB7+RibOcXgyLTPrWjGiNbgz1Jlyw/pYVqxatGhaqVUbZHXImXsPBLaqZNR3qU2bH4VvJy3OQLnDoHg8xJnBzY3DmTcXRf7ia9xoGBN++MWe5xi7KULJnvxR5SQR8l0jx7ZoSrS8nb6PLIRnuSshSfP+Ov9sec4USJT1OE+xbkXdVv0Kv1PqFYhMkLVao9kwfHswa4nnDwbicZCRhsLgHZ0RSBySKYkw1/YT0f2xv1l4N5roSJx1Q7jJydfaiO53IVFrDCFBXONkiF84enJ89q6GBvRPeGhKENEtSpOl4y0xbfebw7QfdX27uCjdsDFH7Jf8RfPKerv1pUvTUJB2+2qmTpQd0AZ5CTLzl6YpBlv8/K/iyvwe0RcTNybBoWVrlJqkP5i5rXsTuXi8GdIGLpE1zImJ2gn9CulpMAqiJFYrm9hkua88Vp2ugRJd+urQqeY6TB/CkSC0ztdUakaMNcLp8Q0BRRo1Hu/ghYjcvR6gZtTglAJfYTVqDVG4LHd0VNM6KyfRt7QAPa0G4iz4aGVpqbSbQsmv9qGN3Xd2tKxx/+ROL0K+pq9MmWHq17fnWarfJZMSmlJJQs2d6+vriiCSHaAUNzd/w12SrNg6xl9Z72+ImbI3yOwMj7b5qdQec4nWtKZwd3qf46TjgZB9kh4lOC/unmr0f1SpILhnJLyTEYiJqiu0OJ+C4f3f3Wh4i2o1WZP0cphKrs2uB61jbACVT05VdgOEG2szNI1/rmqzXZ/UBai5c7M4SunqfnNS5hiDCfTR3mW9dMlQ31Av5FIpKLAk+vEsyi/yg5f+BvxSi61ri+JP1VUz57fDKmorH3N4Sm81ENi29UgWxPy0YmzNNy6v/npi0XOHs+muJDzF3V3qP28Ejb7i2+bTJhz4dkZWyKSNbZBkZkHCoGqvYXqkmv6SAXkrMIOGnoENAqZOn2WpXwIQaEeHhIrAWKXQPeHqM+1n4NRimRQ4HHLieGniKuNlmdShGmeIRYYKUxbPWIyzapICEuumVOZGRXpKsvMaVHuj5ryPbpldTeg2bU1MrNYMF9nnCd8F1lnKzNzm9Y2aFFvR8sfS+ikCpJwcp+gLkGTlQ0Khej81x5Xw8/cfxtsDzcuaZ9c8fo2SolJj+Clzhe6BTvdWL78Z7nLe5kJ0T3EpGCwtoW0NianUZ6fVKZ21s0+IOa2NC+CtZQfwk+JzRDIVUwq6SlJho4WMkl2rSvDSPnccNeSmrVNe2xpBfciYLojVeqYEYGtBlzirsABsu47SwlQz15QJCblhWzR91uaa4lx7CiSluSWvBi1kEx+5CCD5wJ/2O9Nc8VrzSD58g965wGFZRkFh9a1qsKf1XmOccRuhRdsGIp3i0rwNSofg7C5/iBjH35qFGASiJEz49xXERTpRpH25dSKjj4ci83+lvoopbKpd2pe4Smd4gprdYzdxvGfUktkhpAdfax35rYmOv+S3doxuxgoO+y/PQhqSUtN6FfLbdB3Tf5fM/ochqB9iDLinQURC4oOsdoglt6MWQUYW9rXLglh220U4+Hls0uTsFrU9Dj8yubrGbuy3vg/vl9W726nZjRycEI44THRaw25M/Vnp8SNN8pqAFu4cjE6b4O72h9fdQOJKOTE3+Vpm6+1177akRxcZI0xR1EAZIoC21MFBCyfnaxLcBA1sqHcjo8CVXNhaM++kz+wJQ/inchzaz5pbm7eOmxdaod/j9pByR2kWwwozBevKn95yjBCMu8Gs2NTgtXSgI4aCzMvThhKF7u61l+nPmTsXJapNCLB1Bfmbn7TkUsYwTR+sJI+7+oDo4p0QCby6Ik2jKaKvjsmg+gbqdj1TRNMG26gVgZ6i6WULszep0MXFV2Ro4iuRqKHZnoFUrQCAw8W3VCVWr+qSn6Ul3xatb0lZLmW5/4Vf8ux09Kt8bDT0PV/r/+3UP2bYJ/iXNT0gFDHu6QA0EevfZ94ZdBDUEbM2n2QA0FmPZBuKlbWkapRzW2VldXI+d3QTvgnkTU0pAFAJwN7Jf5ogUHDFr75rLwDlUMlvEAwKbkoyAgNQA8DkYBrEUA9DHRowtpswuAt4Juvbr3mzfZkwpCTWzE2F519Bu55yeqvdEEM8vRhPInyB4KPgnvV/fD8IJq6kMq6kMoCvsTpf6oKPMBnkhSE6qb93ZX4EMI1vBPPNg/wuemu+BnC24l5EOUxcTnlcTkAAj0MUXtkR/y5vbeGZ7W2FU+/mVPDvvMgPTyhoIuc3OwEOkLNAg+GkSRIe7aUvjhOmT2tuGq1Q+f7Rxl2/i4E1Zwj6cvRJRgYxcJybOczGNGtIbK5Tw+nIcBTj/vsX6kbangvVj6WmGYwkM2ZNx1p7W/AuKAD+qQ4eo0dzq3ymz00vLJyXUdNkVRjybDUxzBtzqU7tSoHI7FTqrrb6q/NhiWFHkNWts1NMJLlIpFxxV0OHpVlNDAOrIJusmH8WJeqC4tqeY5axSry2/vWIzxVA4GiTI2cMLwfom2hjbqbF/RX769H9isvYwBjL13Y/3UKK3bMppLQzz8XZpRKFD1dCUWJZ/wqHzdadiD3GOYfIiPweiwppJs3rmDzwy2L9QBuhy+b9dTN1M0WzRCMmldDD7tx+nTH7nkUFHqmeuNPv0OPdyByz2GxpXXZKz20VvBiYPKJPc047qCUj6EcDd4vmBc9BT5wdub89yvqIWUpN169VvJJmIQ0OVxKFblSuaxCM5hWX3rK866//wq9zIJZNj2PtbkmXoGlIchXY4ed37gCk5ZMZ4Ibs9oCT53tPYvhXdeVc8oLWVpAlsNy/cPhqwap+fLB9uUo7/zwIBzQTFgTxjIfqEEr0vwuWYRxmrVRJSvC2F6LACWoW3wonmgngmtawmD7EGGTT+FgUtxmuUzTAc/+gv0HZAIdhsTgsDkejIogM34XLpXjW7nVnmKwyYXDt+V7AtQs7M+3oGpCDp2G4caErumqQLlPX2n3aheFpOcK9kUiLeazYvzf9fA1dyCvMLzrFMeoAfSnL2wOlHnU4yDiNdLaRG706z+EqQR4zq93MHrYaQkbqMtMFUZGCXvhEkufY4kgowRfacvOnP1BSIvsouBZk0qSGjSAnKBZGsqLj7GMlCwcHtywjKIly23wbgoKgWNE5eOPJNwRWO9i8cMXJB4R1isIXrbhZyMrov4lW+G7I/PJvoXzHg6dObOcHljfErC5J2PQq8apRyQzJ9IWpzCJWSVRsdGy6IE3QAIBDPwBxEsmbM3JVNSzBC3LSOe9dn3j+DTxYCzwD849MuaQsK1jWl+IyJZXLgalcRlxUXFju2e4cpOUs7JGcxdoWwv9kKYL/nWqOc25gLjQKzhziPGeV86Zzkp5zjhbkIu5/uQhbgH/QpGwgKGvz8YG6y3fQMvxaGd75zlLd0CNpsQyAIQCoc2o5w4s//BaHux9vuNPX5/+NnVMrjMEgABgGWK9hl9Srixz+v5NaehfLA132oP3+5ktKzKnQLglrr7pw8Elp0u08zAmxJD5omJEdpOQ1Kja1Hm6K+Hl81cT0XvxfGVzcTk7g1FCWtekX02nLykkTf9V8XdKuev5+hF+58uFbDGJxddz+w+YTb3GHRva/AgOUd5RjGLQMWw5tKwirmpHCdfuzbNzsjj984VcQw1ers/CCzVO1nqWL3j69da06YIWKe+oW2F8LMTDPzNQ+Ojq56tcPpyDfC/Islfz/p722K23rnu+xo+5QSz/6qUdf37emSZUyTqX2/FSJLlCvzd8rTNha29oVv7IrQbj37B423ew3CemDf0+2bTgyxtje9MVxWevLWDHx5TOTJyq6FzSVCezzdD0nyzweM4TgnUeHa7cESF2Jbz7+GbkU6nKTpg1/aDCOgh3XzRk6DASzh/zckwhPLGdLJGZIjrIUUDK/ky9pXa4vNpesmFFtW7w4WrNMndeu5Mjwyr541T/lxy1+3dY+9ckgMCtevKZDF50s87w132f+LqUpXfihUkp5AfjNfLigmD5RxgyBTuRrB9iuQO7MzDPCzGetvj1Ov935/TKv0ho3d8NvXDlcPq+7sbRUoPhW51W+af62jlsS4YmHs8R3O+FX7jQOdNZyZyc5/PTvw+L+xoMuAOLQ9bteNPnPM+iMug45Pr+obsPthIisDURZRx/eesgCJSzDYcNO/mpjZlttl3c8PcJQuPKn7UCNEY+7sVKivl69tiOO6VSWdc1EddKW2nmhdUPf2zAPaeTm4XmlH7RzW895aVg73nPhNg0Ae6p5tMWVCDRrp0LuwQDuNqCegBq4emomBeDeBpmCASbYkqV0bIuFowzZFUOM5RvI3qmAq7cGja8LCOQ+EQcHT1bZ/U7wQIivfMOazJ3jZ/aKMLf697sHA48A5Z8/Z5YWNGLp9Geu9/FRAmJsBnwIPC710/IloyP0sOAnDzvedrP8TCmC6ASig1rzH+ejZVL4Pl12OLY69iwOBlqx4/axYOmxame4nF8UWj+xu+5kvC5v0+1rx7YHLU5vfHesbrR49X6rfrv+N9Y/+jtvq1tU+z7VanU/Zp6pCpXR3HAs7BHP4OBgJ8guArf5nxduG04z77QqHJdzrwXqV0+8zwvg3ZrvDf+/w+0iRgLCJLmjh/c/DX3SWc0a5BujPGSJZZ7yjJesRmtPvTQU+T1g8IuEx5EfCbze2iu5RgPJQrZq3FggYozMtgTVHdow2F4MVHGg6VWAJobs05htqWyYUtgg4qyIkhlRUhpV5JATTJkiZ3TNvTUa6la+L/DWdftAherQHs0WR7KlFruRHQdX83lbQJFVekScvCzktLh1hDNMg1sC3+5qrqsq9Ek505wpHvaG8u5poB/yLSPv7L0Jdm219jRvnlZt8KydLJdOIRM+1wkpq4p4b4t4sOa/4Bny4vyuaOiMBm7yJpgjRFNprpJ3azuc0WwJ74NpAkgX2eiZq3XfOZ/+4RFA+hhmPxisZ2NMClokB5dNuP7+Jdzktu4T0vO1ig8PQaDL2/lJVb88U6LLb1eruBlAPXXIIFGLulnj5aOoDF/qvPF5TekOstwOAbyRzeKMvAqH0aNJ7uzxeVB0rD9+x1bn5qnLGQ923E58+GSFnfzwqQI7tZPTuhen1xA7OVOGPDs9W4Rsgmo1o5rK0zhy/k4RiDO1m+bOhTNbdcpEG/XNpVUfiF4zv9wuDGlg8/IclWvxEFuOnP/276xa1Q+Td70rNSLTVD3zTHHr7mtCmNV8tFa5hckDblVXnTFTbrvEm804Ez9lVRE2fMJUD0IcQ19Xt7498STLCj/xBKYerztBXi60VPO8OnNdSnYdOE4Hkx+O1lE3RafVtL02djxCiCf7WruuDGWgXR0t49Lh6O+hyTmdUVftWQaV7+NcqDuYnjC64s0ZWHvsTL/t1am+Hb3vuDPmZuDt0NmXt9ei1jruxvc660bc3Zl77+oB9QL31cfT9rvXrZuXHeh73n52MPvXkqpUBtDGRlGH6zOC/dKn2N/t16X5Di1oB4PVb7bp+1Et9ktfQX+Jv54N2vaVXENENbzqAd3qCJc+j/hlTOMNWvljbddIb5AhvdiAZSOX3LPHvGpnPN590B/1FrKN23XtdvVzHXiArhza2xm790xFv5bGgLPV8OlKCMGDcqg5tHrkMWL92+1mEB9/cVXF+P/rhB6GY6tn5ss+7328ri9/f/LhV9M92PM7/Kn9K/SQHH/ZM3MkTp0kfzauqHssEUlhJ8w5JqbWYy+OPjyeYfJQy8Fl/vTWXZtY+tgkoLoJMF/2EbLMc4W/PV0//+hLDhJO4y4u/hfb7vXej3ef6cTF3fqQHPuTbNXkwV94thclAPBV0LE5aoXU/5SZeGZNDnFf/qATi+iamSjQXwbnT4WO09Ijobi+rYCJjMljpxthV2YfdA8pTZXX11xZe5U11lmevPP96MACjA8dvSLW8RAck6KNmG6b8fbO9YVEuyZLeBMtBy/qkK6AWZnD9mQCoodyWMet3EYUgXrspCUIzGdreUJnVA5Oq/XLKq1IW7fjxjrDNTsiBwVIyLoSjOZDgH6TRgNckiE4co5lT6bepOZ0ysUjeKpAP1Ojgeo6Hs3jMUWxpew/MCF6mdjpW7ntiqb+hf3EYz0VopUJ754os3EBXqBHynbSHPQ9eZpePkvn+vTMOTnxe8QqsnJ/iPx72Z46Wyfj+nM/XT4TAQZ6OpanikcwKZWvwm3erd0bNGagU6oLuK5/RY4sWReB/OJZDQcRI5sM4RNfMsMJ3eEej0cdsxOLrusiOUC8hd5S45Nj7hcdE8i6OnIZA/Ov2zj8NAxmuoftoK+7l9TI2T0Kq6CxcJGxvP448XmSqpeLNA/T4+eNiDy6bBu+N22XXWQQrgKMDx91LA7bPm2Ty9fCxAIjYP7tRAHjU3LU9HuGh3Tn5Edm55URVCYU3Trm5OY/LkX5gdmuHr/RQrG5i3HK+9s9FbMJh1Sfl8wmGgZnWfGv9WAeRWWyiXKeREiJTSyMZ0r+vnRekZPlIA3/V9fDvP0NzlFZNvOr2aArnxoQiizpRy7saoeRFx0JcwPWRXWNVkrs07dHIe3M0sgnus6mhrFHVh9P3lK1cy4rSlL86R87we8wQofNaJfYLTqu6xQ3jQ0fpzeUGB/8KSo5SDpa8gMpjWyd7V23Zx3P3fkEujKtayO+oRuZZIvhAnGfzhylbGMb+L5rm/qCOM3NyohurisC/SHG0Ztdv87XrT54Bn0pSqZQD9yZ+PzFMPaEYlRSLItVNNcJWzQr18Kc35eRQQraoKskFGN0SFGvYd4Ta/ZX5OOoxcas0oYyjkzP5TGJB+gPGb09fWHnc6jHJgCvsNZb8rIIzoyZYcuk7zO9xyzDvY5jkKaC++oyddxszUpgnVRJ2wlan+qs/cwZSIh2QVha+QbSUyL9kgBd8y8j2y2mmWVEZBuJrI7daVvEp//L+B7yqupeKtffyz5ERxTVGIGMVoP1G0TW5q761JX9HNpjrms+6ZoLmkxLQM/1mSqpxi7brzvHXbB+Dr4Wd59jvKkqIQfk81DcBrCeKjh+Tc7YJXdypFtu28mxrx1w85Uu1tfy6vbOqHO5uRMQPf9qAOrl+pf1Xfek2ybMFsyp+IT/lEw00IYeV2JvhpfMD8fc58m6iR41zSF1liXVWidyCp/TLsQoSpncdN8+TCKiZNBc0/Nqe1+M2Y1v7oExkd7Y7YVn2x8+6eaJyNWtLSm6hstg//BKnoMV9EzLyKAxStIgIw3zUpR6YFzzVNTI/8E2Dje9R88NdoTXYm7bYLjpjcfUqsPDMtACADaAOrku4EMAXSOna+R0DWtNzMtjZr71gxvj6cZxcMx6O1rSTbWws3nWxhJjXp+/aZRxmNY/C7bk/DnYCMBc1/CFCBAcDTETdsSV7e758mXX+LcjA6FrELoGITBKtN67LiYPcrP+lAWlKOeq0TPu3iuV2RP5Wq2ikgPfUnYjCXNdw6ZrxAwM9VEFW/7y6JHWezc+z0QdeKWRPMI0Jr9N3u7PhSGJLgG2px5VtWd8mVHd27rHzwfLqD268d+UI7nYSLSMuhx6Eo+uZzUBhzshP4xKo+fdIrFyd8/3h40CtOZArXkBG6nYI3qv5QHmiNW1rLQn3GndgmyV+ZBOMPj9Y2pLJgpGlvLhixx1oA6umUMQIF5Z5Xi8fbukrwvrinP/1wrRFJ++du6nSJD0hlt0UndVW1frajYkvkz+X3/n5TzennP7Vg/OCi+reeZnBVXYFmakrPLzxha8rVUO821croiy2TiCodbKYHaHXGcW3XYSTNVTly4IKdxu7P0vRy+yPs0zxYXn66d9Y7bJ7ui4My1HSepFL/ONjHBsiECwvQIA4k3AYA+Dh2IS0WA6nHbCCkP3DL9iRSEADL1X6CUxeV0COQICEG9UEEIOBo/5RyH1aJzgb+prPTDgmBBAho/5e1/Tr2fbLxXc7eV0syyLg77SNJC1EshwzmTmgck2co+RVRSxPE/8R/wnYvb5mKexb6siT+OwERqMsNdw3PZ80HcnHUj0E/RWCn/tedDCO1Au+hQe8rgOgAnuEWaxjggbwcJOvk2KuinmDqa6xO667Bz07f/Q8Ptkn4ksn4xI7yCQiz0cRnrpYYYTAGobTGaMEbGS4geNN/MT44t5idvu8mRb5gd960OWEa+4wO4ujWdIbh0iPo0UHoLUWFBamWu6728h43TwrdT1Kflk6iKPQlGwKTuH1LIeb014c1qYN443gTdWYLxbv9NcWObHrxUv7mzRoeg3K9WRYxmqLHJnD7VYBZDH5jgoc4NiRoFjTRKCFGiCCI2g0Mk29hp5yO78eec2HGOX5O7mTKCxhLUGZu9yhhnwaGD/auTQJB1BGfi1h/CWHNhWdvMXhnXCwLFp3FZ1bO6SodlzyXJl49rOw8Dng4TohIvNtZUzv4zlCpDsIDrlU5A2htmxybjj2HHl9EoR+aZerUaKzTUBwcNFyRI5BWAEjMlluLfEr+y+YvHVm3EPJ6XAXXrJK00Wf1KxCUTuAMCdMlSv+4E5RQcZ4YhCaM50ROpF5H2kw6UjPaYQtCt7q8XwwIlYsOWKxnZhOylD3G7OfPIbC+fLKXxdQga9ByDGmmZ3RAiaCwMXzmlK2SmcaFflMzI/YQkAMhTYLyF9FXQ8f1EW6NfL+E8QvlKoUIcAW6iHu/nbfrss5YZPRhJ2R011kLL7h8CjJhXi/jDAfhXarfyawHWQg1dnHD1MYIeT555XzPGTBlIuC8IbEDdRx+Uc2xLCQcufgc/Xm38i2frVH1D1c4ageBDnYJliLUgRdXHTSX8rRELHw41DoClJLyBtWwiQTWEO4b4PqvElMJj+2vZM0khElPWaRKa2pev8/ABUfRNqvYUQ743AmzKig2CZas2QUlTKgbnlkCISmJ/kpjNvzfFXsbHY1HAzL/zSc3h2tYzI3gYZRsLc6DjvLugEhb6E+VXZpXJ0EBC3F/VCmWtiMgIR8P8wR/roDW+X1moG249IpipvtfUHzQfMnRjo7IBMxjUsTDHVDLfw62dRG97gPgHgKC4sIrGph5uLXixZQVqoQ6Yy5qVV1qysikkh0VmfVhYyCqAAxn0bAXyIK0T7YxVw2yI37l6tOLdTuGHO9HDYadxu+/zj9zy8dY+lKV/7hPKMidLtzyU9RxN2xzxFl+Q+7mDOmSgfcCBRnWkLbSeq+Rs5eujozL8wDAG26ZXSWUpXEM0pqSJRka2ypJOLZA7OgkO+HLbdoQGFiY0dF/1Oi9yo0FE5qMSTnZKAI/1rojQobXCtfUxhRbAQ0dUGU+4exr27vBP2SheQ5byMl6Etz4hgfASmqNbnJpoESHOFvFGkx5qGBj07mEgIyevsQtJ1J85uclstY1fS6UDkPhozd83RDPpBrFpFaXX3pgC7Ttvwmyt2bmNoqRllXSkyVoWzti/jry/yWRzdakPfy7hmLYYf1GPaazQRWaoghQZBWzyK4cadrJaMaIAALjbPHC5Lvg0i9jEkoUEQlhNlUyLKXZGtsIV+bkgQiIMf+v7MMSO0tE3c0W0PNWAPTORIKzeQEB5ZAeEEozEjfK9mgBLXPGRN6iQh6GvFBYd2kxYiKuPQjYU8bFL0cT2MmDJe6oeoeAKRWrMgGa0jnmQE/X1QBRweIf+zvrokAyRtjpK7W5bwWjWXg6U/L4Kb2TENnRdTJdihvnNYEcgygvjVx0QZ9YTSZJlAipD85liZxwnF/VrzeilM+i7HIIdVHuKXrcM+/GABs3O7wPCtm4SyLhgjRJybpzCy6dLywzqBbLc9WZuSV6znhC93UBFPG/P4AYD95vYo+FGX8VQDWcg2r78Gcn75GjJqulyaeAiAMqUWOVixSzqYQjylSzzIEALG47+gKhpumdzs5nbHHYHfbJNYVxEpWv2s37B2F4oVC4KyXgtGKN3g8tww82AOAAPoK/kkxt6WoDb3aivIePQQjDxLHvd+gOre6VAhNIYhPmBmvEpyuN2HlOsFPU6Ti33mg8MxQOqrq6h7t0TddqIzTw8f+glrDH4M1vFlahyO6i31VXZnUC1Bk1ABBOzAl4+N4iTpaw0M9EUBk0d2IlhTh4O0kEnY0DKcaobNcARUfAtLXn0mh44fmIQ0AQW69QxKaX/tumt7yrMNTUEOk4mEKZcMIFeJgSvFLa6UHJRSKFAupqUHpCBfscXvjtjLlnxZbFvQdPEYEgV6ExH9yzAh9QuThxGXsgq/lOKhIAuX72WQMD0FLZagCT21FTWYDrhP01fJ3TFoJwRX+oEOhVtw8BgEFsJ1ayk7+mg54/E6oN4o9uqH1Zs1Wz69PznKhHvXugi8/8DDcuR+4LfUYEJvdhlGlERRJXoWAPHxJzBWSvL7MAISnxCu1LAI9XzpmUwmraLdWyy+p3mGUbFEMay+tJivSH53y8XtSW6OCImdnQ0CcyoWIbce2VaGrp63/HwYfv+XvfAFxPLKgRRiuAvAahhU1sGIHmFHHiRgECbQOFeH6tzFCZXttugnUHrnAa7iwviBcuYY0OldEs+CIbhicgUDueWKPuS6gFmDCYkd+zQcneuzGAhangLTErfePJczRw9jNB7l2NnVeNK3d2qY7MARXJW7MCgNYs/rNXcrekADzxCsz9jaILCt1jbYFWf5qiHaN8no4iV9atKbWgZpE5QihsVSCmUa73wAjuCl/eSeYOu14aHIfqSPPEbWUvngO4Nb0h7eqAa2rnmBGE4faNizhWh93C49lGDpSR/723i1Ayvm2KNrBm2mh/nEZulTfDDFUJGRrB4Ke4Hnu4zLAAS6JBltRxn+VvB7n5oVDgpvP3/btNqpgmYhIoqpGMAZR3nYpRTPHi7PsunV3Ee6st4vvw/CmpI5SMHBigoXscOYMSGK6zj6O1YwWJV+s1+7DmjHBWRd5zoy6zHqrE9/ty41JegkTOoxVd4bqxyjeF/mbP/LSU4A2Es2wSwitEXVy/QmMwiNM/y6kSVGj5ZF2mZsEp/RwizcOZVncOAJq7BAt6ueJsSoEjjdi+tb8oaI8NJU+euqeNs/zCGkUfDW6QhoixvpTSSyQKk+8IGgF3Wag1dcQjoiYq0eAauKukfVsLheYDp1XS1J1h/ECUbjts7hAWO/Yd+NWdbUpAQ+F+PoaunYyqHMpSmfoYCvgiN25s9eT5SxgziqPc8xy/hy4djK0shNy82MDLhoQPxwjsyYPC9n+ciKnKi9oe5WaZbVBO7VhUGcqgyAi7aem8FIVwSOWeRn9EPrT4Z2FJ+ighOUfFKrvuCaHM7ZIyHTr0z0thFuXM2ErqXKy5l3EXnmNr3JMnm8qVh2+JY2ibGdyLzg002XASGtGMnNdlJbxv2wRWcMcZ+XQgktMJrViSLXNlS08EjHZKBTM6Q51Wge1PW0AZDanRToS8Mmgaon77hzanIsTRWKR4e32S2HCjSi5jMCA4R5R8t/zk8SVzjaKkDpJr8zBDgPEgmpdYhSId8gieuIBYIfv3z8OaYwhwQU+qPC6V5zWBJPy3tDGiob5PBPZrfKcxS+UvhI8/uyHtZpYN55vBmy9/R46AnnQ93imq5Fd2CVmiqthwcXqGQ4AAAJ7heMHWPJPaaPJTv12xWV6KETGoPyvuv0WmmbceBIZ8Ky2Gs63hs7Q2/SFyshWYTecrX5D94FbQg3mnPKDq+vaVvPgsuMp5Pknuo8TS9gYTG0LzRKnixLs9t9tqc74IdFE9emttOIvVAPr5lt1Ic8++ODLG4BWgENSYLXAzLSRkH5U4Q42ZeYuiKJ5mqeaUznlNweLuJrCSd0POyHy5NcqL26krj6kLpPHX3sk2VUOrGEaDqbmJjEsNRYnbkxjKP67UH0GG9MBnlrAvdmhSEbkSTFOl98nPTI/DPnwxOoNFeWeY4UT7vED1ubaiJv0klHz7JnyWsVetVXsv1QTYfu0u4S7/SHPHyzruNdEBwrui6kLs5z11NFnvcRWvsKi4ZFDnKY4SgIjlpccbCw9MVm3bjwcONJHzI8kahH2sZOLJqOujz2JvSpz6rw2lQci18hpZVTI6sdJ35++Xk8AUn8pfPMjrE3FBj8svJ/ML/R1M4NbczMOlJwjJDlLn2+pxbN2+pJYqF5HVTT80wOf1Y33YV++z1I0JDtBRNE3I0x6RG+Tj7lHqdrRPaz6CpBkc6+7ljiZp8ztnezy0Af2qTsrzc/I47GF9Gafevo/W0oCHYz97apXZs7VRtSqJQcNq5SQBibhJWl7T70VXmTsEbHjbsJ6OerX3/Z2FbYXQlhjbCINFL2qJI6dmXYoKa0neEI05XEhia8Ib6euZt1KVDuWpveNB4y2GkCSlC3RCa3zY0LtGT7xtIGkHLRiM1YEdneFCTpuKiR4BEeyWsHIPkT76CoWxKJBJG7oYoODhzEFlGuh8yBwG84+sIlbO/6DH5g1xdNJf67w5RMqAZKrIIEHd4RdPdfZf3i+Zubv30F7u2V6cUuTK7FEKQjIOVbG9uuIbBvz1KmytwpOZrixZ29fFPbNZlMFjsvEMJmCSXNwudV+fMA0FGYWiV7wBA67PIbmpaaOhboH5owNOB7tqlIO4eXbUGkk09t5wwBPiIkk7NiWn9u0AwBkl3OgFyFUcv2C6A7lpZr5Wt37hzv+t0DWqlTWlx7qGoYnAF1CqCgrhALDeNj24/4ObhAdI+Y/ns8dEi6ky7KoBUMi2POCxgD6H6dC5oGSfMejJAEJN6iYJxZITFkf+qbNDF1gd94UDVHO/SrJzjmulv4AtVvXglRFRE+laIbplea3DcgShHo27wd0y+lyK28C45R2daRaGeQ+5swbaMitOHGd7IzB5EhZIvXNWX61wGlI9mYajqTpjZz54Q2D/0iDyEND3ytCnSxzWDl0eSEhiOeX/djIkTlIijVJSa4uGLnCKGdhaW6nTQNrPYgvaSRti4Zm3+q1SAYw9F1NIVTwOnasEZfIhhvTH9Lp/MWvkDVr9UUQyBypDqeenr2kVtkmVhKzy3Rg9vILsDW4QSxDBAHygBKHQW5bbpFfjgcEN2f55YdST1JwbztAXpeTs/de5mMI/EKuD/AsVutEPBj7II+7TaXZUNDkZgHGfZ4mtrkfFcj5/A6j+JawA1uUQ5FPloLzJDSt8e25NAaw56wXiB9nMUfa4aXLxSeL+w9CYVV3RXOT8pvDlDfDREBDmDuhFlSjGzDPDeRtYDUq9ZkT5p8WpCmU5PwsMUAVOxmAYdTN4jVPrJmf5ar50Vbad6vjFSVJx/aloFSeRkMi9teWQK9EHda68CqZ+p0uZ9WOLqyy84hiMGM3WME/eLSZVv6OCLs7k167CadTYwgAn+udPUYyFXGhrqMQ8fSFG/tc2rJhyoGwZqaDs67RkXo/tz0th/7Gei2RZ4m+LTUnXdXf9Brnz+tcNW9FqL5/3JadefFPBaxrjqXCQZdYFJSiTP8aD2Gc2skCrhT4nCdO92fhFDxzVHfUMPX5l5wzzE5hhAOMnm67Bg6Z61A/dBmeloXC5H3HezoRDEBSWsEsAUYTIzETQ0onplvCfFXs3ZFDhTU5S1DuDEUS58QYxnarWVUyohUyAX28FqdS0kHhB84hQOnVzzXXmLV6NGu4WLbZHMw09RPF2XOeCjIUXre2o2EdzelJt/5b9+KVY5A5A9g7AD+a71If49CANxRvxuZHair2xLyRzrQOr8k5AEzRB/t3VUxP5hJPHQmUtpbwD6Tj3BcExpsS0jEJJ7tTZWmI0qRL4zIQ245kQYnfOe89BzjJu4irqBdQDXNsHRVFriDd7VoLEsqCpYroxhe2lfXN1/M/w46mGXB/xvKv14xo0MDBTt6IiyWDMDdwQBR4RMCYOKLjf6rXi3qi40NWem+hVgUnusyiUh8dLwdc29HawouvJYHNzxP62TKouWEdnQPhCY2ELl9G7IGANxRRrEDEImFkMvJmiWqOHeoRr+UUpS69NEhq2/5l2V1U5q6TD0sLTNKTnwMnxVZW9Y01RhVtbQve7kq4dKFTBh4mkLhO0Oe1nUrWeROrcJVek2glks+7AOMvVhyGeoyKPVgWo9EmQkGezFKhhv48lbT39DMNnA5l4hF1Z62IcY9w+hY9kXs3ueXR7bp7zCgKs9RVnMA4kR6ZzEbJoGneejWikB2qopy50tDM9VzfYTjRy0jHuVZ6N41ZZ6RKLBNdsUpuuQr8tv19Xdo/NRTM+0jUdWfjVJ5B+AxpC4DqzKij39Ngii9PE+2sbLi8Z3azIyom0xo6QLfP5bxfpG9f36B1PtsCAJNlSrGEZpwnNAclxGuXlakBYIwTzB76LxRmRMB4PE6H2wfOAR9OhtCE1Ibz6qUFPM3AyFTb+FxB8Sdm8V8JuVcu9eKuHcNsCJFL7zNzZukzQWMszNqHRo17ZgDc+004OtNyWYR1UWaRD7qvK4NcS/uhQdl+1eY/I5HGNAcEGFJr3vVzNbsttOtfXbPjIS+oeHN+K15txNAOyDkdJymcO9uElxBgnXRVExZbGwBBbBnN1rCSuu167Adc/SkWZJDCJpkQQbW6yM4YRoJ7+CKiIVplkD/iTDgYcY0yGuUJuh/caKknMEIhOZkwojefAlL+LDK4acfB5/ti2uLcNwI6yBuvhpGURb9+WFTQ3oq12NipXAsQnG+uawEqru3IGyGICMDaU8L9Fnp+Jgmth4AXZGv+RSKwbf3tWug64MR/nrKEp0LpPcFzFX3ktOjAvlapCQTohnck/UjT39Kj7jKZaIagS1lZcg/e9Mvlg5tqE1YVfSksZjQaz6vGayP2VQJjC07a05hSioG2uE3ixwR+N2W9xDhgew8WRLZnl6cBFaHMsGZPNg1/O2dfVh4mAtFqc+8LJsCHuyeutu6My5J+qCFltufXPVNV5aulVmLefmJGQdTUNOvMsXeviw4Hgms6v/QvRbu28ra3J3/x5FLU3KpsorRLgeHbJoHhEfhl5uZLFKBlXl6UiENqm8TVoo/eOkRU0lGPzWXBysI9jdj0OzknONCLO7cOb79XCyJh/7fUzHsghSfeO4esGZR0bUWHDZbo8GScH62b4Z80iTgQ2Bl3NvwFwwsv6E6FRNhJdKhClAa9FS9bts452jVm0v3fMYBsKErwp373WYRLZm5qobNjO7Qlw99LU5o9f3+D1v1sPqEWz+mV+/jJN784W68GgoMLXzFMCMYNr8UPKoebvlS6BXEtsxv2bnlG/0bkJM5VJXiOCEbPiL68sqzNVeioQ+DPAqVdUiHTIBvfobjUp7symvHxnmKaRZFc7zxPTQ5YFU6UGc9osAiEjeMVUJFFhD5lvNsTTToKTet4rq2tWMNhWW8Khp3Qde/pm8oum+3GB7m2CP+iRj+VWN1s9VhSlIn6nk43Fq1qUWzpqv7gj56HTCgDMfKFx4A1T0gvbQWTIWmTBxNU2EU0f61eVw47Ju6dew7g8a5VeihQJe8wkSAfOWatbiQXgiCx6PwtjXmV02RErjglsAyI/bes0YvC87mC2nWcrcC3Ye2LjPirIPKfJ0nPl60+QPRCEmgSNMANnpG0gAeKzdbPNhg32BveuKt70XsFrzK0tfJ3fT5IV6LsWsHAs4jxpbi6OqSHOZkY4R9ewTuYMpTx1Il/ixrtGrdyp8MwQB+7O6yEJJ0OoLFEpyWjORDF7mh1zodBQXzU/zCWG59iI2APUuY73UIgSIGWUWD9E37mP2yUOhwwaufKn22nrkQOj8HQpMQbEEvdhS8YVT5biTMffzBbhdg11Zl7mvh69TdBcalnXgkg15ZiK62eacDx7WJLB7upIki8bfar/NT3P6FNNcJFDpJZ1w/eI61zSYjka8p5//BD+PBs/ozl+tiXWpBjRlCbvFapOCL2r33olzxfYz2UrlLIrHZLE7WaPo6NyDi0WN1QaQJiuQNRGJAUu6K0Z7EyGmWqE3kdb9XzQMM01wpeP8n+qK+ecHzGXCKRVePK5R4zQ+Je4aJv67Utwke0WH/W0BVcxj+8A39J4zFN/Da9aGpHxPEOychcGU/GNdBkTbEjqPLImPsam1se4rZ59/+kk4qEktB/5p9N9JB2yubVFzbXHR5pqVGQMS9GDDEczZQemXVtPMYIKrteVvtRInIsG4jJWAisZWTtzj0LlGzglhQbfA1LDxEQt3rDjq2CMkJ4TZkMYM4KUPqVdjXMDWRO+hdA/w2X/SDOoIOQuMBZCd7kwLKpkjLGxwEg72lysACwcnGA7PE3EzfFlmELtb5d+B5q8DHmeZY0XLXQD1dmcrWJVTLtqlK7FolbDbq3UPr7bSnozDztVfG5ybD6rc/IgKZnymzKECOroivSa/tK4Rpp4HStBl0xj8JDdSXV8o1nwYOGDnZ3tCG3nUVSbS7ieesYnqtNxaIu+Igtx5QSpOKij7ATWQ9rjM1URW2KYs7R5s/XodTXe/0z/QEEDqe1RnBVTUvXEDGA/KhR8fuGjR3DKiraa4UZ5jV8ppAs46RphwbLJhL3shuIyGGll6BjoypQBmARTw1NhhQKQl31oTKtVkB8anrWIGjEs41Ro0Ydp1rtRweNqqknilDFRw4AJU2qP1+PBgQ0kun01gvgMGGuiC3kUsqtyOYPVW3zUiIwy7y15oiYzBju+/2thrwFGIjXgetoV1HeHrk1EuDDPNrvkoJI8tlNE098g9U10da3DwNw4b2DU9OH26vzs/Ck/CklM+kU8nAbxh7xyvE4dxULDs/airze8Q/EXl/uqnZzcyn2bVJvzZ5yzR2OXv/VqPdyGc7JuhHemtTIyDikeFDy6hZlJIZUZCV7RCgualIDCOhHpbdYmBxAAI1KlQ5PQnhuBBDUg1ap78VBY6piPuCIt0Mctk1O88WcJq2m+z+ra3TGLumMXjy11ZB1r3QlALTfbg3Sbl4VtHClgd9GaZmIFMr8xsvjxCjC8+d13RM0q/mNQZKlP74dzePyPEWv9vysomtphT6bGmOi3vdW95RvRcBE1/32PIukbg53vjDDfGOfrRK0tNt+Y1mQQ+dQadpklrEj5PabNus2YYsnBr6+HUgnG24CbOvT5WIHitydM7c849H3JyghwKm2QgModPlexg2bVIQBKFakMKcSPrn5Nbph/5xNeUQsRQZyhvAPErHxiJzHTNYrxZlVxM+kuEQFIk80+SXUYr2aUI41dI3Q29oKvI5VQR/jYwYdrZFKiE6knNe6rCw0othI3vhjSstNm07n+oAf78nrhaK00lZZJeyfed23lt3wMjjfwBHXz3R9bgUYJwV/JBV64kbfd5en15/uU3WBt4YOW/bAJGjWcOA/NuRU763sLIPokFK4MWWpXwNpaLWN08edgI9uZjrpOvkiVO5FXSp7FhqqkxTJKHcsi3MsxHSGFWXTWOuwaoQJZZU1zqPGb9qW+sMiAN7GJMzCWw6MDVJYFZ51ZJmrH+xBUpZo5l8O/lgH8S+XKL+5FQlS5VTDGZ8ZuBT1DCquvR+JnyDnOm9dNiQTX8lK73M3oL/vI1/vL4IkxSxN+ap83/3c7nC7GJgpUWtW/Pzu5urcpaXUviSUeEK5FwetwvSsvI6oLcZ62bKHV+FhthxckN3zl5jzz5CPq7lPTcRo6n1WhSq5HeH/jsKqMrHYyZ/BjF4SQ0mP5SoOEWmnBMS1jhbsFqG2fAxM1mKhPEeNV2iEz/ioIp/NldXluZHH65Z1buorbXiftB9n+LMDHOKVhMoJZMQ4zVL5tAK2+q7Eydau9EHk69cH/E+Tcu2YbLCOL1qew9Zn4U9fAacPCAGqkaPgLbhwc0TY2uGBxd0z+5sm1ldUZCfkWaICwsBeJT3Z4mpI9UGJMbYBhrFWYv980osTP2hMZeCD42LjgwP1VD0UU0NCb8h3LhfNleP+vbZk+fsnqBU/C/S/Av43aNd9JX/fN6f6/bODSXAGu4A4/eYkLrz+xHSp4Pe3ytvwT/A6I0lvrmeFcgP05z5QvoPiV7iP4X49C+m4cksRwTlLIoKhuxM8lEI5HPBlU8pg/W9l056bmuPOVbFSZE+UtmLknvMECWQe5R+FcYd2MaRag8pLSK4ZlzZRFmODCxDX9tIFTHytfUmsZG4Z0L0RF0gLQ30MOlhMSO1uzYDbSXjqfDhsP3IvT6UtA5KYDLoiI9EOcMby+ZDaViQG6woBxOrZBNfOkiTbX0vG5xVvd5mFGy3u96LcjqRQ7/g3Lkci55iL3LpQTnJKDdxa7Sd5Caj6s1cdg/L6V32NUc2OecWSuC1TiHpIRkthmOaE2xt/M2I7npSm+wjFF9VFa1vI0iA7Hr8qohoV5Z9m/a4z7DX13/xUUIf0iobZlOXdhVdxfVC2p8v/Idi6tGqdib5j39rM8xTInlKIJNYdoa0OiKadBLiD6cc4lVNvLqe6tikOqUpTjn29YRYVKCpSSWVK7KuuR6fRWUXzxTAWtO88y+FtHMNOB4JHG8P7O8DHC8HXP97nB5cKW2g7QVNDWzji6B86xEQb55vzdQS0/Lgmh3rUhzAVQrhOEA3vjGLAzmbMOPqZhLh4+MMK7rj2u56w2SH/NrYdWOOaddN0e7xfIcEi+sK1tW4KTAaB4y3e4xHA7PeYDgmmOFDW2gJkAXiBWvEHo0XVx6vPKfyispjyEfiF6TtV4FrcnZAcLa02fwmtB8LHSt9LXYBfcRlMFIatLRhQ13FfmBAT12hlgbip5hDTkDnGCBfJnlpcExWtICqu1l9rEkR9trtYpv91YmxbQ++cEzjgcvTARDJ74vkzUi8YaQ/BO3Fv/y/jmb3svGisqaKwD+erG6vr1HB4KufJsoQRyXFXGGRr7HlY5j2IdH51POu8JrUNuy0iQe2ryfmD+AbB9OLjaZKNavmajppdYqjXHj1CB5bz50FirqBc5PUH3zLe9cSi4u8vAGB+aCXMnkQ5hqTucxwXqPZ+axGnpLuId6FinuK4EWeUWIvqjqJqX+88zgCLSqoMQCfBuYyn10iAaEfYetdiptjJS1or1j22VjD2pKLYjaLyb2WtkCLZOWBQBqT1T8mG6maR9DoApMcmDYvuxFyYu3azTQ8tBb56mb7sc/N1+zubGSL3mVHV+OR91nPFsLvQp/TmLewVBgR8qW946ZC/2iSmO2RqzgiffS0FGffsiNNnyk5/Tl8KYCdgDILHVPseAKTssC+4AA9+rQ2ZLbZ8jJSEHd6llx6gFNldc7yteWI/XzEgMms5P0ZwB6P/ah7JVbH0KsVoPdT3aQ9QquzE1jo4MUeI0epyoCwQC9CrVvZIbItrrzQ60sa9FWhWcasjlyq6CEWk6LN1GCkfy1JmRVMbUyoaYmCnljrBnnVu/KAvI1QjgJlRfPaNAEuz0H7Ik3F43UxERcvUdfTWzaPjkLgkMvT9V/rLBBPdtT/kB+MxtMoT6E8Unk+/mg6BZm6hlMZsMb303zOOk8pFtlFXn1dV+qUXN2iHf9kXwB4MYrs8SQLAhOGNEEg70c0OqeIIYRKkw3EU925jggS8JjQmzeicdvYn01AB1YiCpyCDfp0LxsoQnRzViUXkqHrzk2GiHWX861iV9C3vrqH6Nb5fx/xrf+QYJMAkI+8jQYQ6d1LELB3eSEx3JUMqvrQWO66j4gmwPC6W4b8wbP6/6Hw6Cm8USF9in+Ag32K/zoaOk/pwObObQgN3+njv7TtRLxsifLNDptywuBngAWkyMetujHt6jsb7P0UyUxFMSDDtIG101Cz27Z+gPAQFWnBTqhJHmcrT61/OYMC/043DIeTLRgkn3OJVXMdamUZECDlb4L8o3A9q7l4NxTK8iCxZN7jhg1whj3IBpGNVGezeOJ3/h29oYn4kqMkD/iyHJ5Sp9nbJ3pb4omtH9KSgKiAF+5hHXcFhsH6mT/eBbOEVwx1cgl3JkXC45FlH8BNMHiDBsAqvoq85GKr2pSgmvmE8F2BwbIWdt9BfzhJAG1xKYw1LxUIULMAYbhWCCsAmI1qI5CbTafXxa0EdIYNDcoC9v+xr3zHDdzmmvUqFDxqLcgCaZuraP4CMkZaIT4utOJwtGUFBvS/qQZJiEQr+SI0dJxA8TrEMhXaTGU7CaIoh/ib4bgm+mETnW2QeDmm15C0ks8NA/jay7bIcRyUYwuEz0l8ntGPVDIZj9jqaNERBMnECYqDlJvAJ7baMVQB0wvbUl70ZOWllh3g+g55Y/wcAwvnIQ8QnUYXDLg1awAGvnOj7wT1GqJ39HuBUu8kUiExiGwSeQySya2fZaCXC5ARHUUTVOuXgKJDJjR8unOhQoBVemgbxVYNDRwioRI2GEMieAjoiGCmZUkVCwTXAPgW63um7lkaAiEBpvhG2cQ5ZIUKFIrWJwygoTTwZyMMyX6tD3ItXvNLCVqXFVpxxaUOApSWJ5DwBu0pwI+BhjMgvwWmFEKFpwSIPlcb1XJ1eUCLYy27asgMJlNAwiB3C69RoM0ZUBSOIr2MK0eUgSvVvIlDMz2ODao6Gje9cmWnBjoFed1Ne2kGjWE5pLH9cUAj9tnUo8kdy4x8oIUT/9gpB6j9TUcgnH2aGNM7nu6m3wFd4NEbDcbyG7g1NX+n/yxkcViUqqijfJU873Rb/tbetaKIh9znrrbwKI08nDHbzGs3YpFDK1B6dzDVvM6oyzvuPhsTPkceWm0T7Vo5bPqRmU/BHZSM5QVPWTuwsK8s8yoDX6V3SBdmA+1Lb1gCtX8fATrBrASLgoNj+h8BRa2HCr8ZCyAVXSV9G2IRQihTrZDvnW180nPM4NMEbI4KiXcZ3xrgIevmMqe3oqop2soM6PJxhe2LAOpSy8bat+IIOKuSgR4/124Z4AJ80sxlbIfpvehb7u3h7m44pgCcpA8EXWYMoT5uilgf6KHnye2ZvSxAUAF0OXYsm4qfETTZogumOcWjedaPIMSGkymHTAXtgzZjgwdoxaJBJbHuTBkmQsNe7AxnJ2q4mQS+TP0diBh4s4GaPWd0ow6EsgJ56gtJfLeaUCasAj7P+wkyPq8okH/Dtf/ZaTaLUiy9KhheAqjlBA5mNsbIDB5A7VJiRc94XPoax+fKWBCrn+t3a6zdifDh39Nvlt7gaiRVahO0kFlCd27o+T2URkdk8naijjJvLwgtMvo6DnRkGoArZ2iHI3UYC8rj6NRivvXPga3wSUjMUKYmdKpLQQL7JpK6OKzHVBNC9s1cryXSvwBWFSnG/ai0GRpLkC3S8aQc+YrwQXTkel7qmBEVBeNCABZ1MsXq8PXVoCa/7eTK84NoMRYuUUVGRVYnQkWR+NUttop9yFNRKY0RfMZeWpsJKVSZZnnGDGOZ1BiRpRMhOyigjdZBBXJ3Ar0D/SmVEL5INuu/S7M28c543Y883npKusWfLIc61LYgMyk+neFOkG6pJjfkpsLhitT/FEzz1p4hLq0nGx02qv2fcqUjlN4VmQ3dBea7HmkghqJJW73snS094Po7GyigNN/WOEC8ivCcj/1VQP/QwKfnje+AfFsXBR7ISRhAraTh+Md6JQ2ANlhqF5rBDkLroKbjpKpB7lwokavpbo2o72YMxAxs5boGM5wvsHiaon1UVYT6TuQEeLTzYWlJZSXwRUP2ait02nWXmFJLzSA/1yy7EN0NSq8zkuAmMKAyH1JRgeROmljm3Jh4WNAjOvyjfUKZzia3ZpTDTho6vuRmipUnZKnWKKWLzdThvy0smXTSNtMMuRzlTFaqxzFRTOuaDekvRkOSaJ5dg8pghyTUeQndW5Q6N8thIBxlDDQhqvWC37IUtFb+ojeikahZzNkdgOGmbHSW4p1bdHbCtjTnjt2yaKZ8DUrkChG+/6mQmSK1C2VqPJLqKGsLqXZaFOWtM3NETGIg6LSvZz5E9vMuoG6UdJ3A0VP3yRuH/q9rhHwlSAtcvrYZhKCPv6XQEhHguqvd3lehNPK6Uj0pCTaJinTZOsiRr0PKGpvcTUk3A21NQtiJJCHnMtebhpsMLzRwqcqsOfTApp5OXIj9kyLe6Z9g5iSSwp+T5p0UHxLMQJ7mAsuraz5tMSPFLC0XTh06yF/AyXtQBqtROmgxeeqVGdkrewdHKjxu3xykMyPltW/SRmHQ3twXnwFt0Paawdgv9UTlkoASaZoBlo1FxpNeM2LxScC7OA6lG1wSbjoUxZR1R5enN0OXQEPgYUuKHlpc1CLmc7O+fcFJc17QJYjm+l1fnwY1NGOancYukhhpPnf4SNmH5vNwORL5hJzcUD046n/WpS7KyKYrCOijcChFurHi3Apx0dET3JcHzC4d/XFEm7ANJdH+yNZELImctE4sBz5aCcU4Vt9mMdwbH1B4xBLfVTi7rjj+4Y+OfXkJQrsY15MYODklVhytocTsXd4E2rUqXLgpqAENI9nShw33E5LfzEnZ54Vf71hWmZExDSxQ3xKAPXOKJprdtgwCFXgvLbHggESI42bnZM+hkG2i4vSj646HnOZouiMj63/4SR/Z73pWIqRJioqMkCIusmvRUO8FHakUKox9ipCpjEbBpB+SptpzvxUI4Dayhy6nzBqTtpFXHdYCIRRzAzX5N9QnRxGTMgZQMoIsqaAZSKMWLORJPAtNsFeZeWP0gG444pWBiXCMm1gs/tVrrUq71DLCM8u7HZaBsLL4QdXjrTjrWHsZQCMdqHug+JmtvSVXrXziypKKoqZvigTRoQ83DgyAw64/5PauCcveBP6k/xXXOaLV1NJ6U5Zc3jcMh21r9SAlJHJyad+OmA8I7lvFcfG8PIy0dTW0OTFWk2g9cy6Jz3KA0IHllR22JUzwSakbV3zOmc5t80/XfDI+IBMvKblvt7qXyvkLvDANaiJRPwMO/VSic4bj3J8AMVqqZzw0xQJW3sZx7kSbKVHijVaVkBcfTuvwVAgaWTbQeU/TVGJLmssstfb1JGz05+W/PxqPeenvBiSkBqiyOp0GY3N1zGF8JqMcxl5leq1VnMYzpPW3Fwrgv6xIK5dZgKOqnWoxng/eGCXnL7fCSXSQgwQsm8rylkBjgQyh47E2hk9QNy+o4Yg1Y5ZcgyY6f/g5JV7qZYq/ZrzmkELCeMuO62X95d78i9yf9Lv/uhu2sDQ6/R2inb5edJtuU3FzCoJzZK2sP0Uwmf8upKe/Ew8ZKIaPIYT7J3T8Pg/b877/jQ6IQEAkQEJFQP/6HhMo0CRFqodKHUqTJ1uNNrcCDbJsSFbki69ylckwYdtntdp9980PjUEE1u15jSLuJe16ZQeq3f9FSwEpQatnli+54gVRkhVV0w3Tsp2LizzsB2EUJyTN8qKs6qbt+mG83qb7/Hi+UBTDCZKiGZbjBVGSFVWLRGPxhG6Ylu24nh8kU2E6k83lC8XS0fHJ6dn5xeXV9c3t3XIQrexeMcWqGzDZparPlCTj0otnlWCcbnhktCQjJZfiJ+DSSi+jzLLKllNOueWV303lKlU41axQtRb5ipUYqqDCioz9j2VohuV4QZQy2Vy+UNyXFVXTDdOyHdfzS+VKtVZvBGEUN1vtTpfleEGUZEXVdMO0bMf1/CCM4iTN8qKsAAmtm7brh3Gal3Xbj/O6n/fD+vnfIF0BQlE1qRumZTuu5+MJRBKZQqXRGUwWm+PChXgwXyAUiSWIVCZXKFVqjVanNxhd3UzuZul8gVANCoMjkCg0BovDE4gkMoVKExEVE5egM5gsNofL4wskpYTSMrJy8gqK6fucZV4DoMeO7C4I7Zuo1+nD1zJJw2Ym09Jj6PPpdvcprkajpVnbBlfKMFejdtog7qdYPrXN9vg6imOBJeFdm8dw83nbOcLpiKHqbuHumG7CMMW5akDwtFXDEvfwPUIqbdlOpgwQYUIZF/IrkrfAEQSECWVcSKUt28lUASJMKC9RIn+Sk27N3CzN2mzN3hw2hwSgjraIcdY6aiU3dBjN7Slysl5zEkf1LS/NXhRutvDdZm2yJRPNLgi2aitYjiYAIESYUMbFyCchaLhzCREmlHEhVWjRqe7toBncJpqh+6j3G3Eh1Oz8KK1eiWNTkNn26Pc06aM7Fxi07TsW2I2Pi4IlFesHxm+HXa4FQXdBaRUPcbeNHsenuPGqS+KU4DXHxMNjN/KgXSPTzj9uZQxE25m9QMc2XpPHZ5W4HIoX2Nr0tOnJLC1FlbeP8/ox5ZCFgduzGJUyhjy44TDpAPrIdBxp27hItlvaym6vtJNpHyDChDrX3P2D9it1wvf+zY7Y4FjvOP06iU1f8sbksi5AhAnjQipt2U6mPYAIE8q4kEpbtrPvqQcAAAAAAJAkSZIkSUqSJEmSJMEpEREREREREZGIiIiIiIiIiDHGGGOMMcYYY4xzzjnnnHPOOZl0zBH+Ho59PcVfViaz0fb0ch9rUOJ4qjZv9jaSxctUD4MgPfrQhSC4OXsDNB6p+9CYYY1NY5KlzTjctjX+vB4E607BY3XBZ3gf/K7xHMfn9/3P/qJK6M5ZFRF/4oT+Kv7HFQZ66eY7rT1NTW6lXgmHOPr7v3vbOBpmO1jDbv5WxNQ0HgdbHQ9+Zivm8i1N4+znxs8ZMXvYnkJZ7yY+XhoVWtrQpH53BNzneCFe5l76kzie9t8skQ7DGZ3S8bD/YcLGt03PszbeN8YGM3UbP5vzNzu8CkT/ewHZq7/uHQjzXq8XwmNr9a53APGLf4cABEHgefp3XXKhRCMw57t5YXQ1l+TFf4A4sQFI0F+E7F0BAaE9Emh8G5dDxqvZ9BIybA5UnoJhTCLY55S7BQ95vKStXLmPzQU3EFiB74UXqd8Kzf02x7zi70B7TKDxkgAA","Vazir.woff2":"d09GMgABAAAAAJTYABMAAAABSHgAAJRtAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoE+G9AoHIsuH4FyBmAAiX4IXgmabREICoOAUILZOwuIKAABNgIkA5A8BCAFyzoHoVYMgRhbay9xB9Vr/yUg0JtVvdgFOx7yguiGWakOf71ZYdlNun64YLrNE7kdQBRXvYns////Pz9ZyKH3n7nLJwWlVCldN9ChKGSaKDWCtzYKo+uHWirLWFEKSn9HIMo02rhBqLMQxEj7oLyFLiVvFWRIjyAJkrSLjAI5ewS9p5aMQgWRkZGRISsIskJAASLTjZTttR/T2xzNPWuttTdH446ebE0nCOPcocaFwLQXeyEwrpC5TOf22IbN3s0p5zHdQOez5a19oyZ/6H6Y3v3Mb8Lmki5p1/tvhBkYz0ja8xeysT5BG5aWljRhObsFcl9J7+/scH24LZtzelpSdxAvkt6fISSSOJFtdiclZrdmeSryRHdq0uLuzZ2+g6cGs7qXS7K5/w1bBtguPYYkJSxy2Cf04ju/nyPJTtpeoN1HzPwHmPjn+bn9uW/BiBowQoSREpIpEi0RZWFgEl/CRMkPSknHJJWQQYsIBiUSYgEmUhYKgtwe2pNIVWSlVopgDPDb7B86AyMxGlQURUowCImWSBFRUEGwKBt7RuSmzrUunc6bere65W233fW222X9f1W7m/+8TvvOfSSZZEuyjIoMkkVOTBhwJkAegvz5vMvtznYIXQXU/rpb6oF71rwqDCwIIdA0ivKYzo7hL0W6YDuk3yvGoizEI5TEe5IvChsK0c6d1wAjDCTBgG3tSBAyqctrVDOzhi33naJaCyWT+5I1bucUvd09MB6MxDng32/vP9tJzsm8Ty/CszASoUAYhAdVhUWhukYYukWY0nS37c6kBgz+51ysE5lhHGACHug9X3T/VaAM7iMITJKIWsrp95ITFyTbWWA4EZ4APTOBssvpvjwO6OJJF+O0i0xOvUz/w23hfV/dv9B7IseW7QeKgvSRptLYqX859fvp0ruQiuYNlTSDFofckc18BCL6XC55LWAZdpGMi646+Jff627G6+/YuhIjkViL0iiPxilsmhz//81V3nvfe/9XYXpO07SxNIyBZWaNsdTWmp6EgxxDz2mxpUg+WkPCBLGSeEMbK1asWLFiRRqcF/KECxg4HfPu+fWBIPAG5hlymMgDbPXxJYAPT+/e/9/smSSTk1Nue73nt07RLBL1NRojEcIgDMowTCcFxAwIxNsmQLQmJ8bN79P76NNv6y/j+eawuV+AslzGZCdt4xSHhWB2ApJ4aFnttsLfW6+ul4oy4W1ms2E/O0AfHJIPgrAKSkdFnaJWV40cPqypSS1LAXaRQNIESg5RCfTxtj87vV8J0A6yIHRADDtgdzcD/7+lvvS9vTtu+srxuDSl7f+dMH2nV9hY4/KMldXqaa1jr3VsadKa0iWllgZ46QXwHJ4A9mlYcDoKIKUhFIQbJQEABsL4/y3f2dm0em8S4D7oMhLhqlClK/fbcHaoM7Td35qw6A+Sg85BdmMxGiNxGo3EmFisQ0j8/6Z+Us86rTmdbhalsADSCkTyfTN6Hj+N9e1fEv3Z0suMpO+V5L/phQUGLk4QyglAJGHh+eZE/HOt6QnnwoV1kO8WM6hxE26MAScc4QD6QM9/6rLrl2wzsoGsyeS9kJlthWyph8vA9uPmtHu6yb/oS1+yLX/ZYKSBARum2DMZIzPEgRRZeLI2kEx/D3IqteyuzWxYk8psKe20t9L6rR1ux2UMOD1gXnCg/2+tzFYt9oYAhUlcJDnzp5ZqOtS9hD0h7O7QQIBJEaq8qCGBYRgKAB6yBAIlTq6Tx6gihDmjz5FQR5he/NP4CxwQVGAwMBiYj0CbTMN6qYDKBaEQxkB+kMAeVQQG+H5D1HdHlUHDKiJSwkeck+x863Nk00yvYWdZQniEYIwxrjBCCFWowuSr17XM+Z+hiuUJoh0LkOD0p1vvb6+O0bEWpc+KiBzuBN9xOP9saP5fzv8OjX0R6wvB/CIJTBeb+X+/7B0zmrxtb06bZBbdIxoMKghc7gWdfvVUNVshlkTLrPuiXdnJ5GAY0J9x3n3+ygN467c3Ae9fKr4FAfQBXK8eBj+MLIhs2XDkyIXIUwSjGB2ixxM4xsxDLFiAY9EHiGXLMFamFZI27TDpsA/JgSJMjvJD8lQQJi/akLwVhclPcUj+zGEK9XFIS1bCtGo76Yd/uXYxKwQewAAMjGSpEGnSIBBAVyMfRODWDZsrygEi/Wv0BuC6f43VBlQG1OgrgOZAva0WoJeUm2qA0ZKmGgswU2ay1wBrZTUmM7BTrrdVgNzLTYYaEMSst+lBsRa9HQpCW/R1NhDJEXuAGmzm6f11nSrTW0ETZ+ptNaClc6W2MtDauXJ9Begi4AF+an1ooADOVioFFAhWSthXzgZsY+UAAXbyzguOzofkAJwOCdlQwE+pYPpMGwsTe/6wjkdQBdwtlGIoQBBmiLRYKhJJmlJIoUcpVNrizJx0xnPLcVONDRDIRdEf2ysDUlazVVQVD6CPCANwMBEgJIwJdnhlggSZAFEylGkzZIMIseXRk4swYkHhp13/Oqcb/53aJx8GI7ixn9DROsAAYqKv8A67MmIBCEWSENpYwEGCDW7I7N6jkB1/OyHb/2pD4Ogz6PFrNAsccLgfGANMTNH0oHMnfhI7VATErHpIRGCBmwxF6nQZMmfDiQc/IUKdES7aVbekypALWeFnSsikty7S6kQVe/fZvqs9FzItHBw36cm0mVmcH5p6R7o3M+V/84AKo1YEzh9HXBwHiu+vPH8Sqbj/cc88g9DR+o0Ht2w9evUbMGTYIyNGPbGwH3765bc/dvz17/kPGgOsDdgQsDlgW8DOgD0B+wMOBRwNOBFwOuBcwMWAKwHXA24F3A14EPA44FnI0rZbyOyXJmSVqzdkJk9OyGyfwJC5PJdC5rluh/Rk4wBZDB3qDJAhggfI9CzOqucYVIk4W1fN5CuKx+XD0LrLc0LU10mqV2V+X8tVes+RICP+KzXHg1CiSQWDCAvIB4ZXSObDVbBjyNfUHzY/kLF+KGIT4FjMFoU8WKTOhFrQvjcwa6ykzPG0Uub/4Vy0Bz0GYzSex0wsxLv4GGva1o4gVGhHfZItlGvNTj8ST2UL5Vqz0wtNpHPFSr25rbMngcYRKXRmp8SMtGJrlOaKlXqrG4om0rlipd7q5oMlM/lStdHS3tWbxOBJVMDqFtjvAHzGs+DJ4pOQxCUjRalLV4Yyl42c5CE/hShUZxSuaF3VLaUqQ7kqVqXq1ax20TWoUT3XjBb0Th+1FtuxIyhRxE70k9mF5bXNnf2R8anZheW1zZ29ohPTc4sr65u37dwzIS2nqKKuubOpOTOVtE7r7ni5v76j6WK9O17ur28/2XKzP10fL+9fv0uN3rTtOZCmp0hIjsMnxO/Xj8bvJiF+NKZC5nh9LMRG4Rbyuj0upN5XtK9Ffb+K8fXuGbUMZ26IVIN7W9X2CnFwYRyOXH1j0ocyodKVEdw7P9CcOLQctIQecpCud4miq1DedZ5Ltttt6lXXEXIIvZ5/zJLOKo9iu5EzR4Z/Pp6J2w7KEIaeeRVjuCUT12VApcuka3dtQOy4oqDTds1PqM85+mQUknywq/vUpM5sLVOvw8Tf7Rrpk95JUJKHy6NPr25TYUToM7Yc2kF8er2i5K6L0psKSLv7P6akuQAsHOVO0jYVb4T1Y3vXfW3ulLXgbhc4DE8SO/WOy/Ay9jbKdTk929psPOTCubZH/kKUsl3k1dvQ94Q9BaV2ITV2SXjenkQtBCsWYdSt7eK7QvQZj5hY73EWhEqpVoptXW3xOBNLTr0fnKJa/8sbf9nZMRwQQ2+cIfTNmragZiZO5C0SUfGI+Y4aAUNfJpJSwnSWLdjpvYOpxDXuja0cU18WbwM7HDwp9/Gyfk4TlrzLcUf2Tpg1ZJeHbvitWe0Yq8VzjBRvr4ei5sqZSGxf2qPrhoLs1Llv8hzmwA7cc9W2M0YVqWbHP0cYjORCB/iUeSR4zUf2ST88UZZ3vMYu1rTJRGxrm5exi4CPE8MweLVM/X3hyt9hpIXP8GEhjLf0GbYqIsZ638egr+niWMeamx+/ea+8OT9zYN5f4RB2u/N3n795Tg++UB4t+ye3q2t83Pz8kyUY6Nv81hI7ubW90oryRB9IXmir7k193aNGxxATNV6Ety384/lYtJQqAYUpL7SA1WRNgNoE03RLYbLFzF7YBa19SqTYT8m+AxV4wsmhP/eIzd295MiG6JS6VKmOUgNyAZeqE111X/7NN0SEHSaeqf0UpU9+JctvH0Ww7yrs2142rTppaSVLJfYtLaO6oOScgTfYZ1+RgMnXbHDUual7WZJ9R025YJr2r3xrjkWrM2KahQhmKdefKa2nTIvgVqd5Z5emnYlXhdAtBG6v4DU7GrVJSNKwhaRjTlmT/jdbs3V6y6Y4L/LELI0dSLoN7Kt3iaVLbcJaKzxfnVBteKiAh807yxlt9ukFAlaF8bsCMjG0BjBQt6GdbITt7DAQRgwQZcXtZl22jZo2HzxsafzK/tjMssnbJWZGTTetZMgmEG3nHM3Uez/u+nv0HEtNpGX93Vyhl1DT+NOSaEqyCJilz9vWqNEqNGr+DhMRn6MqpTdT1jyv9uGSs31ZPreH0auntzswgv/9Ss6w757S6XNHT+SJFncCp/2Ut63WtD+Y8F0WPmp0/1Vd8kjDK5NI8s90Qq/aL5MMmlpRrcW6My0N83pzGsmWudJYI5RUGQMVz5G+QvkGKnkLvn6qdKUvWlrPgs30PtZ2rlJfm8jXkulz5dWc0cT7/NmjkpwbjH+puBOsAdf2FdcyfS7eXEqlQPgLZnoy7mrpkum73VLVNvin8+sdCLIGDTPM1C7gH5C75v6nT6yJM+Nw3pXvyTdDHVW4jZy4eZ7T8bElpJo2NVN2KG7rQWl/Uka6Nb4R2yns7nMouxl8J8IhAGQodZ8SCwPKWX1yx0bKm7Ck/P31AgC4avo5QlvFRUraKc3KlKtW0ywfuA1ye9aA5l4aQZNWbbk/x4O0n+mAdIKuFu6BJ4rQ97yuefP9doTqR+/TaeYsWbP5dUcXXV0cOOzS1jFnbiQJUqQrUKJCjQZN2nTo1pehaesxm23jkOm8lospeDniWIkkdrqhBhmsROK6ltIuZcpTXaQm/Qs+QUNou3saNWlNG8ZwDTJYWWT1mY5GOkHXK88U+p7XY3e+JJDodJo5S9ZsBpc22j3whj5zY18JE4Znkq5AiQo1GjRp05FujPRBhqatx2y2jWfTa7lI4RkX/NeY+CiY1R9isCwQRGqp402YRU7kgpCMoAxCCPUgvTCHwTt9A8cULOB5h30tvt9TYeMNJaCfC1y2SHzgAabCGmsccCOEcz9D8eiFNNLPR9bYZi0PCY/Ik1ifndMaPhqEF8wguIv3qOEQr497G69yONjKB4bdbT3VMaxaV8EI4RqhW8idf3V3bGCK/tnx8D9DUzXEOc2rBOBidmbhqc4GI8xr0/NQ7GWcITKrxms24D5M/17juC+wqT2CSLs0OEQho2kcVh9jd8q8cEJYYQUhggEWuEmSIkOWIiVqtOjQpe8AS1YOceDIiStPPq7KGAMiISbEjFgQD0qIWXi0+6ck7oyr0uTCoYObLjJ9FFw4oySZSwrHTwvhZlrGvIlFE8sm1k2cmrg08WjkGfAJZKSBdylYdyk4LwX5UsKj1SSd3tHtM/3m4dCKRqcv9HsKQ6GvtPuKHQY4sMDBPGARsAxYB1wCV3GMAThGAo4xAceYgWMswDGeOEaJA4IIK7LUaTBgBRECD5B+7mtlU3YIezSzaGzJ1uxSRTiVRgKcXR0jzMqcRLbE6LNt1Q+hshPbf0/OqQe3nhAE7Ljz4jd3wDq3wgPVyedWIvYCSHO4jJEictniG/Fs0kEMW2IpVRTzSO+kvH8VV0bWbdmQ4b6zc77it4d+xzsZqZ8m+vlZmuc+MpmjT+UO5bCqd5jPeNfZP5z85epj5RuE1VMvWh9zn/+I5vNMlDyxw1GK6BcHHHDAPUGRzO+AJvhIZ40UEuEQlDTOwAI7XT2PbCwCDMWK62KAIR2gL2gPTp+YY2NAhWfsZ9/UeObgz6f9PmUOB6YpkTeU9HysCnEphZ6SErXXuxkZWgnC5n9MOHs406oa3aM8Ervk5adSq+xyl3KBpenkQ/WBsvVVi6ZeCz8Cj/OklfLccmHDtuSeMJFvvGqTT4olnvVs2WYMiwbE6X4uNdltRqFEfylOOMtL3ogMuXasWKxFTrw/W2WUGdZoY7CvyvqtAZPB8ivlWnW59Bddi77IPmzl9lT9XI3TeET1FTr0JftlI9kQPV4maHerPl9ukrNW/uf6SPlOjbm+WZs5966VdT8zBYaaZWipT2ad6DuZpb731+4Pf4M1flVU+tOLBrnh2brDJ2zfP7JwyPXGPp1foqPSvvOrMrd5AnNhXDp9ZRx/TAxMvfUyBi1fJC5m6yp0aYumMkwdyyrsRPE01uFMGUnMR9eFFWFoxzAN8ov8HPnqHCYPNg8RwoTAUzimKfE0BmB4Vh7PyeD5zOIFTMHwEo6X5fA6hTfk8aYC3lLCCQPvKOJdJq7t4cY+bvVx7wBPd3hP+yHe4Ahv7eO9E3x0jC+c4kvH+MoZ/tDz25zxY70wqAEXVNi59cxudcNW5oZXPuCOjCx2FLoq7M8cahOxlnggkrW4HKsSr0hLvCZ1pshmK2RgwUA5OMEt6miP7LPDEYrqEd6h9/FBn+IzaWcIB1C1g78gh3yrjn/QuiFj4JA7MvaQsQf7QA3ES7xll2UUZZcgVVeGd2ajp8xuzrJ5ysmzdo0Z8fAGLfNntCzl1TMun8XuLLuN/xrBTfqa/sMv+Cf+hX/jP/gv/gfFhANc4QWf8Dv+wE/8lf33aEKIcF5VEIDOjXAtE4d/L+NDqj9/e4r9v7T3OCh/Krp1NHfR/2Opq5h+fxOsQVxYCgCwc5J+3R+js/lmj5fKCDdB4vZTpcuYNScIRsXm4PcmUoccqpoXiDFtQXyZEdMJ/vH5sTBCKO6kKjXqNGjWqsNl192SLE2GLDly5StWrlq9Rq3aPdRr0Igxz02ZNWfBmk0HGOH5iQUxOYXn6IPfM/DkaQE8gI7fnHliXvtIAoYhoYVr1yNeolS3FSpVqRZNs/s60fUbNuqpCTNcfOwgjl9YkcoPg5EiRYBrlECUqYJRrwUDbbqw042O4rUlfN56T8CqVVN45n6b9e/uiyFQGBKFxmBmZefk5oUn09l8qB8E7M8Sy3i8MlCAMhwsUFAh8PqVMfTCjv1ZafuSwfpE38+2245nikaETJAkTZZCR8o/hrN/8t+rj+x3gX/4c1w8THCgENxkoEf6R6UXS9VED9xKvL83hyDGvOsjEEI4Jrj10nKiyKVaOS6mx0ZD6AMmxH9ceoy9D9M5n6FP+6R8UogP+ByfnkyBFFv9epxEuipZFhJkfISI/7C0uBd0bXhHbEsW4joJMtwLmJq/G5P5WgdvwZvdLIA6z/Aa9jBVoWuP5TupU17zIwg8y9Qu2wvaitJyeGYiBIp1eYi+qRDkN7iRsrbY0JJVRv0OeW2FHd07O+AGAOnHoLt20P9wAOtwcIrtiq/J6IUzxHZMOyRILyfvwuw8z0N2SlHIxtnFfEfakRbq/OFVPuNm5Rk7zx5x0kQEIM3zZAeavPYP2T8o5BQQWI+Iw5HwGIaPjXqODQBqANZ8h1rQYeXvCfn/AOrtV3jAUg8SQCy8QwKmRAJwAAeYFALAfs9BAJPC20zA3WIRUYbBCCvRkk93duZQzueGIxwOx4hjx4nVtbpdVc1C5Ok9Ldza7dyu7dGn+1xH9/XO6qKu6oZub3qP9GhP9q8p76c+ThWiilIlqYpUFao2VZdqDD0HjYGWUk9Sz4i4iDwqQhERFZEX8YnFRB8UfURUQFRIVFbUPNYvNhg+8hXbfqbwfzaqthqu2TpUx+tsfVO7f///7vw7N8/+7e5udsFcTaVQD+ZMOyx9tVekDVad39HWpoQ6SuWl2qNKUBWoylQtyiXZp+GZ/TAHMXoo9Gf9aq6hGquVNO9MfV07+vQ08PU/zKr8YYv39Pdwd/f5PtBjPdoD3d1V7bexnYVYhZerVi0a1KtlY2ZQQICJbBq6pir3Obble84araSbtTSqF+UgQLUW/1n8W5Re3LsouMizSF4kLvy28GLh6atQLnWmC63lFQ+70+1udJ0rfMKedbT88kt+zo/xFQQdzsYEJSGRszvrF9iqtrArCX88UuVEghEmmGGBNZL8eebAiYwLNx4UvPjwE7CHoL2ECKMSIUqMOAlsex2y9uNbGw09N02U+1gGDjJkxJgJ4hWL2HFkXY5qw5Yde/wbuZQTunHnwZMXEn7A+vEXINDgO1oDcE6Iw47Pr0jA3k4MXrjQ4QPQnJ0fgVpHRQxJzv5Ac3VStEwAHCPY6WECzV2GU2IWUJDq7eE4wmN1GDD8mwTNH4AmJoIXH2062CFqYMSKuOP/SI+T4Kwb4t30n0S3XAdqt1dwr/eaH8DM07NMeSCQ2fJKC9LXSztoq3S4/36Oqs3Mj935Gv0upUMQb30agaf/YMSfUt18cs52GT+lDcrbRzLP/3Vxp2RpC1ElHokLm4wgWCm0JLBdNy0ZsAK/i1HkT2OcAk6XU6riSu7xzWdXUykfDvni8ie7e5JdXO1dPUVU4HheMRbZknPiiI1A4LsSbFD+lg+Q1dLE2mKWXYoLsDBTtOsLmTPLJfHKiQdmASaFiZ7bO8n/SrKUjv2TYqCWrHIkxdrHiBe+/sRacmAKCs8rUPKVU1qgsiCq/2tbWwqYmmJV5TxACO0zxFw4zZJVl804+UwTnzhR2n9/34466vcU+bWnV5LfRLeoEdzduGDiCCw7Ji4oQY3NCOZXoFSNjRkIvTuTzTdS+zRZypmxNUDNqXku/wkxpGO9vasRWWkyPZ6OUVsW1jRc1kiBTHXkjCyHYQqLnYzCE6bFb1h5l6MZAfmUl+TOQ7KacMsT9kvJkaYYfBAw7wzy0Jj3P+YWu8VVTONlFRUFVNYp/D5hvKUBowLsAp+QxjYZa0cavwmvBEPui0WAJXeshX9CSorfWGRC+ZqDomrJNUt4+s6r+JrEsyx8248HMCde+9O3z1OiJmD3tVBRGt6rpXkWqQUWIxpTYB5q4ZNgVJA2DOTeseo4k+Jul79B5LgxUytRfhqyB1jMo1elkQXOaUAs4hOmWoK3bgVsm5BInI6U0svvABtbFSz0zlmygCnzFpgzshqQSO23tbINfGGG8vW/Ndjyr83umdiyjAq7aemg0ldQERmoihzURAHqogQNUYGmqAFX1MGBmBlNYD5vSlWfvnNDR3rLDrmuT5/YVAn+bNvfFAZ/79MetlgI28avxdOmOlSX8qmA6lEhFVEx3SHQp2iOPtGqGCzsEEZlKvXsEKbmABk1jDrb75EhgDkimLO8Z+2z9l0mloMRfpar+VEBWSsOZ1Wm9alfjRYaY9fUvp+fALe0HpliCy1S5Dmk0GPee21R+QUAuLxne3WSuJ33yAzoMdc9S1xouX6U5uhO9C0XeCYpGsNWLlGZBJ9Dp2zCL5Ddj8vf5uYKGb6QKltpYVwkuH70Mp+6AlGhCSnhI8JZu2aFyQybdRkY0JdVNcA6jY6XSfFQDtrg122k7e7Kf7LD3VZ+srxbxdBaizpR/MOmzZqjCuYoS+0Nnz7vhzGtjJx5pWNBKotgqbX5Hm+fDaDINst7YtQ5O5nkBUk4ZsJsWBNVxQ8GYlh69r4YNkW2SHcFJE+4eXrkqPGX2PhBQyQjM8pav/e+aWtR31NnAAXCCCaO7yNDsJflx+u98Q69qdDnDDrFxZMp5ZeGxz0CDuC8QCeRYpbuiZO3yPPkFUtjhK+5SngLpzB0HpT92ib9lbyJjj52dZBYk+l/9q5v5NXiO7qaD6f5/T4HVyGs8CTZtI7SPuzhdTnLCq+Bgh0HZLpIUIFmKXt9NjPbjJttXhcMvw862+Pdeomq9zygMzmdfxVzABt7TAu7e297olCpaNSRrnbFqvFIdH3JtRW1JW9JaD7flJycnxpR3IUjsY7ZbNXc7n+HCgomOReF+3y0XOjh8VCZGjrMit88NbVHMucSY0fDU4w4A5ZVHPEQRbsEHPMQxTWwHCc8RMkuAac81JhGE8BSkjNAlE0JOAdE+R5AXACiYkrAJaBiWR4v41XMjapdAq55iOoaWJ4bHqJml4BbHpK2Trw0OmaibkrAPSDpI4N4AETDlIBHQIeOcQ/t4Mnkt8kN5/Cn7BZnDrc39grz11j7tFDCUolWM+hw5LWvwxtfR7bIvuFd/g3tleigFB1/7bp88nX57Ovyxdflax7RTYnuStED2vX46evxy9fjt6/HnzyirxL9lI70x5aFx4bZArM5shn8R/y38Xw+LgoQqOzKx3Zv9LOI6QN9Hkx9APP9A7rHBp1zg4X+eCeH01y2O144u8MfbHesxMWz5EdVke71rdIz3Fv0bmxQrQsaW3w+XCUQdXrjiDlyL9X6Nnsq+V16xp/u9R7wWkZhEAwWz4w6qmTvqNT5UZa90cFb3XTvGFSezuf66BSJQYe0+eM2MTPVPsyHmdd9mxRfeW5l54bf8+/X5CtJVLeMivWv9XmHZutRB4utVI/sifGEbNLKddXdGl7En5CK3xoHsQb3XuOGJGnwV4WAp3g+VU1kjsDgbFp/OdxNGS0iU+Y9AbTx/7P5kXl3HwLbZ0bhk2hVoy+9oZ+mojOn1sAguYcYo/fG1sDlrRbgA3vcFfruFJHTz6Ygz429wd0Gfr1fJAf+ZczX0qze2qSR0UOE0b+hiFyQqrMbp6mySDUAcjDxAAsA0Y93n7Ln69sUmIN9dJO4Gy5qsZUJ9nib9/QMoI3ozYHLSKfOlDclB3UuungCMslnRjlzJ6s/VowSRSefGCSCQ/EeffN8H57CK0PVejOkuxqP9Laq5mmSBABXuOmkteGpu2vl+/X7wbn+1sW9CWHfaL8P9V6vbSjtZks7qbuR0dh8OzYawylh6S0yGNS6wUnTYe34MM0p6hBaDUogKNiBenJ4AwZmMrsp4U3YT51c6xhrfZOeCdKZUS2QE0UbJEVSQR7fUus8uYfQr3gswsXNDJSikUhWrLFhYaLY2lmAGXo9RKiCdFSdQvEkhLmOongizxAhJuN7KZrgmaSRd7iLFrkEv4k+6in/g6kstBitKaggnbKAQs1jb04XxrTkCUf52vcYlArNL5oVTj2xMxTjRL/EpYXbZzemTvsofViosnnIY2bDnVp/E7KPH5qSDii3sFFGMjdnKlxWNSEJXuZWs9fm3RZcj1V2mv40ubsVo2155tbAK3371JBMgDueFiO+LY7FxwoZDJ5DOQ/9HEca9eosw1r9UR0Q05noOrHVa0dcOxmopOPNprhAg2NY4803QVUd6zDGAuSCiXXJoYK/BPukvkxnRSwNGWWoUulHBORQLkDhhu8eMDoaCkHxxeeUJi3oStUolr2VigJpSfas2ja4saG9o/QCcaY8IHdvgptK/Kmx/BmaG1ZGue6AzZR+sS1/s6RPSWBRnV5wswkru0cZi3QNMjwNxF/cx3NQCwV0ZHk93WtxExo4Y9DoQn+jp4W6/pk2654t2kY1Vo/ipzzbIC8O2LS40KwbbL56+FAKeKh22n6j02QTU1/b44xUz1FlPzMtqQ/wrf2cJp/q5gNKza2stRMtr+c9JVasI0OKJNykjf4Ii69FtVeXzef9mCUmfl4d8SRNxTM5WdkECWCKuW1uDTBePqAE+QJsIptC4BTOOK3x+zj3b3kzd+z28+I8pHJy6VycL7jsZ8qxeQCudj1sd8BtqnR9k0RCbZam6c3d0QZpDXcgEdIacMYNBlniJvnB1obmbNsGtOqnugKAqY+Y2e4jcRNzs0Q2qbonbT/5NARXykC08VZdaREL74uQqi7Wqm1MBjXJXwE3lz6/LOvnvo331xp/RYtnFEjanNBvXLM/379U6ewcmZ8l1Xla78YaeXL7QrQpbIYJPhuEmgye+G6U50LTQ5YLREbZc9RM/uk0zZveUCwUUaq6wSUgVQU6LKxhPaNhItvYExPQnsF63fa4YJHzN/rcwCjn4fobq30e6supWXPyxLf++y6u78hN0lA5sLZxbO6Rghrshc5jNIEg6B0ZBn43qR+qZDwU2e+j/YSMZy1nRTYDAQP1CTucQ3KeuQDeHRU/U6BfYUIEu/LkWtNw56dgnUjYp0EuVw3WpQ7tLhmCdz97rrB48L6eBv/yPjNDJ+dIphhKHz++qDk19hJylEHBoPeWNHolU5s8CaoEMryhQ3+FEmHfsPz9+dWIBkeABV2/7FrY8YGGNXPPcz0wv7tZHC328VimiA1S1cN3rnuC1uDtH0Htk6h2DJSPHz1oYU5KXXDX2xkuIedECdvlfGrC+O/tzAMU5Y4uX+Bz0OTVStZEykVpRvSb5KjXbQ8FXQ1R1k40OFiJylEC3BTWqKujkiqmDDxSpXkZYM0JJnHi8uUpvjM+9KycxMdla60Ae3RQSocLBg9dnu5Bn+OwIRS6xJ59f5eNsHtio8WLIKJjuJBcarhtbPMMefNmlJnFm9/7qEK4GfK9hdZiTcjlRjVZ8kFy2hIQIRVWAkMZDHYJyVB3CEB0hrVolw8edE8a+ibzXOrnvn5yuTOoXhsNPQXEpYMqqubSlF9Hn+nJ/Ye3kOqTftbQnwHCawiOhVdZgwJBNqI2bd65/ef71P7UGv4obZhHIr1qvQUbuZova6HiWdJXu9nD9Lf9pcH0D1xhckA73k1HZSwGOu10t6P+nqCw7Nm7e0UmzOoOdM35/DikRYnme0vfNPTS4/YbkgRYGOXxjLhG73U9sN90N/TRoH3Fy07a4AtPiFw9wBmprMGwBalXZ/6Iip5Y8fR+7eYbZsDoEBpL1Umv5w3CxUna+x3OcUgK7im03G+OhnBa8C53P3p3j52lE8N+8e63D04xVeKGGLE8fgAdsvhB4eSoZsmfaFPp73Db6e926Nnvbnve3bqkgvig0XNWoVmbe6+vZGCJRKRDAj8Ni6FQpDKySOWXuh58VvhLUFLKJ7eNKoJ6WYh1rCEEYpVQE7lfv15tLet9dYGHEHcxJ5UuVePiNf+Ni0uaVE0FaqgyN9l4dTk5L0CurSxzkZR90v3YIH89e1rnMOlUvG909ZyqKmNO/MgWkM7VyqxIktbSvKXDW367fZCYRL+dOihskWmeyjUsaB6jwY/1Y383bt+7a81WUnirZk8WnKc3hTzkL3IQP+p8ASh4lcxMT0Or7vWaoFQc0mE0WWuNJ8hDdlUR25A0xjf4oOq7RNQ8HWyFMdbJ+GcHCNnYCECqNFgwmBmD/7aRcGYoPestip2Bq+5Iqi7Y7rrHxRDjRunt0wpBP9VSFf7gtEMTtq1eVxijeQnbVPjSaWd7xX4N54eKn8uOkF6BKtrkLXe0raDNupTwhF2qORFOD1HB/yquEh16mCKSutAlsMaZM3UMxxBR61O+H/dxqqrfTCDbDkKbLUBmfBBcOMh93w4dBYt2QwN1kndbY0XjPTQUL3dcTDJokw3PtS9Lhz3caLk6pg5GS/0EQcwkCXxe7sx9bWYRqwVzSjs6qtfos32tTLWpMTZCP0HsrDA5OWHvsi1Y3uqA1dOc1HjHhCltQh1hqL9e8XrSRMnDSSlt1eRjm16WgtgF8alfOnkUEr2S5tS+UQm4Ksxrb/8RxFL7bQvi84qKDrt9YM9tREuOCdZnkIqyg+qJLmPmDNp+ipY72gTeJDiCCYxA7kOx87XFD7Bl3m3aWOOHISvHPoLs2GnOjnkZbnYaLETwDMUlDSElLae8IUjoTImTfNtpnJnnM6bwzrl9nMyu2psNtylKtGi4bP0osiOqmZ4ZxpxNOSrc3HuCQdsR8AjFTkUnGmz28kDnm3rHMvfMFfF/CsIz7uz0OqYaWyOcX3p6dobdjzKhsIprw5WWxcqVGZSG5Uf0INbtZOpseI8tPCfq2ZF3kRXXh9Ag5sl+JOOpMrT4b6xX9Ygmc2ua4hplHppeLRumH6wd+mHZ8MNf7p3gdLOqrIh0Vlx/3U55OOVMy+a8Q7kL4qXmBCyqNHSdaK+I7sE9CrKB861NnFa6nGigEw5/VGxkgFbOmiaMjtkii8QUz5XoM+OojRxnJfRLqMb5J0pHwMn/5Qsn5qyl+sgu+LXc1tS4JpXWGRlcJX7nlpayXT618tR/8/TNCJa/hsgP8/BtqbXqFt+P0u/n2HflpmrQjS7FNZfISEomgR4JgZSwYZPGMKF8+P1tPtHrcAipr6+H2O7moFImLWlYxw8I6T0KF6ylmdKhCtdYg5HoqSFTEsxbV0rR7I9tsaX7RMwWfhXXVpypuNJqw74EtZiHGLhAOhg4883IGhcJ8HX0OQ14k0/KTt/qIMtO1yW9Ckr1TUXQPSvbsyMraLOK4TWyWZVwu/OxSPY8hvJVqDxvWQb1ZadOzAR148/z8U1ye8DXXodNAeGKvi7wknBeg6He6W608POaz8sK0hSROPHBlsKMbJY8hkf9s24HsIBlRL8E9P1rNTAzVvnSPDRJoMnTBvBi6hfDee0Xs1xbORj+p/EJajkbKaEOq4PY35UZ/smQaDWfVYLr+LhE12xMSenDSMiuauJrliBDPMkZYVf1UsN4et7ro36rYcTxN7cglHMV4vX+wudJElhrH21+oe7OLAjo0cVben3xJrW4+PgLS2hRls9CS56VQqZxhmUKTdLMNDwgbfaTAKGnq3SSc/sAq6hDufD7kbsxLk/94lnT6Of8ZuuY8sEDiEZs4zdovK52WBP3AO32lbzoJXgVDQdiMY4sZiXGKrK9azJ3M48f9joOvLgu/QVoDrklzjZ/K4VAR5vpltTZpxE68qn2lxVDludltdEyq2vQPM2LpOyQy6UKzdM0mrmd0AcmFDzSKtObOHDv/RzyqnXtCrkvVmQszlGvnUzcqKR2FgK+LMhxnhTeEFcPDlrg7c1lPZHirm/Em8MmGxAVtg5CLh8h5O+xJjzG6aHxT7Yr3qgXftN7fqaAmwgHfDyrG1w/SVoApxSiCbLm6mscflamiDU5dKfboaYUZvTZ4vLywXc/eFTscnP0Wu6KiteS5SMVJZOaw+ax1MCDAflsGRJqIOibEEJBMQqeOf8kc7NkvpqekbWV5HiKCPDTp+k3qxCU/Zqz1ya5YYEGeVN11g+gjrGYTQ9o/xzTE5uHvqpTUyUWDq20qtqolUrQ8xJcSPQpwWdiG2Fqtz1yrUcrRM/gS6p8mQxRO7DOFd14bMo1orUHA86E7/KlJBgC8XzVY5948o8dofbZmi+nZSktSzoFYae4V8RDXLNNeb4s7tvq19etTC9o6h/hab0d2x49Yw84AzCGnuKTj/M4zJRnPnT2ETVwh5lG6XYErTgKnDEG4EAp9YJ5IF5iF9uA13USOKJFz/9HDDo1Sc8qRdYFsdMtusl4G9Gmrtbr1q/mbV0RnYdnyHWom/Yroa5nUaDrQ5RI4UdZz+2TL/Oc0skoNSQHb3wa2PpbztS9/kUQK9IMbqCb9j1WJm+NGwBvb0fS0ZrfNswao9/iimYo23rF5h4RtaW6hdon8NV4ikHw79NHkj5DG7Bwl0HsJy5tUz/fzSZDHGV0STrrpf21JuaoKxBESKbYWz0gA2LUQi1/4mp7TEWIdW00OtYccG1Vfaexf5BRFRvU7RcrPamit542d/bb9Ik4GOBpObL+/JwCRz5V1gpuqnpWLyzJfDkQdPB88nEhlLwMszAUxEVhoMBb54hoDTWStadceyHHGaLm5E5c1H3MyAQb2zFz9XAdjhzDn6ZD15Pbq2tUSsUozFDdpfNUjmzvY4af6N25WCxY9wnEZvCo6MF3THtBoKGOQdTDtDl1+pJbC7/mJiVI1Zn2Y3FGPKcOu9sv1v7W5DKJTN6OsI9HxGQc+6zMhPrtFy353xaqGLU8QDmYNbUWD2HTBLN1O7m5/upTxiHGNJminD7unkdSqEm8rXmALaF39HlsXVF/D1sJyc8PkVJ50zK//bShfQ/Ji8vgW7HT6tB6S5XcvoBi+qS3LZk0mca+MG1ydizsxA9H4QKvVquSRtzIMbioID9bp5XzgUDQdwgbwEkttjVLyDUDwef65j9M5NpkBaGGuaP18QZ5/KmaBw4ddC4U1OzreFFI2xXpjQ9q2miJDzkx7bnRgEKKgIcYqMVfpA1nSUKikBDnjwIPJXhAw8il4FfMh5+Qz5/JQD4DIKTuptUadoPNyqNlRwMYZPrDrx6x4Wl57gWBBAwccPKIHIb6aRchmVV1N1oiFkv59cvozqMJoyC+eWzY3y14JyF1cRIiPrtkNV6nZRFhrixSeEdiPCd9dKpZervdu9GP7RSAXjBMhVGTBUmUJewOh1cLx+EtNoFRjPYQTds9w2NUNpynThDZVGUtRh51jfmbUJjCiB8fqYzZhchkj6/CBA8CuzRaOfzKXcYtRJOtw1fhTzlz5LJy37estq3QYzmAYxZfvVp3gmfxxlbY4yApOrCZHTTNyBKCwQvvzdBbwWYD+HaNdJISc+dpaSl31XrTSdXDwnM+TZszd4xo+45MO1S/bOw4evvAb/DKthvCnM6N3lM1VLkij7WXB/1HPYG3RqLvL5Kki+Og74ebjGy90/Be+aHxCrmjCbVXE5aN9Z8M/kkIE8ux7hLYZ0ZapwMVJWQyKjPEYYWRc6KKsox+jRI3oDV2UxXgp7NzFZS9757cN4qxU+VaFIVWAHspSkXARogYNGumIrwoelZUakrrzVOnDRpLxshq96u3r4pcxzRsFYwjNbsqnF3GMISlssqgPAo8l+M6k0VFWERyG4bDtWGEcoSFKs5KtIhk1gtGLFvXrKE4WvWDJMTl4gB6nDgukK5/gEi6rF/FcXFb+CyEleZrQ6IEa5akpt4LImpkID3BeixBxVkRl6vEf26XM1LqaqZPeqqxj4moFBSWqZ6KyPJkWbAcqcJ3F2l60QrZfpxGibFT0yJz8SI+c9UqY3U9E5tQnmwjv0VVvfbnh8U1ck1qMdTkh7OeozRZ6HPvVpkPEo8b1lbUVMHzy35psYVcrhnh8ssXGbSGNEZ59ufgGPeE6LJ7jPDkFEb0rWAuz/edSW57J+AbMxvYI5lE/Wf9yHjB0m8p+gvedKZxueRLKuaKzxV9TMlXjYfPw6u+sRZZBoznRY9Q/6a5prOnUP9SrZ23DFiLvkmoOtO0aviGiquqM8SbvnGsFiRk7TdeaPXf/66Qo71TNKg5lN1dvQjWIqyo+dT8Wz4tut2YrdDW/Mikz7znGuZebR8Vj+/1vQQ8FxWsTymiqSfLeWhG6pB8ftvPK/rr+RU+0fsfS1wbrYcSXFErgfQj1i3arxfm1hiVFesMxxzj160Pmwx+ckyv0Soq12mOadpPTTvRLbGnOZWlGBazFMOujDvdEt4cd45rL8Uz2SY82w471xzzZO/ZuYE1/9tREfi93vc5Gfxce6o2UJacDiukcXSILIEFyRPHWZi7WspRR9MFbn3ZkYyqUvK4mo7szO4oabf0nXwqH1qS2sM3w3nMuPz0trauTnJxLJsO1xJ3c2iT9ZZjVFPJYUJNKW2xNClck67KFezwgosFxIIQE66Us9JiPplZUnSS0FbKn9PvEeFaHtMUR6eboDwW3MRmI0tk9OoYXg8nU//NvcwRhz3FvBVx46dbib8M3RpxRT54YvHOtzWHkCOlzYly4yrb3k7esldkblR3nOHX5y1hm0rE8+6m836t4+0NTBOKq4pvFrHh9dm5FhwXw/JSv9yjS/jiQp5/767U0ZN12q2AzF6l6qxLClMf9nR+OfFidc9Jkb3hvL5uhXjHpC4NvZe1U7pyoO5txsgnKUqaaEFaJv8btgE9IzGa8Bn0Eiw7L64pmwFtZGhLMkhMFR++zX8ZPhsKWXgsTL1JsNas6zGOfB49P9acZeQutpavpRkM62kt5dxFYxbMTC3Q8BzFGPu6pYg2U21aTtPpltJqTLQZcK1rFsKUzS9NpNJMiTx+gimLBtfz2KVxDHppHI+doId9mh5bQGdq4Onpmlg6PVZLyowtoNE1sRkZmlgaPbYgjXlg7rpdVR/qnLOOyF5VFluWcowD2LOacuKlqoE1ib3tvNF+HP+mnVUU8DLhhcJDiw3vs+cDln54p6COyk4j8cIEJagFUZkxLYNRgmfnx7VkM2Ka6UUGIttzel1Ih2Z5fjOFMNitO+zZTTysZQoPa77pmnUUzTzMpDNXmbG4zaEZpytq+uapNH3LNVfjImDGaUpU0iU/BvwfzYwQ4yusDRUpsuCP4QLCLuB0oNeqncGqi2cIJgNhRM1OqudWagqfGeD7BdcoKEt6eisK1ZyeXlluqf49JagtqZZuzBPUJvMLG9Wh0rScIYVAYKGyq8NW3Q2e3bZv1U9PSMXpCj9mZO82PsmFH5ivh4ZSdFS6JX7aSem+Z5Sw/OC35dzyvxcuPj6McnuBtGeddOT1TftqSr5HLkQc+Ul8DVwDNQSbPNBXEB13v+vz3N91f3W/9v3/UsdfuibZ9fKaTk2/kOw9ajefF15vwwkIrk6o3xOvxqUXZwjt+ONiyhuthoGW27G3Nipj39kYaOT/4Y81+DpAoM2dPp/SXEifLC2tXSpJvlbIoGtg9qxS9lJb5YU0K2XNK4tTGZ/NTCimUGL0bFZFfDZnMZZqiuGTE3MzGoct45FUcedD5lLRRn/HDfPuzjd8ZzZkfyxOLcr/nN947NffcpnX0yHe9DBf9xCimmQqBypHPyUw9OGu1M6YU14sGBmV6bVtSIUC1egpSl8HCLS7E9/5rl3Q/ruSu6L999TGLz7zXsfJ9ffqzgvqB0nXGzVt5Jdr+05yLClUp8MX932wnAcQaOkrb01cTKK83B3YfQ0ItOsrt9dL4sTXrh7K5jfSziNbej/0Xt3QACVnjoqe377wxHu07UVmd4P4qHfxtVPy5XKJA5VTOp1dNIi+0VLXTr5lGVzg6SQWiCD67R/M5Et+RFkH0HN4oYgOBBr9zIc112GOv93Lhd3euM5gYZ1otq8RjaaTqU3lrBXzNU5iCYeujyYT9fE8XqKZFxt+7MLO97m372lew9fCX1O6Eo6ivoypWNpcrgUItB7+8KCNqJvHRvZXBuMa/iVRnx9Mj3p7gVycUYTdd+02qLcNhus5Tz+5Xw+XXY2WTa0fUzjNtzzy7e185HtwW+V0zOuoat9iyyO/zt7Hfgvbin1HH4K6VO+Y+qc4Os0kp7Q/406XT3fmnbKBSY6mcJJjHMDf6RYuJ5Kqf6Pkb73M6GhgHtFXMI912C+TWvOWNDmNSSJBXCk1M65cJG3E5GiQsoD1t64pNqqc73eFp/5i5i9r1mfRpxsbayvUTNRU2kbmiihX3JubBt9su3/0bnzaK5eVVBVeDydX90nqksX8BAORFl8qznYkKmFIsn8VPlosofdmlkaZo89JmksZ3SoVd6Kzcptc1XI1u6uJdUh1PSuhTCp0JCnE1XHZ1DgVHp0glNM60jShLbFbOXXmzF6VhjfeY9pLr2X1hjbjyrPFemRT9nUhqdLA6YDyFg634LPrA94GCOSrAIH81kpIhOD4xntRqksTTVcplfarlJEm2aWW967MOmNb1YrmRKGoJVGtwLSq3oMN/Sew78JzkVsb1bDtjTd4Pr235yriTIDzn0f8p//cdz76hk/c59cpQRvnA27Cg23BtsA6+Plglw26CILVpUV9ev/Z1Py74IyyjM8ezY8+WxI2vt3y3nvCJZMx12JiSibfF8xcYizHT+A+7+Jc+SMpCbr9dTeoQjzxi6wIYHjwNVHs2qc0SVe5T7mAjDcigeHB17N6gHjiV6ICpR1dS7Uy78ZIT9XsIcZm3s68TY0qnSlAEr/wS6V3Kh5g4ULHiuI1kFRlH65Qha9jqVk97ZotlH1Hpa+tqSaoIh5Gxe6RKNX2/JVMQ95MSkU+ub/gj4yARqTfr4mp6gheSvb/P8wpOG0wJoax6KJINtPJ35Fx1zx1UG40HxSkcdxbTwFEeKCXxpznlZUuSSsnMu617sqjxphmM1WCl4fRUf/i3g70pqPkYXhhRRarImZMnp7VhdPEsDOSRZTzzjxuV61hgZTbfDHXMU26YU22km44prdym4sOkKvKaePOivO4hFwGPR+emVvFYtsihrjJ/IghlrWaRS6Et1Lu2SeWpPqSaWYhYRcgQjWpNo0xzykrWpLbpyh3Hbty6BinwpwlxImDvwEH/MTxx4o4GCuyUDlm6Jg8XRRY/YK4c4hztSa5R/Jad9K6QFt3UmYZxV+vUX4AEqR0KorqMgSGfmkqo0o9ny0wkPbHunaPaOoQ2WJsrbsg2gceWUFRFuHpX52uGT9do8b2FRR0o5X0j8GzRuzwfH25oear8eUajSJ4K+mebWJZWlI2z0tjuTvW48zME001J8mlyZYAW7KJRyiyhfEy+DCBD5xRES/ITqzkFepmGEb9ktw2Rb7r2JNDx9i9qFYS8s1fAf/3+3PVz7zjDIjyEpF7WGqU7k/WFGJnKm/tDh2IyCuThaXl9xfBxc43ptUDWdUuKeYlIZQ1Pb0NhWpJTzfHQC6SXpwbXh4P/+vwDOFTfyqdqXwxIDrFlpbaaUHG7q9nG1uLmi4yNMhKPjnWN3n+SZzqyYdpXIHHSPscGYyV7MqKVUVyfpr4TFGDujdFW4SZLr2zO2wM1WyrIASiOu77eIXk4d7QAWjepZywtBKHKoodvEtKC7xIcunX4h9VlLZ6HbVR+QkN7Lvt09vK6toXlPunWXcbghsm0f6pbUVNjYCBsm/rtieHj4ssNTSxqJYmtCSMy4NlCRMVU0vnqukgg0/IYhifjlufSnulCzQLeBcIs+skRzrrYJzNPJF+eGFjPLOVKsKIgh79HuMS8/uUOAgrtNB4ZtiEPL0Q3kq8Z5s4JC0tmWUUullOAYTZXbxmOqvYtCK3TpHGGlCABlTbQm2TvCgA7fyOIAglstJ5lqJf35JqZ2q7wosblVFc4IH2RafWJGabOB+SOZOAhcVEQyT6RKmfJmAcb+SnlbDomTVludOpBfoFQmVBRjN3DxbFnFFCM0iycEpjdDStoRgq8jMETxKLROgSJo9Ub1Uuogstx8h2A7GdtYvAirIx6sAUoipk/bFKaD3d9d74SIFMqucabwjizTlnjncqPj+SxUq0yVdupQwQ01I7zMiDTJusM0VXnLpgeXH3cjassIEHSageUMXwAndJG4k//va7QbscyiaNhvaQLgexV5+z/iDvBl4kzfnVEvycCXOBx0g73spk3xvJs9Df63+4NeMfbIl9968ZRx+tcArvxvzPJ375I29HED75SkEnkpnTsz3fevu2/xz29Y/peAzPvxHBAiGsofHoe3DiXNN8wQBcGSZaJHQnOaymyAGd3BE7LnmYHqJGyWCZk1Ul+62vSWPH5I0DWlMkvOaIlIXNh9iyXjNJDqvRuWjpEeNDKsSKzZeyjiSyvGeB+PBOYMDfxbIseqzUh+Wqw4XIwuQ5ruK1rJLgnUl4jSlyQKtohI1JX2sCQd+dM2UwVIg6/aEENq5wDOhMkUmSX8BiTL/K1EDmpQj8uTA23kDNSU2VKCsLV0ESdK9KX5/BR4oCuLEcPH3t87aOsMT/3+EVYcjrp9eACcjLXrPWs2+0SIEifFGHzqjT6loYXK9v9j75+o0WF46iNvTJxegN3ehocZH/p3uL1p6tbI0R3+nEl4kfO8JrVren3Kj9/30A5JKWD83GB/HcpTC394/nrbo7lzGPNNiPkIr1i5nlpowx9VVaYi4jQxWKxqniqdz4Mpa7M22Zyv6xSkjdY1eU77KEWb39nX1DIzhB2sXSStIuQTQ119k/NSvIvEA1GrdogsyZ+e6BuUW8iLhTbkzbwgjGxrv7SU4tRczjNS2LvDy1L6OmhXG8qLCMmuZFrjoPVoj/sKAnlPiYDz8tGtds6zje0drBvM5sbm0+3txGPPzanMqUd8heyN297fZ43uT5Yv2gOpGN5fUb1Zz+9sItrL34ReRUSf6x5l2QlGIuYjgiyPwqqCgzUYxCw9gyYh/BGGWNPMNx6Gm9hbrCodwkBpbbb1Sy+/YXXcTba7cz2y2s1fJdUqJJLKxGCiU1sGxinBiZGsUVZ/alVkTao89yHMXU7ugTmhBBuDRAYOTgo/hS4gC+MupVaUiWOFBp5KBjuXLyYDrR1VQAFchQjn42+b4eMjjnZ5UUVa8SNyeIZPszNCbMWG5dLmZUY9qfKRM1J6jE6HrJVElhTkGqAJ7KCivMrCeGFaayAstardL0X3ef7ovVqsd+LS2Pilc41fqu6T5frXzke+UeFzFglmp6KlOvFRzv7FsuvIg3GDy3VAhwhSdb+RI6kWGpOGi5GJ04rTUV1y44f2pM5VO0Md9BlXj7CccZC4FJYdM4kjT8qicemSPLqo7l0itihWxEKYeE81Q/LWhGqhP3xsxopv95fmjKBe5VQOOhJzdz8K76EJdCePCl5kMKwNE+fchkMvCvxpM/cey59xbRqJrHbRu9pqKzWQ+va2vXfn74W/bVcYdROUTQEKOkphTTaXTtD1Hf3BwTy0hwZcz5TYrUSQmeaXwmW3Zk/9KPBZeXouGxh9je+P5CAhx2b3yE6h5/LQ1RyOZqEQRCPoLFTSxMS0/Ustj5iQSCNpHNRmhb0yIlsE8jIj6FoSMjoXGfRUR8FkdPRhxVmxfMKydXuha6lk5C9v3MmmchTx1QW2J8mJQ0NQz3TFfIFRKX0xGFIq4ticuqgGZnJajTEeFcLJvLuXR+YlzmN2PKEfAoWNQ33MhnGrigZTxSJiaWR1MY5khRZrIyI4OTzwgVQXg6TiZaJSfaoxmZleHKzFR11gpKQmZx+WQ8NZeQnUMPvPXfx57w2bAgAslWBusg86RhaEuLLJIL3SOdANcm0zu5+dlVsbPvaLdLhNDnrnZc4rS20k6bjLTTra2XuA5/wIUmPPVYcZxIPI/FnCMSx0Kjti6W7iwhMQkiUUZVlMC1MvbenTsCYVDj02nhXvz/D+dpHmV2GOoCAtyOBYoxnXm6drxE1o7P06E7xTIx+panDS+VZtHoMNaPooPEd1lQNIoJ3QkSo2Uo5ctEd484KvIjAAYJDyjcjKFXNAe5np89HFR5lcFMH7qrPQiY6Ia4u7sLTwJmnCWJcpr4jZ+voNgRUry1tsaKlIe+CRe67dvRZymcwakN86nl+vSRfHayg12pLr6viGsWVsFzzyfl1Z+JNf7fY/HO+sz6otdvvlWwSBfV7Pqqx7/+1X/7eyzvQfU+0kHoxVxbIodjSxRzk/Tk+ejfpPqTEP2Zvwmh3d9Rz+O/Z6Bus7FIqHBBHINGSWIWoEJkCjR7ThKNQouj56DZBmQw+IcpgbAj/2cMCQV/fIQ/fOpjxuT2P9744x4MFpwCg/3B0tgujKQkcUIwUVwMIlJKFRVzWdFI/Bfva0A158QwFJ4RpWhLDsKe/ZqvxTUDmp9Jl8ShkPSoox9IBWHP/cmHg7/z/DUW9LoFfeuJvKAMibaf4j/7tCIuNvyqThxeMzsoJv7hY4eLOOfC+c9ksV2xj+9ij3y+uCAjWDoTHSe5QYW2Qu0n4nVhUv0vIeslvMnz+3jyeoZFiUffzQ5xTigrOdsHpnzVUo/5/PMqJfAn/4Hnthgfwu/82vd77vMu7VytrAoaHTzwktGt/0C8wqsp/S9LDMK0cSo+bUNFBwi51mEziJiPDxt6WZSikaRbHWfrcRcKHb1ZOcqeLJ0j9UJ9bQfytmTEpmB5HfmcN6+k7CBOxawqqsdk30xWvOrV2vpAO3VS9s1YmCJmlTil7MC9v/xO5jsY9tf+mb95o74f9iAYI8EFNJTyGPiIIR1CkfmlV28e+ZkZK2Y/YhFFFogIgOqS3aE5ogsCOk7+ihrGKno4z2kvIgZIF073bQ47P3Gadixq7L95EtTNtMp48/aFDOZFBRCb2P7ujURgVqv33DzJU4dtaleB66ZyU/3RNY0mc1CSacsFOJ5yC05LnmVGnP5nbyI4HAwGewStnAUIeXWB4G//JdI6wb+/8v+iOvZlCb+ar9taFP7T9vBTQNEbqoz5U65eZxs8asMmF05VBz654xu3edvPq6tmt2OIBja+2RZWW7P9Rj6+ZP7/kmxbKDB9LCQG3MOlvHKB/WJ20np6JrCSLT7hCtb7AbVGGUCfweAk+oYO98D4ywpd+dapyxefopfu5++eIZN3UldOvwwPHTHCY4G+X4IP7AOAZ2XI+VMo3BKQ/Da8Qsho3SUNG0eywKaJnQNBjWkTNKDPAEUSVQIzQOupH6oygEGDvpp/xWS9CTVtGwt4wAvrMqMQCFN/VSzuzALTnLFvW1fI6trb78vtfIA5abFyAJ07u/+Jb3ODb1v6FK1bdaw292nQJQq4+eGmUDvg4wYOPqdyev0W17be/fU7PnGbt/ycTrAPBC83Di9zwjnhjDxj5aXFzSbW7ExeRSdJ/zoBtV/LArux8wLFbDREHJgHCQeDSdd2vOs8vkpxERZt6jxP3rpbsfFp58ZxB/CzF12+xA5jAW7oaLhgWnsiVgdmA8eOIX2Q3zwZmqQ6b+Efdgt2OocUCIYg16KAzYgGugDRLyvxIXMmjIAa6QzAXTvp3pYUh2SDsKZAQ1AZwrhCZ66fbZs5F0VYXekEEhlZyZU1oH4keP1MRs/cGFvLKV4oHVM/MwOFWSDgy03W1WbPy1CNVQpnxQsDkKmaP4Ei6F7VAz/o7jq+/+T9Mai4EP35K9aQy8dMElwXEOGcfFL56OHnD4N8Da8Eic4UIxxB2KGbYA4WjdaUJrxZd/PKqOvnlGWg3xlzmpO0/khBEdnggw9CmB+DNhPofFhZOZ8oqQZ+AoOXL3YdWAsLuh68Ws6vFIAs0c9Y4Y7vgeHYmO410aNu/kdDWiv05mAsGFJHKL+9e/h26O+TyD3+9rZ6NJERXoE+izXIAJn4r5w/6QRTsLZ4MVH8TkmQ9O9UPAiZU8YDqv66uQWxX7++V1o1IXRF2dRCKSd3F8ArcIWXy+/s1mxY1MQ9oJdzOHyuqe/s6OUAb9su/I9ZsuuW33HysQs21zf5XXnWjb++PCgKHlEy+J3x10mTk7p7o6+NE2MwjKhKaq6GoYPkmuD6dag74GnEASBQ0k+q9o6i3JuCtdmouuZ+p5PMb4i9VnA5bDmACwsAWGdCvzAeq646yoFbqj4a/rKP748YzI+7ITwv/HvDc/bbMFeTzafAYqyoX18Pnwkp9m3KYgx0SKcDXcFgv3nvw6auwO2JbxTJTlT11BsNhjgp98EZEwFrkZcSLKhN/e6NWO0vYshi6PdfNkgF2eciGTGmY9eMyg/9UPjtyHVW4tiIY4AdH0MZxDPJDMLAtafirLbmstg9BwMphnARP3wgb2d0abUNsaX3oIyGhHjw//8vZ+tC2WMDTQP3u9OTtlJmL3f4h120UU6/E6ugS6/4ZQsASxw94Lkb1zfdAG5YoF2hf+/m6fkoMSU6EAv9Ezv9o95KTG6eAfKBgEB1y/ucJwg/zIERjLpo3PIBk2sXgDgdV3WkyRU0C36nYgO01Q6DPSdtKMPtj5qroUZgzI5mjT7MUvTa5kGGAUABFAZHgi6NtzPOMR6MAF0HUP99DVAsfAYTm+45eUypZs/OyYqy+MAN1fgT5WtNcwCO40Zji2gDoEGM6XuNTgFO+dnWUIJx7HjKBeDdjsNbtzy/on/xxeyrHnobNGVMftEV/r3nJD5OmJbKbh1fOzlzlNa5pvJmVT2r/s+bAfFwW3Omdc4cPTl1hNG9luPNqv6n6j/IvyFjRZOcqqYbb2UK/MxzwOOnM94rN1hzTpfjO2jBEbKPq+l5JKnqFOV/ASN+ABvE1xr7h+O4Bv2wH7zkAdcP4IApAkxNgRuP58S4AMcLrAUJ0kRZUCJhytSujKh9mF6ia/ucbxydF5MxCQh0eHPDKkgf3a9QPHPW+xKDs7Pbj3GNoaE+M+znMFBvVu8CyOmcx7/+oJ5M3TM/P92znnmQf1hLyJf96k1LbKhCJJT/1lX0X0N+3MEjCNxc0/8G/S62QWBqGUT4Ef+NIb1x2hgAXfDe+GjFILkysACilTvNDMNLQLhjX0FEJWCMnP2RDuiqVKHIaVMCK6dOxGf5TYd+CVyiAY7gzOddFy/BWvLLEX0XM+HB0Km8qQSPPzazM8vzzrL5FiEjGehaOUjzfwkRoYXdPGzizfFun9O3JILBYCvjCSi8t8ShQQv+YvTE50h4mdZm0E2we0GEmbXPx8MRtaxUKVStOV+vhUIJrnS3wUsbgJNLmE9tvBRr1pQn9W7ji6ZmOkdAa0Rd4fazOg4fiMu7uAU8DCgtXhxz6KrzDJ0jaRddtwv/In0YAb4f8hQE3Ke775yh6H+5ATww7JtJugp4gtQ7JT9rGs8CzciRCAazto3Jp0XRyjJOam2ud691DpIb3zbShAs+15I+AgoEHCnhsb+tjfpPhWPE9EPM25/ITpbnmjVzQIRahGK0ZpJJagHUsuYrptgrq3m3DaYAnqFjH8hf3jLf1uDvftoefFv5pehLHGbfKwTqNVHuuPBRIwDDFgXMbbfi6g8maxnLA0+mkiVAkkK4pO47JkhW4J0Mdt23LhdsSCmiqzsreBgGZkjRsuMHqe9APxNJy/XYUix07L4UQBJ7cRFfP3pIVrnr5+LSEXupW5GEG6DKnqTlphQFGzQwwWUpJbSC6UIdLnoq9/Qu4uRlDfTt24MwWYdnDu8dnlicaNhrmIkjzK3urY7Oj3qMZo9yF88tznnMqbof5UdG8vGCKAxWGMWK4COzkBE8tiASixFEsiN5yFB8tSkLYRWH6VtJahnpCX4IiQc/XiizvQbV0WPoYk9+PAbf2WcRy60kX8hGARIBBHATMj4j+PvxZf/q4BOlHsZ4Rfyxz+eLC9/8UozWoGqNQUNGJGPEeX+eXLZJACaL0ig4aCQpoTswoWc02qd2WytMD2OgUTQmecSa/nrvCne+be4yry+vO1xMjS6Ho775SMQT6Xu8Jqo5lm7nZ1OKYpmC+Fr5s1Pvq0MEYhaMLCDhUk9BCTj5u1InFspyp3Nin2o74dxf3Lbs8gLRAum3KF5taud+R2ERIW0XINAiW88x7Q34I8XF+KP2hnPM1mvzPa5mHEUGKc/MhFRQFGac+noWFoHkfWlowWkBUR2g0tT5fGM7VkKy+EEDD7U1+tLqb3BGh2VvOg03tm4ObrZt7uu3fzB685pxHa3O70Hg4RhbAEncitYU46ecSva3dQx2yJJnoglwLZddmkhnlGP4sgRLlpiaYOHLSzEMRimCx4brCMMRACQ9Pk4M82fEieNicOL4uIzg//h8d4Sl70ISJhzDNzzs0f9s35uLRH0fUjpPMzZgT5T6e5d6Z26Qyvxfh2kSR4TFlXg22YDkyRD12Uka7EtFF0YO5mcaOEGWVKESQX3P4MOvQtcH16chFRhhQuUH6c2MpbKxsiGKGNOel9+Gk8racXn56HaxQYy+ZdW0YSl2hQQBr3kFt1hRXNT2Ho82oEJfJrqljYKwy16FQ2y2wfoO/ViCXV19iZr1BWx4kDA8MJgfVjU+Nj5WFZb/653pYc+7M/ZdBEZxYQ5hl1LC70uszS4ysVrjx8RixBi/1WCqy96fyCzbkveOi2/VYwB+wDBJUrhDyqOGOCcLR+gDQZHRrAFKVtyN/3THRUSWh5W1YWrpYPJkPTHccN+5mruWAVovytCD8wOPjHEvkocY/2s9d7GkpmZT2jJKv1YdUkHdcnSfEeyfF1el83VxzewQUdwAv9ROEUmqeNmtcWt6Jj+ez2VY0EKJ7J1dIHy5B4Qvu0C8phuRvslgb/culI4X3y9+Y4J/gci5nELdHGbNs0IxEeEXZy7DvthI+vXs7gFyVOumr5Vzu31uK8+qm2LayxT7L1+W77eXTTJ1tq289jnObWv4q+k2NVmryuWAgJVOs+zWC5qDYAYE5AkTIrOdKiAXo0Q8Yh4iNzSbk8wO5SNySXkinh5FzrbThOaEcXlRFWC/b3wQbDQ+hZZNzCMJfHYyBx0SoeIs/CrqIUmckKcaK3OQrQpZQ6IouukV/wk9W8lwF8hydACBX43uzc1vRUvhXM/MkNF9t6I0Wosh5uUU15Leny8TmVWn8MnPF1awCjizifXPlZ8jiEx4hdPXH+4i305VMbtY/wDvfu4kZcny66dm1Dga0Jn4Jx9iUdbh8cCRn31IlZfOrXrN/Cs6/DzLRUdquHejSGT6v5Y0f/+IWxuJ049TppLS351kC/aJ8A7xjvL/O3z0epLGtWnDeHMPIfxz41TpYnE5TxPXwFFc8LvnbzoQhdr0UVPxFE6bPRDLD4s+eD08hu8orzQXfjA+X2OxR9rLAn8bXfe3js3KeeGCUFa8Mq0UkL1rmGCS8F5jpzQXO5j39x0/N0nd70k3rXpjBw22CarVTHBXzxn0tUPF/yzBcSAQwg/Ng/jWJIE5IlJeoJgkWh3PwR1yxE8eQWAPTv+WUGESxXytzoN43BaMGEb+OEJEuIxY8lVotwKbmrJPdjTQ90uvrSZ3SG4cGOwfgFz/WZ/3gvzn06FXCGCwy8wGfAfxGBapAVeeoJ7N7+s/7jwJgIjDwA92JEdmvc6GuBV4uQeGAjSWVom2CVSw5M2tONBDf93tTmx/7bN9pMCtA7eYIvji72z43GXRDQnPMW8QEz9gQGfPgAlHznziRyH99LL+qjjD+ti7tFKdJ8nIIH5oXhDZGuNpOEFvjK2czWix07rhembkznDkPHmClv+oPeWY8NbvdUkOCEQcCIPGZfJdICcLV7sPoUidcmVeSzkwGdmpTv3H6jLfa2I5+o4PZUjWYsFgpbyAcGTtpRekERzV47GcPgt6haETHQueyJfJ758gB4kDQepAvzu4Md7Y5lXSiH54u46ZTg3kudKWv6OdSZALtUkoWsG+ncdy2uy7sXgZuIFzBt4wf4HuzjugMywd+UWzXwLpQfRUSQYkbm0rdatIml7tsXx7DhiUMhkJGWf8XWwz9XLWSHn0sBYemj8cGQYzwWI5lnjcYKfsSkKfBcnH5YV4EkIjH0D7gQem34zht0/B1Q7nN5xBLzzI3zM7/G60/p0STTYwDpzKZxY2Ncvt/Rvf5HA1p03RgWtgIIhpLPAlYNZ3ieSQxSxUTHzNyZIW2e/j4O6zbrXcXY7/V+BuE390g3lf1AZfk3Sx8tl7bSrgA+P2ZWZhU4vc1r8RwGqKLX+iutwkv08ioAfa0kezrEpPN9Zp545fe8Y4DeiU/eSN2Stu7zn5bohN72AnWW9majbvXAOY+5b7+29AWMF7b5a02Sno3JBLzSHXtoty3o9/NCQ+4QSa0NWByOhs+blvun/wJpzagDvpq7szfvszxqndqplXzMOQT+tfIUrxzox31zNRMzvVzLbGrODuHb0LxwvIedUD2WZ//+DTgc2ifxOOyLntPxKCBxmnvwTRNaCCxo/bPCH4CPgHJPnutgE/yeQ7MScPVKxyrJirt4+hZqi2Ecqtg5GhkcXdFYnzXwuadcNDadi0tJ/NW0xNwJopnhUbHk7oPyjMx27Zdp6mp2pbs73+boQhakYOcBFKXG3fcuEFuBZgFLh6E/nXTwvdPUTbjYLEZfJdQ8QvjPr5HRu9EFrkWR+h1tNTU9Gnjpcvcy3Y60AHnFecoVqnMm4wmrOoHh6+IT/whIflfsCMjTL3+f7024Tcf4oT5bjYwLT33VHvco+vcC6ptZs11b+HzN/7N2ZYnZmbGV+9jyC0vEA5TyRTURsxpWV7b33Hv9fY2TnitEbQCcZbHDm2rMbrL7hLoVFywV982ZYnU2MG1H/fVeXDebSMHVHOqhGQIJ4BuAPe+pw7uuVhBwWCUAWVDUopDyyhsqLOo1SjKaznP9+d+153BYZMPXcNwQMYA5x4z4a89pgzVByYF+r7yDhaPIoi/FiwH8ASGEvQlRYA+2p2+g42lKENa+bZFf0LAIEgtKTqi0lTuAVn4BMKJvNY7zZJDu7dMVnzD1Do20ARRg4mvtgkalgaGWRQMZaqIf7DrownrM1jy0GaZIf85BJdWJKuC/YWUObTUFh/6CBToiieflnZsTRx5XukxJirgeso+/WOO71bO8ePFdo0LVuHS8jthL4NFHs3MFXh+xNfbPBlDdUlqHqZd9i8bTbBdSXpCFQuCT5ylDc7GxqA/dRRPvuR62RohK2ic6L5sFiELiIFdkF6hIiiUn6creDUpWVRHhAamaMvazwya9DlSIColuXi1WAMW2xJBmrQj5TA3IUltosGNO1arLc8PAhveD/zCoQshpOE8Fq+qhSf63Cj3d5ha5n9YiVbl5IHcMwEzyoTUMTLzQ3iZebBt69zdt0JPDO2KFf/MnYGyMZuDxX3rWy4JX6PPVbnVKDP1y90GZy2CMiGS8G6U4A3yDRCcJ0vAuYAh7lVHnkQO2BZryYnnXqiIvEA0k4mY4cSBWzRxE5Q682gsbBhzuLFutf6BLtd3zE+XTHIeXc04K2NBFoNHpttgOb2LM5C1IuQkKOoKUEDzE76cQzgznjgPT8v+mxM68pQju92ddBB8OgqUQef+/C5pk3Wt8I6Ik/8xeCTwwtJ6fukImgFPPaRoD2mA3fK4CffVoJKX1HG4Ak5Ma/ApLgqLEy2mxP64LdbhmXy4C8ZqvnihOVDkXgOSlwu1rbwONliBj1bzKnasjDp/IuafFiqbUZciWCHIPIsMqUO04JNUqWU3MggV9+7GaboAMKG7p0iN6XHRKXV3Vz3ubZ+Lj3Kvk5iCdbbCcjEBG+Qi7ezoC647nhdUN2xOkgd9MTdsODq49VB1ceqIdWeN256N8iSlik67E9y1c+q26v/rv6u+q/qGmi7/Znd2/jb/p39L/vz/X/6FORfxuODeuM1gx9/CuN9PHzIf+uhQHYSPblUxq9PENCtUQo6xgiYPPZwvUuGEPcTCARRE4IU4MfAvpJ/79SI5dY+lQeQWdkn5iWW9vcPDLBoV/9j1M5ALHZvlvT09PayqMC6KPvF3u4Ij+Y97WE8ZD+j3QHaCo7gNQx/2lilOLvIvbkzMDc2eJ/sWKDvuy45l47rve/POnq/lbdxYiMNo3HqbCdl0bL5OYkJ2Tn8nngC5h78JAQiibPXcUf0r1o2Xm63Qld6ds/fijfBKuVbb8a8ca6wWwu9AK1qZ6MTiZdrOc4+SEfU8onTrTlfnzgem+ZKJ0X0GR0a9LPx3MStzf0WtRThk4QjZXcO886SX46YkvJyBwPRlOy46dmOkqSCi5zkDNgJX3tjcJ/kfxhTMGtLbko1F968ooCKrHvRXj2g6WkGng3rjdF4Hdz9ZFuuxysHTU3rTkGCdKcAH5CeQWIWOoT5XljjKLj6+wcIdwREhIODoyR5gWJJzFd//HTupx/3PWPEgdiuOh/3e6Yx/RjK7ZWeSTfful9/pbcRZtLmCD8XerLUhb6fvvLGe5kwegmozqmhuVWal7EMkC59us+nFmxzrnMK1AfoVYX6yo8oLA/cEjs3qU2osCCYTAtCrEhuyx1SJbWLleYbYnEi5XlqqpZ8jNwCFpNbYDxp4muZTI7WRHL5jPHO6NyhxRnZOwOXKfcahjb4daApO1smqyxqKh8Yuf9ibFKUYHzjVlXe+vJNEdeF0+qRO+hOUhj82wURl1trkXW7rQy7cHcYG5XG/EYjo4vV3NYEicRzai5TJ89FE+5yQwh4ePzfJUSX7pt/9mRGAfybLyosDyHF0usqFcnhFVmNu34KPRKFiTl7OOg8x/jaCcDbnkJnhhabBjMPVmsaIB5JD8UbsY6CW+dbQwU33/yzTpqfWSRqXtPfgmImMSVHmmmOoNFqaOFcJyIzu/jvJmoeKR0hz84wRlIopkgA2POBGYKYSKUJiIQ0IZFGExIDh9C/a2Z8jkV/lZn5FX6iuQsfpeKSetMAL1XZ/TS0VaJYZlJ/GlI4ueImP7zqHbQeIoCgO8YGmtJj9Xy+DSnMLI2SEVNz4AdZAjQ5Ps3llxiqWCSIcHxnO7lcOEXAyYhuqnbvhHbq1uXjTpJn/fYBV1mMsw8TgbMPyBnIwND0GBPAcIUEgg9S8GNOz2c/FiYy4TQIkSxXkHD5AUPbA8UvgwFap2YZPJpQQgvGWO7ZqX7LSxk5vZNwT4SRSXtvPlzhIeDg8RnCjIptXQ/Wh2I3gU6YO+Yg+lxGR/XVHNE17wtdivbntpxXy4C/goLK4HM+HPuCwnco5nVkL38iVGL71ZkQVG1cm+opxWb6zem8r35VjlRvRjNrXEqg+Y2ZipNS3Dyrz0OrGW3HEt7G81R7v1Rv/CG74DwIpe7WUIxeF4/nzwCLwbx7+pj5UXNb8C2TT+749eoSc5/6gV95n7uAd8FWoH+7NO7DcGDgrTd3HXEG9IXaKtMg19GNLoxhHE/xDJOY4unjLA+S/w6svzX42PI7EPKqUTIwhrHgOo3vZhEDSVTVkBGXLhJLDwkd0MAVKwGXHqgZqKq5G6YUliQMTSFWHdHYjSqs4MkmGFuLLGg4MKZggkyHsa7+AJQ4LqkoU5y4oshCNbIWwZ8uWgLJT0Y7dhPjbFGd7wsMcSFB0e1oCfGHJMGKlLbPofxlzUhbzwBWtt3h5L2GM7y21dxvmXpyu9BaCjnXvoGrmFYanLgM+EtLRMdc+BxEsp+yXBSlowipeGPNYTPl0FDx3Z5CQzLcg/fWNBbEApksaWjeFr7HZj8siBUGfbAG6541TZBFPHS1jGa+vzia4zbvC0ztevZjHKxA9YX8wt1RHyqFCT2VKVwH+OmTQ8QKdV3x7ZOoaN+/9u57GVATcl4rAN7wcjqNBzKgSJfI7XrOctfOrfE7d/KTpg8bBlSv6jv//QOq//wPdKiBVTkow3mSDFblUAg5VuVwCC5DrpqcV5ohkHPvBMNK5C8aOaOTIAXK8Gy5CmkpTIgMHg8Lh1CEufoIB/5TCr7z8Pm7Uxi7jA/xvdUfkmJklMRrkSkSupsRmyqUXZWLNzr2AKXxVDA6fXlUzl6Gs9UvebcMFnxBwCtszsDrTtnlC75mZnHbawaS1ykXx+rWgIo4Oaqd/0jbtf9zelGKzcq7mCp6Ciqp6hRrp4KSU2+LVJZKCcdQLTW5lDFzOFpV5ohQW+e6iTkWlfGxF1KfqMGuLn9uGuVf0xk6WoEUzgPtXO6tuWlUntLSGK1CKsfQ6DelK86vT+fSuTWA0ADN0sJTtepXUstJtfU+l5u67/6GsCqlNrSM0xUg3xHUeq+ultRG7bH8OlJwP960Te+2p6v13v+14G/sFTxylVweEJX2XTroxp1ceoPiF9mf3MobWajKoWDGOYQLNly5NFyiR9Vw9FxHbTyOdbjHHq7tNiEpQcvovFKqSuvea0ufR3Wb7N1ql2/YppNdeCVnTNV7YKD1+JGGYGi+uUtC73/mSfM183ro/e9Bz0yg5PqfCK1rlvYeN3BtgGZsvtVDO7axH+22+J44aoIKpzAMqU0HDswHvbg61Mxy8/Cy5JCQ6cLgUCzvndWSsULs37u7P/0sx4xvfeGnhBYMYXe+ZhWe3c2DO9+FJ+ZvxUUTitkXBPAQBA07/6sMwb1dikS6XbAK3eAGEPPVPBImnKxYK8cjnkjTGUhnuQ478Ev4lDN+cweKQQmzhp1T8uXYrBWaIJlQ1kVAN9brOy4Q4ZApmPMw25afmMcCu7zj2QOmxiWH6QkqUTtBbU5bmwsIOV6EBN2kENAayVLQwfazXCYYvDs6OjFAlAzgNjAzBG/NAtzJD56w464d5pdqHsy4dtaHJ2eT+8GL96Tdn4yB2QnpbZ5jpJSwHQBpdxdwZGtyRlIPD3iVQCC/6yWCDt7x6iVgpyk8ezl8MuxVBylGVSenqJzkotglhFyK46CFqVSLnSgbDPj2CluioW8MJ7fEw+WcCOF5ZBLOK5Mlhm8TccpLMNw7Ndfq4sScJBegLRIhvzjXd6m6tMx6lbmglHOlkAqz4Qg3H/nC3PGSdNzJ2EecqAzApylofnjuPKdg9iknMYxIHHAdhueeZ5cK0cdmiyHNSpyzm6s52skdbJZIvL9TIWhnahEqNZHSbMlqk0CgmtRFR1TTJMjQq5l0e/9oVJqDoQzz2eKsMzih9e/uueh5G1O+xaGyOBOUVKKk6h396JmztrtGEcCaosSRBthRStnRXOjGcF53PwbB44Ibwom6zmGJ8DcDnChyirVXwj79zMlAzGEavudB1jbAurO1mnyXIM62c3QzgS+0cCnu4fX3GemDeZz0uQbyOdmzQFswWxNdICZtHujO54JvqKRqINKqlKZ7a1rmq5Wr6Wht9TqwltPrUgbJwYoGCBaq0UJ9Amm6u/zQw2MKjVCrq2ld3SQLW5mnuxeaEmWTh5NALNuleSyNCuc+fTt23PUOBDZNvrJ4yf6LyIYalRtsOlLvHOzZTwLdhW6Hns1758cuQC5UYzvLTovA5/Nn+jXb022JcgJk92IAldbQ/qAJezKJ6T7cc8HDSCQM417iV1kV6LflTtx9hDSUk3AflpSXckusdUExzmtdOzkCZPtGkH8UaRKuXz2SNLNRnxNNNwzeDW4TUYhrGvdCAsuGx+hPmokuCLCXRpgaKKgtkqROTBoabUjiQXtEHNLGuVEGaWRbVWAnnaIPtTrNeMYaLj6GD1qla7CRwfoBjUx0gOswb4kvrWKm7fCN0osQAsROLotUbDlPtKZmIy5QG7F5Ju10xLI/yq7DzPeZRi9qddm8y+aeSEYQPVpKMNOIJrWgM/M5e6N7d/Ds9nMgLuqr1FTDHKujvrQk6eU3D0+21m8d23FJKa0A1OqyWpfdBi28GuCRrzMhwFObp/HSjoXstzIODNm/ErmU3got6K5aOiO+OyofLZjrWch1C4FEyE/ra8qS/aKsIPhPNspFQ/YcUh6nKwl72Phl0W5VJh2iGFlusGq8TVcXsr48fLOyymJalO31802pcCHbVUQgsc/X1IogDGkM890IdwGI67m+4IIBrDkzLOgj3+Y9Y06NCaTZTPPH6ulclrYLF9slqmws6QfJKYhZKt+sdk7f9thfsWXdS4FwUXV8HWewgnN5cYeS7MqhJ0Ku4spm8YZofSjDLgkjZRQLw2KIV0dxrZ8SpHXby193PSHg6DyCzSVfgHPMe2xoIQ0aAFqBvKSbXFIzH1XdtEUgawZASw45lL310UnjS3FujLKOBBrWOikNWrHIPZYZV8SoFfihlH8quvIfRiXpBxtj97zqJ1aiwgtDZKEalIu+gYc8vgXACDUIs1ggwpawsC9OXz59cj41VcYJtnO/6u2vnzG1X1PKqiHQxQaOnDw3MMMKQPSAlGKFiEnsyeOzU24+q/ryvGEZ48UPojYD76JuNSIGnoTUiiNdNoX72U776PjNw/DV6VXP1gdHCF4C8hg4k/NJCMoH9cMY8dznL76ux3On3SqLnEzsYAaghX0Z5v2qfSChmAtgpMA1IiKyPfSFm6J2PskXUojG+tRYuQMmaQ4VtCgIDEuEStAoykr5s4fwBAzIga0uYBocN/fwGE7RVVyjNdNg2B2QsJhoY1+m+jT7CDhriE75BqStYDZucMcSr6Kh2BZb+di85IkHHQAATxc55UgbAFogN5QwNMA34D4J/fTl7XLYz6NiQ+tq0ieOgBc7oVo6SPuK5gwaAjFkUg9VrC2SpoRJqnHySB4bCMmVGi9p+GBFSKyYWI8Fm2Rh1smn4g2XDs4x0Vsx0YPeAMBDBEDrSxPtvjjsxEM+6mnoAs/cFEGOooUEXVBiEmLkQzVlkhuqkDyQ5FfTwN3v/PbaZtcyteudHVt+HknXauPipxoOjycaJH/KKLSafmndF1C0WX2zTonnGNJ1zv1XiDdLvURxjby0m76DH/zs39/uPiQMnrwF+O0h1jCkMIeW6AZAhrHxEfQ/eVh/1wMEA22jMId5rmK1HLgXGbi81M0jYMIe4dl0NFgm0EMvYDvHZZ/MvQsH/TarVr5JxFuUwmsIpal0H8iunAdNZ0kREsYHpA+U0oPUv/oinOZptNXgNxne9VuCUBdBjq8iZPDqhMoLAVXdIiLmrkyTWxYq6bJX4lId3ZDDAQ5TJXjH2yIDZdgdN1psGtmnMsVGEW7h38Isxqe5VwLoo58oNjJHnpRYDSYhKNYzFsA4XU42iXTRGcLBHQIJUFx5jtsyJRHcSA5sIvG2jfXr6u5np2uxBcwjL19oyZTufkJ4irXCGZMrC07THkhEey0RnmHAnAquL1WMoDm3BRgMso2JCvvyCT1gPW42W10/kTMWg3PcbqXkHEpWTqjQI4vgsioNfKcRYMsgvg5X7bUCYGBnb0eofY5JjgJxDo84ce4hFB9cI5wdAx4UTD4H9JjWHGjWSSI76A43tpHRyAArsqQZw+C4KwCejLjdVwFyMu6GzpkLji7FtHQ2VTWxJsfPH/fjXrGD7ZJ9NQSQHjTq2NCoZ5rORPPC0V1Hvcd7i060vCTIx1EvSoK6BAZwU5nTUyjlXS9ZEHROCRhc6KCg1jOiqvh2WbQs9JB5ax+FpDG5SvklN6x2vgU4eo0DQIlz2CfZnBDsesAn27YAYqZ8DZGal9cuUCSYeJeDLonYVjPjk7mxNws++nctlyzd0w0yxkz/2WR3PoEx3TdFV9PHRBlbECmY1pCuuRnTphERgDaD/f26f3F4oZicRted7aYRbsMrFL0gwhzDhgWJwi0XMswZIqXykqQKKOUrIILhonYG8S089Ol1oVxfctdu1G7qnIclBe5T9XW1qUtg2EYhuiOQQw5FkOvD0/1UCTvPSV0h09k2stZYglNLsZxSp4Vyr9duu22RURIWDOjygpo6CzF1ObG6RgBajRw2BbHBUdNI6TJ1ADXUzFT1hLgitdP+w8LLMxTTkBAH+8jca6TkD+QaPExADZDJ7I7KE+Pcp1VsdgxI2CM0Jgz5MBuS6amwNe25SLjkaBiMjwo/E0jAzZ25UJkgFzLMmBKsOArjGhy2BBo1RkERt166rRR6u90BYR/Dya/loTY6wLDZBGIYu47JRiHo3ZzuNJ0dFRQYaMBupHbPna2kZ2c4hYE+MnGZDNrg0Z4qqrqslNBST89A6jSthSgltxVNieQIJiC+EnmHG4JV58ATjAI3maYzmKAA1UXTB/ADoAQRMATIQCrHCLrQpqbq2C99t83T29WexMC1vUZC2gYisZQAXfHK4YsCaKJp8j7dWgYpVIKQag5LJEQX0KZAIdVzoG7hwI/iLFiy2xoBWYSggbsv6paxikOyJW4Ie/DAqSwcY14vR4q++dFHGGygkHWFI6oYygwEaGEp3gLClVmBBlQ9bOGT2RRJlUJmABELd2MV8Kq9Wa9Q7kvUjYwAc7iwUVEGurE5zfjCrCgIXAHmXj5WdDCFkNq06wD1JB4Pw2FTnWbNbt0SRdtpSzj4KDluMLq0pstLWMg6sPzA0Bckk1B0dRVNYvPz9L79FqjsOflGx1ulDNaelbM9umvcGDwj9hpw3D3JCGGBMfmpnlQFxaZxeJoMLhvlZJDVdYKofEf5eUMTrdGx0LbfkjFhnuLIgwVl1Fcaluhhvs5qRmw3Q6jcQVBzdgdgYE/j4+hAexMthcNgu7HKB178uI+NQOeNAQKaIYDhZjJY42gtSOejsOB75TQQQ8kZCeckamDRBKNLXeKZiRvKXggFMovcdBa63QAAX41UlmmBlMoVylReAa9eXD5ZPQ47ECFKBJtVMNzsQgyBnJikTlR9j2bXDXADCR7iJWVjqYc9QD/pz8MZBAgiOShPMIzOgOWlub0vyRYgu+d6VwtK1refseOiV0R2wT9ZA05TO6Pd9yXr8T+mJuFQ2etjmPLH7iW7cczG4Undh78BwAPWIFDkKBrkkslzMjrEhbj6l+ZqdPr94+uXo+9H33X4tOwGP59YGtSUWbCpUY2toXYAGmIioQDlkFg7aQk9qtAvEP0wPrnymCfJBqSf4YDAY9f8mg3ozVfA2PX4v2qhI6iAk6IGuD8jwZPfxGCQzllCN9F6INhBMdWyQsypKAjvBMvHHmB/mfUjKkoHK9jMuXC/E7SYKYnRHYWqKD5qrWJQYE6uOThY0JFdZiBU8GBvnEElXFhGbZWjeG08bGTUrEzGWhejmxwVgE8lcsauAzYoyRv6qY7rT6tsLDcEOKllq7fDVuLo+5o2zxqyoOf03GZCY/txpxPfus36tPvGtc70h8+oD+MVA4gsBCHoyp8s2tq2oyUEp1d2KHme+W5CVNxawDgDsMAU9h07cAKmrJzzcvISFFuay2qHGiZcD3wrfOfe2D7cAGYVnPAFDMQHuLRwRpL1FRvjloypknCBeWBJYcBBtjNUPui5Or8Y02ev0KfQFnPeQESExTBfCvbT2hcAbNhmRvjrNAyuRcfOYQTjBz8INE2ci0tfdssDE9FUGJi9FkhgTd6Z6QJduqRY5B3XxiQh2IUvNJ+MMsDSiAKH9Uhc4izFaiH1YuU5jqEDjZFL0JsMOPJpWBwQCLRZxrf4h91wKhlecDrwqJf6srtPdZ3tTB3QwomqQh0amkqfTSWp6UdVTwD3cPuzIjSaUEA90i7NqRZsyWR+uOkOBVHHj60gYOPuOCw0Ihk/lj+1uSD0Q7FMXwAwdBFphzWLBqq8x8P/cn+CjK5XhfkAsgcclQ2otmA/RLQq3ukGABegxECUtz8OEFqS6Yxg50RY5CbAiIYbou/zCF9IkdkeV74i9D7cOshCJI5YbtTRK2sJdl8Go44dHrXooRSATsPO9hHpzQ4pjHUgVw1Lg1JYpQa5IPkSyCTAwp7kftJuigzHHniaXrv36zvsB3esoYXYrDNuCbs09PQw8eY0cJjbjdwX1No97fnx7m1dUhy8mupDy42D9otKzppGyOuTKwApRAOz3aYFCSrobcxhUM6bbM3XBHs5B/Zol9uRsAo+mZ0How+Q6AcluhR3aIoaDrFBIwso10A2ZeBMYYiL/iLFRRwRn4TVEV0Fsxb33p0dbbasKYH40vBy7823/mroC2IaX9iiYKphHZ/ZgNxt0pEXe/nnh3W5f9EhHSZ3GvE868hN3xAAE/tEEcMPq964gKwLaKY2cPkT3lKCINjrWxY8TeZslywHB/YiYgcvx+FsuoZjiaDY6sQxKVVXM6QzwkZmAtIrMVwVubK7KifjScOs7O6jEZomdBDugn5eibiB+6RNPboRc/Is7If/HdM/Zbyg52TEjK2NoVdBS3Ch0ZIMTn5ZEYs3iN3BeJi36jPywHty34rZVRdKTZMfDFjf609LGKIknEALZNsC5r8szIjKiTCserzlP4lSxpH4LRpUZ7K8evi7s/uwa1ncSf2PeEdyIT4xAa5dpodN7aUel2/jP+bHXUEAD14kRmn70uWEKlV7iDkJ2HwyCJVusXARhhVkMrTQED8BM6gRGGkLAYL7GxqvGmU5VmN2wJYvUsCFovcREhC2gaS/A1BIvY3pB8rZX+/BKQOQPxxHtXMM51XXtbC3oe9XneSegrekwY4ahCE0G1aBWc+606edbJ/tuuRDIseC43TI3MvE2BN/gDsZVdssUJmgQ+r4adUYziDXNFEQCLYOek5nXObN5ThlNOI7+73TZmagdH8xipWkRcU212U3w/RzCu9NwFJNXkx0zCYn6WHbNYHmHcJUKyy4pwEjsIsq3EgpAft2crwug5IDO+zmOf9BYgG1CiRituz5aqdc3Ofy5uDRmdNOUDJ6+tLpytYVE1QmjqYyMDMarRl+1uXhJLr3bwexUmGv1CpwQPs/Cz0f/cE8euiM6RVdfjhDWTAMctdFUGTqm2YJZyQW4NhK5nIrgO7qIxhKPmbqLb7Bvhf3Q5uLjt1lJ2y7aT1i7S3ZHSGWY6IwDOrJtV0/oa41deUPweo1+Z0uyoLZ0gFPhlABaNqeHEmntaCIBuBp68uL0R+87NlPmhqJX8wYsWeoaDUIGZUFIJiKYLtSfh2EZYO8eNBAoUWC+0CI6yJfiahsTY359Dg6X86vSWcLXllUQlEbGZpuJkvHOaPJiaKPcWvARBQpA8EZh5u3qRLF8LPTwf6AU7edPcdTwLRNSsY7Hj1Gk1LS255b7J/YLzEbJdSD1DsGKnGdrQRcI9YyKOIsEWLRu5FA8OcxeSOJ+pLp/S9/wUr7G11TVl2HiZ+ihUArGgIlc0Ju0G7fZD5u6xggoEQY+bSf/+ynP/7qi7UCsuYqbMJqGlz3tfkjNpnUvsWKCZQGmJJg1Te5Z3l/2s3v1UaBAWHZOIgWHaO3gZZy4k/hfti3KFu5VeZNjtxhipzWBcLpP5zVahUrFMW4PP3Yeno5n46HeZSiJwTp4jhO/qqPKZRZgTadbd/AOlQOhZVnSCmW2buEnHpDh7UlbgPgLt2sx/12PezGnhr0hMtADAGu/UMxJqf8tANzHpGKkkSLotcZUoshSZaDvthPZhVF2BfR8Eooo3J42O+2S6+IVdms40GKv1kVIuVSQaw8yFQWZVHXNb5Owjap+PEn3oHXL2+vT15cTsFaMZg77SO1dAHW2EyRYWy2LqBQCfX0lW1GQhQONLzx9gJDvEpCEUY3OZhRDPvZmawDCXSUrJ8Symcb78XaPXYNhkCrYcZO3WaoQANODZk7GnXMy/8BNoNE0QfHgKdoYGYgFUfcolft1E2S78R6hvBtXmqzaHS8Bh6AmpnpAW943jhcR3EqI5QXx+PL6eWqpthz3KOH0M5IDYEhY8TSG4Z88sTB1EkwWJCwmvSlPmtmwUWd7Gpa7eJqAA5REKsDlrjA3OEPL5aPjZ/c+k9HTGrodRty95yZR7MDE94K1CypoOl0UFrRc+qPQtoKe3FYzzQR8sd6VwKMGJpI7YUbFP3DKUrZa8NrDyFntz9yisV6JLxCoRjpKu6/6+KaTzSJJnnFVZhJPK0+mKohgM0Xt7AkIKCvpUZPaTsILENbSY0DXXTsIzRw3QAzlsKY8QZd4W1DOUN3R0K8rrzOC4zoEPkq+Lu1iTDtBOscPSjJDErgui8YVuZm6kEBvndRTnCc/0l32Tm+0pDebbto5+j+IJXnVjNuhWDF1KLAsXXy+He7mybImNBj9L7Olrd+CDZHh8AzBOeQ5bLj4oRCYw3sTB+j9QRzRxLtKtx4ljX0JkyKwB7bFdsWEFO2odXow+MOWPn19XKuJiPMtdc54vsYQvK9wQmNxAENlxYaMWIL/C8I2O4A2tJ6c5418MP6vJcTr2yTYZpdwDVm1HlZAU1BjwCLXJuNONdBqVQ81IihGuTjO/+PA+jo1+qTfumDBsEmrwN+cMx5kazUD4qI1HikVAmKGj1Qk+qooyLgBHAdlA7ujrqkNdaiRKJ0HBqk0f+6AY8WFcPk48vEHOkA5SEmrzWSwxM2CHgKbyCY7GawmgIYYNCbZX+9u6YQELiDjtee0WJd3UU5NzDI7WFwJe3w5kdVnsZTdpzTWdqxmSNXOLewEw50JQ4BKGspzPxa4t4LfXpzNu0lEKIUkM+xn0pepzWyda4mV8zmW4uTKo6S44zOHghahB+R3Wu0SN67YEOpiosLEp5eKKEkbyE+aT3vu5VhYL18HPYEu55KVMhIOd0wZAB3ydA+UkJcn4yd62dVx02BGmp6tIvnFAmVDDo4XHVQE+mI7WTrlx3VOTO0+tRuq/KotKRnx1cymLZ6mtOh1yfVUsSq1qOjL1M0a7otuVuICcgd2VKZEYsRTyN5dX7cU1qzwyE7HlAd7uNEuKrKbZlkRaDFYUlnry2kNbTsl47myVfnwfcRDtMKgEbkRkW9AwYTMxzQ+cv1IbtACLPajmh3V5I6M4QvIXIQnpxMWWEAu9YGOacbVbw42i/tuiopST6v72HBjrqtx/I1DpRB10ukJWFyZSQeKaI1vAbJuNfM64mnydJuwSk7HdYXYfRE+eLVQXxqLwx3c7epK57Gn9a3YEBXnRaxd7AdXW1SJ2qRCM+2CRdMSKOxUYQbx1eYM2Xl62OR8qan4gEn7bBwi5T1bguYgeIFafmKnpiS3BokQRmCkMTDOSJwp/F0vT05k4eo1aKaoITbk4RwlFg6igG67UiU9CMWlSiUflosCK5t9fk2nuGwt04QeJbgKKWeIHUaFs5jZU5ttBe7Wz9uu3mQXVu/dd/W8871fZQkUehDHbE1ve9Yq6sQGV6JpPpiTi9ZxJE5aZ4hsEORpVhv3LT10U5KhE5AsO6NGhSUS3IkAk6W3i47DmvS4SeYBbtKkohYP7c8sHE0torAETtSkuCuDOxhMaqAxX7rJktPcBCZTUYLc7B14g8jV4hp3LWrOk9JXJ4d36CkSLxXDl3maDopobjqa1QFI/EIc4tnK6aTCrWjQiF1NmtWouu5ngpl21SMT5b7Y40oMksGP6JfQINeeRQcHN3DKxRBO2OV4VwVGtkaiuujfP0sQ8R4S1O6tfakxLpMNBwMpfPLc4NBlTlJ9JYJe3J3HI4wzgxeAZYytRaXSnZOQHkq1fUsk2cccYZsFtJJsZSmvG0LtL0qpzgqKJGHPqaKKSVIWr3DdLNJDKvL/OAg51qv5y7dUZRY3gSECn8jC1smoVG8qyfqbh/5WDh0d0HdxaGa0AbmFmClKEu4bQsenVxHVcmxCfqkzAFb7Oiai0KM4lwv6Vj+f+H/6vAO/lm+o+1mJvQ/FIcPufvwj0FrOo6tPysV7xLGhAZ3lvAw3x3+dQQfX8GH+PjwR8XTyC+YYSql2aye1U/LB3c3G/y7WxWpuV5vvhrAp6f59yF8fhZfjWGty+8j+PLSftVt11FotzuPTuTL7sXmlnwcps6dqc2IWlocjtpau91sLivT6dRquVwo5HCCg1eWlw4eWFyYn5udmZ6anBgfGx0ZHhoc6O/r6dzf0u5621odzb1NjbUNvfV19pre6iqzrddqKat8PxXlulKdsbhQra36FORr8uS5a6pylAohHS4TyqQSsYgjqDaczedxmXRqFplIwPNITod5zFQmh1m9Div2ueTIuAojZgDDVl769YxboseTjMzd5pbNrEdw8y9FQAhM89m5LldlwegaoMoPjvhc/VQRViD7S4/x0M/S+nCjFLcIurdIMnCaXDQL7mcM6erBrRc5xI8m8QsvkMFge0ZhGxWgyY76rcqnj2G8DD3tPG0tYIiTMINAkblEWIKcYaI01hn3uk2ZpdhNOKfzh3tvMNbIwIY6rtndQYMWEhe2fjdtdACJuMm4DmQ2tfYllNt9uQyKp1ROXsSFEd0U59q+d+j3988OqfkMXXSsmPhgJgV+UrEtjgMZHbuKWxKa+KVAx+eJjvT4kSenKTzpMiFJcx3vNCIBCUVYM2mpAc6R2nYfOZtP2InuZalVn1gVsCbC3xnhehB6uuIZEV4s5Y0bUUCORdyJbW9K2A1kDN+SNtVL8BjQXqT5AognH/+77ttHFA/PwGuHFG2qFSIpD8B9m61Xhs0w8DupD98sYNDtOi8KTeiTBtu2lW1GuIw6S9BBFyV7DoFkpNel6NpAAMPvlWl9IAf+hRfZFAIcf/QYkft7TyKQEE/4b8F2mqECELqhJ/mcBI266yVyfWEjFI16l4zlqqXXDaToTKtsC8oEyPERiPkbkvICX5ibkxrsdVaubxM4p67fAtt1TYuccpE2aHe9S3CaJcI+ZW6Q8BOlbpPH0YK3GuaG8iRj52cvnvHyy0m0TMm2QtIURTXhVrW9lDZ2bxaafvLyxXOTanwk3TckERyvWlBqeI2OmLFddntnneGw0JDF3E+aU/1p1RXXn3cc8C5xk4etqqI5l+VlOWjodt9ic8S0Xf29Vp628Qkq//74+99+/dXHx4e7shLthbdQhvf8jal4vSXIdthp8fUKdFpFp8kNXKL1bo2DVl7CpWjbVi3/8uHVi2dP7258ku4D0Tl8w686BJRqA8VRioKNg8tEmx3Mb5oTvL8pQABK9f/74P9SNX/9H5Qa/ke+q671x8vif4e3DA4Ar4yA/kPqw9D/cQvwK0FM+v0S66E/wINWvllzAnYUDzKFeP3BVNGc9BxH9YvgCOZwdnIth5H0MwjGTWwijb2mhkS/A1WVNeSI5qyyWtgb+2C1ojm6xBXloYZPs0G9Tox7SAcn5goiS/JcryGslgLHrIlg/KHKalz0AaqUiDI0FjlLpJsNpBxtOoZawq+QTb7eoaoTx3LBLMeVe0JfqFQ3dhpEKSmSaF4EK370Eh60Ygz2GMElhUkrc6RMGEZ3w6BywVsEWuHBCV0iUYp46Qq+0sM7h9CNS/jpCInxnaRYne5kg6T4Tu7CQYKOkahUPEdaJ+KbLWDq+ubBGEeJr9eIZBzI+g+k/RGUVLVbtmAQGzS04UphXJFdEQ0lyJ+jKsfTzVq/GYT1iXSt4FFuhLQFnpWOvJAbOklM5rPl+nSsJjz/cllm+Oc3DPMb+naZKMWTU6sYJYX0+MO5fEBklRCpQo57DudWw661OFWPMI5sFL2fqkoisY4Rx/G0yDoiUgZlHyQqd/BJD6KBZn6gOV7w/ymCZnPB/zPEt62ZrNAmZghzKcLJgbB8SxOgrY/1qjGCK4jzWTOjtswev4ppKkpNm4RUW7jkCKp6gsmXCuxCsI/lrzcEZdOejXyHEYIz3KOQ0c+zKXPESghN66ZDoJcJWk0YKyJYswS4j8P4ZC6ZSUAFaPmGK7wqnhEvjtfH06HTGbbIqI0s1fhToSo15nKTVPUkxhM2ReWKVjlnfuzNQ8Bjg3SXUybBcKljmNZEtyIrnAidngBbK/dhw5GrSBGqUcvlS18pkrPv85RzY3mKnJAd0dCTuIF6JgAc2EOAdQG0KRBHeHv5uhrgLd5aaUmK+wCp31RV5bAqGz/3KyoTceVglxMcyVfoWg/icRRTpeCajdyqfrrsQRfRQHUzxvEgTSE+Qwhlw9wlxIMqQce+oe5+RCoUsq01+n8qVISvOF9z5KNqjCM3bYqN4LB5yWpJnHqaoB4nsI/hrhSOOZkqNWCiNCo1wIFam4Bk2aXlZYLjY/s50Q8FrokEsmbNQqZwMnHgpZMIx310K7VGBcQge1UmEJhF0+1PoDbTtG7VTFALM5JBAIrNap3NxMn3CjWSmnWK9nHSZ5+or93Hrw/dnyBrgY10VuP3Ob7i5P2zY8WLnMLTsuebF3IiApU07GUGiSOkH2IJnCfeSbuOf2RxJOwxXpcw036qKRE8M3g9thIKk4V8CaSjnjKF4AC9LqFfFnTiJNBDdNqCHt2lQ4QchraMBPRNz4K9Zh94dsVd1tCvQrfe7WfNGiHnzbQhj0e3CY7di1mm11fmiEo4ov0vyJihB/bp3R4Dq6mKRxXcQS9O8zYhlZDKticE3nj1BfSYjSJsM6Ms+RiKEFXAYQkINkR/j6TUCgI9QddGAV9LlGTflC3WFhvCF/BFwjwM5oLvs/MFoJ4Hz5saXvTMS8d23yJ+yGwJPE5PGzrkkMtvEGePA5rVQBLPhzWXMJswtbAMm5ZOSV6bWtcHWuML33xOwLN/2xXzbnFsFJ/4xskqxTP+UnADWA87TkE2RZwIIhB3EGCjFEAhDAYw/iOZBEAL3n8CIjiASWQJAgDU9/+0WYJYBg6DOE8Oq/ga+0hIsEmm2dFUoyI9/V2+OG0A33vjDUHoLRuGofe5o3pvgAMFI4BNeO/vBwTTABkG24AgHAIDMsUrxggIDtiUqBxDIuSBc1jHXmCbxcbD25kM/AUa9rc/et5X8IV/Pff/bEqf+uajqrG7Xm5R1JTtBpOrQ9e4DQwJ3SFgIkycdzFY9RvNF1YAAZxYTXtAazyVmb8gPgKocVpMhWTHbVRhq68vIBDwcaej63K5IfNz1y22/Tp1Qklb8KNL17dukFPEtKgaNW9Z4vgz5hBOAvome/SJljNDn9vlYW+8Ihckpx9sRmhIby08T33tvrwjl4bOdOkpepBzsbvTUyABlQWed2V0uEUvLxk9pDwF5lBMDxDOMIKh0bmxIwYJG23eQwQBQiL+FYrRcq/68rB7+oYA+l8XprqPCaDIUoAjpyyGTwHQy0gWMExZLVY3LwCnHE1jO1DCPltJZ2nwXIlbb5GSWRkBCSIPRVxrkjfHyKwtb5TqWFa2DRiQcI3XVE9sF8ab2MjzBDFOyjYXyWYAdoZQtpB+G05LIeikEFlC9luUXy3uwnjpGCDNNhvqEjtgKB7EP1bTW9f4zOeByZzEyZInRMmYbh2IGgFSJ7FnNAEr5zQSUQr0u4qj4ITLUDYmSRBISLkPINXRamT0TNwBNMguPXZCcrnmwfwsCD12UiB17LE2LWMI6ae8BOD4gvX2LwuSobI/Ara5KT43s5uNIcJIGShdbTE+KyRiYA7qaRABAqJ+aV46RSqIrgkQA6oDa/+chyAmADtrsi4+hqIYqS7IBEABJAUNAoqwIOTKGLSKXv52BsqQFaW6HCOCZ7hRgAkVKCwijIYkEYBopJwiVjxPAH96ObSguD7Q47hnR1NmmE2BjFHp6rYosEsGbM0N3AYnPBkaJIb+8Bi66Rw7VJzMSrESFjNWEoPQZKnRqkKLRBWKnmyvKaqRrIbSpVgnPvCKI1zHr/b0NUYQ2wFhvHf/YeXPzA6rGShkRsFMNCOvw32qfpk5xAY5cM8yUhQtEqrMbNWayZDws4Iw8AJHZTMSCQ0XbCDh4Q3g8sMCIpTBXq7LYeygVmQk6+STxyA0nRUZF2q74aW2FoM/1MzITX5rb4OLS4yM58z39CpDvqgYZORXbY6xPEmAvFBRwqoYg2dzsGwxJhzDX9oVyMjXkmeBTSuI5UwzDBI7ynaGkDT6VRUMP4bMW30kZq7WQsfuv6PUtFJ3CzaOlAZH+0VbJmRq/VGWgbdIEDX6Wtoz4INCmsJ9ZNm6GgRuAn+vh+0EgBhSi3IWoilUz5uiqoA/ciPZcKFfG4AWD0OOBxYtxcmT7GZkpIMIQUHs4jMgiTSMtgBsb3jGENDHFpoSIBdZjAeTg4WQAPAYmikBF3ISg4Zz/xpECnzXh5jChHWkBo1ChLTDuFRnupngJbYR7664BMJqS9DUEbi4ldNimwLbCKWm2QC0DAEmB6fNkQ4CgF+D0A09ItNg/nGsCs01zH6zuyIXm7WC1f/++8gnEzdZzZhWR0IbpS105cKFa6jYFsgoA0kkhy+uUQO18IxFkULX110oxhFxKWrC/8zspFYhgKX2hsotUKlDjVr1Uyj2VsSMZ04Whd6qPLfCDWj9O8AcYoo2maWYhslCyXrmWEiFPB98IloEOMd2dDMqOooNH2wyynRjq7eadOQHo0qqdk5nFLX3KHVD6qacCHmB4UcvO8jy4GSXb8wZfAquaD2JGoZIM7dgqtlLHYbV8w6qvIhPG7OVUOrrctJbkSuJHPWBoeJjrUVPK6htCp/leMWluyyXqLyV6M8MRNDWxtqBdhPACFi9li7zUfm/YI5Nu8pvWDee1O7V+T9VilqouSMyT2S3l7sbdUJUtSrO7XFnW6/ffgcDhSiVz2UOEC8iXBFXvxTYfe7Bfy8C7wD5Du0F+EBLqAFkkFQdfxLX0CCQA5YMG5uBLoLWwYjmJO0EN4ZNpj5Jd5rE+vZnpZKBqV/WRIbTG1k8k5m+SNuFcS1yBnhs53ZjSSl7EH+EzMPo1LRjl5BSTcUg31JsXQh3E6UTJYZy86Aq/GJAEFlNpbFNcb2J8w09Rh8iCfUd0tnkmMZyUCGT431loRhFgmNqFUyx6UuNv1nYnOqkQanPKzn8GRsUjkOikNYxG6bfmA3JRN0SGqwMTkjCOjfAvcnZw7pKDrnKUbTFJYhKXjAvxwSNla/7YjQmShYz7FpguJCNnKW44wGdnTBoLG5k16ynSbUrIeoTIlz8plaSmbVTTdZHJKsj5VxIlWrhhSdnupSY0IUgp7O7jCFmXx0CMq4S7QRePbFPFk7+j0cE+QolLRDysc0gBMf4JqmWyARadxmOj6lWmtqyUt3RoGwyItIGx0iObF1SejLJ3Ws4zEBbpBBUMEnI2az0ZsMFy4smkFR838mBTXQ7YSFKboT0PccnMdMkMoFfJc0dCT5M0AF5NhexnNf0eEa5FNW0tHAyooN8jSCfgDLYiVJrwORiIszIXildHFkdcWX3IDkzkmp0kbIKlbKYd+8CyqKdKAZjv8Q3Ki0JUWKaZIBmb5HihKtCLL7xGxfvmEyLS2iY5nU3y5rS5WIhuAQaAo+OTNCjGfUswjFXHts1b5rVgjZANNbvtvlUibxf0+w0dpHQlWbuHXqllKPp+7A/ou0MORlD5RCo/9aQqsWIb4200SrMG5GeemZvCwXS5KucYy90cd16c4EOYRDKrXWJpckOXdISxYn+hYfmQxmOHvcxHfepVyh4xWa/ywesMW/7Dz/RqxMJEIrtfmF9id2DYhAwfcY6xb2B6lk+EB7ij4AGkRyShxNLCYk3LSVl9+FEzPTcKHSGgQXqAxXgzAKKJJp+DXQIVOAdM2X8Cyoqs4eTHQmbgrOISkDfOtY8xJ6OqSkZaw5/8Nq80PUspU7J0i4iJCkXsUYxUb53aFJZqDCdAUJGZNQUSPo8nyoJ920+Hw5SCXTZqdtjsm3EHVZ7ASEk4wZq4r0wntmKkJTWhyVjEFMqaAbSGAULcSWuBOXHytQxxgTQCUeCQaWLytEeojd5TzNKQxLXmikeWd7YoekLKyY/qLojkjUJq5QBaSQv1E1i8Z2+56ZckfJZoCxTkXTqolQQefFh34YBcEn9IY53SVj2JvAD/0s2ZhBpJJbWTOWeDcUG4/DcMvUGFtv55LJkHmO+VdCx5W3vkecmhnxat/DajBgjJBpjzqaazbIH4QxYXFh7gLCAAyXtrzjMiXBbZXDNgXFLRbxsksm2h3oj4apInZK5QCTCMWDOUYmcJc06UNFxnxYP8aCVamSV1mPUvBYJUxJEa+oUjqzvnTohKCQzHNMg57VIg7Rt2QIjUfPDlRy7qnb/myLbUeH61wEJRHhQKc+Tk2dUq1aZzyEZu4Osl0bcNTzh/MIjRZ1PEQWyv9karSovgRpp9UnnDDs9s1p1VXRLnYR4chiBl2zWwIcoYmtEc7Q9NqVpBLX1HTEl0KVhyS7QIufhtwka1XNEfZcW5xChCP7N2Zletovu1YrYXtGnxETXV125ALWr9YLjipwsO68jXHHiYfZcVw5AEQqGK9+SDCpehXop/pz6QxBcMV5GXoUDY7BtzccKottG+TdaYMIQDnDgL3T1GQMPJVzlGl1ksML1H699seVRRWkQ4BazXCGddTZIIpN4+ljgO/lUs8Um2xQHEWZY4hVzzPOalyxeSPZ/0bIhdqikIJ4aRlAphsvkCqVKrbGyttHqCJLSG4wms8XWzt7B0cnZxXUySyjjQnrz7sOnL99+AEAQGAKFwRFIFBqDxeEJRBKZQqXRGUwWm8Pl8QVCkVgilckVSpVao9XpDUaT2WK12R3OllYD3NraecNa2/i0nt3ghiF9PWBd3YZ3HoHs7xoag8XhCYkTSWQKNZfP8+vpQg2FyXKYRmd092WxOVweXyAUiSVSmVyhVKk1Wp3eYDQxNTO3sLSytrG1s3dwdHJ2cXVzR6LQGCwOTyCSyBQqjc5gstgcLo8vEIrEEqlMrlCq1BqtTg8MRpPZYrXZfbduw6Yt26ms+AdkF34QDFM2y+5wutwer88PgBCMoBhOkBTNYLLYHC6PLxCKxBKpTK5QqtQarU5vMJrMFqvN7nC63AAgCAyBwuAIJAqNweLwBCKJTKHS6Awmi83h8vgCoUgskcrkCqVqWccysgsAmvuZLsDuo17XHL6XDZL5Tsnhil9ouchuRrK+2vtbx/nttTLMreLy22+f8gfJRy5+r1hdqjR26xF+oQ1jt84Rp+5iqPO/UMcUIdr5rK/gXirZnQmptGU7McUAESaUcSFnGXkWaEGKMKGMC6m0ZTsxpQARJpRvxv85qZuckpqWniEvAvDBl0VgW/PXEl7vGM2dYROfbsRTz0ctfTiuCztyjnR7EfUCpuZi+DB3ChEmlHFxzFs6pOIKESaUcSFVcWmjn79DM3Qn18o96ss3tiiRT/uqov+9mJ1M8p6ySr5KOl+ZS+qfsh8LwKn5S0k4T+nwQMsOutzbtEud9q1nM/3xTEgrkkrWq78lZJPaY7z3mD+K/KHd0wS17xc+1kmAWu5+S7STXi+JX9nkROW3BEOZaguuEfRZ5PdvGX4xHA9h7f3XEliY0bIQpECXHAPMXHccUrfGRWTdl7Zi10NpJ6YeASJMqHOa559++/pf698/bYw7prf9wOOxHJPFXpzVcq4Wc7XvASJMGBdSact2YuoBIMKEMi6IgqLmow8AAAAAAECSJEmSJCkiIiIiIiIioqqqqqqqqqpqZmZmZmZmZqZdc3BwcHBwcHBwcHBwcHBwcHBxcXFxcXFxcXFxcXFRTZYj3G1wz/bQ/yHlRJHRXufVt6mvSW11C/51PjuK9F55Pb0LavYBDBzSUMAURVBg4H1uquqVZfrSIoO+5mF2mvPEQcBO4brPGs7YDkVNDndc+Ws5ryVsIfS9llmMOxp7FI7XH4hNaDw2dfUo3iv5jdLQ0cYszT1Z/vtr66t8vgkNbweE3Q68Dhzp9Xblj+PhPn8wn/kY8nE+3vT3iLtr7HV6NvKtnak8QBNcUYrzikhxFzUkwPeaY1JbzT3KBVafZvJ0orlPjk2bLX+vTf2mX96tj6f+m2msZwGE9wFmh7wLINCY+wbogokf7vQFgMFwKxlwApnl4bej3H1dnNzrmUTXYOeHYjR80a0DDwAGjIWYlwcMwOCRnQHje/GgAfu8DfpAHvESDrPn3gEIf58sySlVI1vzefLtGHd/Fyev5B3Q8+M29o3ec6I1N7kYXQFjYw=="};

const EMBEDDED_ASSETS = {
  controlsJs: "(() => {\n  let sequence = 0, active = null;\n  const selects = new WeakMap();\n  const make = (tag, className, text) => {\n    const element = document.createElement(tag);\n    element.className = className;\n    if (text !== undefined) element.textContent = text;\n    return element;\n  };\n  const paths = {\n    more: 'M5 12h.01M12 12h.01M19 12h.01',\n    chevron: 'm6 9 6 6 6-6',\n    check: 'm5 12 4 4L19 6',\n    toggle: 'M12 3v9M7 5a8 8 0 1 0 10 0',\n    renew: 'M8 3v4M16 3v4M4 10h16M12 13v5M9.5 15.5h5M6 5h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2',\n    reset: 'M3 10a9 9 0 1 1 2 8M3 4v6h6',\n    disconnect: 'm4 4 16 16M8 8l-3 3a4 4 0 0 0 6 6l2-2M11 5l2-2a4 4 0 0 1 6 6l-2 2',\n    'rotate-link': 'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2',\n    'rotate-credentials': 'M15 11a4 4 0 1 0-3-7 4 4 0 0 0 3 7ZM12 10 3 19v2h3v-3h3v-3h3',\n    archive: 'M3 4h18v5H3zM5 9v11h14V9M10 13h4',\n    restore: 'M3 4h18v5H3zM5 9v11h14V9m-10 6 3-3 3 3m-3-3v6',\n    delete: 'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7'\n  };\n  function icon(name) {\n    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');\n    svg.setAttribute('viewBox', '0 0 24 24');\n    svg.setAttribute('aria-hidden', 'true');\n    const path = document.createElementNS(svg.namespaceURI, 'path');\n    path.setAttribute('d', paths[name] || paths.more);\n    svg.append(path);\n    return svg;\n  }\n  function create({ label, ariaLabel, options, onSelect, menu = false, className = '' }) {\n    const root = make('div', 'am-dropdown ' + className);\n    const trigger = make('button', 'am-select-trigger');\n    trigger.type = 'button';\n    trigger.id = 'am-control-' + ++sequence;\n    trigger.setAttribute('aria-haspopup', menu ? 'menu' : 'listbox');\n    trigger.setAttribute('aria-expanded', 'false');\n    if (ariaLabel) trigger.setAttribute('aria-label', ariaLabel);\n    const caption = make('span', 'am-select-caption', label);\n    if (menu) trigger.append(icon('more'));\n    trigger.append(caption, icon('chevron'));\n    const popup = make('div', 'am-select-popup');\n    const optionsPane = make('div', 'am-select-options');\n    optionsPane.setAttribute('role', 'presentation');\n    popup.append(optionsPane);\n    popup.id = trigger.id + '-popup';\n    popup.hidden = true;\n    popup.setAttribute('role', menu ? 'menu' : 'listbox');\n    popup.setAttribute('aria-labelledby', trigger.id);\n    trigger.setAttribute('aria-controls', popup.id);\n    const popover = typeof popup.showPopover === 'function';\n    if (popover) popup.setAttribute('popover', 'manual');\n    root.append(trigger, popup);\n    let items = [], current = 0, search = '', searchedAt = 0;\n    function position() {\n      if (active !== control) return;\n      const rect = trigger.getBoundingClientRect(), vv = window.visualViewport;\n      const leftEdge = (vv?.offsetLeft || 0) + 12, topEdge = (vv?.offsetTop || 0) + 12;\n      const rightEdge = leftEdge + (vv?.width || innerWidth) - 24;\n      const bottomEdge = topEdge + (vv?.height || innerHeight) - 24;\n      if (!trigger.isConnected || rect.bottom < topEdge || rect.top > bottomEdge) return close();\n      const width = Math.min(menu ? 256 : Math.max(rect.width, 240), rightEdge - leftEdge);\n      popup.style.width = width + 'px';\n      const below = Math.max(0, bottomEdge - rect.bottom - 8);\n      const above = Math.max(0, rect.top - topEdge - 8);\n      const desired = Math.min(optionsPane.scrollHeight + 16, 420);\n      const up = below < desired && above > below;\n      const available = up ? above : below;\n      popup.style.maxHeight = Math.min(420, available) + 'px';\n      const height = popup.getBoundingClientRect().height;\n      const x = Math.max(leftEdge, Math.min(rect.right - width, rightEdge - width));\n      const y = Math.max(topEdge, up ? rect.top - height - 8 : rect.bottom + 8);\n      popup.style.left = x + 'px';\n      popup.style.top = y + 'px';\n      const placed = popup.getBoundingClientRect();\n      popup.style.left = x - (placed.left - x) + 'px';\n      popup.style.top = y - (placed.top - y) + 'px';\n      popup.dataset.side = up ? 'above' : 'below';\n    }\n    function focus(index) {\n      current = (index + items.length) % items.length;\n      items[current]?.focus({ preventScroll: true });\n      items[current]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });\n    }\n    function close(restore = false) {\n      if (active !== control) return;\n      active = null;\n      if (popover && popup.matches(':popover-open')) popup.hidePopover();\n      popup.hidden = true;\n      trigger.setAttribute('aria-expanded', 'false');\n      if (!popover) root.append(popup);\n      if (restore && trigger.isConnected) trigger.focus({ preventScroll: true });\n    }\n    function open(last = false) {\n      if (trigger.disabled) return;\n      active?.close();\n      items = []; search = '';\n      optionsPane.replaceChildren();\n      options().forEach(option => {\n        const item = make(menu ? 'button' : 'div', 'am-select-option');\n        if (menu) item.type = 'button';\n        item.tabIndex = -1;\n        item.setAttribute('role', menu ? 'menuitem' : 'option');\n        if (!menu) item.setAttribute('aria-selected', String(!!option.selected));\n        if (option.danger) item.classList.add('am-option-danger');\n        if (option.disabled) item.setAttribute('aria-disabled', 'true');\n        if (menu) item.append(icon(option.value));\n        item.append(make('span', 'am-option-caption', option.label));\n        if (!menu) item.append(icon('check'));\n        if (!option.disabled) {\n          items.push(item);\n          item.addEventListener('focus', () => { current = items.indexOf(item); });\n          item.addEventListener('click', () => { close(true); onSelect(option.value); });\n        }\n        optionsPane.append(item);\n      });\n      if (!items.length) return;\n      active = control;\n      popup.hidden = false;\n      if (popover) popup.showPopover();\n      else (root.closest('dialog') || document.body).append(popup);\n      trigger.setAttribute('aria-expanded', 'true');\n      position();\n      const selected = items.findIndex(item => item.getAttribute('aria-selected') === 'true');\n      focus(last ? items.length - 1 : Math.max(0, selected));\n    }\n    trigger.addEventListener('click', () => active === control ? close() : open());\n    trigger.addEventListener('keydown', event => {\n      if (['ArrowDown', 'ArrowUp'].includes(event.key)) {\n        event.preventDefault(); open(event.key === 'ArrowUp');\n      }\n    });\n    popup.addEventListener('keydown', event => {\n      const key = event.key;\n      if (['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(key)) {\n        event.preventDefault();\n        if (key === 'Enter' || key === ' ') items[current]?.click();\n        else focus(key === 'Home' ? 0 : key === 'End' ? items.length - 1 : current + (key === 'ArrowDown' ? 1 : -1));\n      } else if (key === 'Tab') close(true);\n      else if (key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {\n        search = (Date.now() - searchedAt > 700 ? '' : search) + key.toLocaleLowerCase();\n        searchedAt = Date.now();\n        const found = items.findIndex(item => item.textContent.trim().toLocaleLowerCase().startsWith(search));\n        if (found >= 0) focus(found);\n      }\n    });\n    const control = { root, trigger, popup, caption, open, close, position };\n    return control;\n  }\n  function enhance(select) {\n    if (selects.has(select) || select.multiple) return;\n    const label = select.getAttribute('aria-label') || [...(select.labels || [])].map(l => [...l.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim()).join(' ');\n    const control = create({\n      ariaLabel: label,\n      options: () => [...select.options].map(o => ({ value: o.value, label: o.textContent, selected: o.selected, disabled: o.disabled })),\n      onSelect(value) {\n        const changed = select.value !== value;\n        select.value = value; sync(select);\n        if (changed) {\n          select.dispatchEvent(new Event('input', { bubbles: true }));\n          select.dispatchEvent(new Event('change', { bubbles: true }));\n        }\n      }\n    });\n    control.trigger.id = select.id + 'Control';\n    control.popup.setAttribute('aria-labelledby', control.trigger.id);\n    const labels = [...(select.labels || [])];\n    select.after(control.root);\n    select.hidden = true;\n    select.dataset.themed = 'true';\n    labels.filter(l => l.htmlFor === select.id).forEach(l => { l.htmlFor = control.trigger.id; });\n    selects.set(select, control);\n    control.ariaLabel = label;\n    select.addEventListener('change', () => sync(select));\n    select.form?.addEventListener('reset', () => setTimeout(() => sync(select), 0));\n    sync(select);\n  }\n  function sync(select) {\n    const control = selects.get(select);\n    if (!control) return;\n    control.caption.textContent = select.selectedOptions[0]?.textContent || '';\n    control.trigger.setAttribute('aria-label', [control.ariaLabel, control.caption.textContent].filter(Boolean).join('، '));\n    control.trigger.disabled = select.disabled;\n  }\n  document.addEventListener('pointerdown', event => {\n    if (active && !active.root.contains(event.target) && !active.popup.contains(event.target)) active.close();\n  });\n  document.addEventListener('focusin', event => {\n    if (active && !active.root.contains(event.target) && !active.popup.contains(event.target)) active.close();\n  });\n  document.addEventListener('keydown', event => {\n    if (active && event.key === 'Escape') {\n      event.preventDefault(); event.stopPropagation(); active.close(true);\n    }\n  }, true);\n  document.addEventListener('scroll', event => {\n    if (active && !active.popup.contains(event.target)) active.position();\n  }, true);\n  window.addEventListener('resize', () => active?.position());\n  window.visualViewport?.addEventListener('resize', () => active?.position());\n  window.visualViewport?.addEventListener('scroll', () => active?.position());\n  window.addEventListener('hashchange', () => active?.close());\n  document.addEventListener('close', event => {\n    if (active && event.target.contains(active.root)) active.close();\n  }, true);\n  window.AmyraxControls = {\n    menu: config => create({ ...config, menu: true }).root,\n    sync,\n    enhance,\n    isOpen: () => !!active,\n    close: () => active?.close()\n  };\n  document.querySelectorAll('select[data-panel-select]').forEach(enhance);\n})();\n",
  controlsCss: "\n.am-dropdown,.am-select-popup{--control-bg:var(--card-bg,var(--card,#121a25));--control-field:var(--field,#0e1621);--control-text:var(--text-white,var(--text,#eef3f8));--control-muted:var(--text-muted,var(--muted,#9ba9bc));--control-line:var(--border,var(--line,#25303e));--control-accent:var(--primary-red,var(--accent,#38c9ad));font-family:var(--font-family,Vazir,Arial,sans-serif);box-sizing:border-box;direction:rtl}\n.am-dropdown{min-width:0;max-width:100%}\n.am-select-trigger{display:flex;align-items:center;gap:10px;width:100%;min-height:46px;padding:10px 13px;border:1px solid var(--control-line);border-radius:12px;background:var(--control-field);color:var(--control-text);font:inherit;font-size:13px;line-height:1.8;text-align:start;cursor:pointer;transition:background .16s,border-color .16s;box-sizing:border-box}\n.am-select-caption{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.am-select-trigger svg,.am-select-option svg{width:18px;height:18px;flex:0 0 18px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}\n.am-select-trigger>svg{color:var(--control-muted)}\n.am-select-trigger>svg:last-child{width:16px;height:16px;flex-basis:16px;transition:transform .16s}\n.am-select-trigger[aria-expanded=true]{border-color:var(--control-accent);background:var(--control-bg)}\n.am-select-trigger[aria-expanded=true]>svg:last-child{transform:rotate(180deg);color:var(--control-accent)}\n.am-select-trigger:focus-visible{outline:2px solid var(--control-accent);outline-offset:3px}\n.am-select-trigger:disabled{opacity:.5;cursor:default}\n.am-select-popup{position:fixed;inset:auto;margin:0;padding:7px;border:1px solid var(--control-line);border-radius:16px;background:var(--control-bg);color:var(--control-text);box-shadow:0 12px 32px #0005,inset 0 1px 0 #ffffff08;z-index:12000;display:flex;flex-direction:column;overflow:hidden;max-width:calc(100vw - 24px)}\n.am-select-options{min-height:0;overflow:auto;overscroll-behavior:contain;border-radius:9px;padding:1px;--scroll-track:transparent}\n.am-select-popup[hidden],select[data-themed=true]{display:none!important}\n.am-select-option{display:flex;align-items:center;gap:11px;width:100%;min-height:44px;box-sizing:border-box;margin:0;padding:9px 11px;border:1px solid transparent;border-radius:10px;background:transparent;color:var(--control-text);font:inherit;font-size:13px;font-weight:400;line-height:1.8;text-align:start;cursor:pointer;outline:none}\n.am-option-caption{flex:1;min-width:0;overflow-wrap:anywhere;unicode-bidi:plaintext}\n.am-select-option>svg{color:var(--control-muted)}\n.am-select-option[role=option]>svg{visibility:hidden;color:var(--control-accent)}\n.am-select-option[aria-selected=true]{color:var(--control-accent);background:#38c9ad12}\n.am-select-option[aria-selected=true]>svg{visibility:visible}\n.am-select-option:focus{background:#38c9ad16;border-color:#38c9ad55;color:var(--control-accent)}\n.am-select-option:focus>svg{color:inherit}\n.am-select-option.am-option-danger{color:#f4a697;border-top-color:var(--control-line);border-radius:0 0 10px 10px;margin-top:5px;padding-top:12px}\n.am-select-option.am-option-danger>svg{color:inherit}\n.am-select-option.am-option-danger:focus{background:#ed8e7014;border-color:#ed8e7055;border-radius:10px}\n.am-select-option[aria-disabled=true]{opacity:.45;cursor:default}\n.users-toolbar>.am-dropdown{min-width:200px}\n.user-actions.am-dropdown{padding:0;border:0;background:none;margin:0;flex-shrink:0}\n.user-actions .am-select-trigger{width:44px;height:44px;min-height:44px;padding:12px;justify-content:center;border-radius:10px}\n.user-actions .am-select-caption,.user-actions .am-select-trigger>svg:last-child{display:none}\n.user-actions .am-select-trigger>svg:first-child{stroke-width:3}\n.manual-format>.am-dropdown{flex:1}\n.manual-format .am-select-caption{direction:ltr;text-align:left;font-size:12px}\n@media(hover:hover){.am-select-trigger:not(:disabled):hover{border-color:var(--control-accent);background:var(--control-bg)}.am-select-option:not([aria-disabled=true]):hover{background:#38c9ad12;color:var(--control-accent)}.am-select-option.am-option-danger:hover{background:#ed8e7014;color:#ffb8a9}}\n@media(max-width:650px){.am-select-trigger,.am-select-option{min-height:48px}.users-toolbar>.am-dropdown{width:100%;min-width:0}.am-select-popup{border-radius:14px}}\n@media(prefers-reduced-motion:reduce){.am-select-trigger,.am-select-trigger>svg:last-child{transition:none}}\n\n\n@media (forced-colors:none){\n  :root{--scroll-track:var(--bg-color,var(--bg,#0c111a));--scroll-thumb:#2c8274;--scroll-hover:var(--primary-red,var(--accent,#38c9ad))}\n  @supports (color:color-mix(in srgb,black,white)){\n    :root{--scroll-thumb:color-mix(in srgb,var(--scroll-hover) 55%,var(--card-bg,var(--card,#121a25)))}\n  }\n  *{scrollbar-width:thin;scrollbar-color:var(--scroll-thumb) var(--scroll-track)}\n  \n  @supports selector(::-webkit-scrollbar){\n    *{scrollbar-width:auto;scrollbar-color:auto}\n    ::-webkit-scrollbar{width:10px;height:10px}\n    ::-webkit-scrollbar-track{background:var(--scroll-track);border-radius:999px}\n    ::-webkit-scrollbar-thumb{background:var(--scroll-thumb);background-clip:padding-box;border:2px solid transparent;border-radius:999px;min-height:36px;min-width:36px}\n    ::-webkit-scrollbar-thumb:hover,::-webkit-scrollbar-thumb:active{background-color:var(--scroll-hover)}\n    ::-webkit-scrollbar-button{display:none;width:0;height:0}\n    ::-webkit-scrollbar-corner{background:var(--scroll-track)}\n    @media(pointer:coarse){::-webkit-scrollbar{width:6px;height:6px}::-webkit-scrollbar-thumb{border-width:1px}}\n  }\n}\n\n\n.am-dialog-scroll,.user-dialog>form,.cinema-modal-scroll{min-height:0;overflow:auto;overscroll-behavior:contain;--scroll-track:transparent;border-radius:16px}\n.user-dialog textarea,.usage-table-wrap{--scroll-track:transparent}\n@supports selector(::-webkit-scrollbar){\n  .am-select-options::-webkit-scrollbar-track{margin-block:5px}\n  .am-dialog-scroll::-webkit-scrollbar-track,.user-dialog>form::-webkit-scrollbar-track,.cinema-modal-scroll::-webkit-scrollbar-track{margin-block:10px}\n  .user-dialog textarea::-webkit-scrollbar-track{margin-block:8px}\n  .usage-table-wrap::-webkit-scrollbar-track{margin-inline:10px}\n}\n",
  updatesJs: "(() => {\n  const button = document.getElementById('updateBtn'), banner = document.getElementById('updateNotice'), dialog = document.getElementById('updateDialog');\n  if (!button || !banner || !dialog) return;\n  const api = '/' + (location.pathname.split('/').filter(Boolean)[0] || 'amyrax') + '/api/update';\n  const title = document.getElementById('updateNoticeTitle'), summary = document.getElementById('updateNoticeSummary');\n  const action = document.getElementById('installUpdate'), checkButton = document.getElementById('checkUpdate');\n  const status = document.getElementById('updateDialogStatus'), releaseLink = document.getElementById('updateReleaseLink');\n  const phases = {\n    downloading:'در حال دریافت و بررسی فایل نصب…', installing:'در حال آماده‌کردن نسخهٔ جدید؛ پنل فعلی همچنان فعال است…',\n    restarting:'نسخه آماده شد؛ پنل در حال راه‌اندازی مجدد است…', testing:'در حال بررسی اجرای نسخهٔ جدید…',\n    complete:'به‌روزرسانی با موفقیت انجام شد.', failed:'به‌روزرسانی انجام نشد؛ نسخهٔ فعلی حفظ شد.',\n    'rolled-back':'نسخهٔ جدید آماده نشد؛ نسخهٔ قبلی بازیابی شد.'\n  };\n  const busy = phase => ['downloading','installing','restarting','testing'].includes(phase);\n  let info = null, request = null, applying = false, monitoring = false, timer = null, dismissed = '', announced = '', target = '', until = 0, uiError = '';\n  const write = (node, value) => { node.textContent = value; };\n  try { dismissed = localStorage.getItem('amyrax-update-dismissed') || ''; } catch {}\n  function render() {\n    if (!info) return;\n    const phase = info.operation?.phase || 'idle', inProgress = busy(phase) || applying;\n    button.classList.toggle('has-update', info.newer); button.classList.toggle('busy', inProgress);\n    button.setAttribute('aria-label', info.newer ? 'نسخهٔ '+info.latest+' آمادهٔ به‌روزرسانی است' : 'وضعیت به‌روزرسانی پنل');\n    button.title = button.getAttribute('aria-label');\n    const rollback = phase === 'rolled-back' || (phase === 'complete' && !!info.rollback), failed = phase === 'failed';\n    const noticeKey = rollback ? 'rolled-back:'+info.rollback?.at : failed ? phase+':'+info.operation.updatedAt : info.latest;\n    banner.hidden = !(inProgress || ((rollback || failed || info.newer) && dismissed !== noticeKey));\n    write(title, inProgress ? 'پنل در حال به‌روزرسانی است' : rollback ? 'نسخهٔ قبلی بازیابی شد' : failed ? 'به‌روزرسانی کامل نشد' : 'نسخهٔ '+info.latest+' منتشر شد');\n    write(summary, inProgress ? phases[phase] || 'در حال آماده‌سازی…' : rollback || failed ? info.rollback?.message || info.operation.error || phases[phase] : 'نسخهٔ جدید Amyrax آماده است؛ می‌توانید همین‌جا پنل را به‌روزرسانی کنید.');\n    banner.dataset.state = rollback || failed ? 'error' : inProgress ? 'busy' : 'available';\n    write(document.getElementById('updateCurrentVersion'), info.current);\n    write(document.getElementById('updateLatestVersion'), info.latest || 'هنوز بررسی نشده');\n    let text = inProgress ? phases[phase] || 'در حال شروع به‌روزرسانی…' : rollback || failed ? info.rollback?.message || info.operation.error || phases[phase]\n      : info.reason || (info.newer ? 'با زدن دکمه، نسخهٔ جدید دریافت می‌شود. اتصال‌های جاری هنگام راه‌اندازی مجدد موقتاً قطع می‌شوند.' : info.disabled ? 'بررسی خودکار با تنظیمات سرور خاموش شده است.' : info.latest ? 'پنل شما به‌روز است.' : 'هنوز نسخهٔ جدیدی دریافت نشده است.');\n    if (info.checkError && !inProgress) text += ' '+info.checkError;\n    if (uiError && !inProgress) text += ' '+uiError;\n    write(status, text); status.dataset.state = rollback || failed || info.checkError ? 'error' : 'normal';\n    action.disabled = inProgress || !info.canApply;\n    write(action, inProgress ? 'در حال به‌روزرسانی…' : info.latest ? 'به‌روزرسانی به '+info.latest : 'به‌روزرسانی پنل');\n    checkButton.disabled = inProgress || !!request || info.disabled;\n    document.getElementById('dismissUpdateNotice').disabled = inProgress;\n    if (info.url && /^https:\\/\\/github\\.com\\/[\\w.-]+\\/[\\w.-]+\\/releases(?:\\/tag\\/v?\\d+\\.\\d+\\.\\d+)?$/.test(info.url)) releaseLink.href = info.url;\n    const checked = info.checkedAt ? new Date(info.checkedAt).toLocaleString('fa-IR', { timeZone:'Asia/Tehran', month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }) : 'هنوز انجام نشده';\n    write(document.getElementById('updateCheckedAt'), 'آخرین بررسی: '+checked);\n    if (info.newer && announced !== info.latest && !info.checkError) { announced = info.latest; showToast('نسخهٔ '+info.latest+' پنل منتشر شده است.'); }\n  }\n  async function refresh(fresh = false) {\n    if (request) return request;\n    request = (async () => {\n      try {\n        const next = await amyraxRequestJson(api+(fresh?'/check':''), { method:fresh?'POST':'GET', headers:fresh?{'X-Amyrax-Req':'1'}:{}, timeoutMs:20000 });\n        info = next; uiError = '';\n        if (busy(info.operation?.phase) && !monitoring) { monitoring = true; target = info.operation.version; until = Date.now()+8*60000; }\n        if (monitoring && info.rollback) monitoring = false;\n        if (monitoring && info.current === target && info.operation?.phase === 'complete') { monitoring = false; location.reload(); return; }\n        if (monitoring && ['failed','rolled-back'].includes(info.operation?.phase)) monitoring = false;\n        if (monitoring && Date.now() > until) { monitoring = false; uiError = 'راه‌اندازی بیش از حد معمول طول کشید؛ وضعیت را دوباره بررسی کنید.'; }\n      } catch (error) {\n        if (error.status === 401) { monitoring = false; uiError = 'نشست مدیریت پایان یافته؛ دوباره وارد پنل شوید.'; }\n        else if (!monitoring) { uiError = error.message; write(status, uiError); if (fresh) showToast(error.message); }\n      } finally { request = null; render(); schedule(); }\n    })();\n    render(); return request;\n  }\n  function schedule() {\n    clearTimeout(timer);\n    if (document.hidden || !navigator.onLine) return;\n    timer = setTimeout(()=>refresh(), monitoring ? 3000 : 60000);\n  }\n  function open() { if (!dialog.open) dialog.showModal(); render(); if (!info) refresh(); }\n  async function apply() {\n    if (applying || !info?.canApply) return;\n    applying = true; target = info.latest; render();\n    try {\n      info = await amyraxRequestJson(api, { method:'POST', headers:{'X-Amyrax-Req':'1','Content-Type':'application/json'}, body:JSON.stringify({version:target}), timeoutMs:25000 });\n      monitoring = true; until = Date.now()+8*60000;\n    } catch (error) {\n      // A lost response does not imply that the operation failed. Read the server state before retrying.\n      write(status, error.message); await refresh();\n      if (!monitoring) { uiError = error.message; showToast(error.message); }\n    } finally { applying = false; render(); schedule(); }\n  }\n  button.addEventListener('click', open);\n  document.getElementById('openUpdateDialog').addEventListener('click', open);\n  document.getElementById('closeUpdateDialog').addEventListener('click', ()=>dialog.close());\n  action.addEventListener('click', apply); checkButton.addEventListener('click', ()=>refresh(true));\n  document.getElementById('dismissUpdateNotice').addEventListener('click', ()=>{\n    if (busy(info?.operation?.phase)) return;\n    dismissed = info?.rollback ? 'rolled-back:'+info.rollback.at : info?.operation?.phase === 'failed' ? 'failed:'+info.operation.updatedAt : info?.latest || '';\n    try { localStorage.setItem('amyrax-update-dismissed', dismissed); } catch {}\n    render();\n  });\n  document.addEventListener('visibilitychange', ()=>{ if (!document.hidden) refresh(); else clearTimeout(timer); });\n  window.addEventListener('online', ()=>refresh()); window.addEventListener('offline', ()=>clearTimeout(timer));\n  window.addEventListener('pageshow', schedule); window.addEventListener('pagehide', ()=>clearTimeout(timer));\n  refresh();\n})();\n",
  updatesCss: ".update-notice[hidden]{display:none!important}\r\n.update-notice{display:flex;align-items:center;gap:14px;margin:0 0 22px;padding:18px 20px;border:1px solid color-mix(in srgb,var(--primary-red,#46cbb3) 35%,transparent);border-radius:18px;background:color-mix(in srgb,var(--primary-red,#46cbb3) 7%,var(--card-bg,#171d23));animation:update-arrive .25s ease-out}\r\n.update-notice-icon{display:grid;place-items:center;flex:0 0 42px;width:42px;height:42px;border-radius:13px;background:color-mix(in srgb,var(--primary-red,#46cbb3) 12%,transparent);color:var(--primary-red,#46cbb3)}\r\n.update-notice-icon svg{width:22px;height:22px}\r\n.update-notice-copy{flex:1;min-width:0}.update-notice-copy strong{font-size:14px}.update-notice-copy p{margin:5px 0 0;font-size:12px;line-height:1.9;opacity:.8;overflow-wrap:anywhere}\r\n.update-notice .button{flex-shrink:0;white-space:nowrap}.update-notice .icon-button{flex-shrink:0}\r\n.update-notice[data-state=error]{border-color:#bd8056;background:color-mix(in srgb,#bd8056 7%,var(--card-bg,#171d23))}\r\n.update-dialog{width:min(540px,calc(100vw - 28px));max-height:calc(100dvh - 40px);overflow:auto;padding:26px;border:1px solid var(--border,#303942);border-radius:24px;color:var(--text-white,#e8edf3);background:var(--card-bg,#171d23);box-shadow:0 30px 100px #0006}\r\n.update-dialog::backdrop{background:#070b10b8;backdrop-filter:blur(4px)}\r\n.update-dialog-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}.update-dialog h2{margin:0;font-size:20px}\r\n.update-version-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:18px 0}.update-version-grid>div{padding:14px;border:1px solid var(--border,#303942);border-radius:14px}.update-version-grid small{display:block;opacity:.65;font-size:12px;margin-bottom:8px}.update-version-grid strong{display:block;font-size:21px;overflow-wrap:anywhere}\r\n.update-dialog-status{font-size:13px;line-height:2;min-height:52px;overflow-wrap:anywhere}.update-dialog-status[data-state=error]{color:#d49b74}\r\n.update-data-note{margin:16px 0;padding:13px 15px;border-radius:13px;background:color-mix(in srgb,var(--primary-red,#46cbb3) 6%,transparent);font-size:12px;line-height:2;opacity:.85}\r\n.update-dialog-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px}.update-dialog-actions button{flex:1;justify-content:center;min-width:160px}.update-dialog-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:18px;font-size:11px;opacity:.7}.update-dialog-footer a{color:inherit;text-decoration:underline;text-underline-offset:3px}\r\n#updateBtn{position:relative}#updateBtn.has-update::after{content:\"\";position:absolute;top:5px;right:5px;width:7px;height:7px;border-radius:50%;background:var(--primary-red,#46cbb3);box-shadow:0 0 0 3px var(--card-bg,#171d23)}#updateBtn.busy svg{animation:update-spin 1.5s linear infinite}\r\n@keyframes update-arrive{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}@keyframes update-spin{to{transform:rotate(-360deg)}}\r\n@media(max-width:600px){.update-notice{flex-wrap:wrap;padding:14px;gap:10px}.update-notice-copy{flex-basis:calc(100% - 62px)}.update-notice .button{flex:1;justify-content:center}.update-dialog{padding:20px}.update-dialog h2{font-size:18px}}\r\n@media(prefers-reduced-motion:reduce){.update-notice,#updateBtn.busy svg{animation:none}}\r\n",
  studioJs: "(() => {\n  const el = (tag, cls, value) => { const e = document.createElement(tag); if (cls) e.className = cls; if (value !== undefined) e.textContent = value; return e; };\n  function init(root, base) {\n    if (!root || root.dataset.studioReady) return; root.dataset.studioReady = 'true';\n    let data = null, editing = null, result = null, loading = false, mutating = false;\n    root.classList.add('studio-shell');\n    const intro = el('div', 'studio-intro'), introCopy = el('div'); introCopy.append(el('h2', '', 'کانفیگ، به سبک شما'), el('p', '', 'کانفیگ‌های خودکار آماده‌اند. اینجا یک اتصال شخصی بسازید و به همان اشتراک اضافه کنید.')); intro.append(introCopy, el('span', 'studio-badge', 'CONFIG STUDIO')); root.append(intro);\n    const error = el('div', 'studio-message'); error.hidden = true; error.setAttribute('role', 'alert'); root.append(error);\n    const layout = el('div', 'studio-layout'), editor = el('section', 'studio-card'), saved = el('section', 'studio-card');\n    const form = el('form'), formTitle = el('h3', '', 'ساخت کانفیگ شخصی'), grid = el('div', 'studio-grid'), advanced = el('details', 'studio-advanced'), advancedGrid = el('div', 'studio-grid'); advanced.append(el('summary', '', 'تنظیمات پیشرفتهٔ اتصال'), advancedGrid);\n    const fields = {}, field = (key, caption, type, parent = grid, options, help = '') => {\n      const wrapper = el('label', 'studio-field' + (key === 'name' || key === 'variant' || key === 'accountId' ? ' full' : '')); wrapper.append(el('span', '', caption));\n      const input = el(type === 'select' ? 'select' : 'input'); if (type !== 'select') input.type = type;\n      input.id = 'admin-studio-' + key; input.name = key; input.autocomplete = 'off';\n      if (type === 'select') for (const [value, name] of options || []) { const o = el('option', '', name); o.value = value; input.append(o); }\n      if (['server', 'port', 'host', 'sni', 'path'].includes(key)) input.dir = 'ltr';\n      if (type === 'checkbox') wrapper.classList.add('studio-check'); wrapper.append(input); if (help) wrapper.append(el('small', '', help)); parent.append(wrapper); fields[key] = input; return input;\n    };\n    field('accountId', 'حساب اتصال', 'select');\n    field('name', 'نام کانفیگ', 'text').required = true; fields.name.maxLength = 80;\n    field('variant', 'پروتکل و انتقال فعال', 'select').required = true;\n    field('enabled', 'نمایش در لیست و اشتراک', 'checkbox').checked = true;\n    field('server', 'آدرس اتصال (اختیاری)', 'text', advancedGrid, null, 'خالی = آدرس فعلی پنل. دامنه یا IP جایگزین باید واقعاً به همین سرور برسد.');\n    field('port', 'پورت عمومی (اختیاری)', 'number', advancedGrid, null, 'خالی = پورت فعلی. پورت جدید باید از قبل در هاست به سرویس متصل باشد.'); fields.port.min = 1; fields.port.max = 65535;\n    field('path', 'مسیر WS / HTTPUpgrade', 'text', advancedGrid, null, 'خالی = مسیر خودکار. مسیر دلخواه هنگام ذخیره روی همین پنل فعال می‌شود.');\n    field('host', 'Host انتقال (اختیاری)', 'text', advancedGrid);\n    field('sni', 'SNI (اختیاری)', 'text', advancedGrid, null, 'باید با دامنه و گواهی سرور سازگار باشد.');\n    field('fingerprint', 'اثر انگشت TLS', 'select', advancedGrid, [['chrome','Chrome'],['firefox','Firefox'],['safari','Safari'],['edge','Edge'],['ios','iOS'],['android','Android'],['randomized','Randomized'],['random','Random'],['360','360'],['qq','QQ'],['','بدون اثر انگشت']]);\n    const actions = el('div', 'studio-actions'), preview = el('button', 'studio-button', 'پیش‌نمایش'), save = el('button', 'studio-button primary', 'ذخیره و افزودن به ساب'), cancel = el('button', 'studio-button', 'کانفیگ جدید'); preview.type = cancel.type = 'button'; save.type = 'submit'; cancel.hidden = true; actions.append(preview, save, cancel);\n    const output = el('div', 'studio-result'); output.hidden = true; const outputSelect = el('select'), text = el('textarea', 'studio-output'); outputSelect.id='admin-studio-output'; text.readOnly = true; text.setAttribute('aria-label', 'خروجی کانفیگ');\n    for (const [value, caption] of [['uri','لینک اتصال'],['xrayJson','Outbound · Xray'],['singboxJson','Outbound · sing-box']]) { const o = el('option', '', caption); o.value = value; outputSelect.append(o); } outputSelect.setAttribute('aria-label', 'قالب خروجی');\n    const outputActions = el('div', 'studio-actions'), copy = el('button', 'studio-button', 'کپی خروجی'), download = el('button', 'studio-button', 'دانلود خروجی'), qr = el('button', 'studio-button', 'QR'); copy.type = download.type = qr.type = 'button'; outputActions.append(copy, download, qr); output.append(el('h3', '', 'خروجی آماده'), outputSelect, text, outputActions);\n    form.append(formTitle, grid, advanced, actions); editor.append(form, output); saved.append(el('h3', '', 'کانفیگ‌های شخصی شما'), el('p', '', 'هر مورد فعال با مشخصات همان حساب، کنار کانفیگ‌های خودکار به اشتراک اضافه می‌شود. خاموش‌کردن این مورد، حساب را غیرفعال نمی‌کند.')); const list = el('div', 'studio-list'); saved.append(list); layout.append(editor, saved); root.append(layout);\n    async function request(suffix = '', method = 'GET', body) {\n      const options = { method, cache:'no-store', credentials:'same-origin', headers:method === 'GET' ? {} : {'Content-Type':'application/json','X-Amyrax-Req':'1'}, ...(body ? {body:JSON.stringify(body)} : {}) };\n      if (window.amyraxRequestJson) return amyraxRequestJson(base + suffix, {...options,timeoutMs:120000});\n      const controller = new AbortController(), timer = setTimeout(()=>controller.abort(),120000);\n      try { const response = await fetch(base + suffix, {...options,signal:controller.signal}); const value = await response.json(); if (!response.ok || !value.ok) throw new Error(value.error || 'دریافت اطلاعات ناموفق بود.'); return value; }\n      finally { clearTimeout(timer); }\n    }\n    const message = (value, success = false) => { error.textContent = value; error.hidden = !value; error.classList.toggle('success', success); };\n    const enhance = select => { select.dataset.panelSelect = ''; window.AmyraxControls?.enhance?.(select); window.AmyraxControls?.sync(select); };\n    const sync = select => window.AmyraxControls?.sync(select);\n    function collect() { return { accountId:fields.accountId.value, name:fields.name.value.trim(), variant:fields.variant.value, server:fields.server.value.trim(), port:fields.port.value ? Number(fields.port.value) : null, sni:fields.sni.value.trim(), host:fields.host.value.trim(), path:fields.path.value.trim(), fingerprint:fields.fingerprint.value, enabled:fields.enabled.checked, ...(editing ? {revision:editing.revision} : {}) }; }\n    function updateOutput() { text.value = result?.[outputSelect.value] || 'این انتقال در sing-box پشتیبانی نمی‌شود؛ خروجی Xray را انتخاب کنید.'; copy.disabled = download.disabled = !result?.[outputSelect.value]; qr.hidden = outputSelect.value !== 'uri'; sync(outputSelect); }\n    function showResult(value) { result = value; output.hidden = false; outputSelect.value = 'uri'; updateOutput(); }\n    function edit(p = null) { editing = p; form.reset(); fields.accountId.value = data.accountId; for (const key of ['name','variant','server','sni','host','path','fingerprint']) fields[key].value = p?.[key] ?? (key === 'variant' ? data.options[0]?.value || '' : key === 'fingerprint' ? 'chrome' : ''); fields.port.value = p?.port ?? ''; fields.enabled.checked = p?.enabled ?? true; formTitle.textContent = p ? 'ویرایش ' + p.name : 'ساخت کانفیگ شخصی'; save.textContent = p ? 'ذخیرهٔ تغییرات' : 'ذخیره و افزودن به ساب'; cancel.hidden = !p; advanced.open = !!p; output.hidden = true; [fields.accountId, fields.variant, fields.fingerprint].forEach(sync); settings(); }\n    function settings() { const option = data?.options.find(o=>o.value===fields.variant.value); fields.path.disabled = !['ws','httpupgrade'].includes(option?.transport); fields.sni.disabled = fields.fingerprint.disabled = !option?.tls; if(fields.path.disabled)fields.path.value=''; sync(fields.fingerprint); }\n    function renderList() {\n      list.replaceChildren(); for (const p of data.profiles) {\n        const card = el('article', 'studio-profile'); card.append(el('h4', '', p.name), el('small', '', p.variant + ' · ' + (!p.enabled ? 'غیرفعال در ساب' : !p.node ? 'انتقال در دسترس نیست' : 'فعال در ساب')));\n        const a = el('div','studio-actions'), button = (caption, handler, cls='') => { const b = el('button','studio-button '+cls,caption); b.type='button'; b.addEventListener('click',handler); a.append(b); return b; };\n        button('ویرایش',()=>{edit(p);fields.name.focus();}); const exportButton=button('خروجی / Outbound',()=>showResult(p.node)); exportButton.disabled=!p.node;if(!p.node)exportButton.dataset.unavailable='true';\n        button('حذف',async()=>{if(!confirm('کانفیگ «'+p.name+'» از لیست و ساب حذف شود؟ حساب اتصال حفظ می‌شود.'))return;await run(async()=>{await request('/profiles/'+p.id,'DELETE',{revision:p.revision});await load();edit();changed();message('کانفیگ از اشتراک حذف شد.',true);});},'studio-delete');\n        card.append(a); list.append(card);\n      } if (!data.profiles.length) list.append(el('div','studio-empty','هنوز کانفیگ شخصی نساخته‌اید. اولین مورد را با فرم کنار صفحه بسازید.'));\n    }\n    async function load(preserve = false) {\n      if (loading) return; loading = true;\n      try { data = await request('?accountId=' + encodeURIComponent(fields.accountId.value || 'shared'));\n        fields.accountId.replaceChildren(); for(const a of data.accounts || [{id:data.accountId,name:'حساب شما'}]) {const o=el('option','',a.name);o.value=a.id;fields.accountId.append(o);}fields.accountId.value=data.accountId;\n        const current=fields.variant.value; fields.variant.replaceChildren();for(const o of data.options){const opt=el('option','',o.value);opt.value=o.value;fields.variant.append(opt);}if(data.options.some(o=>o.value===current))fields.variant.value=current;\n        for(const key of ['server','port','host','sni','path']) fields[key].placeholder=String(data.defaults[key]);\n        [fields.accountId,fields.variant,fields.fingerprint,outputSelect].forEach(enhance); renderList(); if(!preserve)edit(); renderEgress(); preview.disabled=save.disabled=!data.options.length;\n      } catch(e){message(e.message);} finally {loading=false;}\n    }\n    async function run(task) { if(mutating)return;mutating=true;root.querySelectorAll('button').forEach(b=>b.disabled=true);message('');try{await task();}catch(e){message(e.message);}finally{mutating=false;root.querySelectorAll('button').forEach(b=>b.disabled=false);updateOutput();settings();[fields.accountId,fields.variant,fields.fingerprint].forEach(sync);preview.disabled=save.disabled=!data?.options.length;list.querySelectorAll('[data-unavailable]').forEach(b=>b.disabled=true);} }\n    const changed = () => { window.dispatchEvent(new Event('amyrax-configs-changed')); window.amyraxRefresh?.(); };\n    preview.addEventListener('click',()=>{if(form.reportValidity())run(async()=>{showResult((await request('/preview','POST',collect())).node);message('پیش‌نمایش آماده است؛ برای فعال‌شدن مسیر و اضافه‌شدن به اشتراک، ذخیره کنید.',true);});});\n    form.addEventListener('submit',e=>{e.preventDefault();run(async()=>{await request('/profiles'+(editing?'/'+editing.id:''),editing?'PATCH':'POST',collect());await load();edit();changed();message('کانفیگ ذخیره شد و در اشتراک همان حساب قرار گرفت.',true);});});\n    cancel.addEventListener('click',()=>edit());fields.accountId.addEventListener('change',()=>load());fields.variant.addEventListener('change',settings);outputSelect.addEventListener('change',updateOutput);\n    copy.addEventListener('click',async()=>{try{if(window.copyTextToClipboard)await copyTextToClipboard(text.value);else{await navigator.clipboard.writeText(text.value);message('خروجی کپی شد.',true);}}catch{message('کپی خودکار ممکن نشد؛ متن خروجی را انتخاب و کپی کنید.');text.select();}});\n    download.addEventListener('click',()=>{const blob=new Blob([text.value],{type:outputSelect.value==='uri'?'text/plain':'application/json'}),url=URL.createObjectURL(blob),a=el('a');a.href=url;a.download='Amyrax-'+(outputSelect.value==='uri'?'config.txt':outputSelect.value==='xrayJson'?'Xray-outbound.json':'SingBox-outbounds.json');a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});\n    qr.addEventListener('click',()=>{window.openQr?.(result.uri,result.name);});\n    let egress, egressName, egressInput, egressEnabled, egressState, apply;\n    {\n      egress=el('section','studio-card studio-egress');egress.append(el('h3','','اتصال خروجی پنل'),el('p','','برای عبور ترافیک VPN این پنل از سرور دیگر، لینک اتصال یا یک Outbound استاندارد Xray وارد کنید. بررسی، ساختار تنظیمات را تأیید می‌کند. اعمال تغییر، پنل را یک‌بار راه‌اندازی مجدد می‌کند و اتصال‌های فعلی لحظه‌ای قطع می‌شوند.'));\n      egressState=el('p');egress.append(egressState);const egGrid=el('div','studio-grid');\n      const ef=(caption,input)=>{const l=el('label','studio-field full');l.append(el('span','',caption),input);egGrid.append(l);return input;};\n      egressEnabled=ef('عبور از سرور دیگر',el('input'));egressEnabled.type='checkbox';egressEnabled.parentElement.classList.add('studio-check');\n      egressName=ef('نام سرور خروجی',el('input'));egressName.maxLength=80;\n      egressInput=ef('لینک اتصال یا Outbound JSON',el('textarea'));egressInput.spellcheck=false;egressInput.autocomplete='off';egressInput.setAttribute('aria-label','لینک یا Outbound سرور خروجی');\n      const ea=el('div','studio-actions');const egBody=()=>({enabled:egressEnabled.checked,name:egressName.value,input:egressInput.value,revision:data.revision});\n      const check=el('button','studio-button','بررسی تنظیمات'),store=el('button','studio-button primary','ذخیرهٔ Outbound');apply=el('button','studio-button','اعمال و راه‌اندازی مجدد');\n      check.addEventListener('click',()=>run(async()=>message((await request('/egress/check','POST',egBody())).message,true)));\n      store.addEventListener('click',()=>run(async()=>{await request('/egress','POST',egBody());await load(true);message('تنظیمات ذخیره شد؛ برای اعمال روی ترافیک، راه‌اندازی مجدد را بزنید.',true);}));\n      apply.addEventListener('click',()=>run(async()=>{await request('/egress/apply','POST',{});message('پنل در حال راه‌اندازی مجدد است؛ چند ثانیه بعد صفحه را تازه کنید.',true);}));\n      ea.append(check,store,apply);egress.append(egGrid,ea);layout.append(egress);\n    }\n    function renderEgress(){if(!egress)return;const e=data.egress;egressEnabled.checked=e.enabled;egressName.value=e.name||'';egressInput.value=e.input||'';egressState.textContent='وضعیت فعلی: '+(e.active?'عبور از '+e.activeName:'اتصال مستقیم')+(e.restartRequired?' · تغییرات در انتظار اعمال':'');apply.hidden=!e.restartRequired;}\n    root.addEventListener('input',e=>{if(form.contains(e.target)){output.hidden=true;result=null;}});\n    function visible(){return document.visibilityState==='visible'&&document.getElementById('viewStudio')?.classList.contains('active');}\n    window.addEventListener('hashchange',()=>{if(visible())load();});window.addEventListener('amyrax-refresh',()=>{if(visible())load(true);});if(visible())load();\n  }\n  window.AmyraxStudio={init};\n  const admin=document.getElementById('studioRoot');if(admin)init(admin,'/'+(location.pathname.split('/').filter(Boolean)[0]||'amyrax')+'/api/studio');\n})();\n",
  studioCss: ".studio-shell{--studio-accent:var(--primary-red,#38c9ad);color:var(--text-white,#edf2fa);display:grid;gap:20px;min-width:0;margin-bottom:20px}.studio-shell [hidden]{display:none!important}.studio-intro{display:flex;align-items:start;justify-content:space-between;gap:16px}.studio-intro h2{font-size:22px;margin:0 0 8px}.studio-shell p{color:var(--text-muted,#9caabe);font-size:12px;line-height:2;margin:6px 0 14px}.studio-badge{background:#38c9ad15;color:var(--studio-accent);border:1px solid #38c9ad30;border-radius:100px;font:11px Arial;padding:8px 12px;white-space:nowrap}.studio-layout{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:20px;align-items:start}.studio-card{border:1px solid var(--border,#263345);background:var(--card-bg,#111a28);border-radius:18px;padding:22px;min-width:0}.studio-card h3{font-size:16px;margin:0 0 12px}.studio-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.studio-field{display:flex;flex-direction:column;gap:7px;font-size:12px;min-width:0}.studio-field.full{grid-column:1/-1}.studio-field input,.studio-field select,.studio-field textarea,.studio-output{width:100%;box-sizing:border-box;border:1px solid var(--border,#263345);border-radius:10px;background:var(--field,#090f19);color:inherit;padding:11px 12px;font:inherit;min-width:0;min-height:44px}.studio-field small{font-size:11px;line-height:1.8;color:var(--text-muted,#9caabe)}.studio-field input[type=checkbox]{width:18px;min-height:18px;accent-color:var(--studio-accent)}.studio-check{flex-direction:row;align-items:center}.studio-advanced{margin-top:18px;border-top:1px solid var(--border,#263345);padding-top:16px}.studio-advanced summary{font-size:13px;cursor:pointer;margin-bottom:14px}.studio-actions{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-top:16px}.studio-button{border:1px solid var(--border,#263345);background:var(--field,#090f19);color:inherit;min-height:42px;border-radius:10px;padding:9px 15px;cursor:pointer;font:inherit;font-size:12px;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}.studio-button.primary{background:var(--studio-accent);color:#06221e;border-color:transparent;font-weight:700}.studio-button:disabled{opacity:.5;cursor:wait}.studio-button:focus-visible,.studio-field input:focus-visible,.studio-field textarea:focus-visible{outline:2px solid var(--studio-accent);outline-offset:3px}.studio-list{display:grid;gap:12px}.studio-profile{border:1px solid var(--border,#263345);border-radius:13px;padding:15px;overflow-wrap:anywhere}.studio-profile h4{font-size:14px;margin:0 0 5px}.studio-profile small{font:11px Arial;color:var(--text-muted,#9caabe)}.studio-profile .studio-actions{margin-top:12px}.studio-profile .studio-button{font-size:11px;padding:7px 10px;min-height:36px}.studio-empty{padding:30px 10px;text-align:center;font-size:12px;line-height:2;color:var(--text-muted,#9caabe)}.studio-message{border:1px solid #ed8e7040;background:#ed8e7010;border-radius:10px;color:#f6b3a4;padding:12px;font-size:12px;line-height:1.9;margin:10px 0}.studio-message.success{color:var(--studio-accent);border-color:#38c9ad40;background:#38c9ad09}.studio-output{min-height:160px;resize:vertical;direction:ltr;text-align:left;font:12px/1.8 Consolas,monospace;overflow-wrap:anywhere;word-break:break-all}.studio-egress textarea{min-height:130px;direction:ltr;font:12px/1.7 Consolas,monospace}.studio-egress{grid-column:1/-1}.studio-delete{color:#f6b3a4}.studio-shell .am-dropdown{width:100%}.studio-shell .am-select-trigger{width:100%}.studio-shell .am-select-caption{white-space:normal}.studio-head-row{display:flex;gap:10px;align-items:center;justify-content:space-between}.studio-head-row .studio-field{flex:1}.studio-result{border-top:1px solid var(--border,#263345);margin-top:20px;padding-top:18px}\n@media(max-width:1000px){.studio-layout{grid-template-columns:1fr}}\n@media(max-width:650px){.studio-grid{grid-template-columns:1fr}.studio-card{padding:16px}.studio-actions .studio-button{flex:1}.studio-intro{gap:8px}.studio-intro h2{font-size:19px}.studio-field input,.studio-field select,.studio-field textarea{font-size:16px}.studio-field.full{grid-column:auto}}\n@media(max-width:850px){.mobile-nav-bar{grid-template-columns:repeat(6,minmax(0,1fr))!important}.mobile-nav-bar .mob-link{font-size:10px}.mobile-nav-bar .mob-link svg{width:20px;height:20px}}\n",
  subscriptionHtml: "<!doctype html>\r\n<html lang=\"fa\" dir=\"rtl\">\r\n<head>\r\n  <meta charset=\"utf-8\">\r\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">\r\n  <meta name=\"theme-color\" content=\"#080c12\">\r\n  <meta name=\"robots\" content=\"noindex,nofollow,noarchive\">\r\n  <meta name=\"referrer\" content=\"no-referrer\">\r\n  <title>اشتراک شما | Amyrax Panel</title>\r\n  <link rel=\"icon\" href=\"/amyrax-assets/logo.svg\" type=\"image/svg+xml\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/subscription.css?v=__ASSET_VERSION__\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/controls.css?v=__ASSET_VERSION__\">\r\n  <script defer src=\"/amyrax-assets/controls.js?v=__ASSET_VERSION__\"></script>\r\n  <script id=\"subscriptionData\" type=\"application/json\"><!--SUBSCRIPTION_DATA--></script>\r\n  <script defer src=\"/amyrax-assets/vendor/qrcode.js?v=__ASSET_VERSION__\"></script>\r\n  <script defer src=\"/amyrax-assets/subscription.js?v=__ASSET_VERSION__\"></script>\r\n</head>\r\n<body>\r\n  <div class=\"ambient\" aria-hidden=\"true\"><span class=\"ambient-orb orb-blue\"></span><span class=\"ambient-orb orb-violet\"></span><span class=\"ambient-orb orb-cyan\"></span></div>\r\n  <main class=\"subscription-shell\">\r\n    <header class=\"brand-header\">\r\n      <a class=\"brand\" href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\" aria-label=\"کانال تلگرام AmyraxVPN\">\r\n        <img src=\"/amyrax-assets/logo.svg\" width=\"44\" height=\"44\" alt=\"\">\r\n        <span dir=\"ltr\">Amyrax <b>Panel</b><small>YOUR CONNECTION, SIMPLIFIED</small></span>\r\n      </a>\r\n      <button class=\"icon-button\" id=\"refreshSubscription\" aria-label=\"به‌روزرسانی اطلاعات\" title=\"به‌روزرسانی اطلاعات\"><svg viewBox=\"0 0 24 24\"><path d=\"M20 7v5h-5M4 17v-5h5M6.1 7a7 7 0 0 1 11.6-1L20 9M4 15l2.3 3A7 7 0 0 0 18 17\"/></svg></button>\r\n    </header>\r\n\r\n    <section class=\"glass summary-card\" aria-labelledby=\"subscriptionTitle\">\r\n      <div class=\"card-eyebrow\"><span>اشتراک شما</span><button type=\"button\" class=\"header-qr-button\" data-action=\"qr-sub-detail\" aria-label=\"نمایش QR لینک اشتراک\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z\"/></svg><span>لینک اشتراک</span></button></div>\r\n      <h1 id=\"subscriptionTitle\" dir=\"ltr\">Amyrax Panel</h1>\r\n      <p class=\"intro\">یک لینک برای همهٔ اتصال‌های شما.</p>\r\n      <div id=\"accountDetails\" class=\"account-details\" hidden><span id=\"accountStatus\"></span><span id=\"accountExpiry\"></span></div>\r\n      <div class=\"metrics\">\r\n        <div><span>مصرف این ماه</span><strong id=\"monthUsage\">—</strong></div>\r\n        <div><span>باقی‌ماندهٔ سقف ماهانه</span><strong id=\"remainingUsage\">تعیین نشده</strong></div>\r\n        <div><span>کانفیگ‌های موجود</span><strong id=\"nodeCount\">—</strong></div>\r\n        <div><span>آخرین به‌روزرسانی</span><strong id=\"lastUpdate\">—</strong></div>\r\n      </div>\r\n      <div class=\"usage-track\" id=\"usageTrack\" hidden><span id=\"usageProgress\"></span></div>\r\n      <p class=\"fine-print\">مصرف ثبت‌شدهٔ این پنل؛ سقف ماهانه طبق تنظیمات مدیر.</p>\r\n      <p id=\"connectionStatus\" class=\"connection-status\" role=\"status\" hidden></p>\r\n      <button class=\"primary-button\" id=\"copySubscription\"><svg viewBox=\"0 0 24 24\"><rect x=\"8\" y=\"8\" width=\"12\" height=\"13\" rx=\"3\"/><path d=\"M15 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3\"/></svg>کپی لینک اشتراک<span>↗</span></button>\r\n      <div class=\"link-preview\"><span id=\"subscriptionHost\" dir=\"ltr\"></span><span>تشخیص خودکار اپ</span></div>\r\n    </section>\r\n\r\n    <section class=\"glass chart-card\" aria-labelledby=\"chartTitle\">\r\n      <div class=\"section-heading\"><h2 id=\"chartTitle\">نمودار مصرف</h2><span class=\"pill neutral\" id=\"chartTotal\">—</span></div>\r\n      <div class=\"segmented chart-tabs\" aria-label=\"بازهٔ نمودار\"><button type=\"button\" data-period=\"day\" aria-pressed=\"true\">امروز</button><button type=\"button\" data-period=\"week\" aria-pressed=\"false\">۷ روز</button></div>\r\n      <div id=\"usageChart\" class=\"usage-chart\" role=\"img\" aria-label=\"نمودار مصرف ثبت‌شده\"></div>\r\n      <p class=\"chart-caption\" id=\"chartCaption\">مصرف به ساعت تهران؛ با عبور ترافیک، نمودار تکمیل می‌شود.</p>\r\n    </section>\r\n\r\n    <div class=\"segmented main-tabs\" role=\"tablist\" aria-label=\"بخش‌های اشتراک\">\r\n      <button id=\"appsTab\" type=\"button\" role=\"tab\" aria-selected=\"true\" aria-controls=\"appsPanel\" tabindex=\"0\">اپلیکیشن‌ها</button>\r\n      <button id=\"configsTab\" type=\"button\" role=\"tab\" aria-selected=\"false\" aria-controls=\"configsPanel\" tabindex=\"-1\">کانفیگ‌ها <span id=\"configBadge\" hidden>۰</span></button>\r\n    </div>\r\n\r\n    <section id=\"appsPanel\" role=\"tabpanel\" aria-labelledby=\"appsTab\">\r\n      <div class=\"section-lead\"><h2>با اپ دلخواه متصل شوید</h2><p>اپ را نصب کنید و لینک اشتراک را در بخش افزودن اشتراک وارد کنید.</p></div>\r\n      <div class=\"glass app-platforms\" id=\"appPlatforms\"></div>\r\n      <details class=\"glass help-card\">\r\n        <summary>اگر اپ به‌صورت خودکار تشخیص داده نشد</summary>\r\n        <p>بعضی اپ‌ها نام خود را هنگام دریافت اشتراک نمی‌فرستند. قالب مناسب را انتخاب و لینک سازگار را کپی کنید.</p>\r\n        <label for=\"manualFormat\">قالب خروجی</label>\r\n        <div class=\"manual-format\"><select data-panel-select id=\"manualFormat\"><option value=\"clash\">FlClash / Clash / Mihomo</option><option value=\"v2rayng\">V2rayNG</option><option value=\"streisand\" disabled>Streisand — Coming soon</option><option value=\"base64\">V2rayN / Shadowrocket</option><option value=\"singbox\">Sing-box JSON</option><option value=\"raw\">لینک‌های مستقیم</option></select><button type=\"button\" id=\"copyManual\" class=\"soft-button\">کپی</button></div>\r\n      </details>\r\n    </section>\r\n\r\n    <section id=\"configsPanel\" role=\"tabpanel\" aria-labelledby=\"configsTab\" hidden>\r\n      <div class=\"section-lead\"><h2>کانفیگ‌ها، در دسترس شما</h2><p>همه را یکجا بردارید یا فقط اتصال دلخواهتان را کپی کنید.</p></div>\r\n      <label class=\"search-field\"><svg viewBox=\"0 0 24 24\"><circle cx=\"10\" cy=\"10\" r=\"6\"/><path d=\"m15 15 6 6\"/></svg><input type=\"search\" id=\"configSearch\" aria-label=\"جست‌وجوی کانفیگ\" placeholder=\"جست‌وجوی نام یا پروتکل…\" autocomplete=\"off\"></label>\r\n      <div class=\"glass config-connections\">\r\n      <div class=\"config-actions\">\r\n        <div class=\"action-row\"><span class=\"square-icon teal\" aria-hidden=\"true\"><svg viewBox=\"0 0 24 24\"><path d=\"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71\"/></svg></span><div class=\"action-copy\"><h3>لینک اشتراک</h3><p id=\"shortSubLink\" dir=\"ltr\"></p></div><span class=\"row-actions\"><button type=\"button\" class=\"action-icon-button\" data-action=\"qr-sub\" aria-label=\"کد QR اشتراک\" title=\"نمایش کد QR\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z\"/></svg></button><button type=\"button\" class=\"action-icon-button\" data-action=\"copy-sub\" aria-label=\"کپی لینک اشتراک\" title=\"کپی لینک اشتراک\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/></svg></button></span></div>\r\n        <div class=\"action-row\"><span class=\"square-icon amber\" aria-hidden=\"true\"><svg viewBox=\"0 0 24 24\"><path d=\"M12 2 2 7l10 5 10-5-10-5ZM2 17l10 5 10-5M2 12l10 5 10-5\"/></svg></span><div class=\"action-copy\"><h3>کپی همه کانفیگ‌ها</h3><p id=\"copyAllCount\"></p></div><button type=\"button\" class=\"action-icon-button\" id=\"copyAll\" aria-label=\"کپی همهٔ کانفیگ‌ها\" title=\"کپی همهٔ کانفیگ‌ها\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/></svg></button></div>\r\n      </div>\r\n      <div class=\"config-list\" id=\"configList\"></div>\r\n      </div>\r\n      <p class=\"fine-print config-note\">پشتیبانی هر کانفیگ به اپ انتخابی شما بستگی دارد.</p>\r\n    </section>\r\n\r\n    <a class=\"telegram-link\" href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\"><span class=\"telegram-icon\">↗</span><span>همراه امیراکس بمانید<small>خبرها و راهنمای اتصال در کانال تلگرام</small></span><b dir=\"ltr\">@AmyraxVPN</b></a>\r\n    <footer><span dir=\"ltr\">AMYRAX PANEL</span><span>یک اتصال ساده، یک دنیای بدون مرز.</span></footer>\r\n    <noscript><p class=\"glass noscript\">برای نمایش کانفیگ‌ها و دکمه‌های کپی، JavaScript را در مرورگر فعال کنید. اپ‌های VPN می‌توانند همین لینک را مستقیماً دریافت کنند.</p></noscript>\r\n  </main>\r\n  <dialog id=\"qrDialog\" aria-labelledby=\"qrTitle\"><div class=\"am-dialog-scroll\">\r\n    <h2 id=\"qrTitle\">لینک اشتراک</h2>\r\n    <div id=\"qrCanvas\" role=\"img\" aria-label=\"کد QR\"></div>\r\n    <div class=\"qr-link-row\" id=\"qrLinkRow\" hidden><span id=\"qrValue\" dir=\"ltr\"></span><button type=\"button\" class=\"action-icon-button\" id=\"copyQrText\" aria-label=\"کپی لینک اشتراک\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/></svg></button></div>\r\n    <button type=\"button\" class=\"qr-close\" id=\"closeQr\" aria-label=\"بستن کد QR\">بستن</button>\r\n  </div></dialog>\r\n  <div id=\"subscriptionToast\" class=\"toast\" role=\"status\" aria-live=\"polite\"></div>\r\n  <dialog id=\"importDialog\" aria-labelledby=\"importTitle\" aria-describedby=\"importHelp\"><div class=\"am-dialog-scroll\">\r\n    <div class=\"dialog-header\"><h2 id=\"importTitle\">افزودن اشتراک</h2><button type=\"button\" class=\"icon-button\" id=\"closeImport\" aria-label=\"بستن راهنمای افزودن اشتراک\">×</button></div>\r\n    <p id=\"importHelp\"></p>\r\n    <label class=\"qr-value\"><span class=\"sr-only\">لینک سازگار با اپ</span><input id=\"importLink\" type=\"text\" dir=\"ltr\" readonly></label>\r\n    <div class=\"import-help-actions\"><button type=\"button\" class=\"soft-button\" id=\"copyImportLink\">کپی لینک اشتراک</button><a class=\"soft-button\" id=\"importDownload\" download>دانلود پروفایل</a></div>\r\n    <code id=\"importCommand\" dir=\"ltr\" hidden>sudo sing-box run -c Amyrax-SingBox.json</code>\r\n  </div></dialog>\r\n</body>\r\n</html>\r\n",
  subscriptionCss: "@font-face{font-family:Vazir;src:url('/amyrax-assets/fonts/Vazir.woff2') format('woff2');font-weight:400;font-display:swap}\r\n@font-face{font-family:Vazir;src:url('/amyrax-assets/fonts/Vazir-Bold.woff2') format('woff2');font-weight:700;font-display:swap}\r\n:root{color-scheme:dark;--bg:#080c12;--card:#111923;--text:#f0f5f9;--muted:#a1afbd;--line:#ffffff13;--accent:#55dec5;--blue:#62b9fa}\r\n*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 83% 15%,#25378338,transparent 38%),radial-gradient(ellipse at 10% 50%,#007f8130,transparent 40%),radial-gradient(ellipse at 85% 95%,#30245622,transparent 45%),var(--bg);background-attachment:fixed;color:var(--text);font:14px/1.8 Vazir,Arial,sans-serif;min-height:100vh}button,input,select{font:inherit}button,a,input,select{outline-offset:5px}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid var(--accent)}button,a{-webkit-tap-highlight-color:transparent}button{cursor:pointer}button:disabled{opacity:.45;cursor:default}a{color:inherit;text-decoration:none}button{color:inherit}h1,h2,h3,p{margin:0}svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}[hidden]{display:none!important}\r\n.subscription-shell{max-width:510px;margin:auto;padding:34px 16px 26px}.brand-header{display:flex;justify-content:space-between;align-items:center;margin:0 4px 26px}.brand{display:flex;align-items:center;gap:12px;direction:ltr}.brand>span{font:700 20px/1.3 Arial,sans-serif;letter-spacing:-.5px}.brand b{color:var(--accent)}.brand small{display:block;font:9px/1 Arial,sans-serif;letter-spacing:1.1px;color:var(--muted);margin-top:8px}.icon-button{width:40px;height:40px;flex:0 0 40px;display:inline-flex;align-items:center;justify-content:center;background:#ffffff07;border:1px solid var(--line);border-radius:12px;font-size:22px;transition:background .15s,transform .15s}.icon-button:hover{background:#ffffff13;transform:translateY(-1px)}.brand-header .icon-button{color:var(--muted);width:38px;height:38px;flex-basis:38px}.glass{background:linear-gradient(135deg,#ffffff06,#ffffff00 65%),#111923d9;border:1px solid #ffffff18;box-shadow:0 16px 50px #0000001c,inset 0 1px 0 #ffffff05;border-radius:24px}.summary-card{padding:25px}.card-eyebrow,.section-heading{display:flex;justify-content:space-between;align-items:center;gap:12px}.card-eyebrow>span:first-child{font-size:13px;color:var(--muted)}.pill{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:20px;font-size:11px;white-space:nowrap;font-weight:700}.teal{background:#55dec516;border:1px solid #55dec52c;color:#70edd5}.pill i{width:5px;height:5px;border-radius:50%;background:var(--accent);box-shadow:0 0 7px #55dec560}.summary-card h1{text-align:right;font:700 31px/1.25 Arial,sans-serif;letter-spacing:-1.2px;margin:15px 0 7px}.intro{color:var(--muted);font-size:13px}.metrics{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin:24px 0 12px}.metrics>div{padding:13px 14px;background:#070d146b;border:1px solid var(--line);border-radius:15px;min-width:0}.metrics span{font-size:11px;color:var(--muted);display:block;margin-bottom:6px}.metrics strong{font-size:15px;display:block;font-weight:700}.fine-print{font-size:11px;color:var(--muted);line-height:1.9}.primary-button{display:flex;justify-content:center;align-items:center;gap:9px;background:linear-gradient(135deg,#60e6c8,#35baa4);color:#061b1a;border:1px solid #72f5d8;border-radius:13px;padding:12px 16px;width:100%;margin-top:21px;font-weight:700;box-shadow:0 5px 20px #3acaaa16}.primary-button:hover{filter:brightness(1.07)}.primary-button>span{margin-right:auto;font-size:21px}.primary-button svg{width:19px}.link-preview{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:12px;font-size:10px;color:var(--muted)}.link-preview>span:first-child{font:11px Arial;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:65%}.usage-track{height:4px;background:#ffffff10;border-radius:4px;margin:15px 0;overflow:hidden;direction:ltr}.usage-track span{height:100%;display:block;background:var(--accent)}\r\n.chart-card{padding:22px 24px;margin-top:16px}.section-heading h2{font-size:15px}.neutral{color:#c8d7e1;background:#ffffff0b;border:1px solid var(--line);font-size:10px}.segmented{display:flex;padding:5px;background:#070b107d;border:1px solid var(--line);border-radius:16px;gap:5px}.segmented button{background:none;border:1px solid transparent;border-radius:12px;flex:1;padding:8px 10px;color:var(--muted);font-weight:700;font-size:12px}.segmented button[aria-pressed=true],.segmented button[aria-selected=true]{color:var(--text);background:#ffffff0c;border-color:#ffffff09;box-shadow:0 2px 10px #0002}.chart-tabs{margin-top:17px;padding:3px;border-radius:12px}.chart-tabs button{padding:5px;border-radius:9px;font-size:11px}.chart-tabs button[aria-pressed=true]{background:#1d739c2d;color:#9cdbff;border-color:#3487b03b}.usage-chart{display:flex;align-items:stretch;gap:9px;height:142px;padding-top:17px;direction:ltr}.chart-column{flex:1;display:flex;flex-direction:column;align-items:stretch;min-width:0;gap:7px}.bar-slot{position:relative;border:1px solid #ffffff13;border-radius:9px;background:#ffffff03;flex:1;overflow:hidden}.bar-fill{position:absolute;bottom:0;width:100%;min-height:2px;border-radius:8px 8px 0 0;background:linear-gradient(#61c4fa,#2d769a66);border-top:1px solid #8dd9ff}.chart-column.missing .bar-slot{border-style:dashed;background:transparent}.bar-label{text-align:center;color:var(--muted);font-size:10px;line-height:1.3}.chart-caption{text-align:center;font-size:11px;color:var(--muted);margin-top:13px}.main-tabs{margin:23px 0 18px;border-radius:18px;padding:6px}.main-tabs button{font-size:13px;padding:9px}.main-tabs span{font:10px Vazir;margin-right:4px;background:#ffffff0d;border-radius:5px;padding:0 5px}.section-lead{margin:0 6px 16px}.section-lead h2{font-size:15px}.section-lead p{color:var(--muted);font-size:12px;margin-top:4px;line-height:1.9}\r\n\r\n.app-platforms{overflow:hidden;color:#fff}\r\n.app-platforms.glass{position:relative;background:radial-gradient(ellipse at 0 65%,#0e749035,transparent 65%),linear-gradient(165deg,#ffffff05,transparent 48%),#07090ce8;border:1px solid #ffffff26;border-radius:28px;backdrop-filter:blur(64px) saturate(200%) brightness(.96);-webkit-backdrop-filter:blur(64px) saturate(200%) brightness(.96);box-shadow:0 18px 48px #0000006b,inset 0 1px 0 #ffffff47,inset 0 -1px 0 #ffffff0a}\r\n.app-platforms::before{content:\"\";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(145deg,#ffffff0f,transparent 38%);pointer-events:none}\r\n.platform+.platform{border-top:1px solid #ffffff0f}\r\n.platform[open]{background:#ffffff09}\r\n.platform.current{background:linear-gradient(145deg,#20a4ff0f,#ffffff06)}\r\n.platform>summary{list-style:none;display:flex;align-items:center;gap:12px;min-height:68px;padding:24px;text-align:right;cursor:pointer}\r\n.platform>summary::-webkit-details-marker{display:none}\r\n.platform>summary::marker{content:\"\"}\r\n.platform>summary:active{background:#ffffff0b}\r\n.platform-icon,.platform-chevron{width:44px;height:44px;flex:0 0 44px;border-radius:12px;display:grid;place-items:center;line-height:0;border:1px solid #ffffff0f}\r\n.platform-icon{color:#8ed8ff;background:#20a4ff3d;border-color:#20a4ff57}\r\n.platform[data-os=android] .platform-icon{color:#96f7b8;background:#37e66f38;border-color:#37e66f5c}\r\n.platform[data-os=ios] .platform-icon{color:#fff;background:#ffffff14;border-color:#ffffff26}\r\n.platform-icon svg{width:22px;height:22px;display:block}\r\n.platform-icon .solid-platform-icon{fill:currentColor;stroke:none}\r\n.platform-icon .outline-platform-icon{fill:none;stroke:currentColor;stroke-width:1.8}\r\n.platform[data-os=ios] .platform-icon svg{transform:translateY(-1px)}\r\n.platform-main{flex:1;min-width:0}\r\n.platform-title-row{display:flex;align-items:center;gap:8px;min-width:0}\r\n.platform-title{font:700 17px/1.4 Vazir,Arial,sans-serif;letter-spacing:-.02em;min-width:0;white-space:nowrap}\r\n.platform-count{display:block;margin-top:4px;font-size:12px;font-weight:700;line-height:1.4;color:#ffffff6b}\r\n.platform-current{flex-shrink:0;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:700;line-height:1.5;color:#8ed8ff;background:#20a4ff29;border:1px solid #20a4ff52;white-space:nowrap}\r\n.platform-chevron{color:#ffffff9e;background:#ffffff0b;transition:background .18s}\r\n.platform-chevron svg{width:18px;height:18px;stroke-width:2.2;transition:transform .18s}\r\n.platform[open] .platform-chevron{background:#ffffff14}\r\n.platform[open] .platform-chevron svg{transform:rotate(180deg)}\r\n.app-card{padding:24px;border-top:1px solid #ffffff0f;background:transparent}\r\n.app-top{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px}\r\n.app-card .app-monogram{width:44px;height:44px;flex:0 0 44px;border:1px solid #ffffff0f;border-radius:12px;display:block;overflow:hidden;font-size:0;line-height:0;background-color:#ffffff14;background-size:cover;background-position:center;background-repeat:no-repeat}\r\n.app-info{flex:1;min-width:0}\r\n.app-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}\r\n.app-title-line{display:flex;align-items:center;gap:8px;flex:1;min-width:0}\r\n.app-name{font:700 17px/1.4 Vazir,Arial,sans-serif;letter-spacing:-.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}\r\n.app-card .app-description{margin:-2px 0 0;font-size:13px;line-height:1.5;color:#ffffff9e;text-align:right}\r\n.app-tag{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;padding:4px 10px;border-radius:999px;border:1px solid transparent;font-size:12px;font-weight:700;line-height:1.4;white-space:nowrap}\r\n.app-tag.os-tag{font-family:Vazir,Arial,sans-serif;color:#20a4ff;background:#20a4ff3d;border-color:#20a4ff66}\r\n.platform[data-os=android] .os-tag{color:#96f7b8;background:#37e66f3d;border-color:#37e66f6b}\r\n.platform[data-os=ios] .os-tag{color:#f5f5f7;background:#ffffff14;border-color:#ffffff26}\r\n.app-tag.recommended-tag{color:#ffd09a;background:#ff8a002e;border-color:#ff8a0057;font-size:11px;padding:4px 9px}\r\n.app-buttons{display:flex;flex-direction:column;gap:8px}\r\n.app-buttons .download-button,.app-buttons .import-button{display:flex;align-items:center;justify-content:center;flex:none;min-height:44px;width:100%;margin:0;padding:10px 14px;border:0;border-radius:999px;font:700 15px/1.6 Vazir,Arial,sans-serif;color:#fff;text-decoration:none;text-align:center;transition:transform .12s,background .15s}\r\n.app-buttons .download-button{background:#ffffff14}\r\n.app-buttons .download-button:hover{background:#ffffff1f}\r\n.app-buttons .import-button{background:#20a4ff}\r\n.app-buttons .import-button:hover{background:#36adff}\r\n.app-buttons a:active{transform:scale(.97)}\r\n.app-card.coming-soon{background:#ffffff03}\r\n.app-card.coming-soon .app-monogram{filter:grayscale(1);opacity:.6}\r\n.app-card.coming-soon .app-name{color:#aab2bb}\r\n.app-card.coming-soon .app-description{color:#929ba5}\r\n.app-card.coming-soon .app-tag{color:#b8bfc7;background:#ffffff0a;border-color:#ffffff20}\r\n.app-tag.coming-soon-tag{font-size:11px;padding:4px 9px}\r\n.app-card.coming-soon .app-buttons button:disabled{color:#a5adb6;background:#ffffff0c;opacity:1;cursor:not-allowed;transform:none}\r\n.soft-button{padding:8px 12px;text-align:center;border:1px solid var(--line);border-radius:11px;background:#ffffff09;font-size:12px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;gap:5px}\r\n.soft-button:hover{background:#ffffff16}\r\n.help-card{margin-top:14px;padding:16px 20px;border-radius:17px;font-size:12px}.help-card summary{cursor:pointer;color:#c3d2df}.help-card p{color:var(--muted);margin:12px 0;font-size:12px}.help-card label{font-size:11px;color:var(--muted)}.manual-format{display:flex;gap:8px;margin-top:6px}.manual-format select{width:100%;min-width:0;background:#080e15;border:1px solid var(--line);border-radius:10px;padding:8px;color:var(--text);font-size:12px;direction:ltr}\r\n.action-row{display:flex;align-items:center;gap:10px;padding:18px 20px;min-width:0}.action-row+.action-row{border-top:1px solid var(--line)}.action-copy{flex:1;min-width:0}.action-copy h3{font-size:13px;line-height:1.6;overflow-wrap:anywhere}.action-copy p{color:var(--muted);font-size:11px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:right}.action-copy p[dir=ltr]{font-family:Arial;line-height:1.7}.amber{color:#e8d986;background:#c5a62220;border:1px solid #e6cb462b}.config-actions .icon-button,.config-list .icon-button{width:36px;height:36px;flex-basis:36px;font-size:21px;border-radius:11px}.search-field{display:flex;align-items:center;gap:10px;margin:17px 0;color:var(--muted);border:1px solid var(--line);border-radius:13px;padding:10px 14px;background:#101720}.search-field svg{width:17px}.search-field input{width:100%;min-width:0;background:none;border:0;color:var(--text);font-size:12px;outline:none}.search-field input::placeholder{color:var(--muted)}.search-field:focus-within{border-color:#55dec580}.config-list{overflow:hidden}.config-node{display:flex;align-items:center;gap:10px;padding:20px;min-width:0}.config-node+.config-node{border-top:1px solid var(--line)}.config-node .square-icon{color:#78cbfc;background:#207fbc25;border:1px solid #3b9ad02b;font:700 10px Arial;width:38px;height:38px;flex-basis:38px}.config-node h3{font:700 12px/1.6 Vazir,Arial;unicode-bidi:plaintext;text-align:right}.config-node small{font-size:10px;color:var(--blue)}.config-node .node-uri{font:11px/1.8 Consolas,monospace;direction:ltr;text-align:right}.config-note{text-align:center;margin:12px 0}.empty{padding:30px 22px;text-align:center;color:var(--muted);font-size:13px}.telegram-link{display:flex;align-items:center;gap:11px;margin:26px 5px 22px;font-size:12px}.telegram-link small{display:block;color:var(--muted);font-size:10px;margin-top:3px}.telegram-link b{margin-right:auto;font:11px Arial;color:var(--accent)}.telegram-icon{font-size:24px;color:var(--accent);background:#55dec50d;width:37px;height:37px;display:grid;place-items:center;border-radius:12px}.subscription-shell footer{display:flex;flex-direction:column;align-items:center;gap:6px;border-top:1px solid var(--line);padding-top:21px;color:var(--muted);font-size:10px}.subscription-shell footer span:first-child{font:10px Arial;letter-spacing:2px;color:#ccd9e2}\r\ndialog{color:var(--text);border:1px solid #ffffff26;border-radius:23px;background:#111923;padding:23px;width:360px;max-width:calc(100vw - 28px);text-align:center;font:13px/1.8 Vazir}dialog::backdrop{background:#02070ccb;backdrop-filter:blur(7px)}.dialog-header{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:20px}.dialog-header h2{font-size:14px;overflow-wrap:anywhere}#qrCanvas{background:white;padding:12px;border-radius:13px;color:#07131b;line-height:0}#qrCanvas svg{width:100%;height:auto;max-width:270px;display:block;margin:auto;stroke:none;fill:#000}dialog p{margin:16px 0 12px;color:var(--muted);font-size:12px}.toast{position:fixed;bottom:24px;left:50%;transform:translate(-50%,15px);max-width:calc(100vw - 30px);text-align:center;padding:11px 18px;border-radius:13px;background:#18342f;border:1px solid #55dec551;color:#cafff1;box-shadow:0 8px 40px #0005;opacity:0;pointer-events:none;transition:.2s;z-index:99;font-size:12px}.toast.show{opacity:1;transform:translate(-50%,0)}.noscript{padding:20px;margin-top:20px}.spinning svg{animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}\r\n@media(max-width:380px){.subscription-shell{padding:24px 12px}.summary-card{padding:20px}.chart-card{padding:20px}.metrics>div{padding:12px 10px}.metrics strong{font-size:14px}.action-row,.config-node{padding:17px 14px;gap:7px}.config-node .square-icon{display:none}.telegram-link b{font-size:10px}.brand>span{font-size:19px}}\r\n.wg-copy{font-size:11px;margin-top:9px}.metrics span,.fine-print,.chart-caption,.chart-tabs button,.platform-title small,.link-preview,.action-copy p,.config-note{font-size:12px}\r\n\r\n/* BEGIN CLIENT ICONS */\n.app-monogram[data-app=\"v2rayn\"]{background-image:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAl80lEQVR42uV9ebAeV5Xf75x7u7/1fW+XLNnYYIMADxhjCQeDJyxx2EJCMqxZgD8MFjYpXJWZMCEBnpwZCmYGagomZSJjF2EIA+NhyVAMTA3GGGIYYiQjNJZswICxsQFrfdu3dd978se93X27v+9JT9KTMYmqnpe3qfucc39n+51zgcfTHxHCwgJjQRgitLG/VxgLCxv7ezfgDz0uhL5rF+GGXQKQhF+6+NZ74trSYA4DTLKWcwzxLAwmmW1bhOpgGwEMMWKIaIWJejB2EZE6lAoOaakd7U3bIwdf94zh2L9z1y4Blf/O/18UQFhYGBHA826+d2I4XH6yUeqpJOYZQryNQBeIyDyIZiBSI0gNrIhYAUSZQCHWAmKsCIYgGgA4AshhgH7GkPsA3GeZ7mErP9u7c8dioA3CwngD+H9QAdnL3mCzz1x6y93zJHKJGHkeCa4g4OlC2EKsa8QKgABiASsQCCACiIwKyimD3L8JxAQQu69ZC2vTAQkeEeBeAu6yZL8Frb+/7+rLDuW/Y2GBH+tTQY8ZzDghCQC89lZRP1nct12MuUqAfwrgEmKeIaUBa70120IQIW6TN3sRyYUu4n53VS/hzxMTKXdqxKQQK0dA2E9ibmPCV4/3D++///pXDHJFPEYn4uwrYGGBM4u/+L/d067H/ReK0KtJ5EUgXEA6hlgDWONeWISKpyJ3aor/DpQ67gT4EwIq3kxQKCdUCCsipSDpECJ4iAi3EfNnVb19511v3LYUPLuM+dt+AxQgQtkLX/In+1o8aa8ikX8LyItZRbMOt1MAZAuhE42x4sqjyqgysu9zQvZfCpUlmYIk/0UCf8KEnT9hSJocFaKvgfFJtvK1vTt3dKvv8puhAG/1r731VvXA0kXPN0beKoJXsI5mxFpv7RmcSGalhaBy52o9JBn3YSwgJoOoQLgMEIGIQEoDrED+A8woHxvyP5udEip8ilJExLBpcgyQLxPT7oumtn/7r15H5mwpgc6W1T/75r0XUCpvFaI3slLnixV4yRHEO8vM2jOBEwEmhU2HkGQImwwhJoGkKcQrI4f/ygnIfiVAADOIGcQapCNwFIGiOkjHIOZC2SLFYSLK/IqAiIkY1qYPkeDPiXDT3p07Hjwbp4HOhtXfv3jRK8jK70Hw26QUifWCDyEmhBZrYIc9mEEPkgwgSeL8got7QCGmn0j/2QtJAVP+qIEUg3QMFdfBtYZThtJlmCo7byFiFmsAwjdF6IOdX1z2lW/cQOlGKoE20vK3f+q+OVlZuU4E/551NC8mzayKAhx2kCEWkg5hel2YfheSDryFBz53HNaP/dy4z1PZX3i/4BCLwXENXG+Baw1wFBd/b2ggPtIipcmmya+IcKPV/NF9V192aKOUQBsl/Gd/bO/TycqCCL2aFGvYXJqB8H1YPuzD9ldh+quQJHGCIQKVHO16TH09ilnj+/wzkYqgGi2oRgsU1d1zWhsYgHtkYsXWmoREPqdY/eF3r3n2gY1QAp3ZzwoAkkt33/0Chn0/sbrCwby3+lIEAohJYFaXYHorkDQph4tjBFvWWyW0DEPP/HOhEqTyvdW/p/zLSGmo5gRUcwKkouDUlE4DgRVg0m8zxf95z85LvuGhFacbqtKZCn/7R7/7Kkv0R6z1U8UY6y2eShYkgrS7BNNdhgwHuXWJc50V/A0EFMjIOWEXATn/AG+phQN3kQ8DxC4CCsPT3J+sfaoEAo7r0M0OVHPCZ9I2VKIAJKQU2zT9oYi8c9+1z/lrr4THTAF55rl9955/Y0HvZ1bnizUWAJfNViBJgnTlGExv1YV/ROMhJbdoAmAhxkBMUkRCJoUY4/VpxzlOd+jIR0BKg1QEjmogrUGsA+3KiSAVIIZqNKHb06CoFuQXuR+zYM1izYMMedfenTv+4hRx8AwUIO7I7bhp7+utyIdIqa0uygGXcEMEpr+CdPkYbDL0iHQiBwqITWGHA9hhDzZ1Qs+s10EQrfcZy4pRCqRiqFoDHNe8MnDiZxEL1jF0Zwqq0RmHkZZYsdj0EQb97p6d2z9zOj5Bn3KoSWSfvXvvvzDAHznhG5tXvcQCrABrkK4cR7qyCFgLIh5veV5RNhnCDrowwx7EJMF7UnAq1uWJKyGu/840haQp7KAL0pELRestsI7GGEWWIzIkHSI5fgSSptDtKf+aeeLIYo0lVlutNR+47KY9g7uJvnCqSqBTqmQ6zH+hEO0mrbd5zGcHLexj+hTJ8lGYlaVAyKhApLeyZIi0vwI76LocrVTTqZQY1iw7yNoRaQk2wtMhINbgWgOq3vZhKMaHvD5ZU80Oos4MoHQ5iQMslGYx6Q/Yytv2XvucO05FCXQqoealH737YmZ7M7G+QqyxEOHQ2Uo6RLp8FGl3ZW3I8dXItLcC21t1DpVoHZa9TnglKgkaGJNxB8ogVj4MnXCJmdggSpKS3lSzhWhiFqSjaphmiZnFmr+3lt+y79rLDq5XCbRe4V9y475NWqUfAanXe3PlUGhiDZJjh2D6q3kEOi7sM4Mu0tVFF4YSxsSdYz4ntoh+bOorGmFUQx6tFKBUXoYo6kBhpXQNRegIUWsKXGuskfw5v6DqLURT80EWnT+FJWa2xt7KJG/fu3PH4fUogdYT8Wy/6SYteM67ROx7iEj5F6H8RazB8PijML3VAO/LwhdrYbpLMP1liJWKpYaZryuWiVjIcOBrQa40IWKDMoMd//hE7hmYXRSkI1BUKwpz2ckQjEITM3S9Dd3qBN9bPpT5SejMuXyhiOwy55FA8D6Cff/ea7anpa+dshP24ab92N6Xwch1xErDGimZuAiSpSMwvW4hfAkCeCKITZEuH4cZrOaVy9zaw0KctbCJi4IkTZxDrkJL1uUC+8y57FsE4hSVGkiawA7h8F7HoNiXHbIcY7QYh7S7CDEJ9MS0O0UF1nubE5juCogUosnZ4nlc00iIKBaxbxfG3SD6kj8Fp3ECsvrO7j3nC/BJUtE/ljTJa2OZVZiVRQwXj3idjMH7JMFw+QgkGZatvhxXu/Cz34VNh5Vy8ZgEOPSnlOt55HsEFX9ADI5qvv5TGz0BQRmcdQ1RZwak4zXrUbozA92aqrwXLCnNkqbfEE1v/t5btv/sRFDEJ1LMCxa+rkVwDUBXikkDy3fhoemtIFk+Nt5lEkOSAZKlw0AydLjsWwD5BzNgUpiVRdjV45B0ACaAmYvSMkYDHQkqD6WEe0RZEiAbu/OR9GFWjsOuLgImCZ6JMwAEsYKYIZKlI5B04E92cWAzKaTLx2B6KyNvLmkqIL6SUnnr9t17ohMZuz4R9Kzs3vNcEbyZWbGYRHL4ACDJAOnyMYg1I7gvICSDPoaLh52zZQZSU7ZPEdjBqqsLlYpfvjfCDM6aW0RhYdmXME7YHwtexUEIE2AsYKwBQEi6y6B+D6rRBtebo/IhAswAybFDiDvzoCjO4UhEwExQIkiWj4Kj2GXMFPRRmZU19s3E8hUQfWstKNLjoQfY/sU9TfsIvY2VOs9ZPwe4b5GsHIcdOssOj6WAoMSgJV3YpgYQjfp1ayCDLowFELWCXMEfSyIsrfYwTFOwV65UEiUZY/IUKCr/Gjll9gYDtBsNTDTbsOGREgvWLropOd7AGBk96JrLoK1Y1COFXiJYGqTgNEW6cgzR1OYwLyExqbDW50ma7rzkT/bt20/UHVczWsMJk9hf3HUVwC8vUUBEACaY7oqPeMoHnonRHQxxYcviE+94DeIoHssgcWGrjC0tWBFEWuOtH/w47tj/Q3SadRhbruKE3V1C0HIYydUEWissrfbxlHM34ab/8CacOzeN1NjKXy05zJyoC5GKoKYYjyx28fbPfAfH+gkUM0yvC46XoNpTlXe0IsA/Ux3zTwB8Mas9rq0A7ywu//B3OgnUv2OtZyRNspKlg4I0QbqyhCL7DSyOgbS7BKpF2DIzNZoPnMKfONJOSVlxDh7Dw8ozyo4gBCqBQCuF5dU+Ljp3E/7i3dfgwnPmzrj9cWh1iP/41/vw4LEuWrGCFdfkMd0lcL3lkzl/HK0V1tGMTZM3Xv7J79xxF9FS1SGPdcKmGV8JkauyhCc/ywDM6hJs0h+N94lg+z1XcgZhkKQQEf+A6/8wxvqfC5tjHPSAaY2eVxmmImYsdfu4aOs8vrDrWlx4zhxSa0/pWbKP1LgyySPHV/CGj34FBx8+gnas3DPCNZLMcADTXQo6fhJWbl9s+urKk0RBTjMv+PjX62Lta1hH07DGeZu8tDz0Xp/KbQH48sLqYg45zFSOeE7xA9b4krRLwCRvxmPEG1RVoxVjsdvHhVvn8Zn37MS5c9Mw1kIzn/JzWBFoxXj4+Cpe/8f/EwfuvRdtNkiGQ9jUfYiYwDiTIi4mIhjjToHh117w8a/XPRWGRhWwsIsAYGnQeQZEXlxkjEX7zvSWIWmQ3PlyAIhg+isw6SCHHWMsjLXu38bCGFN2fifsNwKmu4xk8QhMbwV22AuaLzKCzRT4Ba0UllZ72HbuJnxu4Vo86Zw5GGuhmE8ZboxxP/fAo8fxuvd+BAcOHESjfwzLD/0Qw6O/wPDoL73QB4AVWGNge0thFyl/MIJ90cyg84xQ1mUfcMMuAW4AQV4C4vPFZnG/ez077MP0VkdKZcQEGfaR9lbAxBBJwURo1OLTazH7fw+P/QqDwz9HQgm4NeUoJhSjTC6nnKEo3vKXuz1cuHUTPv2enTh/08wZCN9AKYWHf/krvPod78W9P3kQnXYTy0eMK1m0p6Bbk4g6c4iZAZ+wmX4XqjEAxfWM10pijYDVE1hwFYA9nm0XKCBgNdiV1atYaXLONwNhge13ISYpZ7z+P9P+qiNQMSPWCg8vdfGuT/0donSAwfFD6C8dRffYUbzyla/Aq158JawI+CQOOlk6CnPkl0jqGpoVuN4EjcmM82hHaSx1e7ho6yb85XuuwRM3z56x8B96+BG88s1vwz/86KfotBpYWXrU948VTHcZtEVDt6fzaI6IYJMEZtCDzjtpnBX72KbJSy695e5bQlaFU8CuXQRAzEr3UhJ5Vol1lvF2Bt1Srz0ThU1dMyUruDEzVrt93PK1uzE48gj6D/8Y6dFHYH96EJOzs04B1oKVOqEQbDoAeiuwg4HrjllTbvCjoJlorbGcC38nnnTOmQv/wYcfwSte/a9x4N770J6aRn9p4GCdI3CtDiKCqregWx1w3AgqrwLbWwWandLn4J7/WWzUMwHcnsmcvQKyI3EFMU9LVnAjAEy+QDYYU/wCbH+1aJL7RISJ0NHApBbMTHUwMzUJNTGFZqOx/iaEL0Nn5YQwTg8fQWv2lj+PL9xw7YYI/6FHHsHLX/0GHLjnABrtFobJIK++cq2GaGIa8ewW6IkZRJ1ZV3H1UE3eKM2wFxYQSawVYp6BTX/bQb6DIc6OwrP+9OtTDPs8Vppy0/KCcNZvK5JzGa0Z9su1Wq+EpLcKYyV3wMY6p3zq/A3v6KvMiQzzV/u4cMs8PvPuIto5U+G/7HfegIMHDqI5NQljDEgEzNr1AjqzqM2fi2j6HKi47svcqlL9NZBhr0gdXUAjvofwj571p9+b8jIm9kcB3O6cL4Knutg/q/UzxBrY4aCUC2Tga4d9VzKuEGslGbjIQCmQ0uBaE2i0obU+xT6oz/+qPRoAmjnPcM882ilg5+W/8wYcvOcgmpOTSNO0kGtcRzQ5i9rsFsQzW10VlNlVb0f8GcEO+p7FQVmpxbNJ8HSqywUZ9BdPa3ExgK1F8uWtL008qwFBI8OfjGGvQilBXtN3fVcFrjUQdWbAc1tRa7ZPk4VUfkGtFJZ8nL9R0U4BO87yc+ETgWpN6GYHtdmtiGe3QjUnwHEtFzRK6CC+R5VCMuVkSZk1EMEWInma+95d4AL/7TNZ6RrEFskXESQZ+g5kmbMpJoVNhiP1dLHGK8CVdbnRgu7MIJ4/35GdTukMSFHRRBFqLq128dTzNuPW9+zcmGinAjuF8AEVN6GbE4gmZxFNb4ZqTTrhe6Nw9BlTztCzRDKTT1Zbt1ZY6xqJPMPLXxhE8uQPf7kGwZO915Y8+YK4aKRK8/M0QzFpuaPlG/NFo53AOgbXmtAT01Bx7bTYSJnrj5QrrF24dRM+/e5rzi7sgMBRA7o9idrsFkQTM1C1um/kcNFwsqnvb9NIGdwmw3IfmkhADGE87bkf+nYDRC4KmmhtniXiJ5aOPDn8dxzO0UzJJsNya8p/SJqU+7wZZVCpoJ24Xsmz7wVkwu/iKeduxmff+zZcsHn27MEOAFVrumhnah7R5Cy4OZFn/dV3dl08D89Bpug4TgGkF4HE+YO4Np2XIqzlaYjM58327J/WutIDKskXxP9yGWnlZQqjjSCh+ofXSmFxtYsLt8zjr967c8OEPxZ2IA522pOIpzc52GlMgJUGTDadE7bGpDBSKjdFMzJBMKVDnoI/Z2tcKEBTOg9gWnzcnQvW2oKHGZR9RQTWpGW6IHM+SoRqbb6gDJyywLTWWFrt4aLztuDWhevwhA1wuGtHOwKOW9AT04inNyOanIeqNV03zL+fY/+FvWZ2MFTqY0vep3ACD2TqJDHrZZ7xOdWcAHXYYEaLGNYkLoOrys3NeZUnE0UgvpQcwtUps1VDxWmFxeUVPPn8rfjcH1y/wUlWxfJFfJw/g3hqDlFnxpG1fCuSfGk556vmYbd4vpIdPfLWwuY0fNcXdfKxdaRqLlAApogQlzXlZ7JC3n3O8THB91ER/2eYVyWxUzGauH7LV5ClJWx7ykX4X3/2PjxxAxzuCWGn1oJuTyOenEM0tdnNCfi8BcR5MlgKPDKZCPznqzRTAXypuvAZAIS0ZekE1VDbdPNQNuj9UtAsl4LPL553IxglV3nhUwkJKXio9UPQ8WPHcd7Tfwt/84ndeOKWeVcaVmda2/GwU7F8rvlQeWreW37bCb8q6OAdw8qg61dImVRcCaF9VEgQK6yUgpV24YSFGnk6XfLY4n9ByLJxiYWULL1MHZeQHuBxSNZ5ApjcMX3GpZfhi5//9IYI/+Sw4y1/cg7c7FSET6UB/WoEVPr/ca0iO+b7iGFgW/kJYJK4FM+PZR5TAOoySrAKSLCl3i0q5LKTJr1OAR/+wwU0Yg0rcsbCPyHsTGSYP+stPxpJBsN5yxPxS6tnP8enfO4soFX5mFwDgAGgwqM2lpMvxTRU9QHoZK6WTikKIqJc+Hwajf1Tgp3OrIt2stkwWmtiYM25pjW+M4iEpEqzJ5AVlUMQgQYh422Et1lF8PCXjbQZR+nlBDnlAFTOUPjrgp2peUTTm8CNVs52rtowrUWVHzdkXu4VZnMcYyYOBeJW6rgTQCJDMWnY46Oy45TRo1aCLD8Z4x9iXA4gcqr1Nzq7sDM5B92ZgWq2c/7neMuXMdl55TSvOcUThIAhHrsSdz9wwrws1tqS1ydXzSwld5KVFjhgQmdtN+STiVWLp5zJfva2v6w7ycpgZ2oeujmZ83gIPHaidSSjHxOs5DxXCiFJcs5pYYkiYEVWrCXm1VwBiu0S3KapMhWbVakNkHf4mYPPFWOgpLQj5QaR0GOx+ei0YUdrR9olKhMAw6GMqjUzl/1eUO8afVkCwtZrMTQ0hMXxkJZyGOz9QLDRBSobaqgeOXaQIyhvOAnXiJVaOFIuZJ0l4Z8cduZz2Anp6eHrUUX0ZQYIu6JiKCdB+b0rjAHOmHKgEL4H0OZwroCU1KMkctQdL8oztnyPTolz5niUHA5CB0PTzhKKbSal2Uh5vMBOVBZuZaBHSsYajDGRcmNQlcE/VtqTlKXsgP3QeAgh5AjAR1PRh3IF8MAeA3DYHyfJC0qs/ShnEXKReK69jkfiYmKVx9FSCZk3GpDOCHYq9IKMf4AKB7sau5GOKqNLGfRGAUuwPHdWOjFuFQ6IcMjL3ClgsLl2WIgeKNV8gmUWYTU0K3cXoz7lhnyumNJ6B9rQ5SxnDDvVHDNfilP0oEdgiMgpgCoRIFEhiwr8u7zCrzsoTXXRA4PNtcM5K8Lt1ZT7XJHNhyzBLw9nkrLRWFIRiq2GxZHM9/CETTSRDbP9M4WdanQYQquMGYXKR8lYOeMK+uXZmGv+eSqtjwLHcXmFmghBLEjkhwdf98xhiRUhVu4VYwZgDkICAsW1IvQKpEpKg6OoXI4Q6z9fGznOGwFBZw47lI9HyOhelfKYcel7xO2cCBc8+TfiqJbhevlhVQDTTgkCIrJpMrCQg4CUWRFW5D4i/KIkbPH4FkVBUa54Uo4bpf5ohjkc1fOZq9GE5dcFO36CktYgo3oFybg8gBgc18dWAEoyCPmqKi5ORlYlVgoAPWJF7ivY0Tc4VkQ7nrhfQAd8mJSxodwenbg+pksuTtBKlRfoiYCiGBzVvNKCDFN+nbAj45OrnH5cnjDIRz5EHAznMEMlp8xRrUJLyXrK9cIBu962gBhMdLAdD+8HANywSziLa7599dNWSOS7YlPAWgoTLI4bo8dMnHI4DgbcgvYk15qBZdBpx6EbATvjhjrCz437/6KUTu5dwiHvzHrjRsnfFesP/PvnIb0IxLKYVCyw59tXP98PWXhWBBYWCEQiOrpTRA6T0iXeN8c1sK6VVx5luVq96dLtSs2b4po7tiKVDsFjHO0ESE4jnqk8XjhiKiJQcaN4j2D/BTFD1ZrVKqVb+hTVXMQUsimVhlh7lEi+CSLBwgIVmbAnZ7XI7IdgP5Qqa1tpcGPMKKcIWMdQ9WZlOs4dSVVv5w5cfk1JFlW2l9Fai1XGsmIcsWykNyLO+t2WFRkJZ4tZMRtUlxkg7Lc9/odQ5hysaaQ7r77sEAi3i0lsPpyR7TStt8BajzpjELje9kfUFpgnAEURVKO9rsr6xtV2aGR+eFxnsQqKMqaV6jaoRCOlZFIKujlR6XM46idr7QwyjHNdH90S4bZ9128/lI2DVUaUsiMht0HkIe9cJevmUBS7BxrD3eG4Bt2YKLOk/Ue2GhIi64KgM4KdNar3pV0gJ0gLS2WHuO4HuDFS/VR1V8IW2Ep47b+WDWdkW1SUJjH251b4q9UmDpdHlIDFfmcfwLdnVlzACuVWJiMLsqVo51XXD8MtO+L8oc4i7GRtDBm17ipQyJgto9mJ56juNqYEgUj236Tj/FRT2DMR66y/NREmXj6gAUD01ZV+e39V8xwOZ0OE7r9+24AYn7XJ8CjpiGBt/joc1TzBVkZCUlIaUba4orJUj1hBt6YKmsfZgB0J+rZ08v08NK7zKxYcxVCtjl+9ZgvH6w0r8vNqBW++ULXjEdXK5UetyabJMVH0+fuv3zbwO/dOPCes6u07wXT7yGoSosCa7chiJa41PBSVewUiFsj2KZwF2EEJXqrVJzppIExe+KQiqNbUKO57Q9KNCQ+ndnSGIa47xYmMboIkvi3utu88+bYUFx7xXW/ctkSkP2FNcszRVbKQ1FX4dHsSEjTiw+xStyahas2CthLwRmmM/Z057IydpwngZ1xjkUqVLRHrYKcz48sNFdoJnHGpVqdi+QXlQzc7ReInfkkeM0maHmOiT911/balcWtrRk+A8wWke/1vEuhLRExFbVk83k9AN9oBDaW8jVxPTIN1GfPDRQL5LPCGwM4JoMZTCmkMm8E9j3OijhU3Wa71UEFQ4KiGqD2dd/vC8yX+GZ1yAj4mQXxL90tJ/dBta93exOMWdUAEd13/3CUwPmZN+nNSqpzDkHIbpbIVLiizKIg14s5ssTdhZOcnBaOgD58x7Ky5Xto75bIZILd6IgXVnIRqTwKsy1TyvBam3aI+pYM1OZ4pKBYcx9AT0+Vtj+LSYWuSh8D42P43vXQ177Wsa2GT0zyR4DtE/D/8YtZwOgMU1dyMLKuA1R6w6HRU3qsWYr4t5nBf/vo34eA9B04LdtYKOsfhfak1CoKqNaE7sy7RyimHVCIck9KIOrMgX/UNox7xpWhniPWC95kNYVhrCPyJ/lT9/2TLbk9lY5YAwN6dOxJj6RYR+d+kVFGm9kdTNSegJ6YwSp0ooqZ4cg6s49wHiAhirfGzXx7CP3/L9Thw3/1ozc4hNcWoqxuOmFoTdk5WYBthN0i2Z4LA3nBUy0OOtaOVWnFl5nhq3o0j2SpPyjvliakiKsxGtMQKKUVE8i1RcnNwh5mc2tI+d/ENfZ/ogctu3PNBC/M0Yr0ZYiT3YszQ7WlImsKsLo4pN1t3EibnoXopUmNARHjw8BJe884P4J77foT2RBvJcOAaPKRcUteedLDTngQ3Wk6BVcZ17lOKqdrqwiaB39qrtEsk47qDzbB2VREqRNzpmJgGcbgVsbw2Sbc6blKysmGdWLFN018B9MGT7Ys70QkoKaH/q5/8HRFuFEiSe/iA76g7M+BGqzRgU3J4SoE7M5jsdLCysozX/cF/x733/wSdiTbS1OSbSVSjhXhqHo1znoT6lichnjvPQY+O3a6IwNmLmKLWnhOJrecgsYvn622o1hT0xAx0a9Lvb6CRqm5IjdDNSejOrN+YaEfro1b82sqZYJVxeAIkIeIbmeRvN2JvaL6y+Iob920aUPoR0ur1+bJuKebA3J7lQ7D97shJYADLicWbLr8QP334F/ibO76F+rGfY/nhHyNdOZ5XVaOJWdTmtiCe3eoEFtXdNIq1bgrFmPxSH5TIso5tIP4SH8rW12e8piqDuVIkEmuhohp0a9Ivbh2/xlisdcKfnKu0J7Pjzgwxf5mawTv2X/f8RzdIAcEmrY/efXHK9mZ3UUO2tNs7H2ZImiBZPAzTWxlLLTTCSNMEvPwoln68H90HDiBdWQTX6og6c24Iem4LVKPjSsAj3MtxnkrW+JqUqdmy1upidielOeEaKFZGOzbZTopGE3oy2JpbjCVZYs1i0m+ztTv3XHf5PetdXczrJGoKROiuay87yOB3WWN+QKzZ7xRDmKTF05ugW5OjNA0AmixqCrAgqOyihNYk4s4c4tlzEM+e4zLtrP0XYq/NJnb83JVUrrLKvp5/LazhVEuiki/biKbmPd6P8n3C+qhuTyCa3hzcrpGXmP31JukPSOS/7Lnu8nvCaufGKCBQwp6dl30DRO+01jwIFZG/iC0gZzGiqbkiNi7dnVZkoMQKqtlBY/MT0Lzg6Wietw26M1csSpVKLFOlg4RMboSzbTS69r5CGtDNDqLJTX7RRi1fCjLSDZbCx0WT8wCp0l0GItaCFVtrHxQrv7/32ufcgYUFPpXbNOh0L+3ZsXvvG6zYD0Hprch9QrlrZHorSJePuk0rWWPGpEhWjmFw6CGkK8eh6m3U5rYi6swCrGGTASTpu5szbOov8URpZ2w+qBDezFRxrsVqHd861cXGXMfXkTWqs75+5XOZuDMLznsaJa6/W1tvzUNs7e/vvfY5nz6dCxzo9G9OAnbs/u7rLfj9xOqJ1hhLxFyaofILPczKcbdrzvODTG8F6cox2DSBrregWpNQUa1wmn7oLb/CJE38xKbNo53RLIvylfmOq5NdYRL7KEqtrzHkoYXrblCb4kYBaQU8Wbh19Q+ylf+09207PuOfQR67W5R8bWP7TXtfZQUfIKWeChNcUZittcyuM+kuIV1dgh303I0WZuh8tydyFRgc0hUouC/YlNfYjxkXyq8vzDiqoIIyLicpVWc5ZlSHnpiEyrp8+aAiw+dAIBWRtel9EHrn93Ze9qUzucqKzvh+YJBs373nRQK8D8RX+AsQgsvbUIqSzOoi0tWlYLqci9V0J22aUWUKMVyfky0jlPFN4LV+twTXWLU6wTVW1cEUN0FKxBAxfw+Dd9993Y7bg5XE8mu9yO3yW+6+OEllAcC/IqIIJlx5GWx2hbibNrrLsL0VSJqucUmPnKjKVj4t4yZEx90hEVxJkucPOoJqNMHNjsu4Q8ceUiiYSUQSgnzeav6v+65e/y0ZZ/8qQ3+P5Pbde+bE4johXMc62izpULxgqbI1JF8Abvqr7irDZDC+LrPWfNbJTkrVSWQZNBU8T9Voui5WeCVJuREjICJihrXmUSb6M6No9+PrKsPR+wYiIbwUFr8HohcQMaxJxc1/B76hcn2VJAPYQc/dpJSm2ZK78V31Ey1AKC2XDn6YXXmC4zo4roNqjUq5ofQz4q6xikjcKt87RfMH2crf7t25I3n8Xea5xnW2MLgawJtZqfPFGIej2WBmNYPNGiziFh1la8/EpPkKnGxFgox9eCryLT/D5vj5ETiOQbrmaeRcVqCMKa8yE7GCTZOHiPnPjRnc/P1rr3gg9Ht4HF/onN+099pbRf34+N7nQXCNCF5BSs14mLE+ihpDmONK/aaIfMSkfoOLcSUDlNYA+Mt7lL/U2V/kU5phqJTNw8WjbtSFiAnWpEdI8GUwPla50HnD53zO8pXmLja++NZ72rVj3ReT8JsE9ELWetYJ1oRXmlf2c6/FqqaTXNswxrrH3VVZfBORcsN6Nk2OEHAHMX8yqfNt+9906epv5pXma8DS9t17JgF1pYX9lxB5KRGeQDrO7okUYpagd0pY66K2aly5RjZc+XkJSyrETGDl18/Yn4HodmL5LCx9a+/OHYvBs5/VYc+zr4AgacsU8bIv/7D2y4dWLmHYq0TwEgDPZObZbCLTY734TeMYaemFV2wXAyIj7Fov6UyQlCVpfiP7ERB9n0C3kTVfWxxOfv/+67cNqqf3bIvmsVFAqIhduwg33JCHHpd++O55qsklBLkSoMsF8nQAW4hVnYLdQFLZPCXFZWbZ5CaV7hJjLopm1kDStE9EvxTCARJ8V0B3SjSxf9/V2w6tZSiPxZ/HVgHh37uwQI4CU7zssz7+vSnqywVE8jSQ/BZEngrQEwHZBKJJAHWIxMRKFbWd4vpbuIVHQwgGRDgqRI8S5AEAPxKhe5Q1P+Rk6sd3Xb9taYxRyGM0V/64UMAYeBo98hd8/Ov1GdOZ0ZanLaXzsDRvwJMkpiGkWvnycYtESHqKuWtSc5wVHTVD9Ssd1Y5GK8ePf+d3n9cb+3c+xtb++P8j4m7jXljgtYhMp12zWljgjf+9Z/7n/wK+y3WMtt7OzAAAAABJRU5ErkJggg==\")}\n.app-monogram[data-app=\"flclash\"]{background-image:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAATPUlEQVR42u1de3TcVZ3/fO/jN5M0IX1RdNFFEBGC4mKp4q5rWlcEKuDi+suCoCxKk7RUVj3qsit2MsCyR/b4WOgjCY+1PDWjqAgF9axNdlXYtaGcszQ+qK6yurxsKc1jZn733u93/5iZNi20NGmSmbS95+RMJmdO5s7ne+/nfr+f7/d7h3BkoKVlo+nvX+JLz4RWrEBzCP4kgJpEMKKU3rpt25YtudybEgCIY9G5HIXJeG86nIEvAQkGSC677IXZ9fWNV4jgYmY5VWuTojI63nuvFP1ShL6ptVq7di09M1lGOCwNkMmIGhwEVQDs6PAfBbAqivRx3gMhMJgD7wKJlNJaw1rAOX7OOfnUrbeauyfDCIeZAYQyGehsljwALFuWtGitrjdGvzMEwHvnASgiEEB7YCMiDIC1tsZaoFBwf3fLLdGNB2sEOrzopgTU8uX5E4BoFUCXKUVwzgUREBGpVzShCBMRp1LGFIvJRT09qa8fjBHocKAbAMhmieP42YY5c+Z9Qil82lrdVCg4IQIDpMe1j0RYaw0R3uF9ofm22xqeEwGISMY7P3PIko0ItbZCZbO7eP4iInQao9+YJIJCIQlESgPQ4161RCqE4Ovq7Fzm9FUAfa6zUwwAf2QHQKilBbq/v8TzbW3J25XS1xqj3lvheSLovTl+AgZmYyx5736bTtuTb74ZSRnSce0ChUOM5wGS/n7y7e1ybEdHWKeU+rHW6r1J4oL3jonIHCz4u3eBh1L6uHw+OQUgyWTGv6DNIcbz4Zxzfpk6/vgTrhQJV1urjy4WPZhdAEjTpO93YWuVZlavB/B4X1+fAsCHkQFKdFNxKzs63AWAutYY9RbngELB+fKK11M2AQKIuAEAFi9ejP7+w2QHlOQD8v398O3txbcA+lqt9QUiQKGQBIBUCfwpHcQMAGoIAPr6+sb9D9TM5Hmgv3+Jv/zynUd3dIQvEun/tFZfkCSOnXNMpDQRTYODQcr7ICHw1vIO4EPWCxorH8Rxr54//wPLRHCNtfrYYjEA4DCFVLMfL8j/ascOc2ouBzcRL8jMNPmgvd2dRaSuM0a9fTfPQ08n+OXB1sKEIHflcpRkMmIqczxkdsDYEL+jQ94owp1aq4uIgCTZxfNV+AwStNaKWZ4zRp+6Zg22H1KRcBz36t7emIkotLVJk9b8aRH+RBSphkLBcVmh1NWJsJmV0lBKUQh+2Zo1tC2ORRNNTAsytcXzGTU42Em5HAUioKPDX0YUVlmrTygWGYWCC0SkUS1xQxCMiYxSQLHolt96a/TdQ0QN3ZPnV6xI3smsrjdGt0ymfHAQ0AellI4iDe/51yHwVT099sFDIh8w9kO0t+dfR2RWAepyrdW4ZOKp8nQAIJWyyvswKkI3FQrqC+vX044ZnxEbKxO3tUm9UuEqIvqsMWrORGXiSSUbCFsbaSIgBP6GiMt0d6cHD4GcsFAcQ+1OjkgMcKcxqjlJBMwuVOuArfB8JevlHG8CeFVXl32oFH2L6e9HGK+vXyMG2FsmljOU4uuMUefUAs8DEgDSqZSBc/w0IP/4s5/p7v5+8nEsurkZks0ST/a70nTzfFubvJqIP0ck7cZokyS1wPOCVCpS3gcnIuu8Nzfcdhs9O9l0M+0G2DMd+EQ0d+7Jy5WivzdGHVMs+l2rrpp0Y601JZ4PG4BwTVdXavNuuhl/ZFsjBtiT5zs63HlE6lpj1OnOASFUZOJqQc9Ba6utJXjPT4TAmZ4ee9/etULTMReaYvngTQBntVYfEAGcq6Z8UOF5qFTKknO8TURuLBT0TevXU2Hsbp3OGdFUVJl9+MMyb9YsvhqQlcbodLFYkQ+qx/NEkCiy2vsgAN3KXLy+p6f+qeng+Sk1wJ5VZhnV3t75MaLweWv1a6shE7+8fGCN1kAI/MMQ1DU9PfTIVLmV02iAvd1K9xdKqeusVe/YzfPVlA84KGV0FCl4z08yS7a729xdWfG9veCJqJc1YQARocrk29sLb1DKZgB1iVJAkrgAiCJS1QKeAaJUypL3YUiEvuSc+uLtt9OQiFBnJ2i6eR6TqYZmMqKIiBcu3GQXLTrtakB/xhjVWCg4AURKUSxVA3gBiKMo0syA93y3iM92d6efrKz6smQsqKFBE1n5HR2yAAi5KNLvKhYDmEPV5QNjrDEGcI5/AvDnu7rsD2uF5yfJAEKZDGjr1m0NDQ2z+6JIn14sOlfaRdWTiYmUTqU0nAtPAbiuq0vfBpBMpXxQFQNUXLVly5I76+rspaOjiVNK2RqQifMA3TwyMnzjnXc2bds7CKz1QeMBv61N3mkM/sN776uRTXupTBzuS5KQuf321BOv7M8LTaRqYarHOAOjcJVSZRymHXrxWltKpyMtEjY7h/O6usxf3X576omWFjGA0N7gx3GvbslsNCXwSSrgx3GvLtUXCc2AHVCafFvb9iagYatSZj6zl+nj/bEycXgWwA3Mel1PD7l9yQdx3KtzuXgPPefEj29IzTfD6tEvt+Zf+trWULMGyGREZbPEV1yRLDTGbJou8PeSiT1AXcz5G3p6Gp7eJ91kMioePJUqgL515fferUhdCPaLROTVEDFQ+g8E2kJKPTjyzAvfGcy1DiMjClU6rOnA+d+dY615KEkcT62ms9utVAoIITxMxNesWxcN7NutFGpp6dOVVtNFK773LlHUSVovIWUh7CEcKg13IG0AENgVfgUO2U1rz70TmYxCNivTHSeMB0ieauoX4UBkKJ22BgiD3vu4q8ucu25dNFDh7JL0sRv8OO4t9wQs8W+74jvHn7Hy+18VrfqVtks4KbAvDPngCkG8Y/GO2RXYF4aDLwwFEL1epxruWLhiw2pksxzHvWq607Sv6Mk0N5dWRAj8DFGQqVn9JZk4nY50koQXkoT/eft2+5VcjvJja//3pBtRQCdy2dZw2qV3zIpmv+pvWfAZZdOzQ3FIfHBMRJoqi4x2b/rKr+ITdj7hqH7ulacvfwC5deetnO4z4YAP4U9+UupGRvwvtdav8d5PCg1VZGJrrWZmMOP2QiG5bv36ut/sk+dFKG7NqQpIi1Z8v1U0strUnRySkXJUPi71VQB4k2q0SWHnRZvXve/r02kEOrBa/FJ6btky151Om7bdjQ+TIxN7z33M4fM9PdGPyge/yWZfIh9QS2aj7s+WeH7hyoffRtDXKmPPFvYIrjhx9VWElYmIvXsKCxY0D2QX5qcrZjigVbx4cantRqnwL86FoBQRMLEToSQfaEqnrREJv3IuXNbVpZf09EQ/imPRmUxGlSrk9uZ5SH92iT/9ym//0RlXfm8tQf1EGXu2T0YDu+LB9X4RqeAT1umG4/D88+8HSFoyfbpm1NBSUl10dzcNLlvmvlBfb/5hdNQlRIjGJxMrpFJWex+Gk4S/vH37zi/mcnNfHCMTv8StzKAT2SyF5rg3qjum6UqCulrb9AJfHIJPfCBAT5JXXPaA5P0A7l0w+LzUnBgXx6UdM3u2+1Z9vT1/dLTS2r/v86Cs20gUWS0CMPt7gZDt6kr/Yt/ygVBLpm8X3ZyxfMP50PZabdN/EtwoOPjJT+oLWNmUCr74xGNrzj0NpXwHTbVbOgE5Gohj2Hnz+BZr1Ue8B7x3DIBpt4MBEQgAZYxVxgDe86PMvKq72/5gfzLx2KtjTl++4TRtTJaU+UuIILhCIEBhKpL6IkLGknj3fzY9cmIpYq5IGDWVEds9qY4O/yEAV2ut36zUnqcCEcAMhBB+LoIvdXfr24ASlb2cTFz2PBiALGy7fz5s6moCrVQ2lQrFYZapTuoLmIxV7Iu/W2DUiQ/fvLRYowbYnRvIZolbWjaa5ubFi0V4sYicLMJNRGonkf4FgP5t27Axl6PkwOSDjFq48k+XEegabete44vD5eBsGpL6IqyiOsWusGlg7dJF0wH+QVdFHGg5R/l1vCef7sXzKx96D2CuUzZ1JrsCuFS8pacrMhURb9ON2hWGex5bt7SjJbPRVOZWUznhsaMEfulwbm4GDQ5Cmpshg4OgyvNcDvxyMnEuR6E/C7/oygdPEhV1EtHFIAVfGApUOtinN99ARMKeINILADXoBWEyikUVOjsFRLKwrbcJUdOniOhTyqQbQmFIBJBqFG+JSDCpeu2KI49uXvDTPyu7vlyDCZmDa7xDNssgkoUrH/4IRbMHTFS/Sjg0lIUxqhL4TEoTBx8IdiWyWc4O5qhmy1ImCn4u1xpOu+K+k6K6xtXKRGexT+DyOz0RdLUa70TEK2WMsim44s6Pbl53wUANinGTA/7pbfe/Q6fq7lc6mu+Lw55ACoSq9n6ZVIOS4F5kN7pioOuCe/a8vhKY8RSUyWRULhfzGZ/4wQk6Sj9ARPN9cagUxVYDfBERkaBtndJRnQq++E2X5BcNdF1wTxz36ukGf8opKFt+5GJym0k3zPWFIU+kTNXoRhujbb1mlx8Q9qsG1i7dUO28ME11W9JbOx48z6RnfdcXR6rSlCGQQCBtUo3wLv8MhG9oeOKRdf39WV9J6iCb5RlTGzqOKKHiX19RlVqcUrEoTGqWDq7ogxtdp9jd8NO15z2za9Vnq1+8NWUtSgBJ84qNDWnktypljpHgBNPSGVNuNbUpQ2TAwW0Q8Z8fWHPuY9Vuxpi+Q7h8eV0U8n9MwAJhPy1lRJVkj0kfZZh5C/vCBzetPut9A2vOfSyOezXkpcVbmGnl6QfE/4M5ygHQVjUQFAm7Ka0lEiAQRJl0o2ZX2B6S/I32uR03PZprzaOc1M9lKdTi5TxTYoBccyzlYod8KS0wReALWEjE2HrNwQm74q2Bk+s3rz3vt7XE89N/BogQiOTMj/XOdamGraT0HJnUiroSzyuTMkpbcEh+KJKsGlj9vh8DQFnJrLlmjOmNhMvlfgtXbPg3beuWeJdnmsA1wS/L80ppk2pASApbAc5uWn32XbtWfG/MIKp54Kc8Em5Bnyojtp6UIRxkSbWIMETEpBs1kR7yxUJWkVu4afXZd0GEkJFSrdAMAn+qtSCCCE686qGoKchmZetOCUl+/NmtUjE866hOQxjCco93hc7Hu89/shaqm2tZC5K4Nae23ry0SKKvKFGHJgHCOKD3pC2ZdKMW9o/A83s2rT7rkse7z3+yUvc/k8GfXjV0+QOXGlt3pwiDfdET1MuroaUVH4iUMekGeFf4X2K+ftOas28BIHHcq3PNW6Sa8sEMvK6mZISF7d9dSlF6rbZ1xwWXh4REBMQQERCIBIq0IWXrEVw+D8JqFAs3DvRc8AeAEMdf1zN9xVctJVkxwskfvm9eQ1PDSoF8iICTlEnv8k4lOAiHpyHygFfhK4/fvHTwUOD5mskJjwWyOe6N0q9uerMKeAOzm0vaDEPpX6MO/z3whbNe3Fer0ZExGVeXZTaaV8wfZzIvdz5Q3Cu6ZaOYsT+VHoIjO2C8imkGtCteQKkU5OVWvIhQaw4q17ofWUGE4ld6zREDTIC2ekVXQL347t/PN1HdmcLhVGE+WimVJzK/Bpn/uiNu3LKrqbATMlMCMpoJ4P/1vb97bWRmfZYgrdqmFihjIRAQCCIMlx9mUvongYtfurv1Vd8aq0cdMcBBgv+hrz0dW5Nea9Kz5if5IbBPmDCmaEqEoJQ26VlQSsMVRu564YVi+wPtx47OBCNQTYN/1++XpRrn9ISkgOCLnkB6n1k1kQBAUk1Hm2T4hb75mLf0qBjFLGqbjlStgn9J7rk/t/UN3b44EoIvMpEy+01pEmkQmeKLzyepxjmLn/PPdGeJOM7l1JEdMB7PSIBzbnoymnfMUZttatYpvjASMO7KOXK2vtGGkaGld1y84KGxB/mRHbCf0bIRGkQy/5jZF6ZmzT7F54cnAD4AYQVmCQifA4DmLThCQQcyFjyfKwPFl4iwQCmZYKm5doVhKG3OvPju50/OZolrNVhTNfTtm5RrbQ1x71N1Ijg9JEWSg5mfINi6Rk2KzwSAvsU4YoD9jUxn6TxKo+FoEM2T4EEHdZ+PgEhBEY7HYZqQmRhsBRcB0AebT5ddj5ICgMVHDLD/ke0sYVZMhxcJkgepg7JBqcFXBELbAKDviAFe8eAUQKh5S/c2Af1G26jslE64KFexdySgJ0oHfG16QjXnhmazWSbCD7RNgwQ80RIKbSJy+eHtNm0fAYBcDD5iABzYpSBaq1uT/M5AWk/oqgARCbbuKCKou9dfOGdH3Cu6VuWImjJAlojjXtHrP3j0z0OSrE01zNUi7Md7d7S2KZ2M7nhBIvwTRChXw4FY7YlxIhTncmpOOk6Njv7h31MNTQsLQ9tcubNm//NlDqSNMql6KozsuPDeS479di3LELUrR5dl5Phf/+dVdQ1N90ezjlpU2LkNIlK6naVy75iU1COSksNj6hu1cPBudGjZPZe+5qu1Dn7tfqEzkWQyonKXH/8M559aUhx5cbWykUsfNc/Y9CylTESkDJExZGydihpm66hxjmbvNrmksHimgF/zGbHS7VmlAqxLv/b0m5ROXyLgd4P5dczcQASnlH5WlB6Awjfu/MBXvg1keaaAPzNGuRJi7J8u79159Efuffb1f3Pvttd+fEMp0sWufEKvnkmf7/8BpAtW5gQM15EAAAAASUVORK5CYII=\")}\n.app-monogram[data-app=\"v2rayng\"]{background-image:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAInElEQVR42u2dX0wTXRrGn3NmppRaBBT/Au5mRbKJghduJHhlUAyJCJqaKFES1z8xXOgaIgkXrOCaxagxJmoMUS9WQoioISBW3ERFb0iMMXihrPn0Q7NfIsKn2xYQmvbMnL2Aafg+UaYtlE57nmQuCp0Wfs+Z97znPWfmAEJCQkJCQkJCQkIRFwnnZM45CfczYkCcEMIj922cE865LNruN1zkiQY5e1cA55wSQrRJrxcBsMQ5ex8h5NfvMZpOcrDw3W53anJy8lEA2wH8UdM0K6U0LslrmgZKqZdz/h5Au8fjuUgIcQVjAgkGPuf8zwDaAWSLoDOlfvry5cv2tLS0/xg1QTYS8+vq6uB2u1MBOAH8SVVV38S5RDAfxwSASZKUnZiY6Ozu7v4LABfnnEzXQRMjnQshhPn9/n/Isvx3VVX9hBBFMJ9Sfkqp8vbt239mZ2fX6Ox+dAI1kGaqtbW1MqXUMf4jLgnO3+0TJADcZrM5ACgA1Oka+bQhiBDCu7u7lwDIHH8pos4PWBEARFGUzMrKyqWEkF8mwlBoV0Agz/L5bJzzBIHYmCRJkm02m9XIew0Z4Ha7qcAaVCgiw8PDdMYMGBsbEwYEOzrz+WbOAKHZkyEDGGOi5w0hDIkrIFauACFhgDBAaHYkR7p8yzkPZmSJmSp1q6oaysgWs11qj6gBsiyHZBrCm6kCACiKEnKjMb0BnHNQSvHixQsMDg5CluUfXgmEEDDGkJ6ejpycHGiahlBqUJzzQCt++vQpvF7vtJ/DOYckSfB6vVi6dCnWrVsX8vdHlQGEEFRVVaGrq8vweTt37sTt27ehaRokSQq65erwjx49ikuXLgV1vtVqxcOHD3/z95s+BFmtVlBKIUnSD2OyLMtgjCEhISGcqUJwzrFv3z7cuHEDkiRN2/9QSqFpGux2Ox48eID8/Hwwxma1H4ioAZTSwKHDUFX1GzCapgXdYU/ubBVFgdfrRVlZGdra2gKGGoFvsVhw584d5Ofnw+fzhdRvRa0BQ0NDYIxNCyOcTEdRFHg8HjgcDjx69MgQ/Mnhpbm5GYWFhRGBHzED9H9wy5YtWLhwIRRFCcToJ0+e4PPnzyCEhNTifw9/YGAApaWlePbsmWH4lFKoqorGxkbs2LEjYvAjaoCmaaipqfnmdwUFBejq6gpACEWMMVgsFnz48AHFxcV4/fq1YfiSJIExhitXrqC8vDyi8CMeghhjgVaup3vhhiMdfm9vL4qLi/H+/XtD8AEEvv/s2bOoqKiIOPw56YR/n2+Hk97p8J8/f46SkhJ8+vTJsKm6STU1NaiqqoLP5ws61Y3rWpAO//HjxygsLAzANxLGFEUBYwzHjh3DqVOn4Pf7w24McWWADr+9vR1bt26Fx+MxDF+WZfj9fhw8eBAXLlyA3+8HpRRztdqDmhV+U1MTHA4HvF6v4Q5cDzu7du3CtWvXAoOsuVxqQ020/BuqqsJiseDy5csoLy8PjHiNFMx0+MXFxWhqaoKqqiCEYK7XOVGzwOecQ1EU1NfX48iRI4EOPRj4GzduxK1btwIj8WhYZCabAb4Osbq6GmfOnIEkSYZLFXpWtH79erS1tcFqtUJVVUTLkno52tffE0JgsVhQUVGBhoYGyLI8Zf3oe/BVVcWaNWvQ0dGB5OTkWS+uxZQBVuv46r7du3ejpaXF8ABrMvyVK1fi/v37WLx4cSDdhJgTNhZ2hoaGsHfv3pDhp6eno7OzE5mZmVEJP2qvAD2lbG1tDYygg4WflpYGp9OJVatWzUmJIWayIKNppv5eVVWRlJSEu3fvYu3atVEN3xQGGIWvl7OtVitaW1sjNqES82moUfj6cfPmTWzevNkU8GPCgMkTKk1NTSgtLTUNfNOvjJsMv6GhAXv27DEVfFMboM9mqaqKc+fO4fDhw6aDb2oD9BLDiRMncPz4cVPCN60B+qCssrISJ0+ejNpBVkwaoMM/dOgQzp8/P+cTKnFlgA6/rKwMV69ejYoJlbgxQIe/bds2NDY2BsoVZr9xnJoJfkFBwW8mVGLhMTnULPDz8vLQ2tqKhISEwFQkxC1KkUk1c3Nzce/ePSQnJ0fVbFZMG6APsrKysuB0OpGWlhbIeCBu0osM/IyMDHR2diIjI8PUub6pDNBrO4sWLYLT6URWVtacLRuMOwP0yZf58+ejo6MDubm5pi0xmM4APbXUJ1Ty8vJiHn5UGaDfiNfS0oJNmzbFBfyomJDRZ7JUVUVzczNKSkriBn5UXAH6ssPr16+jrKwsruDPuQGccwwNDaGurg4HDhyIO/hzGoIopfD5fDh9+jSKiorAGIvZVDMqDdBXOxcVFcVcecFUfQBjDPH8LFIaDfk/xAObhIQBwgAhYYAwQEgYIAzAVDNU4tHFc2nA4OCgD4BP4DI8uGQDAwMsbAMopby2tpZevHhx0O/3f9Q0jfNwnqqEmN/MjQPgbre7v62t7dfa2lo63SY+0+0hg9WrV8t9fX2evr6+f1NKCcb3RRGa+tGcKgDy6tWrBwBcMFBrM1R+dLlcib29vT9v2LBh+4IFC1I450y/U10cHHx8oxhVkiTl5cuX/ZWVlX9TFGXYarWy3t7esCMGWbZsmQ3Awv3792998+bNf7nQlOrp6fnF4XAUA1iwZMmSeUa2CTOa3UjLly9P+fjxo3XFihV/qK+v/2tOTs7GlJSUZYqiyEY3K4i5DIZSzhhjbre7v6en50l1dfW/+vv7PyQlJXmHh4c9ANhMGUAAWGw2W+ro6GjixM5xqVlZWWl2u10O9WF7saCxsTH27t27LwD+B4DYbLax0dFR10TWyGdyN1UKwGK32+3z5s1Lcrlcss/n42I7Q3CLxUJSU1PZ169fh0dGRkYm4GuzsaEzmejZLQAUu92ucM5pnG/epo2MjPgB+CfAMyMtP9wdtenEuWJH7XHY+qFBSEhISEhISEjIgP4P+jwZhmKQxxEAAAAASUVORK5CYII=\")}\n.app-monogram[data-app=\"streisand\"]{background-image:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAzm0lEQVR42tW9d5xdZ33g/X2eU24v05tGI2mkUW+Wm2TZsg3YFBtwHFI3CYGEJBte3g2wuyHtQ7KwZEOSfdNJISQLpoUY02xjG/deZKtafTS9z9x+zz3led4/ZkZTNFUW++579Lmfj6R773PO/fX+Ey21ezRCIQgQCrSWaAkAQnPpEkJc+rvWs94AhJj771nvTL0W/t5Krtn3nX/NPm+pz13JNfdZ9dRr+pJXcF817+xJ2JgINXW4QCMm/1/PBtuSj3npu5cDHlZ6yv/Zl1qUoFgxjGbDYi5iJSIANBqJEmIGnHolB6tFPiimqOT/7wjQ84jsShGgZ8Fk7v+bWoFETFK9AISYuYVYTizIRYC/MAavtphYyXlazP3NK+XsGbEqLgP+6iSpmCfSBLMfW4KcQoaei1+xkoPlEuJntSy6mndWfppeQIKv7m7yLXKzmEeUc0WSCaCmPnM1hYaeR31SLyZfF2LPqWficmNgOWpX0z95itrlikWpWIDir0TUsIR0mL6XMYMAqScfXK+YOsQqmW8l54kroPy5Z+grJhPeosGwmjMuJzRzmsL0kt/XqxYzSyvyxREwn3OEXtkz6SnBujKqX0gciCvQPSs/Y+Y7YkqH6BkEsKSU01dohukV8oZYEPArBdwk94pLyLoa/Lm63yXegu7TmEpMUozQi50z3wy7GgpWLvrp1d9BvAWQiqsgct6a1jSn2VVPyww9oyBn2MZ4i9p/ZcpazFKgywNNXFLu00R09e3/hX6HnOeBX+n5Yq4IujIAXrkcXVQg6dWbqFcH+PoqiahVcsBSYNFazHJMxCIm1WwNIlZtva9cWbOg0l2dg7UyBGgE4seKADEFO4W5Mu9ULPCgC7nnswAmJz0+rQGl38KDLvxdofUlJGixMl9Bz/uQ0AsYA1NKXWiQctJ6UUrP8X4XgpmeRwVCi2W4a9IkNX8stq+QUPYInAARMpBRc9LVWTUixCxE60WRsjTw9TwzV08HBBYOGUzSDkJCoSQIXEU4amKbatlorp71XJefv7CVY1515SoEXqWAubWa9NY28ucGUS/1o9OAEUcEepVRSHmZwzVJpRo5RamzdZFGTHHGpIiUekZpC724aFFCoQHTAKciccsBe3fbrF3nc+xwhd6hOOGwB1otGK4W6KlnEYuEZ8TCZuhVlWxSILIu0Xu38eG//zCb4hEeyB/j9BdPkPvTE7jjeVTKhiBYgdEvLnPv9az/F/PMz7nm6Oo8XA2YWmBIxWhesL5e8bu/H+LuD11POLWN/qPf4oM/18eRvhTRECh19cxaebVVi4+mErMYiNvU5OEucx03/aeDrP3+LYgb6/DGi5OKQS4X/5jrbV6ifDEpUmaofxr44hLjC62nXiuL6xhyMoiUnRC8d3+Ib98X5QO/1Y5IrsH3DZqb41SlLZSvFjlJzDNEVmqGSoxUtOHTVy+LBEHMQh7rpb8ywvjt9USDCrn+USZaAkLvqQdfEhyeQLgBKmxM5oNWIPKmKV6sKHoklgmqzXCWKQUlJ8AL+3zqI2E+8wmT2rW1OIUUYacHr/sUn/rEMN99ySYW06sIRa/MrL1yBIgpbTWfpRSEDIPSYz0MvjxA+cYUTotNpN+j5BQxb63B21FN8VgOd8QhFLKW+FFzgSgWjBwtpOTECmIzIA2YyEs6Nlj88yd9fvoGnwkrhlIRYuVxzr06yId/p8z9zyhSUVB6LgcIsRQjr8Rj1kshQC2echRTcd+yP5nAsYw5WQolBWY8intsmN7Hu3E3JhA7Y7i5DJVuF7sO/J+sgl6QRyYwwybKmBIfQi+R6tQgDISUM58TAkMI5DxlvaS8l5Ig0IxWDH72ljj/8suKFl+RnagiJSRRO893f1jm1//A40SPoCoZ4AfBZHRAT97TNAVeIHF9gWVeEn4r4kIhJk10IeZwwGJm3rwDhEBXXHRY4O+uRrsBjJSQEeOSShGISWshGcKfKON+s5+iCKNvS1IoZSifdKgUHeI/U4PZEEE9k0dXXAhbU1aGmBdymJb7IZRfwq8U0H6A1AFK+xSoUKSIiYklrQXSHjN/DwnIlALsuMn//GCI375GMfyiopiLUt2s8FSFz/xLhd//kkdZGaSi4AfTRqaeNFGFJJvTNFdVWFdXYWRcgjCQ0l+1WhWttbv03MSImJWguBz4+AGRtZtp/f2N3HbLegbGijzzJz9i6GtnsWMRMCe5Qwgxlz0nHMJ3tlL4r22kq5K457JM9AxTtTeJW/DQn+omOJ7FqLZRwaQivfRc0gDlE7g+ifpNNLcfIhXZSVMxSmvBJ5bLcTo4wZP5R+ktdxGXcQxholCXwhTTz5LP+9y2z+KP3hOnpU9y/kiU2AaTjl053iyV+fh3PI4cDRFPaZT0EabG9xVKgTQ1Fc/AKvr82i8IfvmjO6hrquH+L7/MJz/rYJgCvUpfx0hF6z+9MK0swDpSoN0A0Wxx02/vY6uI0lCbpuUntpFPw+iTvVhFHytkovSUwpp+xWwqR3Oo58Zwdiep2tCKZUuyL+ewoyGCj3YgRwPkqwVCRoA2Jq0ELSLIchZbpIgd/Bj223+P2mvfxo6dG9m4u42azevZntjC+4du4WdKb8OPhTmpOnH8AmFhowHDAKcikC589M4Yf3ZjCvfRFCeP27TugPYtgm8cqfAbX89yYURSFdP4QhFojVIBQghMAzJlg3rT5c8+a/GR/9ZBsnoDRiJNLOTwv748giaEEMGUiBErylnPQsAKHC4N0jbxBvvxusvId7XRVx5jPFeg+dZm7JuqGXklA915iBuTsaRp3aA0xAXGeID57V5KEZ/YgWbsdQ2o8UEYcYjfsw7dkSJ4agxRDtCGRleKVK65CXnoTxhrfBu118M7r3VpaVBU12hS9Qr/ugoTN/nUDKa46/DNHIjcxFnjJJ3+eUIyRC4jaG0y+eufb+Aes4YzT/mUPM2OG6PEGwv87g/7+eNnXAIpiFiaig5QUwaGEBopBdmsz+1bcnzpL20O3F1DriAJxfOMnj/Or3/4PD2jEWzTv+SPrLQGanUIQKMJEKEIw0eH6D/RR/j2OrSpGDozTmyDRfzeBNkJgfNGCVMqtDkjkIUCYUukNLCe78fvdRH76qjf3oIfhHBPd5I6UIW4ax3BcxkIXIq/9Cvk7v0EVGtuuKXE9u1p+sYCLuRNMmMG+X4FZzVRzyb/XhenrUDr043s9d6PH3d53X2dO242+Kd7Wll7vpqujE+yPcqOfZreUokPf6efb3dapGOTYkrpKR0mJKah0K7EcSw+dmeF/+ePJanGBsaGSlQ3wJEfZfjQrw1y+E2LWNQkUHr1wcjW2h16uWzV7ACcni5dMU3EsAebY7T+yVaSu6opXSyBVUC3hBj5tzHKnxtClUrohAJfXoqqaqnxLIE9VibYmUL+5+tYu38Dslxh/M1z1LRHGfUaGDy9nfFdh2g3BO9otMl1RxnvUoQSDo0pmw3SIp7XeOcdGk6HSBZ9jH2S6nAF67+DeTjO2c0vcPATnyPU7zLuNtNQUyKiLO5/eYRPPzLGCAHRiML3QU+WBk6ZqAalgqI2GeMzvzDBPe8qMuRUYRoJajZ6PHD/GJ/4jCanqkjECgRuZE4saPkCrQURsJi9Oq86TEzmNaUhoCgJjAp1v9lO/IMbcIbyZPtGiLQl0QMuxT85R+X1CjJpXHKo9LTjaBpYpYBKIgS/0c72XzpAjS157bzLhehBgupaDiTqac0oOs/a+AWT6pqAHesle9OChgCsQDAxqsg84+O9ZiCGJXJNkZ03WMS+56K/EiUcypL42Feovfklyl0hPveVAb5wohcZhbgwJ0MLAgQKISc9ynxectueMn/8MxZrTYOuTk3TXhPZHvAnf+7yt98xMVMWttAoTzBZ4Mayjt98GE+JoJVUsl3uFKGBkCakDJwnBsldKKIPJPESJvo1n0pqHO6pJ6ws/Dc0wnDAEigkGJP3U1EbhCD0g4uMFcucbmiju7KGquY1HEg2Y5+DU+cFhZJBrMVn92bBjiqTBJqNUlBvCVRYoupNyp7H0EWPoDtO/xkI71c0HMgjj4UYfupaXD/Cbz76I756souaVBghjCmZPeUVG5rAVbie4iPvCfHHt/vYPTYXz9WyaVeFASPHr/1BwH1PR0ilTSw0KpgGhlqCgMWiBD6FgOXiGEt4lhp8A3TcRp8qUH5qDGtHGnmtxu+tEBoX6DtDRDfHUC9o3FKAjEGAgTAtlFJ4IsA9uIXi1g7G0tVs3rubjkgbPUckF8cczLBFc4vJ5naL2qjBiF+mwzDYHTIoq4BcwediX5nQWpNIgyBzLsAdEQwdCZFLBFT9Ypn4qIH/g800ZzYzkLzABXmRiIhhaQuNxrQCCgVNPC74y1+N8qH1YfrfqKJs+mw+OMCj3WU+8kcpjg1YJKp8RKCRSs4SLnqFMLxMCTd++vJaz1Wmx7WejPVHJEZG4T86DDqKcaiJVBjkhIuxzab63QnMvgK50wFWNIGueJSrQ5Tv2k3uzu2oPdvZuvdGkqNNnD7qkyn5xCNhNm2y2dRu4giNDsCVNvlMwJgSvFlQnB8xKGuJHoB4g016l6SYdygMC5zuMENnNJF3+lRtctj4ehO35fZjhSOcFEcJVAVbmoyMm+zbY/Ovv+OxPxOn75hJ/eYM1Rsm+J8PVPjUVxoo2CbRSIAKBELLebHaK0vJLuIJX2F+VwGWwNAG4tk8ha4y3CBItIWpzSua2pNsuBuEYTJ+QeFsbaD0zn2429bRuLud5g1byZ+OMdDnoAKL+qoQ23dHCdeCLoGFwgkkr97XTVdfHnNrFeOu5Om/6WPktENdRxpRcaj4mupdEeyqAPccuOMhssc0TouNvrNEbVeKG/uvZY/cTY8xyFnzOP/XhxP8zWdt6sejjPaFWXPtMAOFDB/7Yph/OFJFMmqC5aK0uELoLKyEpxAwv0TwyvOhAoGWoGKgz1WoPJPF35QitRfaXJOmRJzQHo9jdhujm69BrG9l6417SEf3MnBMks9n0FZA69okGztSBELjFzVmWDIypHnmvsNM/OAcde0NJPelGdOCgfsucubhowy7MVI1SarSJn6nTyplkL5GUup3Ydgi6IzgFTxi79X4ZpGNp9ZyS+kW9jb5/Prfv0GoLYnXb5JeM8ojz+T5xX9N8HomQl0UtPaQSlxhAYBeNIs4zxO+Mtwu6Plp0FEDM2vgPzJBoKJkdkxweBiefWkf47EOqra1sW33bpx8NZ3nJygpRTSaYkvHGqrrDfJFl6gKYSDpfKaXo197AzMnUW6ZSGuSyO46KhUYfWgUNVBCjvv0nwHHi1LVZlEpBoSysOnaAJKKfJ8mGAxT6VQYu0OEbiwSHoYtF25n9OvXQPp1nNQp/uKfTX7v/jBFGSVl+fhqMv+slzE0V1ZKI5YKRVzdSgAj0OiQRgQu7jMlhqp2ciGyh0q0lU37drOuaT2DnQYDA3mk4dPRXM2WjoZJPixDSoQY6C3zxoOvMPbkM9i5IQI7DMIm2RgnsaOeihMw+t1hxGiAjCiyo4fpOj7G2EWLdc02DVU22WFF8/oo9VsUzkiAHg4hzkqkLbHvyOCnK8Q7q9A/uJb7X8rzBy9dwIrESAE+ARo9KSPEVAHAW66SXtQKurqXbwvMogu1SfK/+XbGNu8kubadPTdsJOKm6TpXZMIpkkwm2dzeRlNVjFLRI2GCEoLhTIDOlZk4dho1PowUGlXJo2kivbGBUHuaoBggHnXwsx7FoJNCsRvLamBNVSNVa6rJORVq1tjYBYktPNr3WchwkcKYh7xgontqkQdcjGv6ENSw+9zN7InX8HJwmv5ggphhovTVKeO9/AqmdcBy4kevujBXSoGR9zG2riPz8Q+Q27Oeth0b2NvcwVhfmOGhCr52WdfUyL5NtcSBooDqkE1upMi5MyVUyGT33hRVN2xkwmqm1JMnnBkACoR3dxBrTaEcRfnJEUrj5yiUBmlu2M8td9zAdR+pJb7FoOcxm4GTEr8tT11YIcchvt6mscNAlVzkoCJ0RmLb1ahbx2FtiX2Zdt5dt5UT9HMq20PIMmfVSM0v0lm4ymJpiM1UeswyQ69e1ZgQgnC+QuHgTrK//m5kc4L1W7bREm3mfF+J0VJAKGlx3dr1bG1MYlQESUNgITn7wgAXvvc8/tGnCIYKjBKnam2KjbvSiI1rmCiUKHWeId7aRnx9I37RY/Dpw+T636T55r2846OHaNwfQhYkJ79QoOu5Y/SNnGHwWImq2jpqtkzGeEKhgPQWSIXBzZdxezWRvgRiZ5mJzXmqggg/lbyW0ZLDy/kzhA378m4voSdz1GLakxZzO3Nm0bRYpO1pgYzYUumM5fWElhKz6ODt6yDzyXsJJ9Js2XIDYauWvr4yLpL1dbXc1NpAW0QgPEhaFvlRl5NPn2f44jBGdpjy8Hnc7gswFDDkJDATPrs2Jgjv3UbvxSFkzqHmus0EymT0gVdo2NjBT/3h26mJa/oeDXjtCz10Hz/OiPcSlSBLyGohn41RKrgQ9lm/MYrMmqgWQWQTmJUCYjSPGImj14VwWg2MrOCe+PUcHT/L0eAiERGZU38xk6deuNxlBmKL56wX8AMWy2euQEkLQAWISIzMpz6CUdPI9g3t2NFWJsbLSNtkfX2SXTGbNUgsaVF2fAa7+zn64hmynRdgvBvpOlixWiLRKsJuET10luybQzhjmr0ba/DXr+fMi0eYuJhl+PhpKmaGW37lJ6gbEhz/+jhnHjpBoXiBwMgT0WuJGU1AiWwxw8hABX3axh0xSLUHRJMWdhjclAX1AXbFRRUhmrLw6w10AbbGNvCdgefx8S8D9fLAXzpnPZUR00tUFqxcxweGxCyMw+13MfKZ/8yaYpGWlmomHAuBIpZOU2f6tLgeG5Mh1thhzubynBvOMlDR5Col3IoiCAxU2cer+LgW+JaJdE0Cx6A8MYxnG9StTdI+6lAe13TWxEkdHSMxYhBqaKfKcKkOLAJXEim71KKoMcqEQlFikTBNjQZ1KYtIVBNrBBkYeK8VsSsZvLyNMVwibAQE2xTuiYCa0RS/+fzn+Hr2YdJmFVp7l1X2XN6SpVbUL21e3orJW+imFcgAvP07SKcS2AjckocXhLFNQdjQREIWhmGyNmST9BRbIxGa1ycYkDAYwFgJRgLI+ZPRSUwwXTAC8Eolhr5yhFLPCIc+/xF+PiXodOA7p+Gl//FDWu7cQ/t7EyTHLII8VOUh7UAjUB+BeASqLahtDtAhn4hlYqCQlgVOhWBMkqyBYMhBBSZBpkDIiWKacW5OHeAbuR/CVAXdwgXB+gqqo0XAZGu8vMK+xBmlo7VG2GGMlg3okqSc08SqA4LhHEWvhnC2SLHBJtIU5ainKHqKbEXTmyuQ78pgFkuUPE3gGGTKEyhTYxoRhFOgnA9w41VsuG0HoWiC5770Bk888Sqe6dN44Ho+9MkP0fuqw/ifdtLvBRgSCvkoA77gvClJhw2SYUjbmrAO0742xqa9ZZIJk2AMrJKmYvoUT41inM1h1kYx0ia6N4cKp9ghO4gYYQLtTffzzkHCZGmiXnXNm4kWi/SniFVZRAJBEChicRslahg/W8YZGGVoSy3tpkdPb4GxiQiZLp9SR4bItiryeUhHJBurIhxzS5z71jHU8eMIu4jvVFBlhVV2qVTvoOrWa7np7RsIr4nw8j8fI/jeI6T3bsCf0OS/fJjQZzZzx/uq6X4mTPfj3Qyf66XP7UcEJoZOIS2Ia8mGRCsHDrWycacmmVOUJzLI+jDhokPyiQGcMyVo9lEH47hPZfE7JMF3cqRr0yRFgmyQw5LmJZEzUxgsrqg/eZYSXkrZ6kVK1Gd1qgiBHyiaG+IU9txJbrBCS+cwlXGDkjBoa3EodYHTZ+H2BpQNRW2ToDQu0HlJw5o4ckMbpVEoXxxGSxfhm6hNN9PwoQ9w7Z1NeFGL11/McPEL3yCxazvpX7uH6J7t8NoYxx9+hI7d19G6S9G+uZqw7mBiwiTv9aClR9xMcW3rTu76QBu7r49iXXRxHR8jGiH82CD+dy+gT2bQOyLou+pwHxoj2gL+40OYmRq8hMm3/B+SC4qYwpjVk7awpThdQnmJOxavjFvOE1YL9AIsoOOlQGtFuiHBaN0tMF4h/OZj2CqCm6kio3Js2hRCDMYZHq+QO+tQGLGIr5d4rsQYrmBHJTXXboDwWuRZH3/vDjp++Q7WbZeMng04/d0Bsv/+DCI/RGzbrbRFkth5F3UWyqePMvjmKA2ZXcRDPpuuEdSlGvAG62gOQtx1/Q4OvaeGRmMCOhU67BEtecgfDKJf7Ef05vHvrEG8LYn6Zg8iYdN1/DSZ/DB+1COm6/m34CEmdAZLWLMaAheuep4pqFSI+bmCWdXb5uVdfnqZOv2lBJNAGgYq56H9gLJZi9PXS1XRJchv49yARdtNY8j+KH2vwtgrGcbPRml9W4i21ghmF2Bpdu1vZaymidGCT0MyYPiRMkPfPEp56DWkhKTcQuKcJr7FR3uaYMxF2gcZHzjMg9//LutqbuZd75E01Gj2VdWz/sYW2reUMTsrKCuKXeMj3/DwXxvA6O/Fc3ysj7Qh4hXMv+vHt3N09naSUwrLrqbiG4QrGUIhY0XhuGnxJC+buHI5jFfgCS/tA6jpAJUQaAXpqhClmgN4QYAs5fBKDu5wN16ui3Q5RL6rmnjTGG0dIUq9Nt6AS/lEQN4T1Le5hIoS94JPql4QT7mM3O9x/r5XKOYPI6SHFAmsYgORdJj6nWlM18M5WsIfcrDNOhyO0zd2geHDtbSOR1m7pUKDGSAuFInVSHwDggfy2C+PQ38eXQ2hjzagR8ew7hshF4xyNNMJIkAFFXxVojbRgekJvi2eY1RksEQIJS4vk5/bnzDbAZvdoK0v9RhMjqtZSc+UmCv/58wRmqVtJBoVGChPYSiFP9aDuW4zjQd/AS9XYuJHj1DtTcCDd1LYOUr7XT79L9cx/lqFwvfKHD9mcf2dmkgLjL2pqE5YrN0HidJWXnq2iOMdp85swsvkkUEzTa7A8SQTgY+hNdqwEOW1NJnN3LCjmo1tGqsCdt6jen2EyoCN83AXDI1j+xWihyzUrTH0j4YRr5To0hcZX5Nj7c8eoNax6Xz8ZfpPXUSpEnkh8fCmalIV0yJez+vUEVNiWy/aQzyXmM2VNq1d3sgzrxVHTz6BCiTa0xieh3B9RCnN6A8fp379Htb/5IfpeuUpLr7+LVKFdyC6omy9I8t4k6DnBwalMzZPDQn2HPBYe12IYlcJkfG47ZZG1q+5g8cebcTpK2NUJghrm7XCpuz6XDQUAT6qHOHGtv28Z3899a5LUAyIxi3CaZ+JVx3KLw0TGa0QrgX7XgOvSpH+okW+u8irVSdouLuFa267lcqDXZx58ll65DCWZaNcTUm4BEJdMtenixLUArEeoaf7psQizYtiJeXp85oeFvnXfD2Rtmxy6evxAg+VPQf95whnikycHiF7vov1W/YQb49x4dg30H0p5Mk2qhqy1N4Zwu4JQZemq9slGLTYsVUQCUFpRLOx1uC6Pc30deXoOzNC/eZ13L41RThrcPR8hqHOAh/Yu5F339mAlfeRjqQ6HcbLGow+VSJ4uUC0YJHqyBP5pRLRPpvIN6McH36No01H2fKxQ7SnGhj/qx+QMR+iJzpOtl9hWJI6fS0ZPcbD4hWKooQ1i27FZXXRs1WzXDaBdRUbNCaN4rCUlKqvx8MnOnoGM7aftr0f4vZ33YThe7z2xGukqKX10I3khl5hcOA0fueNhMcs1t89QDIcRh63yA17DJwLaKyJ09IoUXkPsxiwp60KmySWjHKg1cbNQ/9Fn3e11nHopjrGR3xSMZ90XJI94+A8mcfsKRM3XJLvqGDdOUrrEym8xzN8t/ICmZs1d9z1DhqfHmbo3LeIffIoa+4S1BuKnjdCuNpiDdcwpjL8UL6IIyoYwkDPA7UW88EvVpuUv8IQhJjOFE3FtwWUqq7DtzxEvpNUeCcda7dQynvU1K5n0+YOTrx8nNyFMXbteyeExrnQex96pBr76G5qr8vTssWnfDGFMxGhcFYT9iXVayAmFHV2iGu2VLG/w2LNekGiRnNgQ5xNySj5MZ/qapNQQVB+AUqvl7EGA6JNiqoPDhJrgoYHUhw/fJL746+y9gM7uDvdTulrD5G97lGqP+8RGl9H7sH1iM568mNZRtwQG9Q19AZ5HraeJDCmStDFrBz4VLvE5aHnxSygmdcSCFh5EuaSQBICUwQYyX0IK4TKd1Kb3IeyWimUclhaEbVNrtnXTt/JLMOvv87adbto3tZB//BDjGYGiB/ZQyQSof6gQ2jQIxjxGBwysDOC+pTCNiBsmDQ3G9TV21RbJqLkkRszSKUUzpmA0jMSTnvYuYD4dSUiP1UifSFB/IEcD118iue3l3j3ve9l8/ER+h/8F6xfGif8K2mMb2/Aea0e4cYoDjnkSyWGHYtGfysX1QiP28+CkIhpv0nMFUFiUeDrBRTyguFosWoEiHkIkATIyHZEOEFQvEjM2k6VaELqUbbujJMbDvDKmk3Na+gfKXHh/FG047Bl53uRlUFODX+VcO827N5aaveXiMQEwUWB22OgR33WJCysuIFpQTFTojIMyjEJSj75502cVzV2f4AIBUTudkiuc6n9ocHEE6/zleJjqLfv5Od2H0I98C2y/V+n5jevI9V+I94PbbxRjdyxCf/MEJFhn57sBAOepF5s43UGeMF4HkuEZrSh1pf1ri2U9VoqtzKFgNljB97K5ChBoFykGUFENyG8cSqFXsJBLXGxlu7TOUxfY3sGUWWRq0hyxTzZrIdbCNi3bQ9VVbW83P+PGDmfeO8uImt8mra4OCMh3Asmfg5MQyF9l3TExPAllU6T8ecE3nGDYCJArytSd4dL1eAoqe8pnul7mG80neHWe3+Gu6O1dD3xKAyNkDpYhzbqMfrHCI0JAi9BZWCCxDmbvqFRni92I4w22tQOHjNe5rQ8jS3syWmHWi/pCc8NyunlmvT0VRq/IhBCEqgcInotFgl85wzj5Weh0kDErKVScgiHJOWRIt0Tgsj6FtKtO5A943SeO8qapq1sWXc75/q+RqZwBmv4RkKexfadOUKGJN+rCZcN4g4UujTZToF70SN3ykcVBKlbJ0hvdql6zCZ4pY8veffTs6eOXz34q2x9tZdXD/8bTfFmmta9G7fkYxVcTCNGybSpDFgYx3p4fKKLH+UGyIkUm+1bCcqKr5hfpWx6GJgrHJIjVgRTIxWtW1VdkJ5VnrFQiYYQJgRZpOsQidyMlDaVyghZ52F838PUTbhFj2FTkryhjnRjCoY0Zm0VltfAiZP/jFkss/+6/0jO76Zr+ClipQ50d5q69Q5NWw3KBYUYB1W0cXMaL6uIVbvEbs5TNRKm7tsW/cMv8tXYYZpvu5tfiG7h+Yf/gRf7+7kmcSNVsXXk14DckCLww/ijDtkzI4z3n+KRbA/Pl3pxYybXxA+wrtTOX4p/4Ix1EVuEpkhVXjI6xKJd8cu1yF5Swiutjp5pyV/Y/p098jGC8noR/hhVoX3EjFa0ylAqPIVTMQjWXU/8tkZMbeLkHORWC2/ExR25QNTuoG/iNCN9J9i68V6q6hu4OPAwFd8g2bcO18lRs04Qb9YYDRXSVZpw1CdU9LEfT1H1ep6n/Ad4YZPDO2/5RTb0XeTpZ7+Co/Nsq92IZUYw1hpUkh6GqRDhCLYXYWKsl/sHjnJeZIhHG7km+rOsc+v5O/8bPJk4TJg4CoEUs0TMrET8nCkFYnYAbuk+5qn+ALlMMG75KYfzHQ0twCNH1NpBc83PYbuCIX0KtXc/tbtvw8i7aMOjPpbmzJNn8PouEJFRUtHtSCSF0Vcpjx5j397bSLVu5cVj/05Nto595m0kSx6JuEuLFSKRDzAHJVEnQFlDPKy/j3lwA/fU30rPI9/hzYlX2B7ZQXuqjgIVxsbGCUIR6nZvoC4OtEbxcw56zOVCXyePDLzCXvt9RN04fyw/z5t0EjLjBKK44AzQ6VkUevbQK/RUCaNYYOTCPLdtMid8tcf3qsk4iSHxRIlkKUbj9k/jHrgZqyaF8suYZg7TTNP1YD/i7BOEonFa6m6jLpHCcVxS0SS53hOcvfAjmtbvpunQAU4dfgLrQpFDqbfR4sSoyQsaS5oUo3SHjvOIusiu/ft4l5/g4ScfQNsZbqjaSFXzNqyQotjfT2GiwkVvAF2WbG7ZSWKXRLZVITuzMOKhZJjvnT/GZ4N/xA3lMKhCaY3AXRAGC9eK6qUHE2q9WkdspXPSZrGdYaC1g132qdz60+Te+T5S4SQyNk6oyoDeerq//a+UBu4nFF6HTxRbh2mPpGi2UhiBQyhRj/SaGOx7GTWoabzuesbdIXqHn6csbOoMSZlOnjRf4DHdRVtTIx+gg689+3fIRIW74zdjhVOY6TA6X0I7DiP6IiPaZMzyeHn8QZLjaarKIZzdEZyEheg5RySl6BYZLhbGwTAwhF6UCMWK5hy95U55uQIlPTNHWhgWulgAQ2J++LMEt/86scEMRj2EUlV4z2aovHYS4WXxcs/j6C5Cop18UKLX6SMiBDGRplis4EU0iboOZCmMkRZsbtxO/6lnGTLexPMjdJunOGZfRJhhfi12B7I1h98raYu1oLWHMCLIvEdu4iy5iSFyKkY3Bc6pI0yYmpNeE61j7cS781QnFfmGgGRPlvfFtxCyq3nOu4CLTxTjUoxzbuJlYQ9XiUlFrYVYoG5uJiGzDAes0hcQEm0YuLkCYuMW9Cf/ilDtISLHzuKtSVNKVlH5xoPkH/1Dis73CafXUxu7B690npz7GBAmMFsZKA3h5i+QWNtA0FBFIWcQujnM9kSC8uPDdHEMKSQps4VAZXB0kRQmN/QfILnGIL0xSqi7mVBCUK70Mjp+koIXot9wOOWf5Zx8jYSxDVP8HK8lurlff5ETxfO0DUdZFyQp2YKJTIX9VoSDRhOvuH10iQwxYS9Yjr+Y/7QY9KbHFCwTjBOrG78iLTQefnkY67afw/rVP0OOWASvHMVdvwZdA+pLn8F77s8IRA7fC3CLr+GEK9TW3Qk6SSX7FBSOoMLriW3dQijaQKU/RPVeyaa4Ref3J3jdeQktBjCwqaOeSjCGQxmPCmVh03JqLdHaLP51ReiuJx6JkI04vDlxgjflUUatEq3y/fjhXbwo/50eHiRrjXHG6uV77kkqGYNtRgNhYdIVdNHqxXm/tYUBGXDMHSYkDKSQszrCxLIR5KXgu+pg3IJ+gGGDM0HYBfuX/wv67t9CvD6A6h7Fv3YTIa8b569+G84+hogn0IRQUiB9hcqdwhH9VMdvQJYbMBs0a266C7t2J7mMouGmMm15g4EfaF7wTmDLCYwgi9YmUiaoqGE8KkSFhWVANuKSPNNIQ8nCPegT6q5mbWQLpfoyZ4sjNJlvJ2PFeER/nV6OILUBwiSEhTZ8njKOc9ob4XqvgUYjzgUjS8KDXzK3YyQsnvYG0UoQFgI1SwQt5x9d3Wjo7EigKRCZEey2zfi/+9fEtryHyBs9KCy8LWuwjn8L9Y9/gMgNIeMJCKbt5ElTVpoCNdqD450jdMu9hPZ/DFM34BplotdCfCDO8CMOJ8zjeO4ISW0QBMMIIlg6iWaCQLjYStCom7FVholIL3q4mVRPFP2+Ek52gvXZbexbcycT5Rxf0H9ENz2kdR0YAVqoqRwuRIhzTvfwtNNFCy0cdDdRRDJOhvcbbWyra+KVfC9DgUPIMpBq4ZDZjw0B08WmQkpQGlHMErn7/bi/8wVioTWExrqo1LRRlIrQ9/8bwcP/hAqHkJYNSs3YB1KjpIVXKhGvbcW69/O4uw4hx0roOpdIzMB+UdP/6H2MuBmybgEDiOPj60FMkSCiEyiyKOFiaMm6oBbfEFwwenktdBQzH6X6dCtGY5hg+zjC7aKj0MRa90ZOVc7TG7qIYUXQWqH15GyIAJ8wFhNGkYf0CQLT551qK7a5jX7ts8/u4L1NuznlXuB4YYCYGbrkCywfEdWryYjNKzISU6MEBRgiDL6PJTzM//u/YHz096gdVUABp6aV8umz+P/yUYyTz+AnamZyqNMPKA2EClBOnvi2e7F+/p9w2tqI9PcQWWOirCTy6YvkjmXJB4+TCx4gHGzAFAG2VOigiGHUgoigdQmUS5QAJSwuaIOi6MdXXZyP5fGKTdSfj8KoiYlDwX+Ta4I071HvpktnOCpPEsJAqpmKBwWYmBhC8aQ6zWtGF28zGuio2sNg1CJWaeSnN91AzA54YuhNMCUWcs4Q/DkVg2LhmKkWq0CAEGJqJo4N5TKyoY7w334J+93vJDpRIVqrkDpF+atfx/2XjyFyIwSxNEIHTOMPISaHLZWLGLKK4Cd+G+MnP47MnKF85AW8xjakV0Xp379I5uj/QFiDpMyfwjYieMGPMEghiKNxkKIOZRiIwMHQFRxRoCBKmCIgkBOEzOuJu+08Y/01D0e/THNuM3ZmLa4M6DFeIWKe4if5War9Fp4PXsGVPiFlo6ZmqGk0AoMYYc6oHE9X3mCtEbCt5Ua8ZgvPjfOOa29lc7KKpy+coiRdbCEvXyAhZgobxALVc6tAgESKEDIQGOkI5l/8Dbtv2cEa18FdE8Y4VWbs058j/8ifgyUQVgShgnm5Ao1XGcVouw7xwb/B2nGIygvfpHLmWcx9P4lRKqLv+zjZC19FU6FSOYmrjxHj7RjmdnzVj1YOUmqkkQIshMqBLuBTxpQBQvvYYj+eyHM8+DsG1WlGrSIvR54gkGG2O9sxRYxu9zTj7hHeGexim72fI6qbPrOTlAihkcipuJdCEzFsMkLzb8EpdKGPA9HNqGubyVDm+usPsiXSwIMXnkdKMcNFYlaaUs8pSkGJmeqiVXGAlBbCB9IJYv/pY2xrNPDDJqVvvMb5j3+U3IUnseLJSytRJsUWIA104KIrDqFDv4r1C5/DNkJUnv8GjmEi9/8G0SMPUfnmb1HIHsG2UlOcalLxeyjq57HtaiLmdaCjBIFEiChCWGidA10mRCNhazPINkbUs5yp/BNFkcMwwtjaxtc+Z63DXJBdtLh76JA3Mi4HGVQn2G6t4W7jvfTpPMc5Q4TQpeq1ycG/Gksa2FryaOkM5wbPcXNiDQ3bNyN1iGQ2w8OnniQj/EtiXovF/eCZ9/RKY0GTIVhhWAhh4lUqmDe+jdrbdxB6pY/ehx/GsbqIGUkCPwAMAiGQQiJMgchn0KkmzJ/5NNb178A83o/f1U+lYwOkEohvfgrzjW9TsVMgDHyRAW0zOetmCpdGgbi1m4j9Ljy5BynSWEIh/VFspUgEkNeHGdX/TtE9i0ktSgoUCiElId8gKkOTKVPT5Cf8D/B+/x6U0UteHyYZrtBg7OerhSf5C/l1soYmoUMEapILpJy0+gytmfDzdOgYd7fczea6Zr7b8wzPZc9imBJHeZNjeZaZLjk9O3oVCJhUwhoJQqDcEma5iGcAiSQSieH7UzaSREsDjY8qZrH3vBPjP/wudstaIkeHYDiPu2EjE6Mnsb/6X/GGjmBEaxFao1AovEt7VrSeVImTpTZ5LIBoKyG9jZiKgArQKkNRnqbsD6MwkIQATXCpFFNiaoGpJWFpEUEzYubY7x/iV4KfZrNRRSbogsQQ7eGDvJLv4w+9v+ZVdZ4aGSHAn+oFkwg0htaUtEL5LhoXZIqkYRCgUNNjwvRyW570ajlg9mRxjZCTShmtQanp0apTzGJAxcE1YkR/6iNE7vlFIl4YXcyRzygsEcd7+ms4D/85flDEsBKT03TnhLunB22pubP70aBLSOFjC+PSsO2KlkhtT1pql236k5cKqQIJaW1hCoMBO0+TruI/qg/yPg7ihEdQMUl9opGco/nTwS/y5coDhEyJaZio6Tk7WmFoOVV6C2g1L0608jVbV+AHTGNYgw7mpQ8mh3GKkoOsbyf0R39G8p67iRkFbNPDjSVxB4p4X/44wRP/iDRtsCOgvFk2slx0IPalqmMRBqL4IkxAmABrchfa9NySad0zrYLE3A0RPgpXKCKEKYgyD/IcXfRwqzhAU2gNffVZ4mvT3BW/jmaqeTn/JjmzjIU1GX7Ws5SpVotmUH4sCFhyXrKQKN9Br9lK+m//np2HOmjCRcbCZM0Q3jd/ROXvfwun62VEJD21uU/Nnlu+5ETy+bsLJGqq/FvNsbNnwf8yQMhZw5CVVhjaJOFbHOY0z1SO0BZbx57UFnRTmfyWCgdr9nNDYQ/fm3gMT+o51sxyY/MXQ4CeFcK4AgQsnvPUhkQXc4Tf/gEOfeIOdkV9BuMWnZ0l+v/751H3fR6hMhBKo1UwU9yqWbCBQYmZ0OGkGSvmlPXNvOSsl2DOn3lAmP09rScpOBCKmI4wIkf5dvkh3EKR/foQ0f3VuPearJtoZ/xkDy8Eb2DLEMEU1S+3NEgssABVo9Fy8ota6Ks7O3pq7BR6tEi5N8LFQYOuh19n9NOfRr/yA1QijpQGQk02OGtmxIRYYgWh0Fe4o0hMflmsgCqV0FhYmNLgqfIxnh55iubeNNazLv/4/L/ysPscDs4Uwegl+n+XupeeXpk6PX589Up4eZ9BYgYuvqNww2FMT2ELDxkOo5SaESBaXRqAsRCAlZiVfdZvZZOfmrUYaJJbllqvKxAYhkle+4SdgDAGWTuLKePYWFNxI72iHTqz943N7A5Tl6Yy8uNAwPT2JS01Gh+BjVACdDBnPttseT8bEEqsbDmPWgGH6Fle+HJ5WzULMZPnGSArOEZAOIggFSjUFewxVktOTjG5SpOfLluGHAgE9rS64+py2VvfEqaX2ZushAvaIOSZ6EugXyBCsMq1Vato0FhJw95Kd0TMX5apLlvAudKVVHr+ZGu9+slVk/ecEkeLLP28JOUXsXSmRSRTeYTlO+UX7hcwV8dOcoFtQaxgtZ9YuNnvkpyftIGml4rKFaBUzFukttSo4EvvTa891MuTkJje6z639OoysTfjYujLfSKWH4ZrXtkEtKUqI8USJS1zxdf8Ge1qlmh4a/v5Vrh2bonGT7HM+AGxAAEKVtIpr5fboqQX9UpntgXpK1g/oy57uOk1hFqspBH2yhtIZlOtXIGSmL3e93IxpxaxfK6MNMyVK48fz7WyfcZXxU//P/LUBTbpLbWeVaxqNdRcpSTn7Oya0+Sm3/riwMX0l7gCuC3t+Mk5CzwX06FqhY6kuXoMi5VNTllESU8iRSwya2GFRrBYzarz/2+WdM4823RFuVxQLJs/9gdZZKTBVVmpvKIdkvp/O/AXnhGn5iHhLVhBK8W+WEAJT9rM8opBIRYc/7L0/t+rt1v48vOWNt3VgrvkZ4st+b+H8vXVFQJi5d7w1dktvJJxDvOXLuqrYQVdpR8j1HRIbKqp4WrQo5olgsQV0NJilK1WWBE+ExXQ07Wil8IbagX9Y+rKdICen4PRK8TB9If1XEU8f/jH/MKlhawTPdvtmXKhxRXzqF6E6pdT3rO3tE5VC67Q5BKXXHh5pZ7wSsXJTJPyzOZsfWnAHwsM/1jMBxXzfAclxFXyVMQSzdR6GZN8bqYNPV8P6YWfUcx8xlz94y42nE7NS/qpOft/Z3u+cwNvi3uQS4mqmffUVHBNzvLUl/NK9QJBxYWDhUt59HM9ZjErfjRzHyXmSgGNnrPZ+/8F6hKyLln7+MEAAAAASUVORK5CYII=\")}\n.app-monogram[data-app=\"singbox\"]{background-image:url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjE0OCA5MCA3MjggODIwIj4NCiAgPGRlZnM+DQogICAgPGxpbmVhckdyYWRpZW50IGlkPSJiZzI1IiB4MT0iMCIgeTE9IjAiIHgyPSIwIiB5Mj0iMSI+DQogICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiMyNDJGMzciIC8+DQogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwRDEzMTciIC8+DQogICAgPC9saW5lYXJHcmFkaWVudD4NCiAgICA8cmFkaWFsR3JhZGllbnQgaWQ9InNwb3QyNSIgY3g9IjAuNSIgY3k9IjAuNSIgcj0iMC41Ij4NCiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzQ2NTY1RiIgc3RvcC1vcGFjaXR5PSIwLjQ1IiAvPg0KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjNDY1NjVGIiBzdG9wLW9wYWNpdHk9IjAiIC8+DQogICAgPC9yYWRpYWxHcmFkaWVudD4NCiAgICA8ZmlsdGVyIGlkPSJzb2Z0MjUiIHg9Ii00MCUiIHk9Ii00MCUiIHdpZHRoPSIxODAlIiBoZWlnaHQ9IjE4MCUiPg0KICAgICAgPGZlR2F1c3NpYW5CbHVyIHN0ZERldmlhdGlvbj0iMTgiIC8+DQogICAgPC9maWx0ZXI+DQogICAgPGxpbmVhckdyYWRpZW50IGlkPSJ0b3AyNSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiIHgxPSIzMzAiIHkxPSIzMjAiIHgyPSI3MDAiIHkyPSI0OTAiPg0KICAgICAgPHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjNDQ1ODYzIiAvPg0KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMzk0QzU3IiAvPg0KICAgIDwvbGluZWFyR3JhZGllbnQ+DQogICAgPGxpbmVhckdyYWRpZW50IGlkPSJsZWZ0MjUiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIiB4MT0iMjY5LjUiIHkxPSI0ODAiIHgyPSI1MTIiIHkyPSI3MjAiPg0KICAgICAgPHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjMjYzMjNBIiAvPg0KICAgICAgPHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMUYyQTMxIiAvPg0KICAgIDwvbGluZWFyR3JhZGllbnQ+DQogICAgPGxpbmVhckdyYWRpZW50IGlkPSJyaWdodDI1IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjUxMiIgeTE9IjY1MCIgeDI9Ijc1NC41IiB5Mj0iNTAwIj4NCiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzMwNDA0QSIgLz4NCiAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzM3NDg1NCIgLz4NCiAgICA8L2xpbmVhckdyYWRpZW50Pg0KICAgIDxmaWx0ZXIgaWQ9ImdyYWluMjUiIHg9IjAiIHk9IjAiIHdpZHRoPSIyODAiIGhlaWdodD0iMjgwIiBmaWx0ZXJVbml0cz0idXNlclNwYWNlT25Vc2UiPg0KICAgICAgPGZlVHVyYnVsZW5jZSB0eXBlPSJmcmFjdGFsTm9pc2UiIGJhc2VGcmVxdWVuY3k9IjAuMjIiIG51bU9jdGF2ZXM9IjQiIHNlZWQ9IjE3IiByZXN1bHQ9Im4iIC8+DQogICAgICA8ZmVDb2xvck1hdHJpeCBpbj0ibiIgdHlwZT0ibWF0cml4IiB2YWx1ZXM9IjAgMCAwIDAgMSAgMCAwIDAgMCAxICAwIDAgMCAwIDEgIDAuNDUgMCAwIDAgLTAuMSIgLz4NCiAgICA8L2ZpbHRlcj4NCiAgICA8ZmlsdGVyIGlkPSJncmFpbkQyNSIgeD0iMCIgeT0iMCIgd2lkdGg9IjI4MCIgaGVpZ2h0PSIyODAiIGZpbHRlclVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+DQogICAgICA8ZmVUdXJidWxlbmNlIHR5cGU9ImZyYWN0YWxOb2lzZSIgYmFzZUZyZXF1ZW5jeT0iMC4yOCIgbnVtT2N0YXZlcz0iNCIgc2VlZD0iNDEiIHJlc3VsdD0ibiIgLz4NCiAgICAgIDxmZUNvbG9yTWF0cml4IGluPSJuIiB0eXBlPSJtYXRyaXgiIHZhbHVlcz0iMCAwIDAgMCAwLjAyICAwIDAgMCAwIDAuMDUgIDAgMCAwIDAgMC4wNyAgMC40NSAwIDAgMCAtMC4xIiAvPg0KICAgIDwvZmlsdGVyPg0KICAgIDxjbGlwUGF0aCBpZD0iY2xpcFRvcEQiPjxwYXRoIGQ9Ik01MTIgMjYyIDc1NC41IDQwMiA1MTIgNTQyIDI2OS41IDQwMloiIC8+PC9jbGlwUGF0aD4NCiAgICA8Y2xpcFBhdGggaWQ9ImNsaXBMZWZ0RCI+PHBhdGggZD0iTTI2OS41IDQwMiA1MTIgNTQyIDUxMiA4MTIgMjY5LjUgNjcyWiIgLz48L2NsaXBQYXRoPg0KICAgIDxjbGlwUGF0aCBpZD0iY2xpcFJpZ2h0RCI+PHBhdGggZD0iTTUxMiA1NDIgNzU0LjUgNDAyIDc1NC41IDY3MiA1MTIgODEyWiIgLz48L2NsaXBQYXRoPg0KICA8L2RlZnM+DQogIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMjUuMjggLTI3My4yOCkgc2NhbGUoMS40NCkiPg0KDQogIDxwYXRoIGQ9Ik01MTIgMjYyIDc1NC41IDQwMiA1MTIgNTQyIDI2OS41IDQwMloiIGZpbGw9InVybCgjdG9wMjUpIiAvPg0KICA8cGF0aCBkPSJNMjY5LjUgNDAyIDUxMiA1NDIgNTEyIDgxMiAyNjkuNSA2NzJaIiBmaWxsPSJ1cmwoI2xlZnQyNSkiIC8+DQogIDxwYXRoIGQ9Ik01MTIgNTQyIDc1NC41IDQwMiA3NTQuNSA2NzIgNTEyIDgxMloiIGZpbGw9InVybCgjcmlnaHQyNSkiIC8+DQoNCiAgDQogIDxnIGNsaXAtcGF0aD0idXJsKCNjbGlwVG9wRCkiPjxnIHRyYW5zZm9ybT0ibWF0cml4KDAuODY2IDAuNSAwLjg2NiAtMC41IDI2OS41IDQwMikiPg0KICAgIDxyZWN0IHdpZHRoPSIyODAiIGhlaWdodD0iMjgwIiBmaWx0ZXI9InVybCgjZ3JhaW4yNSkiIG9wYWNpdHk9IjAuMzAiIC8+DQogICAgPHJlY3Qgd2lkdGg9IjI4MCIgaGVpZ2h0PSIyODAiIGZpbHRlcj0idXJsKCNncmFpbkQyNSkiIG9wYWNpdHk9IjAuMzgiIC8+DQogIDwvZz48L2c+DQogIDxnIGNsaXAtcGF0aD0idXJsKCNjbGlwTGVmdEQpIj48ZyB0cmFuc2Zvcm09Im1hdHJpeCgwLjg2NiAwLjUgMCAwLjk2NDI4IDI2OS41IDQwMikiPg0KICAgIDxyZWN0IHdpZHRoPSIyODAiIGhlaWdodD0iMjgwIiBmaWx0ZXI9InVybCgjZ3JhaW4yNSkiIG9wYWNpdHk9IjAuMjAiIC8+DQogICAgPHJlY3Qgd2lkdGg9IjI4MCIgaGVpZ2h0PSIyODAiIGZpbHRlcj0idXJsKCNncmFpbkQyNSkiIG9wYWNpdHk9IjAuMzQiIC8+DQogIDwvZz48L2c+DQogIDxnIGNsaXAtcGF0aD0idXJsKCNjbGlwUmlnaHREKSI+PGcgdHJhbnNmb3JtPSJtYXRyaXgoMC44NjYgLTAuNSAwIDAuOTY0MjggNTEyIDU0MikiPg0KICAgIDxyZWN0IHdpZHRoPSIyODAiIGhlaWdodD0iMjgwIiBmaWx0ZXI9InVybCgjZ3JhaW4yNSkiIG9wYWNpdHk9IjAuMjUiIC8+DQogICAgPHJlY3Qgd2lkdGg9IjI4MCIgaGVpZ2h0PSIyODAiIGZpbHRlcj0idXJsKCNncmFpbkQyNSkiIG9wYWNpdHk9IjAuMzQiIC8+DQogIDwvZz48L2c+DQoNCiAgDQogIDxwYXRoIGQ9Ik0zOTAuNzUgNDcyIDYzMy4yNSAzMzIiIHN0cm9rZT0iIzE0MUUyNCIgc3Ryb2tlLXdpZHRoPSI0IiBmaWxsPSJub25lIiBvcGFjaXR5PSIwLjkiIC8+DQogIDxwYXRoIGQ9Ik0zOTAuNzUgNDcyIDYzMy4yNSAzMzIiIHN0cm9rZT0iIzZFODc5NCIgc3Ryb2tlLXdpZHRoPSIyIiBmaWxsPSJub25lIiBvcGFjaXR5PSIwLjciIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTMpIiAvPg0KDQogIA0KICA8cGF0aCBkPSJNMjY5LjUgNDAyIDUxMiA1NDIiIHN0cm9rZT0iIzBCMTQxQSIgc3Ryb2tlLXdpZHRoPSIxMCIgb3BhY2l0eT0iMC4yOCIgZmlsdGVyPSJ1cmwoI3NvZnQyNSkiIGZpbGw9Im5vbmUiIC8+DQogIDxwYXRoIGQ9Ik01MTIgNTQyIDc1NC41IDQwMiIgc3Ryb2tlPSIjMEIxNDFBIiBzdHJva2Utd2lkdGg9IjEwIiBvcGFjaXR5PSIwLjIyIiBmaWx0ZXI9InVybCgjc29mdDI1KSIgZmlsbD0ibm9uZSIgLz4NCiAgPHBhdGggZD0iTTUxMiA1NDIgNTEyIDgxMiIgc3Ryb2tlPSIjMDYwRDExIiBzdHJva2Utd2lkdGg9IjkiIG9wYWNpdHk9IjAuMzAiIGZpbHRlcj0idXJsKCNzb2Z0MjUpIiBmaWxsPSJub25lIiAvPg0KDQogIA0KICA8cGF0aCBkPSJNNTEyIDI2MiA3NTQuNSA0MDIiIHN0cm9rZT0iIzY2ODA4RCIgc3Ryb2tlLXdpZHRoPSIyLjUiIGZpbGw9Im5vbmUiIC8+DQogIDxwYXRoIGQ9Ik01MTIgMjYyIDI2OS41IDQwMiIgc3Ryb2tlPSIjNUE3MzdGIiBzdHJva2Utd2lkdGg9IjIuNSIgZmlsbD0ibm9uZSIgLz4NCiAgPHBhdGggZD0iTTI2OS41IDQwMiA1MTIgNTQyIDc1NC41IDQwMiIgc3Ryb2tlPSIjNEU2NzczIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIG9wYWNpdHk9IjAuOSIgLz4NCiAgPHBhdGggZD0iTTUxMiA1NDIgNTEyIDgxMiIgc3Ryb2tlPSIjNDQ1OTYzIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIG9wYWNpdHk9IjAuOSIgLz4NCg0KICANCiAgPHBhdGggZD0iTTM1Ni44IDM1MS42IDM5MC43NSAzMzIgNjMzLjI1IDQ3MiA1OTkuMyA0OTEuNloiIGZpbGw9IiM5OUFBQjUiIC8+DQogIDxwYXRoIGQ9Ik0zOTAuNzUgMzMyIDQyNC43IDMxMi40IDY2Ny4yIDQ1Mi40IDYzMy4yNSA0NzJaIiBmaWxsPSIjRTFFOEVEIiAvPg0KICA8cGF0aCBkPSJNNTk5LjMgNDkxLjYgNjMzLjI1IDQ3MiA2MzMuMjUgNTkyIDU5OS4zIDYxMS42WiIgZmlsbD0iIzgyOTZBMSIgLz4NCiAgPHBhdGggZD0iTTYzMy4yNSA0NzIgNjY3LjIgNDUyLjQgNjY3LjIgNTcyLjQgNjMzLjI1IDU5MloiIGZpbGw9IiNDQ0Q2REQiIC8+DQogIA0KICA8cGF0aCBkPSJNMzYwIDM1OCA2MDIuNSA0OTgiIHN0cm9rZT0iIzAwMDAwMCIgb3BhY2l0eT0iMC4yNSIgc3Ryb2tlLXdpZHRoPSI3IiBmaWx0ZXI9InVybCgjc29mdDI1KSIgZmlsbD0ibm9uZSIgLz4NCiAgPC9nPg0KPC9zdmc+\")}\n.app-monogram[data-app=\"shadowrocket\"]{background-image:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAPtklEQVR42u2da2xcZ1rHf+97LnNmxh7f4yS2m7aJU5o2JL2EdEtL222hAoFabbe72oUPsKIg7QoQIIEoAu3CfuBbJT6AWAosX0Bib1rolrbbdim0ou0mm/SyDU1ztevYcXwdz3jmXN734cOZGTuO06TdJvYk80pHtjzjc+Y8/+f5P7f3PKNERGitNVu6JYIWAC0AWqsFQAuA1moB0AKgtVoAtABolmUFhKWjBcBlXEZAK1AsHbZJUXCb6cPWZewoGClb/vq9KoEDvzMc0B9orICqAdMsSzVLLUhqwgX49mjE145WKSUpD3VnNF8aDnhwk9cASbUA+PiFXzXwxKEKT41FtLkKv0agoYGKET57bYYv3hCgVwDWAuAncbY1RzUbCV85WGbfdEJ3TfKRFSwQOAoRYTaE+za5PP7TObKOQprAEvR613wNzISWx/eVOTiV0OspEFiILF2uos9XFKsWJdDnK146FfOVHy2ymAiqCSKkdWsBUlPfciz86Q/LvDWb0OkrjEAxEvb0efz+ziwZR/E371T4wamIvKfwFEyHwj0bPf7stjya9e2Y1yUAUgcA+Or+Mv91KqY7UCQWSrHw6NaA39oRnCXUbx0LefKdCr6j8B04UxE+szXDF2/OYiSNnFoU9GGoR8G/HK7y0vsxvb7CGqhEwmM3Bvz2jgBZloxZgUeuz/BHt+SwBpIE+jKK7xwLeXYkwlHrN0/Q6zHD1QoOnEn413erdHsKLCyGwm/eGPDZbQFGUkqpJ2NapcnZfQM+f7A7SxQLGChoxd+/VeHkgkWnp2kBcCHqUaQ083dvLOIKeAoWqpZPbw14dDg4Kwtevpw6CIM+X9iRpRQKGQXVSPjam4uYdVqz0Osx3v/24ZCROUvBVSxULXv7Pb5wc9CwjvPReR2ER4YzPHCNR7Fi6fIVB8Zjnj8ZpVYgLQA+kHpGipanj1Tp8KAaWXoymi/dkjur9nOhGxLgsZ05BtscqpGlzVF881CFYlgLTaUFwLnhWO3nd/6vymIo+EAUwa/fnKUvt1TnueB5VCrgQkbxGzuzxDFkNZwuWp45Gqavtyxgdeo5MWd4bTSi01OUqsKeTR73bPEb1nHRN1Wjmr0DHncO+JSqQrureOFoyHwo6HUEgl5PVc7nj4ZUI8EBPKX4zIpYf9V84QIW9eiOgECDr+DMguXlk9FSotcCIBWgVjBbsewbjWh3FeWKsHezx/Zet/H68vdbqVlNTdAiSznBSiq6rsvhE4MZFqtCzoGXj0fEZv0U6vS6KDkAB8ZiZkoWX4EHPDjsn6Opdnn8r2A+FoqxoNRSdLQ8yqn/+uC2DL6GjFKMTCccnkrWTRNnzRsydU3cNxKTUYowFLb3uvzUBu8s7a/7galQ+PfRkANzCTNhKvw+X7Gnx+OXB30Knmq8t87123oddvS6vHM6Rqxi30jETf1uqyNWd76TJcvxMzFZBxZC4Y4tfsOR1qlEK3h1IuaJtypMRTYNN23KQWc0vDmR8MzxkD/clWNXj9s4d/1/77zW5+1T6TUOjceEiZBx1dVNQXUGODKZUKoI2kKHr9i12Ws40joIb55J+KtXyyQVSyGGDShuKTjszDsUYkWXgYWi5auvlDkyaxrCr1vYzs0ePRmNFjgzbxiZMQ3LumotoK5/707EOBbiSNi+0aO/XTfK0Uqgkghf379INkqldcc1Pp/aETBUcBCBQ1MJ/3xgkdF5Q2KFf9y3yJc/2YanVQPE7pxmW6/LwfcjEgPHJhOGN7hXtwXUtXR0yuA7YBPYvsFtJEt1DX5zLGZyMsEP0z7A792RZ6jgNFDc0efyJ3e30e9o2g2MTsQcmkhQK0oPN21ykQR84OjpZF30jvVa08902TBbNHg1c9y+inM8MpaQCSGbwK/cmAHA2CUrSix0ZjUPXOejFgU/hOMT8Tnn2dbnknXSmtHEnCFZB+GoXmsHMDlvqVQFbRWFjGJDu24Iti6byoLBj4QupejK6ka2uzzzFYGBDodsLASRUC3ZcyKt3oKmO6vRFhZKlqkFs+ZJmV7r+H9mwWITQYzQndN05vRZQgPIoVL+L1vCSBA5W2h1qlqYN/hhCkC7o8/yNSKQz2j6Cw6SCFFkmV6wZ1nj1WUBNQHPFA2OBTFCb5vGc1WDt+tC3tLtEESgF4WDb6UFNaXB2vRwdPret98OyVtFJoKhHucsS6sLeUN7GglZA/Nle/U64bqCzy3YtF9raNDLSurYsc2nS0O7wBuvVXj9tQrWCFqD1lAqWb773SJTIzG5WOgPFFuvSUNZveIOe9sdlAVlYK5kWGsTcNc6A15ctDiSNlLas2rVKKmry+HuvTleeLpEe0Hz0tMl3j1YZXDIIwyF48ciFoqGzoxiYdZy7/0F8nm96uaszrzGqcm8VJY130a35plwNRIcSbPatkCfN1Tde3eOyqzh4H8vks0o5k7ETB9LIx3PhZwFUxbu/fkcu24PzhF+/ddCRuFKSl2Vql3zUHTNATC18rO1kD1PaaAuyPseamdwyOOtlxaZO51gk1SDHa3pGXDZ9ck8W3b4fNC2xMBXuApigSiSq7wWBIgBLaQ9AOfC/zN8a8C23QGz4wkLU2nJoaPfpaPfOWcT76o37KTXMpImfisjrquvGiqCsqCtXJQgxKYRUPeAS/eAe94d1Of3PQpdu956qEevOQBa0sPa1BouCJheFqLKEsErdXGabG0N8Np1r2oAFOCi0DathCaJfLgo6iNQRxILyoC2KRWxxlvZ17wYF3igasKoVi+9SlbDlHq0hayvWtVQManwk1AIq3LJEqP6KYsLlrgquHrJCV91ANhaBeC5H5QZP5VgY+GG6zxu35XG7/oSfKp6wW74Wo+tQx4kwpEjEf/zv5W0bG2vEgDqAn59f5WXX1lEGWGgz+Vzn+qg0H7pP05HweHzjxTY2OOCgRdeLPPm2yFarw0Iei16wGNjCc9/v0TgKbK+5pGHCmSz6pI7w3pWnc9rPv1wgVwmzT3+85kSk2cStL78penLbgHGwLPPlsAIJhLuvy9Pb6+DtZcnEqnTTV+fw/33tmFjIalannu2dGVbgNQE/ObBKqdGYhxgaLPL7t2XjvfPe9M1Tb9ld8A1Ay4OcOJozKF3woaVXHEAKJ3WXva/tkjGVZhIuO327JqYfYMONezZk037xBr2vbqIMVegBUjNtE8cjZiaMDhAV4fDtu3+qjX7y2UFAFu3+3R1piXqyfdjxk7GqRXYK8kCatx++MchLoKJLIODHtmsvqD2r2w/ftxWkMlorhnysBGQKA6/E15ZFiA1xxdWhNMjMZ6jIIahLd45DXGp9QXELv39Yms8HwjginOu7EsPbvHACJ4D4ycjTCKNmlPzW0DNlGemEkqzFleloV9Xj5OauawQtq4dtWjlzHhCce5D7l4QiEMhqu0dXX7O5aDUr93V7eA74GlYmDHMz9jLtlvishXj5qYMNhS0o8i4ikKnkwqlHp4mMD9tmJtOmJpImBxLKM4mnBk3DN+c4Zd+teOi8gRrU35/6Xsljh8K2Tjk0bvRpW+zS0ePQ1ePg+unW6nrp8q3OfhumofEi8LCnKF7g8PlmHVw2QCYnzIoSZvvfqCoLFiKU4bT78dMjSfMThlK84ZqRcCCdtLDdxXHfxwyfiJm07Ue1qR//yDhT4zEvLu/ggicOBRy7O00vPQzinxB09nrpKAMeHT1OTiuIvAU1aogCRRnzRVUjq5pUKVo0VZwUZiq8L1/miOsCCJSE7ZCO6kgrBFMIiAKN4A4hhe/WeThx7rId+g0aVvezK09nKE1lIuWF79RRJlU4FFFcBRoN626lmYsxTOGE2+HoMAPNG3tmqQquAKxFSrz9srLA5KqxVUKV4MWgQQyHvhaoQzYqmBDIeMpNmxyuXlvlht2B5iKkPEV86cTnnpyjomTMXoZp9c5XmuYHI156slZ5scTMp5CYrhhd8A1wz75vEYZwYYWYsHVKRVqA+VZg5IUKEcgrsiV15AxoZBULFWrEAueD0Fe077ZoavfoXfAo7vfpb3boa2rNo6mKowfiagULblAMTce8x9/O8v1OwMGh306+hyUguK04f3DIcfeikgiSy6nWCxZNl3n88DnC6kFliylWZv6mNGE2YmY4rSlPG+JQyFeBNcTbCSY+AoEIJvTDG716L/Wp2fApaPXoaPPJVdY3QhtzVfc9XA7z/3DLEZpgkBjE+G91yu893oFx0tZyCQgImSymmygCcuWwFP87ENtjTwi26bJtmn6hlyGd6fXiENhfsqwMG2YPpWCcvpEvDTYQ11B01KSSNLo43z7ROXcVmM96jm6v8or3yhSLVv8rMZx0xBGak11pdMIxsRCVLG09zjc+2sdbB5etkWl/hDfij7yap8ziYSgTV+Z42oaKb5a4UgvUMKeO53wxnNlRt+JCEsGW9taXheqdiDb4XDdroBdv5Aj1+FcVNi6WnOf1sCm1beiAJRnDBNHI4qThkrZohRk2xw6Njps3OqTrVFaa2bcJdrOfkGNth99xwSteUEf3EhRtWko9RUlQmJWPEesaarBoU01uNWSPl50vGz5t5MhR0oGBdzU4fC5LQEbAvWh50q0KOhD9pNfnYz5yzcqlBMhU7PfihU2ZDR/cWueHZ1OU4HQVINbx0qG33251Hi4Lq7xke8oIiv0ZR2euKuNzlq42wxOWDfTzOhvvRsSlgUvFq4PNF/ek+fPb88z4GtyBs7MGp5ehzOBmh4AraAYCofGY/IWOrXi8Tvy7NnosXeTxx/vyZGzkLPCG2MxiW0O7W8KAOo7yKdKlrBsoWr5RL9Hb06T2PQZ4aEOh9t6PXQIpQXDzKJtiqm5TRWGWiN4MfgxbMypxhCO+pbDwbzGiyxOBImRNX/47ooBoM4kbRlFG+DFwvzC2Q9zKAXlssWNoUNBoR4etZzwx/c05YZ2h41ZBz+GkbGYOFmygDARRk/FZGJhc5tDW6AaE7VaAHxcIy013LTZJUhg6nTCe+8vzYI4fDJmetKQtbBz0GsW9mkeAOqafOuwT8EBJxRe+1Gl8fprB6roUOj1NTuv95vqGzR0s9SBRGBjr8uOIQ8/hmPvRYyeSjg+EnHiaEQmhl1bfTrbL37GaKsW9BHWXbdnOXYowhjh+e+XEAuZWMgEmjtvyzaV9jddNVQEBgc9dm73cUOYGU2YHUtwQ/iZ3QE9PRfXhGkB8JNawT15Ci5krOBGQn+H5o47czTjd4M3FQCN4R29DnfcncfOW9xQuPcX2wlyzVOAa2ofUAfhlp/LcfyHFfqv87n+Jr+xK67p7qdZ+gGs8k0PpRmDn9X4gWouz9v0AND6NtX106hvcvVxm/nDK9WygNZqAdACoLVaALQAaK0WAC0AWusjrP8HV+iAYoFqPiEAAAAASUVORK5CYII=\")}\n/* END CLIENT ICONS */\r\nbody{background:#05070c;min-height:100dvh;isolation:isolate;-webkit-font-smoothing:antialiased}\r\n.ambient{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none;background:#05070c}\r\n.ambient-orb{position:absolute;display:block;border-radius:50%;filter:blur(90px);opacity:.6}\r\n.orb-blue{width:85vmin;height:85vmin;top:-25%;right:-30%;background:#1e3a8a}\r\n.orb-violet{width:70vmin;height:70vmin;bottom:10%;left:-35%;background:#452080;opacity:.42}\r\n.orb-cyan{width:50vmin;height:50vmin;top:40%;left:20%;background:#0e7490;opacity:.35}\r\n.subscription-shell{max-width:472px;padding-top:max(34px,env(safe-area-inset-top));padding-bottom:max(26px,env(safe-area-inset-bottom))}\r\n.glass{background:linear-gradient(165deg,#ffffff12,transparent 48%),linear-gradient(180deg,#ffffff06,transparent 70%),#0b0f15ba;border:1px solid #ffffff26;border-radius:28px;backdrop-filter:blur(28px) saturate(160%);-webkit-backdrop-filter:blur(28px) saturate(160%);box-shadow:0 18px 48px #0005,inset 0 1px 0 #ffffff28,inset 0 -1px 0 #ffffff06}\r\n.metrics>div{background:#ffffff04;border-color:#ffffff10;border-radius:20px;box-shadow:inset 0 1px 0 #ffffff08}\r\n.segmented{border-radius:999px;background:#ffffff04;border-color:#ffffff14}\r\n.segmented button{border-radius:999px;min-height:40px}\r\n.segmented button[aria-selected=true]{background:#ffffff0f;border-color:#ffffff08}\r\n.chart-tabs{margin-top:17px;border:0;padding:0;background:none;gap:7px}\r\n.chart-tabs button{border:1px solid #ffffff12;background:#ffffff04}\r\n.chart-tabs button[aria-pressed=true]{background:#124369a6;border-color:#259ede80;color:#d6efff}\r\n.usage-chart{height:176px;padding:17px 12px 10px;margin-top:12px;border:1px solid #ffffff12;border-radius:20px;background:#0000001c;gap:8px}\r\n.bar-slot{border-radius:13px;border-color:#ffffff20;box-shadow:inset 0 1px 0 #ffffff12}\r\n.bar-fill{border-radius:12px 12px 0 0;background:linear-gradient(#60c4ff,#4295c57a)}\r\n.soft-button,.download-button,.primary-button{border-radius:999px;min-height:44px}\r\n.download-button{background:#ffffff08;border-color:#ffffff0b}\r\n\r\n.help-card{border-radius:20px}\r\ndialog{border-radius:28px;background:linear-gradient(150deg,#ffffff12,transparent 65%),#0c1219f5;box-shadow:0 18px 60px #0007,inset 0 1px 0 #ffffff22}\r\ndialog::backdrop{background:#02060aa8;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}\r\n.qr-value{display:block;margin-bottom:12px}.qr-value input{display:block;width:100%;min-height:44px;border:1px solid #ffffff18;border-radius:14px;padding:11px;background:#ffffff06;color:#c4d4df;font:12px/1.6 Consolas,monospace;text-overflow:ellipsis}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}\r\n#copyQrText{width:100%}\r\n@media(prefers-reduced-transparency:reduce){.glass,dialog{background:#101720;backdrop-filter:none;-webkit-backdrop-filter:none}.ambient{display:none}}\r\n@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}\r\n\r\n\r\n#importDialog p{text-align:right;line-height:2;margin-top:0}.import-help-actions{display:flex;flex-wrap:wrap;gap:8px}.import-help-actions>*{flex:1}#importCommand:not([hidden]){display:block;margin-top:14px;padding:12px;border:1px solid var(--line);border-radius:12px;background:#0003;overflow-wrap:anywhere;text-align:left;font:12px/1.7 Consolas,monospace}dialog .dialog-status{margin:12px 0 0;color:#a9e8dc;font-size:13px}dialog .dialog-status:empty{display:none}\r\n.row-actions{display:inline-flex;align-items:center;gap:8px;flex-shrink:0}\r\n.action-icon-button{display:inline-flex;align-items:center;justify-content:center;flex:0 0 44px;width:44px;height:44px;min-height:44px;padding:0;border:1px solid #3b3c3f;border-radius:12px;background:linear-gradient(145deg,#2e2f32,#2d3034);color:#fff;cursor:pointer;line-height:0;appearance:none;-webkit-appearance:none;transition:background .15s,transform .12s}\r\n.action-icon-button svg{display:block;width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}\r\n.action-icon-button:hover{background:#383a3e}\r\n.action-icon-button:active{transform:scale(.94);background:#404247}\r\n.action-icon-button:disabled{opacity:.45;cursor:default}\r\n\r\n\r\n.config-connections.glass{position:relative;isolation:isolate;overflow:hidden;border-radius:28px;border:1px solid #ffffff26;background:linear-gradient(145deg,#ffffff0a,transparent 38%),radial-gradient(ellipse at 0 62%,#0e749035,transparent 64%),linear-gradient(165deg,#ffffff13,transparent 48%),linear-gradient(180deg,#ffffff09,transparent 70%),#090b0ded;backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:0 18px 48px #0000006b,inset 0 1px 0 #ffffff47,inset 0 -1px 0 #ffffff0a}\r\n\r\n.config-connections::before{content:none}\r\n.config-connections .action-row,.config-connections .config-node{position:relative;display:flex;align-items:center;gap:12px;padding:24px;min-height:92px}\r\n.config-connections .action-row+.action-row,.config-connections .config-node{border-top:1px solid #ffffff0f}\r\n.config-connections .square-icon{display:grid;place-items:center;flex:0 0 44px;width:44px;height:44px;border-radius:12px;line-height:0;border:1px solid #ffffff0f;background:#20a4ff57;color:#8ed8ff}\r\n.config-connections .square-icon.teal{background:#37e66f47;color:#96f7b8}\r\n.config-connections .square-icon.amber{background:#ffe02052;color:#fff2a3}\r\n.config-connections .square-icon svg{display:block;width:20px;height:20px;stroke-width:2}\r\n.config-connections .action-copy{text-align:right}\r\n.config-connections .action-copy h3{font:700 16px/1.4 Vazir,Arial,sans-serif;letter-spacing:-.02em;color:#fff;overflow-wrap:anywhere}\r\n.config-connections .action-copy p{font:400 12px/1.5 Vazir,Arial,sans-serif;color:#ffffff9e;margin-top:3px;direction:ltr;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\r\n.config-connections .action-icon-button{background:#ffffff14;border:1px solid #ffffff0f;color:#fff}\r\n.config-connections .action-icon-button:hover{background:#ffffff1f}\r\n.config-connections .action-icon-button:active{background:#ffffff26}\r\n\r\n.primary-button{box-shadow:inset 0 1px 0 #ffffff26;transition:background .15s,border-color .15s}\r\n.primary-button:hover{filter:none;background:linear-gradient(135deg,#69ecd0,#3bc6ae);border-color:#8af9e2}\r\n@media(max-width:380px){.config-connections .action-row,.config-connections .config-node{padding:20px 16px;gap:10px}.config-connections .action-copy h3{font-size:14px}}\r\n@media(prefers-reduced-transparency:reduce){.config-connections.glass{background:#101720;backdrop-filter:none;-webkit-backdrop-filter:none}.config-connections::before{display:none}}\r\n\r\n@media(max-width:360px){.platform>summary,.app-card{padding:20px}.platform-title-row{flex-wrap:wrap;gap:4px}.platform-current{font-size:10px}.app-head{flex-wrap:wrap}.app-title-line{flex-basis:100%}}\r\n@media(prefers-reduced-transparency:reduce){.app-platforms.glass{background:#101720;backdrop-filter:none;-webkit-backdrop-filter:none}.app-platforms::before{display:none}}\r\n\r\n\r\n.chart-card.glass{position:relative;isolation:isolate;padding:24px;border-radius:28px;background:radial-gradient(ellipse at 0 100%,#0e74901c,transparent 64%),linear-gradient(145deg,#ffffff10,transparent 40%),#080a0cde;border:1px solid #ffffff26;box-shadow:0 18px 48px #0006,inset 0 1px 0 #ffffff38;backdrop-filter:none;-webkit-backdrop-filter:none}\r\n.chart-card .section-heading{margin-bottom:12px;gap:12px}\r\n.chart-card .section-heading h2{font-size:16px;line-height:1.7;letter-spacing:-.02em;color:#fff}\r\n.chart-card #chartTotal{min-height:26px;padding:4px 9px;border-radius:999px;background:#ffffff14;border:1px solid #ffffff0f;font-size:11px;line-height:1.6;font-weight:700;color:#f5f5f7}\r\n.chart-tabs.segmented{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;margin:0 0 12px;padding:0;border:0;background:none;box-shadow:none}\r\n.chart-tabs.segmented button{min-height:40px;padding:0 12px;border-radius:999px;border:1px solid #ffffff0f;background:#ffffff0b;color:#ffffff9e;font-size:15px;line-height:1.2;font-weight:700;letter-spacing:-.02em;box-shadow:none;transition:background .18s,color .18s,transform .12s}\r\n.chart-tabs.segmented button[aria-pressed=true]{background:#20a4ff52;border-color:#20a4ff66;color:#dff3ff}\r\n.chart-tabs.segmented button:active{transform:scale(.97)}\r\n.chart-card .usage-chart{height:212px;margin:0;padding:16px 12px;gap:8px;border:1px solid #ffffff0f;border-radius:18px;background:linear-gradient(180deg,#ffffff0e,#ffffff06);direction:ltr;overflow:hidden}\r\n.chart-column{gap:8px}\r\n.chart-card .bar-slot{min-height:110px;border-radius:14px;background:#ffffff0b;border:1px solid #ffffff0f;box-shadow:inset 0 1px 0 #ffffff2e}\r\n.chart-card .bar-fill{inset-inline:0;border-radius:inherit;border:1px solid #20a4ff61;background:linear-gradient(180deg,#ffffff47,#ffffff0a),linear-gradient(180deg,#20a4ffeb,#20a4ff38)}\r\n.bar-value{position:absolute;inset:8px 0;display:flex;align-items:center;justify-content:center;color:#fff;font:700 11px/1.1 Vazir,Arial,sans-serif;letter-spacing:.09em;writing-mode:vertical-rl;transform:rotate(180deg);direction:ltr;text-shadow:0 1px 8px #0007;white-space:nowrap}\r\n.chart-card .bar-label{color:#ffffff80;font-size:10px;font-weight:700;white-space:pre-line;line-height:1.6}\r\n.chart-card .chart-column.missing .bar-slot{border-style:solid;background:#ffffff04}\r\n.chart-column.missing .bar-value{color:#ffffff60}\r\n.main-tabs.segmented{align-items:center;gap:6px;padding:8px;margin:12px 2px 10px;min-height:58px;border-radius:999px;background:#ffffff0b;border:1px solid #ffffff0f;box-shadow:inset 0 1px 0 #ffffff24,0 10px 26px #0000002e}\r\n.main-tabs.segmented button{min-height:40px;display:flex;align-items:center;justify-content:center;border:0;background:transparent;border-radius:999px;padding:0 12px;font-size:15px;line-height:1;font-weight:700;letter-spacing:-.02em;color:#ffffff9e;transition:background .18s,color .18s,transform .12s,box-shadow .18s}\r\n.main-tabs.segmented button[aria-selected=true]{color:#fff;background:#ffffff14;box-shadow:inset 0 1px 0 #ffffff3d,0 6px 14px #0000001f}\r\n.main-tabs.segmented button:active{transform:scale(.98)}\r\n\r\n\r\n.header-qr-button{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:28px;padding:3px 12px;border-radius:999px;border:1px solid #20a4ff66;background:#20a4ff29;color:#a7dcff;font:700 12px/1.5 Vazir,Arial,sans-serif;white-space:nowrap}\r\n.header-qr-button svg{width:13px;height:13px;stroke-width:2}\r\n.header-qr-button:hover{background:#20a4ff40}\r\n#qrDialog{width:340px;max-width:calc(100vw - 48px);max-height:calc(100dvh - 48px);padding:18px;text-align:center;border-radius:28px;border:1px solid #ffffff26;background:radial-gradient(ellipse at 0 85%,#0e749021,transparent 65%),linear-gradient(145deg,#ffffff15,transparent 45%),#0a0c0feF;box-shadow:0 18px 48px #0006,inset 0 1px 0 #ffffff38;overflow:auto}\r\n#qrTitle{margin:0 0 14px;font:700 17px/1.4 Vazir,Arial,sans-serif;letter-spacing:-.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}\r\n#qrCanvas{display:flex;align-items:center;justify-content:center;width:248px;max-width:100%;aspect-ratio:1;margin:0 auto 14px;padding:0;border-radius:20px;background:#fff;overflow:hidden}\r\n#qrCanvas svg{width:100%;height:100%;max-width:none;display:block;margin:0;stroke:none}\r\n#qrCanvas svg path{fill:#151724;shape-rendering:crispEdges}\r\n#qrDialog .qr-link-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:8px;margin:0 0 14px;padding:10px 12px;border-radius:16px;background:#ffffff0b;border:1px solid #ffffff0f;text-align:right}\r\n#qrValue{display:block;min-width:0;color:#ffffff9e;font:700 12px/1.5 Vazir,Arial,sans-serif;direction:ltr;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\r\n#qrDialog #copyQrText{width:40px;height:40px;min-height:40px;flex-basis:40px;background:#ffffff14;border:1px solid #ffffff0f}\r\n#qrDialog .qr-close{display:block;width:100%;min-height:46px;border:1px solid #ffffff0f;border-radius:999px;background:#ffffff14;color:#fff;font:700 15px/1.4 Vazir,Arial,sans-serif;appearance:none;-webkit-appearance:none}\r\n#qrDialog .qr-close:hover{background:#ffffff20}\r\n#qrDialog .qr-close:active{transform:scale(.98)}\r\n@media(max-width:360px){.chart-card.glass{padding:20px 16px}.chart-card .usage-chart{padding:16px 8px;gap:5px}.chart-card .bar-label{font-size:9px}.bar-value{font-size:10px}}\r\n\r\n\r\n.account-details{display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;margin-top:16px;padding:12px 14px;border:1px solid #55dec52c;border-radius:14px;background:#55dec509;font-size:12px;color:#b6eadf}.account-details span{overflow-wrap:anywhere}\r\n.summary-card h1.account-title{font-family:Vazir,Arial,sans-serif;font-size:26px;line-height:1.6;letter-spacing:0}\r\n.subscription-shell{width:100%;max-width:680px;padding-left:max(16px,env(safe-area-inset-left));padding-right:max(16px,env(safe-area-inset-right))}\r\n.subscription-shell>*,.platform-apps,.app-card{min-width:0}\r\n.summary-card h1,.metrics strong{overflow-wrap:anywhere}\r\n.brand-header{gap:12px}\r\n.brand{min-width:0}\r\n.platform-title-row,.app-head{flex-wrap:wrap}\r\n.app-buttons{margin-top:auto}\r\n.app-card{display:flex;flex-direction:column}\r\n.manual-format .soft-button{flex-shrink:0}\r\n#importDialog{max-height:calc(100dvh - 32px);overflow:auto;overscroll-behavior:contain}\r\n#qrDialog{overscroll-behavior:contain}\r\n@media(min-width:760px){\r\n  .subscription-shell{max-width:1200px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px;padding:40px max(24px,env(safe-area-inset-right)) 32px max(24px,env(safe-area-inset-left))}\r\n  .subscription-shell>*{grid-column:1/-1}\r\n  .subscription-shell>.summary-card,.subscription-shell>.chart-card{grid-column:auto;margin:0}\r\n  .brand-header{margin:0 4px 4px}\r\n  .summary-card{padding:28px;display:flex;flex-direction:column}\r\n  .summary-card .primary-button{margin-top:auto}\r\n  .summary-card .fine-print{margin-bottom:21px}\r\n  .chart-card.glass{display:flex;flex-direction:column;padding:28px}\r\n  .chart-card .usage-chart{flex:1;min-height:240px;height:auto;margin-top:8px}\r\n  .chart-card .bar-label{font-size:11px}\r\n  .main-tabs.segmented{width:min(100%,472px);justify-self:center;margin:2px 0 0}\r\n  .section-lead{margin-bottom:18px}\r\n  .platform-apps{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}\r\n  .platform-apps>.app-card:only-child{grid-column:1/-1}\r\n  .platform-apps>.app-card:nth-child(even){border-inline-start:1px solid #ffffff0f}\r\n  .app-buttons{flex-direction:row}\r\n  .app-buttons .download-button,.app-buttons .import-button{flex:1;min-width:0;width:auto}\r\n  .app-platforms .app-head{row-gap:8px}\r\n  .config-actions,.config-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}\r\n  .config-connections .action-row+.action-row{border-top:0;border-inline-start:1px solid #ffffff0f}\r\n  .config-connections .config-node:nth-child(even){border-inline-start:1px solid #ffffff0f}\r\n  .config-list .empty{grid-column:1/-1}\r\n  .telegram-link{width:100%;max-width:472px;justify-self:center;margin:4px 0 0}\r\n  .subscription-shell footer{padding-top:22px}\r\n}\r\n@media(max-width:380px){\r\n  .subscription-shell{padding-left:max(12px,env(safe-area-inset-left));padding-right:max(12px,env(safe-area-inset-right))}\r\n  .config-connections .config-node .square-icon{display:none}\r\n  .telegram-link{flex-wrap:wrap;gap:8px}\r\n  .telegram-link b{margin-inline-start:auto}\r\n}\r\n\r\n\r\n#qrDialog,#importDialog{padding:8px;overflow:hidden}\r\n#qrDialog>.am-dialog-scroll{padding:10px;max-height:calc(100dvh - 66px)}\r\n#importDialog>.am-dialog-scroll{padding:15px;max-height:calc(100dvh - 50px)}\r\n\r\n.connection-status{margin-top:10px;color:#e7bd75;font-size:11px;line-height:1.9;overflow-wrap:anywhere}\r\n@media(max-width:760px){\r\n  .glass,.app-platforms.glass{backdrop-filter:none;-webkit-backdrop-filter:none}\r\n  .ambient{background:radial-gradient(ellipse at 95% 5%,#1e3a8a66,transparent 50%),radial-gradient(ellipse at 0 90%,#45208044,transparent 50%),#05070c}\r\n  .ambient-orb{display:none}\r\n  body{background-attachment:scroll}\r\n}\r\n\r\n.bar-value{white-space:normal;overflow-wrap:anywhere;text-align:center;max-width:100%;font-size:10px;line-height:1.35;direction:ltr}\r\n\r\n.outbound-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.outbound-actions .soft-button{font-size:11px;padding:7px 10px;min-height:36px}\r\n",
  subscriptionJs: "'use strict';\n(() => {\n  let data = JSON.parse(document.getElementById('subscriptionData').textContent);\n  let period = 'day', qrText = '', toastTimer, renderedNodes = '', renderedChart = '';\n  const $ = id => document.getElementById(id);\n  const fa = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 2 });\n  const bytes = value => {\n    let n = Math.max(0, Number(value) || 0), unit = 0;\n    const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];\n    while (n >= 1024 && unit < units.length - 1) { n /= 1024; unit++; }\n    return fa.format(n) + ' ' + units[unit];\n  };\n  const el = (tag, className, text) => { const node = document.createElement(tag); if (className) node.className = className; if (text != null) node.textContent = text; return node; };\n  const actionIcon = kind => {\n    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');\n    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('aria-hidden', 'true');\n    svg.innerHTML = kind === 'copy'\n      ? '<rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/>'\n      : '<path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z\"/>';\n    return svg;\n  };\n  const toast = text => {\n    clearTimeout(toastTimer);\n    const dialog = document.querySelector('dialog[open]');\n    if (dialog) {\n      $('subscriptionToast').classList.remove('show');\n      let status = dialog.querySelector('.dialog-status');\n      if (!status) { status = el('p', 'dialog-status'); status.setAttribute('role', 'status'); (dialog.querySelector('.am-dialog-scroll') || dialog).append(status); }\n      status.textContent = text;\n      toastTimer = setTimeout(() => { status.textContent = ''; }, 2600);\n    } else {\n      $('subscriptionToast').textContent = text; $('subscriptionToast').classList.add('show');\n      toastTimer = setTimeout(() => $('subscriptionToast').classList.remove('show'), 2600);\n    }\n  };\n  async function copy(text) {\n    if (!text) return toast('کانفیگی برای کپی وجود ندارد.');\n    try {\n      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);\n      else throw new Error('Clipboard fallback');\n    } catch (_) {\n      const field = el('textarea'); field.value = text; field.style.position = 'fixed'; field.style.opacity = '0';\n      const active = document.activeElement;\n      (document.querySelector('dialog[open]') || document.body).appendChild(field);\n      field.select(); let success = false;\n      try { success = document.execCommand('copy'); } catch (_) {}\n      field.remove(); active?.focus();\n      if (!success) return toast('کپی خودکار در این مرورگر در دسترس نیست.');\n    }\n    toast('کپی شد.');\n  }\n  function qr(text, title, showLink = false) {\n    try {\n      qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];\n      const code = qrcode(0, 'M'); code.addData(text); code.make();\n      $('qrCanvas').innerHTML = code.createSvgTag({ cellSize: 4, margin: 16, scalable: true });\n      $('qrTitle').textContent = title;\n      $('qrTitle').title = title;\n      $('qrCanvas').setAttribute('aria-label', 'کد QR ' + title);\n      $('qrValue').textContent = text;\n      $('qrValue').title = text;\n      $('qrLinkRow').hidden = !showLink;\n      const status = $('qrDialog').querySelector('.dialog-status'); if (status) status.textContent = '';\n      qrText = text; $('qrDialog').showModal();\n    } catch (_) { toast('این کانفیگ برای QR طولانی است؛ از دکمهٔ کپی استفاده کنید.'); }\n  }\n  $('closeQr').addEventListener('click', () => $('qrDialog').close());\n  $('qrDialog').addEventListener('click', e => { if (e.target === $('qrDialog')) { const r = e.target.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) e.target.close(); } });\n  $('copyQrText').addEventListener('click', () => copy(qrText));\n  $('copySubscription').addEventListener('click', () => copy(data.url));\n  $('copyAll').addEventListener('click', () => copy(data.nodes.map(n => n.uri).filter(Boolean).join('\\n')));\n  $('copyManual').addEventListener('click', () => { const url = new URL(data.url); url.searchParams.delete('client'); url.searchParams.set('format', $('manualFormat').value); copy(url.href); });\n  document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => button.dataset.action.startsWith('qr-sub') ? qr(data.url, 'لینک اشتراک', button.dataset.action === 'qr-sub-detail') : copy(data.url)));\n\n  const mainTabs = ['apps', 'configs'];\n  function selectTab(name, focus = false) {\n    for (const id of mainTabs) {\n      const active = id === name;\n      $(id + 'Tab').setAttribute('aria-selected', String(active)); $(id + 'Tab').tabIndex = active ? 0 : -1;\n      $(id + 'Panel').hidden = !active;\n    }\n    if (focus) $(name + 'Tab').focus();\n  }\n  for (const name of mainTabs) {\n    $(name + 'Tab').addEventListener('click', () => selectTab(name));\n    $(name + 'Tab').addEventListener('keydown', event => {\n      if (event.ctrlKey || event.metaKey || event.altKey) return;\n      if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {\n        event.preventDefault(); selectTab(mainTabs[event.key==='Home'?0:event.key==='End'?mainTabs.length-1:(mainTabs.indexOf(name)+(event.key==='ArrowLeft'?1:mainTabs.length-1))%mainTabs.length],true);\n      }\n    });\n  }\n\n  const apps = {\n    v2rayn: { name: 'V2rayN', description: 'V2rayN یک کلاینت V2Ray برای ویندوز با پشتیبانی از رابط کاربری است.', download: 'https://github.com/2dust/v2rayN/releases/latest' },\n    flclash: { name: 'FlClash', description: 'Flclash یک کلاینت GUI چندسکویی برای clash core است.', download: 'https://github.com/chen08209/FlClash/releases/latest' },\n    v2rayng: { name: 'V2rayNG', description: 'V2rayNG یک کلاینت V2Ray برای دستگاه‌های اندرویدی است.', download: 'https://github.com/2dust/v2rayNG/releases/latest', scheme: 'v2rayng' },\n    streisand: { name: 'Streisand', description: 'پشتیبانی از افزودن اشتراک در این برنامه به‌زودی فعال می‌شود.', download: 'https://apps.apple.com/app/streisand/id6450534064', scheme: 'streisand', comingSoon: true },\n    singbox: { name: 'SingBox', description: 'Sing-box یک کلاینت برای مسیریابی امن ترافیک فراهم می‌کند.', download: 'https://github.com/SagerNet/sing-box/releases/latest', downloads: { ios: 'https://apps.apple.com/us/app/sing-box-mt/id6785326793', linux: 'https://github.com/SagerNet/sing-box/releases/latest' }, scheme: 'sing-box' },\n    shadowrocket: { name: 'Shadowrocket', description: 'Shadowrocket یک ابزار پروکسی قانون‌محور برای iOS است.', download: 'https://apps.apple.com/app/shadowrocket/id932747118' }\n  };\n  const platforms = [\n    { id: 'windows', title: 'Windows', apps: ['flclash', 'v2rayn'], recommended: ['flclash'] },\n    { id: 'ios', title: 'iOS', apps: ['singbox', 'shadowrocket', 'streisand'], recommended: ['singbox'] },\n    { id: 'android', title: 'Android', apps: ['singbox', 'flclash', 'v2rayng'], recommended: ['singbox', 'flclash'] },\n    { id: 'linux', title: 'Linux', apps: ['flclash', 'singbox'], recommended: ['flclash'] }\n  ];\n  function platformIcon(platform) {\n    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');\n    svg.setAttribute('viewBox', platform === 'ios' ? '5 3 16 17' : '0 0 24 24');\n    svg.setAttribute('aria-hidden', 'true');\n    svg.setAttribute('class', platform === 'windows' || platform === 'ios' ? 'solid-platform-icon' : 'outline-platform-icon');\n    const paths = {\n      windows: '<path d=\"M4 5h7v6H4V5zm9 0h7v6h-7V5zM4 13h7v6H4v-6zm9 0h7v6h-7v-6z\"/>',\n      ios: '<path d=\"M16.9 12.1c0-1.8 1.5-2.7 1.6-2.8-.9-1.2-2.2-1.4-2.6-1.4-1.1-.1-2.1.6-2.7.6-.6 0-1.4-.6-2.3-.6-1.2 0-2.4.7-3 1.8-1.3 2.2-.3 5.5.9 7.3.6.9 1.4 1.9 2.4 1.9.9 0 1.3-.6 2.4-.6s1.4.6 2.4.6 1.7-.9 2.3-1.8c.7-1 1-2.1 1-2.1-.1 0-2.4-.9-2.4-2.9zM15.2 6.7c.5-.6.8-1.4.8-2.2-.8 0-1.6.5-2.1 1.1-.5.5-.9 1.3-.8 2.1.8.1 1.6-.4 2.1-1z\"/>',\n      android: '<path d=\"M7 10h10v7a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-7zM8.5 10a3.5 3.5 0 0 1 7 0M8.5 6.5 7 4.5M15.5 6.5 17 4.5M10 14h.01M14 14h.01M5 12v4M19 12v4\"/>',\n      linux: '<path d=\"M12 3c-2.4 0-4 2.1-4 5.1 0 1.5-.5 2.8-1.3 4.1L5 15.4C4.3 16.8 5.2 18 6.6 18h10.8c1.4 0 2.3-1.2 1.6-2.6l-1.7-3.2C16.5 10.9 16 9.6 16 8.1 16 5.1 14.4 3 12 3zM9 19.5 7.8 21M15 19.5l1.2 1.5M10 8h.01M14 8h.01\"/>',\n      chevron: '<path d=\"M6 9l6 6 6-6\"/>'\n    };\n    svg.innerHTML = paths[platform];\n    return svg;\n  }\n  function device() {\n    const ua = navigator.userAgent;\n    if (/android/i.test(ua)) return 'android';\n    if (/iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) return 'ios';\n    if (/windows/i.test(ua)) return 'windows';\n    if (/mac/i.test(ua)) return 'macos';\n    if (/linux/i.test(ua)) return 'linux';\n    return '';\n  }\n  function appSubscriptionUrl(scheme) {\n    const url = new URL(data.url, window.location.href);\n    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid subscription URL');\n    url.hash = ''; url.searchParams.delete('download');\n    url.searchParams.delete('client');\n    url.searchParams.set('format', scheme === 'sing-box' ? 'singbox' : scheme === 'streisand' ? 'streisand' : 'base64');\n    if (scheme === 'v2rayng') url.searchParams.set('client', 'v2rayng');\n    return url.href;\n  }\n  function importUrl(scheme) {\n    const target = appSubscriptionUrl(scheme), encoded = encodeURIComponent(target), name = encodeURIComponent(data.title || 'اشتراک');\n    if (scheme === 'v2rayng') {\n      const remark = encodeURIComponent(String(data.title || 'اشتراک').replace(/[\\u0000-\\u001f\\u007f#]/g, ' ').trim());\n      const targetUrl = target + '#' + remark;\n      return 'v2rayng://install-sub?url=' + encodeURIComponent(targetUrl.replace(/%/g, '%25').replace(/\\+/g, '%2B'));\n    }\n    if (scheme === 'sing-box') return 'sing-box://import-remote-profile?url=' + encoded + '#' + name;\n    return scheme + '://import/' + target + '#' + name;\n  }\n  let importTimer, pendingImport = null, currentImport = null;\n  function publicHttpUrl(url) {\n    const u = new URL(url), host = u.hostname.toLowerCase();\n    if (u.protocol !== 'http:') return false;\n    if (/^\\d+\\.\\d+\\.\\d+\\.\\d+$/.test(host)) {\n      const [a,b] = host.split('.').map(Number);\n      if (a===0 || a===10 || a===127 || (a===169&&b===254) || (a===172&&b>=16&&b<=31) || (a===192&&b===168) || (a>=224&&a<=239)) return false;\n    }\n    return true;\n  }\n  function cancelImportFallback() { clearTimeout(importTimer); pendingImport = null; }\n  function showImportHelp(key, platform, reason) {\n    cancelImportFallback();\n    const app = apps[key]; currentImport = { key, platform, reason };\n    const url = appSubscriptionUrl(app.scheme);\n    $('importTitle').textContent = 'افزودن اشتراک به ' + app.name;\n    const platformName = platforms.find(p => p.id === platform)?.title || platform;\n    let message = reason === 'platform'\n      ? 'این دکمه برای ' + platformName + ' است. صفحه را روی همان دستگاه و با نصب ' + app.name + ' باز کنید.'\n      : reason === 'http'\n        ? 'نسخه‌های جدید v2rayNG افزودن خودکار اشتراک HTTP عمومی را نمی‌پذیرند. لینک زیر را کپی کنید، در «تنظیمات اشتراک» یک اشتراک بسازید و گزینهٔ «اجازهٔ آدرس ناامن / Allow insecure URL» را برای همان اشتراک فعال کنید؛ سپس اشتراک را به‌روزرسانی کنید. برای افزودن خودکار، مدیر پنل باید لینک HTTPS با گواهی معتبر تنظیم کند.'\n      : reason === 'linux'\n        ? 'نسخهٔ رسمی SingBox لینوکس ابزار خط فرمان است و لینک بازکردن اپ ندارد. فایل پروفایل را دانلود و با SingBox اجرا کنید.'\n        : 'اگر اپ باز نشد، نصب بودن آن را بررسی کنید و صفحه را در مرورگر اصلی دستگاه، مثل Safari یا Chrome، باز کنید. می‌توانید لینک زیر را هم در بخش اشتراک‌های اپ وارد کنید.';\n    if (key === 'v2rayng' && reason === 'fallback') message += ' اگر اشتراک از قبل اضافه شده، همان را به‌روزرسانی کنید؛ افزودن دوبارهٔ لینک یکسان در بعضی نسخه‌های اپ خطا می‌دهد.';\n    const host = new URL(url).hostname;\n    if (host === 'localhost' || host === '[::1]' || /^127\\./.test(host)) message += ' این آدرس محلی فقط روی همین کامپیوتر کار می‌کند؛ روی گوشی از دامنهٔ عمومی پنل استفاده کنید.';\n    $('importHelp').textContent = message;\n    $('importLink').value = url;\n    const download = new URL(url); download.searchParams.set('download', '1');\n    $('importDownload').href = download.href;\n    $('importDownload').download = app.scheme === 'sing-box' ? 'Amyrax-SingBox.json' : 'AmyraxPanel.txt';\n    $('importCommand').hidden = reason !== 'linux';\n    if (!$('importDialog').open) $('importDialog').showModal();\n  }\n  function handleImport(event, key, platform) {\n    cancelImportFallback();\n    if (apps[key].comingSoon) { event.preventDefault(); return; }\n    const detected = device();\n    if (detected && detected !== platform) {\n      event.preventDefault(); showImportHelp(key, platform, 'platform'); return;\n    }\n    if (platform === 'linux') {\n      event.preventDefault(); showImportHelp(key, platform, 'linux'); return;\n    }\n    if (key === 'v2rayng' && publicHttpUrl(appSubscriptionUrl('v2rayng'))) {\n      event.preventDefault(); showImportHelp(key, platform, 'http'); return;\n    }\n    event.currentTarget.href = importUrl(apps[key].scheme);\n    pendingImport = { key, platform };\n    importTimer = setTimeout(() => {\n      const pending = pendingImport;\n      if (pending && document.visibilityState === 'visible') showImportHelp(pending.key, pending.platform, 'fallback');\n    }, 1800);\n  }\n  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') cancelImportFallback(); });\n  window.addEventListener('pagehide', cancelImportFallback);\n  $('closeImport').addEventListener('click', () => $('importDialog').close());\n  $('importDialog').addEventListener('close', () => { currentImport = null; cancelImportFallback(); });\n  $('copyImportLink').addEventListener('click', () => { if (currentImport) copy(appSubscriptionUrl(apps[currentImport.key].scheme)); });\n  function renderApps() {\n    const detected = device();\n    const ordered = [...platforms].sort((a, b) => Number(b.id === detected) - Number(a.id === detected));\n    for (const [index, platform] of ordered.entries()) {\n      const details = el('details', 'platform'); details.dataset.os = platform.id; details.setAttribute('name', 'client-platform'); details.open = index === 0;\n      details.classList.toggle('current', platform.id === detected);\n      const summary = el('summary');\n      const osIcon = el('span', 'platform-icon'); osIcon.append(platformIcon(platform.id)); summary.append(osIcon);\n      const heading = el('span', 'platform-main');\n      const titleRow = el('span', 'platform-title-row'); titleRow.append(el('strong', 'platform-title', platform.title));\n      if (platform.id === detected) titleRow.append(el('span', 'platform-current', 'سیستم عامل شما'));\n      heading.append(titleRow, el('small', 'platform-count', fa.format(platform.apps.length) + ' اپلیکیشن')); summary.append(heading);\n      const chevron = el('span', 'platform-chevron'); chevron.append(platformIcon('chevron')); summary.append(chevron); details.append(summary);\n      summary.addEventListener('click', () => {\n        if (!details.open) for (const other of $('appPlatforms').querySelectorAll('details')) if (other !== details) other.open = false;\n      });\n      const appGrid = el('div', 'platform-apps');\n      for (const key of platform.apps) {\n        const app = apps[key], card = el('article', 'app-card');\n        card.dataset.app = key;\n        card.classList.toggle('coming-soon', !!app.comingSoon);\n        const top = el('div', 'app-top');\n        const icon = el('span', 'app-monogram has-app-icon'); icon.setAttribute('aria-hidden', 'true'); icon.dataset.app = key;\n        const info = el('div', 'app-info'), head = el('div', 'app-head'), title = el('div', 'app-title-line');\n        title.append(el('h3', 'app-name', app.name));\n        if (app.comingSoon) {\n          const status = el('span', 'app-tag coming-soon-tag', 'Coming soon'); status.dir = 'ltr'; title.append(status);\n        } else if (platform.recommended.includes(key)) title.append(el('span', 'app-tag recommended-tag', 'پیشنهادی'));\n        const tag = el('span', 'app-tag os-tag', platform.id); tag.dir = 'ltr';\n        head.append(title, tag); info.append(head, el('p', 'app-description', app.description)); top.append(icon, info); card.append(top);\n        const buttons = el('div', 'app-buttons');\n        const download = el(app.comingSoon ? 'button' : 'a', 'download-button', 'دانلود');\n        if (app.comingSoon) { download.type = 'button'; download.disabled = true; }\n        else { download.href = app.downloads?.[platform.id] || app.download; download.target = '_blank'; download.rel = 'noopener noreferrer'; }\n        download.setAttribute('aria-label', 'دانلود ' + app.name); buttons.append(download);\n        if (app.scheme) {\n          const add = el(app.comingSoon ? 'button' : 'a', 'import-button', 'افزودن اشتراک'); add.setAttribute('aria-label', 'افزودن اشتراک به ' + app.name);\n          if (app.comingSoon) { add.type = 'button'; add.disabled = true; }\n          else {\n            add.href = importUrl(app.scheme); add.dataset.importApp = key;\n            add.addEventListener('click', event => handleImport(event, key, platform.id));\n          }\n          buttons.append(add);\n        }\n        card.append(buttons);\n        appGrid.append(card);\n      }\n      details.append(appGrid);\n      $('appPlatforms').append(details);\n    }\n  }\n  function renderNodes() {\n    const query = $('configSearch').value.trim().toLowerCase();\n    const nodes = data.nodes.filter(n => (n.name + ' ' + n.type).toLowerCase().includes(query));\n    $('configList').replaceChildren();\n    for (const node of nodes) {\n      const row = el('article', 'config-node');\n      const type = String(node.type || '').split('-')[0];\n      const icon = el('span', 'square-icon'); icon.setAttribute('aria-hidden', 'true');\n      const globe = document.createElementNS('http://www.w3.org/2000/svg', 'svg');\n      globe.setAttribute('viewBox', '0 0 24 24');\n      globe.innerHTML = '<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M3 12h18M12 3c2.3 2.5 3.5 5.5 3.5 9S14.3 18.5 12 21M12 3C9.7 5.5 8.5 8.5 8.5 12S9.7 18.5 12 21\"/>';\n      icon.append(globe); row.append(icon);\n      const content = el('div', 'action-copy');\n      const preview = el('p', 'node-uri', type + ' · ' + node.uri); preview.dir = 'ltr';\n      content.append(el('h3', '', node.name), preview);\n      row.append(content);\n      const qrButton = el('button', 'action-icon-button'); qrButton.append(actionIcon('qr')); qrButton.type = 'button'; qrButton.setAttribute('aria-label', 'کد QR ' + node.name); qrButton.title = 'نمایش کد QR'; qrButton.addEventListener('click', () => qr(node.uri, node.name));\n      const copyButton = el('button', 'action-icon-button'); copyButton.append(actionIcon('copy')); copyButton.type = 'button'; copyButton.setAttribute('aria-label', 'کپی ' + node.name); copyButton.title = 'کپی کانفیگ'; copyButton.addEventListener('click', () => copy(node.uri));\n      const actions = el('span', 'row-actions'); actions.append(qrButton, copyButton); row.append(actions);\n      if (node.wgConf) {\n        const wgCopy = el('button', 'soft-button wg-copy', 'کپی فایل WireGuard'); wgCopy.type = 'button'; wgCopy.addEventListener('click', () => copy(node.wgConf)); content.append(wgCopy);\n      }\n      const exports=el('div','outbound-actions');for(const [key,caption] of [['xrayJson','Xray ↗'],['singboxJson','sing-box ↗']])if(node[key]){const b=el('button','soft-button',caption);b.type='button';b.addEventListener('click',()=>copy(node[key]));exports.append(b);}content.append(exports);\n      $('configList').append(row);\n    }\n    if (!nodes.length) $('configList').append(el('p', 'empty', query ? 'کانفیگی با این مشخصات پیدا نشد.' : 'هنوز کانفیگی در دسترس نیست.'));\n  }\n  $('configSearch').addEventListener('input', renderNodes);\n\n  function usageBuckets(history, updatedAt, period) {\n    const now = new Date(updatedAt).getTime(), timeZone = 'Asia/Tehran';\n    if (!Number.isFinite(now)) return { buckets: [], total: 0, approximate: false, timeZone };\n    const calendar = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hourCycle: 'h23' });\n    const parts = Object.fromEntries(calendar.formatToParts(now).filter(p => p.type !== 'literal').map(p => [p.type, Number(p.value)]));\n    const offset = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second) - Math.floor(now / 1000) * 1000;\n    const midnight = Date.UTC(parts.year, parts.month - 1, parts.day) - offset;\n    const step = period === 'day' ? 6 * 3600000 : 86400000;\n    const count = period === 'day' ? 4 : 7;\n    const start = midnight - (period === 'day' ? 0 : 6 * 86400000), since = history ? new Date(history.since).getTime() : Infinity;\n    const buckets = Array.from({ length: count }, (_, i) => ({ start: start + i * step, end: start + (i + 1) * step, total: 0, observed: start + i * step <= now && since < start + (i + 1) * step, approximate: false }));\n    for (const [key, value] of Object.entries(history?.hours || {})) {\n      if (!/^\\d{4}-\\d{2}-\\d{2}T\\d{2}(:\\d{2})?$/.test(key)) continue;\n      const at = Date.parse(key + (key.length === 13 ? ':00:00.000Z' : ':00.000Z'));\n      if (!Number.isFinite(at) || at > now || !value || !Number.isSafeInteger(value.up) || !Number.isSafeInteger(value.down) || value.up < 0 || value.down < 0) continue;\n      const amount = value.up + value.down;\n      if (!Number.isSafeInteger(amount) || !amount) continue;\n      const duration = (value.spanMinutes === 30 ? 30 : 60) * 60000;\n      const overlaps = buckets.filter(b => b.start <= now && at < b.end && at + duration > b.start);\n      if (!overlaps.length) continue;\n      const target = overlaps.find(b => at >= b.start) || overlaps[0];\n      target.total += amount; target.observed = true;\n      if (overlaps.length > 1 || at < target.start || at + duration > target.end) {\n        for (const bucket of overlaps) { bucket.approximate = true; bucket.observed = true; }\n      }\n    }\n    return { buckets, total: buckets.reduce((sum, b) => sum + b.total, 0), approximate: buckets.some(b => b.approximate), timeZone };\n  }\n  function renderChart() {\n    const chart = usageBuckets(data.traffic?.history, data.updatedAt, period), { buckets, timeZone } = chart;\n    const signature = period + JSON.stringify(chart);\n    if (signature === renderedChart) return;\n    renderedChart = signature;\n    const peak = Math.max(1, ...buckets.map(b => b.total));\n    $('chartTotal').textContent = buckets.some(b => b.observed) ? (chart.approximate ? '≈ ' : '') + bytes(chart.total) : '—';\n    $('usageChart').dataset.period = period;\n    $('usageChart').replaceChildren();\n    const descriptions = [];\n    for (const bucket of buckets) {\n      const date = new Date(bucket.start);\n      const time = at => new Date(at).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone });\n      const endTime = bucket.end === buckets.at(-1).end && period === 'day' ? '۲۴:۰۰' : time(bucket.end);\n      const shortDay = ['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'][new Date(bucket.start + 12 * 3600000).getUTCDay()];\n      const label = period === 'day' ? time(bucket.start) + '\\nتا ' + endTime : shortDay + '\\n' + date.toLocaleDateString('fa-IR', { month: 'numeric', day: 'numeric', timeZone });\n      const range = period === 'day' ? label.replace('\\n', ' ') : date.toLocaleDateString('fa-IR', { weekday: 'long', month: 'long', day: 'numeric', timeZone });\n      const description = range + ' (تهران): ' + (bucket.observed ? (bucket.approximate ? '≈ ' : '') + bytes(bucket.total) : 'بازه شروع نشده یا سابقه‌ای ثبت نشده') + (bucket.approximate ? '؛ مرز مصرف در سابقهٔ ساعتی قدیمی دقیق نیست.' : '');\n      descriptions.push(description);\n      const column = el('div', 'chart-column' + (bucket.observed ? '' : ' missing')); column.title = description;\n      const slot = el('div', 'bar-slot');\n      if (bucket.total > 0) { const fill = el('span', 'bar-fill'); fill.style.height = Math.max(4, bucket.total / peak * 100) + '%'; slot.append(fill); }\n      const value = bucket.observed ? (bucket.approximate ? '≈ ' : '') + bytes(bucket.total) : '—';\n      slot.append(el('span', 'bar-value', value));\n      column.append(slot, el('span', 'bar-label', label)); $('usageChart').append(column);\n    }\n    $('usageChart').setAttribute('aria-label', descriptions.join('؛ '));\n    $('chartCaption').textContent = (period === 'day' ? 'مصرف امروز' : 'مصرف ۷ روز، شامل امروز') + ' به ساعت تهران؛ مجموع ارسال و دریافت.' + (chart.approximate ? ' ≈ یعنی مرز بازه در سابقهٔ ساعتی قدیمی تقریبی است.' : '');\n  }\n  document.querySelectorAll('[data-period]').forEach(button => button.addEventListener('click', () => {\n    period = button.dataset.period;\n    document.querySelectorAll('[data-period]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));\n    renderChart();\n  }));\n  function render() {\n    $('subscriptionTitle').textContent = data.title || 'Amyrax Panel';\n    $('subscriptionTitle').dir = 'auto';\n    $('subscriptionTitle').classList.toggle('account-title',!!data.account);\n    $('accountDetails').hidden = !data.account;\n    if (data.account) {\n      const labels={active:'فعال',pending:'در انتظار اولین اتصال',disabled:'غیرفعال',expired:'اعتبار پایان یافته',limited:'حجم پایان یافته'};\n      $('accountStatus').textContent=labels[data.account.status] || data.account.status;\n      $('accountExpiry').textContent=data.account.expiresAt ? 'پایان اعتبار: '+new Date(data.account.expiresAt).toLocaleString('fa-IR',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Tehran'}) : data.account.durationDays ? fa.format(data.account.durationDays)+' روز از اولین اتصال' : 'زمان نامحدود';\n      document.querySelector('.metrics>div:first-child>span').textContent='مصرف سهمیهٔ کاربر';\n      document.querySelector('.metrics>div:nth-child(2)>span').textContent='حجم باقی‌مانده';\n      document.querySelector('.summary-card .fine-print').textContent='مجموع ارسال و دریافت این کاربر؛ بدون محدودیت تعداد اتصال.';\n    }\n    $('monthUsage').textContent = data.traffic ? bytes(data.traffic.month) : 'در دسترس نیست';\n    $('remainingUsage').textContent = data.traffic?.limit?.bytes ? bytes(data.traffic.limit.remaining) : data.account ? 'نامحدود' : 'تعیین نشده';\n    $('nodeCount').textContent = fa.format(data.nodes.length) + ' کانفیگ';\n    $('lastUpdate').textContent = new Date(data.updatedAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Tehran' });\n    $('lastUpdate').title = 'ساعت تهران';\n    $('subscriptionHost').textContent = new URL(data.url).host;\n    $('shortSubLink').textContent = data.url;\n    document.querySelectorAll('[data-import-app]').forEach(a => { a.href = importUrl(apps[a.dataset.importApp].scheme); });\n    if (currentImport) showImportHelp(currentImport.key, currentImport.platform, currentImport.reason);\n    $('configBadge').textContent = fa.format(data.nodes.length);\n    $('copyAllCount').textContent = data.nodes.length + ' مورد';\n    $('copyAll').disabled = !data.nodes.length;\n    $('usageTrack').hidden = !data.traffic?.limit?.bytes;\n    if (data.traffic?.limit?.bytes) $('usageProgress').style.width = Math.min(100, Math.max(0, data.traffic.month/data.traffic.limit.bytes*100)) + '%';\n    const nodesJson = JSON.stringify(data.nodes);\n    if (nodesJson !== renderedNodes) { renderedNodes = nodesJson; renderNodes(); }\n    renderChart();\n  }\n  let refreshing = false, refreshTimer, refreshController, failedRefreshes = 0, refreshAfterResume = false;\n  const canRefresh = () => document.visibilityState === 'visible' && navigator.onLine !== false;\n  function connectionStatus(message = '') {\n    $('connectionStatus').textContent = message; $('connectionStatus').hidden = !message;\n  }\n  function scheduleRefresh(delay) {\n    clearTimeout(refreshTimer);\n    if (canRefresh()) refreshTimer = setTimeout(() => refresh(),delay);\n  }\n  async function refresh(manual = false) {\n    if (refreshing) return;\n    clearTimeout(refreshTimer);\n    if (navigator.onLine === false) { connectionStatus('اینترنت قطع است؛ اطلاعات آخرین دریافت نمایش داده می‌شود.'); return; }\n    if (!manual && !canRefresh()) return;\n    refreshing = true; $('refreshSubscription').disabled = true; $('refreshSubscription').classList.add('spinning');\n    const controller = new AbortController(); refreshController = controller;\n    const timeout = setTimeout(() => controller.abort(), 15000);\n    let retryDelay = 30000;\n    try {\n      const url = new URL(window.location.href); url.searchParams.set('format', 'info'); url.hash = '';\n      const response = await fetch(url, { cache: 'no-store', signal: controller.signal });\n      const retryAfter = response.headers.get('Retry-After');\n      if (retryAfter) {\n        const delay = /^\\d+$/.test(retryAfter) ? Number(retryAfter)*1000 : Date.parse(retryAfter)-Date.now();\n        if (Number.isFinite(delay)) retryDelay = Math.min(300000,Math.max(30000,delay));\n      }\n      if (!response.ok) throw new Error('Subscription unavailable');\n      const updated = await response.json();\n      if (!Array.isArray(updated.nodes)) throw new Error('Invalid response');\n      if (controller.signal.aborted) return;\n      data = updated; failedRefreshes = 0; connectionStatus(); render();\n      if (manual) toast('اطلاعات به‌روز شد.');\n    } catch (_) {\n      if (canRefresh()) {\n        failedRefreshes = Math.min(4,failedRefreshes+1);\n        retryDelay = Math.max(retryDelay,Math.min(300000,30000*2**failedRefreshes));\n        connectionStatus('اطلاعات به‌روز نشد؛ آخرین دریافت نمایش داده می‌شود. دوباره تلاش می‌کنیم.');\n        if (manual) toast('دریافت اطلاعات ناموفق بود؛ دوباره تلاش کنید.');\n      }\n    } finally {\n      clearTimeout(timeout); refreshing = false; refreshController = null;\n      $('refreshSubscription').disabled = false; $('refreshSubscription').classList.remove('spinning');\n      scheduleRefresh(refreshAfterResume ? 500 : retryDelay); refreshAfterResume = false;\n    }\n  }\n  $('refreshSubscription').addEventListener('click', () => refresh(true));\n  function resumeRefresh() {\n    if (!canRefresh()) return;\n    if (refreshing) refreshAfterResume = true;\n    else scheduleRefresh(500);\n  }\n  function pauseRefresh() { clearTimeout(refreshTimer); refreshController?.abort(); }\n  document.addEventListener('visibilitychange', () => { if (canRefresh()) resumeRefresh(); else pauseRefresh(); });\n  window.addEventListener('offline', () => { pauseRefresh(); connectionStatus('اینترنت قطع است؛ اطلاعات آخرین دریافت نمایش داده می‌شود.'); });\n  window.addEventListener('online',resumeRefresh);\n  window.addEventListener('pagehide',pauseRefresh);\n  window.addEventListener('pageshow',event => { if (event.persisted) resumeRefresh(); });\n  renderApps(); render();\n  if (navigator.onLine === false) connectionStatus('اینترنت قطع است؛ اطلاعات آخرین دریافت نمایش داده می‌شود.');\n  scheduleRefresh(30000);\n})();\n",
  qrJs: "/*\nQR Code Generator for JavaScript 1.4.4\nCopyright (c) 2009 Kazuhiko Arase\nhttps://github.com/kazuhikoarase/qrcode-generator\n\nMIT License\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n\n*/\n//---------------------------------------------------------------------\n//\n// QR Code Generator for JavaScript\n//\n// Copyright (c) 2009 Kazuhiko Arase\n//\n// URL: http://www.d-project.com/\n//\n// Licensed under the MIT license:\n//  http://www.opensource.org/licenses/mit-license.php\n//\n// The word 'QR Code' is registered trademark of\n// DENSO WAVE INCORPORATED\n//  http://www.denso-wave.com/qrcode/faqpatent-e.html\n//\n//---------------------------------------------------------------------\n\nvar qrcode = function() {\n\n  //---------------------------------------------------------------------\n  // qrcode\n  //---------------------------------------------------------------------\n\n  /**\n   * qrcode\n   * @param typeNumber 1 to 40\n   * @param errorCorrectionLevel 'L','M','Q','H'\n   */\n  var qrcode = function(typeNumber, errorCorrectionLevel) {\n\n    var PAD0 = 0xEC;\n    var PAD1 = 0x11;\n\n    var _typeNumber = typeNumber;\n    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];\n    var _modules = null;\n    var _moduleCount = 0;\n    var _dataCache = null;\n    var _dataList = [];\n\n    var _this = {};\n\n    var makeImpl = function(test, maskPattern) {\n\n      _moduleCount = _typeNumber * 4 + 17;\n      _modules = function(moduleCount) {\n        var modules = new Array(moduleCount);\n        for (var row = 0; row < moduleCount; row += 1) {\n          modules[row] = new Array(moduleCount);\n          for (var col = 0; col < moduleCount; col += 1) {\n            modules[row][col] = null;\n          }\n        }\n        return modules;\n      }(_moduleCount);\n\n      setupPositionProbePattern(0, 0);\n      setupPositionProbePattern(_moduleCount - 7, 0);\n      setupPositionProbePattern(0, _moduleCount - 7);\n      setupPositionAdjustPattern();\n      setupTimingPattern();\n      setupTypeInfo(test, maskPattern);\n\n      if (_typeNumber >= 7) {\n        setupTypeNumber(test);\n      }\n\n      if (_dataCache == null) {\n        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);\n      }\n\n      mapData(_dataCache, maskPattern);\n    };\n\n    var setupPositionProbePattern = function(row, col) {\n\n      for (var r = -1; r <= 7; r += 1) {\n\n        if (row + r <= -1 || _moduleCount <= row + r) continue;\n\n        for (var c = -1; c <= 7; c += 1) {\n\n          if (col + c <= -1 || _moduleCount <= col + c) continue;\n\n          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )\n              || (0 <= c && c <= 6 && (r == 0 || r == 6) )\n              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {\n            _modules[row + r][col + c] = true;\n          } else {\n            _modules[row + r][col + c] = false;\n          }\n        }\n      }\n    };\n\n    var getBestMaskPattern = function() {\n\n      var minLostPoint = 0;\n      var pattern = 0;\n\n      for (var i = 0; i < 8; i += 1) {\n\n        makeImpl(true, i);\n\n        var lostPoint = QRUtil.getLostPoint(_this);\n\n        if (i == 0 || minLostPoint > lostPoint) {\n          minLostPoint = lostPoint;\n          pattern = i;\n        }\n      }\n\n      return pattern;\n    };\n\n    var setupTimingPattern = function() {\n\n      for (var r = 8; r < _moduleCount - 8; r += 1) {\n        if (_modules[r][6] != null) {\n          continue;\n        }\n        _modules[r][6] = (r % 2 == 0);\n      }\n\n      for (var c = 8; c < _moduleCount - 8; c += 1) {\n        if (_modules[6][c] != null) {\n          continue;\n        }\n        _modules[6][c] = (c % 2 == 0);\n      }\n    };\n\n    var setupPositionAdjustPattern = function() {\n\n      var pos = QRUtil.getPatternPosition(_typeNumber);\n\n      for (var i = 0; i < pos.length; i += 1) {\n\n        for (var j = 0; j < pos.length; j += 1) {\n\n          var row = pos[i];\n          var col = pos[j];\n\n          if (_modules[row][col] != null) {\n            continue;\n          }\n\n          for (var r = -2; r <= 2; r += 1) {\n\n            for (var c = -2; c <= 2; c += 1) {\n\n              if (r == -2 || r == 2 || c == -2 || c == 2\n                  || (r == 0 && c == 0) ) {\n                _modules[row + r][col + c] = true;\n              } else {\n                _modules[row + r][col + c] = false;\n              }\n            }\n          }\n        }\n      }\n    };\n\n    var setupTypeNumber = function(test) {\n\n      var bits = QRUtil.getBCHTypeNumber(_typeNumber);\n\n      for (var i = 0; i < 18; i += 1) {\n        var mod = (!test && ( (bits >> i) & 1) == 1);\n        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;\n      }\n\n      for (var i = 0; i < 18; i += 1) {\n        var mod = (!test && ( (bits >> i) & 1) == 1);\n        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;\n      }\n    };\n\n    var setupTypeInfo = function(test, maskPattern) {\n\n      var data = (_errorCorrectionLevel << 3) | maskPattern;\n      var bits = QRUtil.getBCHTypeInfo(data);\n\n      // vertical\n      for (var i = 0; i < 15; i += 1) {\n\n        var mod = (!test && ( (bits >> i) & 1) == 1);\n\n        if (i < 6) {\n          _modules[i][8] = mod;\n        } else if (i < 8) {\n          _modules[i + 1][8] = mod;\n        } else {\n          _modules[_moduleCount - 15 + i][8] = mod;\n        }\n      }\n\n      // horizontal\n      for (var i = 0; i < 15; i += 1) {\n\n        var mod = (!test && ( (bits >> i) & 1) == 1);\n\n        if (i < 8) {\n          _modules[8][_moduleCount - i - 1] = mod;\n        } else if (i < 9) {\n          _modules[8][15 - i - 1 + 1] = mod;\n        } else {\n          _modules[8][15 - i - 1] = mod;\n        }\n      }\n\n      // fixed module\n      _modules[_moduleCount - 8][8] = (!test);\n    };\n\n    var mapData = function(data, maskPattern) {\n\n      var inc = -1;\n      var row = _moduleCount - 1;\n      var bitIndex = 7;\n      var byteIndex = 0;\n      var maskFunc = QRUtil.getMaskFunction(maskPattern);\n\n      for (var col = _moduleCount - 1; col > 0; col -= 2) {\n\n        if (col == 6) col -= 1;\n\n        while (true) {\n\n          for (var c = 0; c < 2; c += 1) {\n\n            if (_modules[row][col - c] == null) {\n\n              var dark = false;\n\n              if (byteIndex < data.length) {\n                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);\n              }\n\n              var mask = maskFunc(row, col - c);\n\n              if (mask) {\n                dark = !dark;\n              }\n\n              _modules[row][col - c] = dark;\n              bitIndex -= 1;\n\n              if (bitIndex == -1) {\n                byteIndex += 1;\n                bitIndex = 7;\n              }\n            }\n          }\n\n          row += inc;\n\n          if (row < 0 || _moduleCount <= row) {\n            row -= inc;\n            inc = -inc;\n            break;\n          }\n        }\n      }\n    };\n\n    var createBytes = function(buffer, rsBlocks) {\n\n      var offset = 0;\n\n      var maxDcCount = 0;\n      var maxEcCount = 0;\n\n      var dcdata = new Array(rsBlocks.length);\n      var ecdata = new Array(rsBlocks.length);\n\n      for (var r = 0; r < rsBlocks.length; r += 1) {\n\n        var dcCount = rsBlocks[r].dataCount;\n        var ecCount = rsBlocks[r].totalCount - dcCount;\n\n        maxDcCount = Math.max(maxDcCount, dcCount);\n        maxEcCount = Math.max(maxEcCount, ecCount);\n\n        dcdata[r] = new Array(dcCount);\n\n        for (var i = 0; i < dcdata[r].length; i += 1) {\n          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];\n        }\n        offset += dcCount;\n\n        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);\n        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);\n\n        var modPoly = rawPoly.mod(rsPoly);\n        ecdata[r] = new Array(rsPoly.getLength() - 1);\n        for (var i = 0; i < ecdata[r].length; i += 1) {\n          var modIndex = i + modPoly.getLength() - ecdata[r].length;\n          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;\n        }\n      }\n\n      var totalCodeCount = 0;\n      for (var i = 0; i < rsBlocks.length; i += 1) {\n        totalCodeCount += rsBlocks[i].totalCount;\n      }\n\n      var data = new Array(totalCodeCount);\n      var index = 0;\n\n      for (var i = 0; i < maxDcCount; i += 1) {\n        for (var r = 0; r < rsBlocks.length; r += 1) {\n          if (i < dcdata[r].length) {\n            data[index] = dcdata[r][i];\n            index += 1;\n          }\n        }\n      }\n\n      for (var i = 0; i < maxEcCount; i += 1) {\n        for (var r = 0; r < rsBlocks.length; r += 1) {\n          if (i < ecdata[r].length) {\n            data[index] = ecdata[r][i];\n            index += 1;\n          }\n        }\n      }\n\n      return data;\n    };\n\n    var createData = function(typeNumber, errorCorrectionLevel, dataList) {\n\n      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);\n\n      var buffer = qrBitBuffer();\n\n      for (var i = 0; i < dataList.length; i += 1) {\n        var data = dataList[i];\n        buffer.put(data.getMode(), 4);\n        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );\n        data.write(buffer);\n      }\n\n      // calc num max data.\n      var totalDataCount = 0;\n      for (var i = 0; i < rsBlocks.length; i += 1) {\n        totalDataCount += rsBlocks[i].dataCount;\n      }\n\n      if (buffer.getLengthInBits() > totalDataCount * 8) {\n        throw 'code length overflow. ('\n          + buffer.getLengthInBits()\n          + '>'\n          + totalDataCount * 8\n          + ')';\n      }\n\n      // end code\n      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {\n        buffer.put(0, 4);\n      }\n\n      // padding\n      while (buffer.getLengthInBits() % 8 != 0) {\n        buffer.putBit(false);\n      }\n\n      // padding\n      while (true) {\n\n        if (buffer.getLengthInBits() >= totalDataCount * 8) {\n          break;\n        }\n        buffer.put(PAD0, 8);\n\n        if (buffer.getLengthInBits() >= totalDataCount * 8) {\n          break;\n        }\n        buffer.put(PAD1, 8);\n      }\n\n      return createBytes(buffer, rsBlocks);\n    };\n\n    _this.addData = function(data, mode) {\n\n      mode = mode || 'Byte';\n\n      var newData = null;\n\n      switch(mode) {\n      case 'Numeric' :\n        newData = qrNumber(data);\n        break;\n      case 'Alphanumeric' :\n        newData = qrAlphaNum(data);\n        break;\n      case 'Byte' :\n        newData = qr8BitByte(data);\n        break;\n      case 'Kanji' :\n        newData = qrKanji(data);\n        break;\n      default :\n        throw 'mode:' + mode;\n      }\n\n      _dataList.push(newData);\n      _dataCache = null;\n    };\n\n    _this.isDark = function(row, col) {\n      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {\n        throw row + ',' + col;\n      }\n      return _modules[row][col];\n    };\n\n    _this.getModuleCount = function() {\n      return _moduleCount;\n    };\n\n    _this.make = function() {\n      if (_typeNumber < 1) {\n        var typeNumber = 1;\n\n        for (; typeNumber < 40; typeNumber++) {\n          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);\n          var buffer = qrBitBuffer();\n\n          for (var i = 0; i < _dataList.length; i++) {\n            var data = _dataList[i];\n            buffer.put(data.getMode(), 4);\n            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );\n            data.write(buffer);\n          }\n\n          var totalDataCount = 0;\n          for (var i = 0; i < rsBlocks.length; i++) {\n            totalDataCount += rsBlocks[i].dataCount;\n          }\n\n          if (buffer.getLengthInBits() <= totalDataCount * 8) {\n            break;\n          }\n        }\n\n        _typeNumber = typeNumber;\n      }\n\n      makeImpl(false, getBestMaskPattern() );\n    };\n\n    _this.createTableTag = function(cellSize, margin) {\n\n      cellSize = cellSize || 2;\n      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;\n\n      var qrHtml = '';\n\n      qrHtml += '<table style=\"';\n      qrHtml += ' border-width: 0px; border-style: none;';\n      qrHtml += ' border-collapse: collapse;';\n      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';\n      qrHtml += '\">';\n      qrHtml += '<tbody>';\n\n      for (var r = 0; r < _this.getModuleCount(); r += 1) {\n\n        qrHtml += '<tr>';\n\n        for (var c = 0; c < _this.getModuleCount(); c += 1) {\n          qrHtml += '<td style=\"';\n          qrHtml += ' border-width: 0px; border-style: none;';\n          qrHtml += ' border-collapse: collapse;';\n          qrHtml += ' padding: 0px; margin: 0px;';\n          qrHtml += ' width: ' + cellSize + 'px;';\n          qrHtml += ' height: ' + cellSize + 'px;';\n          qrHtml += ' background-color: ';\n          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';\n          qrHtml += ';';\n          qrHtml += '\"/>';\n        }\n\n        qrHtml += '</tr>';\n      }\n\n      qrHtml += '</tbody>';\n      qrHtml += '</table>';\n\n      return qrHtml;\n    };\n\n    _this.createSvgTag = function(cellSize, margin, alt, title) {\n\n      var opts = {};\n      if (typeof arguments[0] == 'object') {\n        // Called by options.\n        opts = arguments[0];\n        // overwrite cellSize and margin.\n        cellSize = opts.cellSize;\n        margin = opts.margin;\n        alt = opts.alt;\n        title = opts.title;\n      }\n\n      cellSize = cellSize || 2;\n      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;\n\n      // Compose alt property surrogate\n      alt = (typeof alt === 'string') ? {text: alt} : alt || {};\n      alt.text = alt.text || null;\n      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;\n\n      // Compose title property surrogate\n      title = (typeof title === 'string') ? {text: title} : title || {};\n      title.text = title.text || null;\n      title.id = (title.text) ? title.id || 'qrcode-title' : null;\n\n      var size = _this.getModuleCount() * cellSize + margin * 2;\n      var c, mc, r, mr, qrSvg='', rect;\n\n      rect = 'l' + cellSize + ',0 0,' + cellSize +\n        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';\n\n      qrSvg += '<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"';\n      qrSvg += !opts.scalable ? ' width=\"' + size + 'px\" height=\"' + size + 'px\"' : '';\n      qrSvg += ' viewBox=\"0 0 ' + size + ' ' + size + '\" ';\n      qrSvg += ' preserveAspectRatio=\"xMinYMin meet\"';\n      qrSvg += (title.text || alt.text) ? ' role=\"img\" aria-labelledby=\"' +\n          escapeXml([title.id, alt.id].join(' ').trim() ) + '\"' : '';\n      qrSvg += '>';\n      qrSvg += (title.text) ? '<title id=\"' + escapeXml(title.id) + '\">' +\n          escapeXml(title.text) + '</title>' : '';\n      qrSvg += (alt.text) ? '<description id=\"' + escapeXml(alt.id) + '\">' +\n          escapeXml(alt.text) + '</description>' : '';\n      qrSvg += '<rect width=\"100%\" height=\"100%\" fill=\"white\" cx=\"0\" cy=\"0\"/>';\n      qrSvg += '<path d=\"';\n\n      for (r = 0; r < _this.getModuleCount(); r += 1) {\n        mr = r * cellSize + margin;\n        for (c = 0; c < _this.getModuleCount(); c += 1) {\n          if (_this.isDark(r, c) ) {\n            mc = c*cellSize+margin;\n            qrSvg += 'M' + mc + ',' + mr + rect;\n          }\n        }\n      }\n\n      qrSvg += '\" stroke=\"transparent\" fill=\"black\"/>';\n      qrSvg += '</svg>';\n\n      return qrSvg;\n    };\n\n    _this.createDataURL = function(cellSize, margin) {\n\n      cellSize = cellSize || 2;\n      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;\n\n      var size = _this.getModuleCount() * cellSize + margin * 2;\n      var min = margin;\n      var max = size - margin;\n\n      return createDataURL(size, size, function(x, y) {\n        if (min <= x && x < max && min <= y && y < max) {\n          var c = Math.floor( (x - min) / cellSize);\n          var r = Math.floor( (y - min) / cellSize);\n          return _this.isDark(r, c)? 0 : 1;\n        } else {\n          return 1;\n        }\n      } );\n    };\n\n    _this.createImgTag = function(cellSize, margin, alt) {\n\n      cellSize = cellSize || 2;\n      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;\n\n      var size = _this.getModuleCount() * cellSize + margin * 2;\n\n      var img = '';\n      img += '<img';\n      img += '\\u0020src=\"';\n      img += _this.createDataURL(cellSize, margin);\n      img += '\"';\n      img += '\\u0020width=\"';\n      img += size;\n      img += '\"';\n      img += '\\u0020height=\"';\n      img += size;\n      img += '\"';\n      if (alt) {\n        img += '\\u0020alt=\"';\n        img += escapeXml(alt);\n        img += '\"';\n      }\n      img += '/>';\n\n      return img;\n    };\n\n    var escapeXml = function(s) {\n      var escaped = '';\n      for (var i = 0; i < s.length; i += 1) {\n        var c = s.charAt(i);\n        switch(c) {\n        case '<': escaped += '&lt;'; break;\n        case '>': escaped += '&gt;'; break;\n        case '&': escaped += '&amp;'; break;\n        case '\"': escaped += '&quot;'; break;\n        default : escaped += c; break;\n        }\n      }\n      return escaped;\n    };\n\n    var _createHalfASCII = function(margin) {\n      var cellSize = 1;\n      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;\n\n      var size = _this.getModuleCount() * cellSize + margin * 2;\n      var min = margin;\n      var max = size - margin;\n\n      var y, x, r1, r2, p;\n\n      var blocks = {\n        '██': '█',\n        '█ ': '▀',\n        ' █': '▄',\n        '  ': ' '\n      };\n\n      var blocksLastLineNoMargin = {\n        '██': '▀',\n        '█ ': '▀',\n        ' █': ' ',\n        '  ': ' '\n      };\n\n      var ascii = '';\n      for (y = 0; y < size; y += 2) {\n        r1 = Math.floor((y - min) / cellSize);\n        r2 = Math.floor((y + 1 - min) / cellSize);\n        for (x = 0; x < size; x += 1) {\n          p = '█';\n\n          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {\n            p = ' ';\n          }\n\n          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {\n            p += ' ';\n          }\n          else {\n            p += '█';\n          }\n\n          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.\n          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];\n        }\n\n        ascii += '\\n';\n      }\n\n      if (size % 2 && margin > 0) {\n        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');\n      }\n\n      return ascii.substring(0, ascii.length-1);\n    };\n\n    _this.createASCII = function(cellSize, margin) {\n      cellSize = cellSize || 1;\n\n      if (cellSize < 2) {\n        return _createHalfASCII(margin);\n      }\n\n      cellSize -= 1;\n      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;\n\n      var size = _this.getModuleCount() * cellSize + margin * 2;\n      var min = margin;\n      var max = size - margin;\n\n      var y, x, r, p;\n\n      var white = Array(cellSize+1).join('██');\n      var black = Array(cellSize+1).join('  ');\n\n      var ascii = '';\n      var line = '';\n      for (y = 0; y < size; y += 1) {\n        r = Math.floor( (y - min) / cellSize);\n        line = '';\n        for (x = 0; x < size; x += 1) {\n          p = 1;\n\n          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {\n            p = 0;\n          }\n\n          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.\n          line += p ? white : black;\n        }\n\n        for (r = 0; r < cellSize; r += 1) {\n          ascii += line + '\\n';\n        }\n      }\n\n      return ascii.substring(0, ascii.length-1);\n    };\n\n    _this.renderTo2dContext = function(context, cellSize) {\n      cellSize = cellSize || 2;\n      var length = _this.getModuleCount();\n      for (var row = 0; row < length; row++) {\n        for (var col = 0; col < length; col++) {\n          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';\n          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);\n        }\n      }\n    }\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // qrcode.stringToBytes\n  //---------------------------------------------------------------------\n\n  qrcode.stringToBytesFuncs = {\n    'default' : function(s) {\n      var bytes = [];\n      for (var i = 0; i < s.length; i += 1) {\n        var c = s.charCodeAt(i);\n        bytes.push(c & 0xff);\n      }\n      return bytes;\n    }\n  };\n\n  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];\n\n  //---------------------------------------------------------------------\n  // qrcode.createStringToBytes\n  //---------------------------------------------------------------------\n\n  /**\n   * @param unicodeData base64 string of byte array.\n   * [16bit Unicode],[16bit Bytes], ...\n   * @param numChars\n   */\n  qrcode.createStringToBytes = function(unicodeData, numChars) {\n\n    // create conversion map.\n\n    var unicodeMap = function() {\n\n      var bin = base64DecodeInputStream(unicodeData);\n      var read = function() {\n        var b = bin.read();\n        if (b == -1) throw 'eof';\n        return b;\n      };\n\n      var count = 0;\n      var unicodeMap = {};\n      while (true) {\n        var b0 = bin.read();\n        if (b0 == -1) break;\n        var b1 = read();\n        var b2 = read();\n        var b3 = read();\n        var k = String.fromCharCode( (b0 << 8) | b1);\n        var v = (b2 << 8) | b3;\n        unicodeMap[k] = v;\n        count += 1;\n      }\n      if (count != numChars) {\n        throw count + ' != ' + numChars;\n      }\n\n      return unicodeMap;\n    }();\n\n    var unknownChar = '?'.charCodeAt(0);\n\n    return function(s) {\n      var bytes = [];\n      for (var i = 0; i < s.length; i += 1) {\n        var c = s.charCodeAt(i);\n        if (c < 128) {\n          bytes.push(c);\n        } else {\n          var b = unicodeMap[s.charAt(i)];\n          if (typeof b == 'number') {\n            if ( (b & 0xff) == b) {\n              // 1byte\n              bytes.push(b);\n            } else {\n              // 2bytes\n              bytes.push(b >>> 8);\n              bytes.push(b & 0xff);\n            }\n          } else {\n            bytes.push(unknownChar);\n          }\n        }\n      }\n      return bytes;\n    };\n  };\n\n  //---------------------------------------------------------------------\n  // QRMode\n  //---------------------------------------------------------------------\n\n  var QRMode = {\n    MODE_NUMBER :    1 << 0,\n    MODE_ALPHA_NUM : 1 << 1,\n    MODE_8BIT_BYTE : 1 << 2,\n    MODE_KANJI :     1 << 3\n  };\n\n  //---------------------------------------------------------------------\n  // QRErrorCorrectionLevel\n  //---------------------------------------------------------------------\n\n  var QRErrorCorrectionLevel = {\n    L : 1,\n    M : 0,\n    Q : 3,\n    H : 2\n  };\n\n  //---------------------------------------------------------------------\n  // QRMaskPattern\n  //---------------------------------------------------------------------\n\n  var QRMaskPattern = {\n    PATTERN000 : 0,\n    PATTERN001 : 1,\n    PATTERN010 : 2,\n    PATTERN011 : 3,\n    PATTERN100 : 4,\n    PATTERN101 : 5,\n    PATTERN110 : 6,\n    PATTERN111 : 7\n  };\n\n  //---------------------------------------------------------------------\n  // QRUtil\n  //---------------------------------------------------------------------\n\n  var QRUtil = function() {\n\n    var PATTERN_POSITION_TABLE = [\n      [],\n      [6, 18],\n      [6, 22],\n      [6, 26],\n      [6, 30],\n      [6, 34],\n      [6, 22, 38],\n      [6, 24, 42],\n      [6, 26, 46],\n      [6, 28, 50],\n      [6, 30, 54],\n      [6, 32, 58],\n      [6, 34, 62],\n      [6, 26, 46, 66],\n      [6, 26, 48, 70],\n      [6, 26, 50, 74],\n      [6, 30, 54, 78],\n      [6, 30, 56, 82],\n      [6, 30, 58, 86],\n      [6, 34, 62, 90],\n      [6, 28, 50, 72, 94],\n      [6, 26, 50, 74, 98],\n      [6, 30, 54, 78, 102],\n      [6, 28, 54, 80, 106],\n      [6, 32, 58, 84, 110],\n      [6, 30, 58, 86, 114],\n      [6, 34, 62, 90, 118],\n      [6, 26, 50, 74, 98, 122],\n      [6, 30, 54, 78, 102, 126],\n      [6, 26, 52, 78, 104, 130],\n      [6, 30, 56, 82, 108, 134],\n      [6, 34, 60, 86, 112, 138],\n      [6, 30, 58, 86, 114, 142],\n      [6, 34, 62, 90, 118, 146],\n      [6, 30, 54, 78, 102, 126, 150],\n      [6, 24, 50, 76, 102, 128, 154],\n      [6, 28, 54, 80, 106, 132, 158],\n      [6, 32, 58, 84, 110, 136, 162],\n      [6, 26, 54, 82, 110, 138, 166],\n      [6, 30, 58, 86, 114, 142, 170]\n    ];\n    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);\n    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);\n    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);\n\n    var _this = {};\n\n    var getBCHDigit = function(data) {\n      var digit = 0;\n      while (data != 0) {\n        digit += 1;\n        data >>>= 1;\n      }\n      return digit;\n    };\n\n    _this.getBCHTypeInfo = function(data) {\n      var d = data << 10;\n      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {\n        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );\n      }\n      return ( (data << 10) | d) ^ G15_MASK;\n    };\n\n    _this.getBCHTypeNumber = function(data) {\n      var d = data << 12;\n      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {\n        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );\n      }\n      return (data << 12) | d;\n    };\n\n    _this.getPatternPosition = function(typeNumber) {\n      return PATTERN_POSITION_TABLE[typeNumber - 1];\n    };\n\n    _this.getMaskFunction = function(maskPattern) {\n\n      switch (maskPattern) {\n\n      case QRMaskPattern.PATTERN000 :\n        return function(i, j) { return (i + j) % 2 == 0; };\n      case QRMaskPattern.PATTERN001 :\n        return function(i, j) { return i % 2 == 0; };\n      case QRMaskPattern.PATTERN010 :\n        return function(i, j) { return j % 3 == 0; };\n      case QRMaskPattern.PATTERN011 :\n        return function(i, j) { return (i + j) % 3 == 0; };\n      case QRMaskPattern.PATTERN100 :\n        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };\n      case QRMaskPattern.PATTERN101 :\n        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };\n      case QRMaskPattern.PATTERN110 :\n        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };\n      case QRMaskPattern.PATTERN111 :\n        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };\n\n      default :\n        throw 'bad maskPattern:' + maskPattern;\n      }\n    };\n\n    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {\n      var a = qrPolynomial([1], 0);\n      for (var i = 0; i < errorCorrectLength; i += 1) {\n        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );\n      }\n      return a;\n    };\n\n    _this.getLengthInBits = function(mode, type) {\n\n      if (1 <= type && type < 10) {\n\n        // 1 - 9\n\n        switch(mode) {\n        case QRMode.MODE_NUMBER    : return 10;\n        case QRMode.MODE_ALPHA_NUM : return 9;\n        case QRMode.MODE_8BIT_BYTE : return 8;\n        case QRMode.MODE_KANJI     : return 8;\n        default :\n          throw 'mode:' + mode;\n        }\n\n      } else if (type < 27) {\n\n        // 10 - 26\n\n        switch(mode) {\n        case QRMode.MODE_NUMBER    : return 12;\n        case QRMode.MODE_ALPHA_NUM : return 11;\n        case QRMode.MODE_8BIT_BYTE : return 16;\n        case QRMode.MODE_KANJI     : return 10;\n        default :\n          throw 'mode:' + mode;\n        }\n\n      } else if (type < 41) {\n\n        // 27 - 40\n\n        switch(mode) {\n        case QRMode.MODE_NUMBER    : return 14;\n        case QRMode.MODE_ALPHA_NUM : return 13;\n        case QRMode.MODE_8BIT_BYTE : return 16;\n        case QRMode.MODE_KANJI     : return 12;\n        default :\n          throw 'mode:' + mode;\n        }\n\n      } else {\n        throw 'type:' + type;\n      }\n    };\n\n    _this.getLostPoint = function(qrcode) {\n\n      var moduleCount = qrcode.getModuleCount();\n\n      var lostPoint = 0;\n\n      // LEVEL1\n\n      for (var row = 0; row < moduleCount; row += 1) {\n        for (var col = 0; col < moduleCount; col += 1) {\n\n          var sameCount = 0;\n          var dark = qrcode.isDark(row, col);\n\n          for (var r = -1; r <= 1; r += 1) {\n\n            if (row + r < 0 || moduleCount <= row + r) {\n              continue;\n            }\n\n            for (var c = -1; c <= 1; c += 1) {\n\n              if (col + c < 0 || moduleCount <= col + c) {\n                continue;\n              }\n\n              if (r == 0 && c == 0) {\n                continue;\n              }\n\n              if (dark == qrcode.isDark(row + r, col + c) ) {\n                sameCount += 1;\n              }\n            }\n          }\n\n          if (sameCount > 5) {\n            lostPoint += (3 + sameCount - 5);\n          }\n        }\n      };\n\n      // LEVEL2\n\n      for (var row = 0; row < moduleCount - 1; row += 1) {\n        for (var col = 0; col < moduleCount - 1; col += 1) {\n          var count = 0;\n          if (qrcode.isDark(row, col) ) count += 1;\n          if (qrcode.isDark(row + 1, col) ) count += 1;\n          if (qrcode.isDark(row, col + 1) ) count += 1;\n          if (qrcode.isDark(row + 1, col + 1) ) count += 1;\n          if (count == 0 || count == 4) {\n            lostPoint += 3;\n          }\n        }\n      }\n\n      // LEVEL3\n\n      for (var row = 0; row < moduleCount; row += 1) {\n        for (var col = 0; col < moduleCount - 6; col += 1) {\n          if (qrcode.isDark(row, col)\n              && !qrcode.isDark(row, col + 1)\n              &&  qrcode.isDark(row, col + 2)\n              &&  qrcode.isDark(row, col + 3)\n              &&  qrcode.isDark(row, col + 4)\n              && !qrcode.isDark(row, col + 5)\n              &&  qrcode.isDark(row, col + 6) ) {\n            lostPoint += 40;\n          }\n        }\n      }\n\n      for (var col = 0; col < moduleCount; col += 1) {\n        for (var row = 0; row < moduleCount - 6; row += 1) {\n          if (qrcode.isDark(row, col)\n              && !qrcode.isDark(row + 1, col)\n              &&  qrcode.isDark(row + 2, col)\n              &&  qrcode.isDark(row + 3, col)\n              &&  qrcode.isDark(row + 4, col)\n              && !qrcode.isDark(row + 5, col)\n              &&  qrcode.isDark(row + 6, col) ) {\n            lostPoint += 40;\n          }\n        }\n      }\n\n      // LEVEL4\n\n      var darkCount = 0;\n\n      for (var col = 0; col < moduleCount; col += 1) {\n        for (var row = 0; row < moduleCount; row += 1) {\n          if (qrcode.isDark(row, col) ) {\n            darkCount += 1;\n          }\n        }\n      }\n\n      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;\n      lostPoint += ratio * 10;\n\n      return lostPoint;\n    };\n\n    return _this;\n  }();\n\n  //---------------------------------------------------------------------\n  // QRMath\n  //---------------------------------------------------------------------\n\n  var QRMath = function() {\n\n    var EXP_TABLE = new Array(256);\n    var LOG_TABLE = new Array(256);\n\n    // initialize tables\n    for (var i = 0; i < 8; i += 1) {\n      EXP_TABLE[i] = 1 << i;\n    }\n    for (var i = 8; i < 256; i += 1) {\n      EXP_TABLE[i] = EXP_TABLE[i - 4]\n        ^ EXP_TABLE[i - 5]\n        ^ EXP_TABLE[i - 6]\n        ^ EXP_TABLE[i - 8];\n    }\n    for (var i = 0; i < 255; i += 1) {\n      LOG_TABLE[EXP_TABLE[i] ] = i;\n    }\n\n    var _this = {};\n\n    _this.glog = function(n) {\n\n      if (n < 1) {\n        throw 'glog(' + n + ')';\n      }\n\n      return LOG_TABLE[n];\n    };\n\n    _this.gexp = function(n) {\n\n      while (n < 0) {\n        n += 255;\n      }\n\n      while (n >= 256) {\n        n -= 255;\n      }\n\n      return EXP_TABLE[n];\n    };\n\n    return _this;\n  }();\n\n  //---------------------------------------------------------------------\n  // qrPolynomial\n  //---------------------------------------------------------------------\n\n  function qrPolynomial(num, shift) {\n\n    if (typeof num.length == 'undefined') {\n      throw num.length + '/' + shift;\n    }\n\n    var _num = function() {\n      var offset = 0;\n      while (offset < num.length && num[offset] == 0) {\n        offset += 1;\n      }\n      var _num = new Array(num.length - offset + shift);\n      for (var i = 0; i < num.length - offset; i += 1) {\n        _num[i] = num[i + offset];\n      }\n      return _num;\n    }();\n\n    var _this = {};\n\n    _this.getAt = function(index) {\n      return _num[index];\n    };\n\n    _this.getLength = function() {\n      return _num.length;\n    };\n\n    _this.multiply = function(e) {\n\n      var num = new Array(_this.getLength() + e.getLength() - 1);\n\n      for (var i = 0; i < _this.getLength(); i += 1) {\n        for (var j = 0; j < e.getLength(); j += 1) {\n          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );\n        }\n      }\n\n      return qrPolynomial(num, 0);\n    };\n\n    _this.mod = function(e) {\n\n      if (_this.getLength() - e.getLength() < 0) {\n        return _this;\n      }\n\n      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );\n\n      var num = new Array(_this.getLength() );\n      for (var i = 0; i < _this.getLength(); i += 1) {\n        num[i] = _this.getAt(i);\n      }\n\n      for (var i = 0; i < e.getLength(); i += 1) {\n        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);\n      }\n\n      // recursive call\n      return qrPolynomial(num, 0).mod(e);\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // QRRSBlock\n  //---------------------------------------------------------------------\n\n  var QRRSBlock = function() {\n\n    var RS_BLOCK_TABLE = [\n\n      // L\n      // M\n      // Q\n      // H\n\n      // 1\n      [1, 26, 19],\n      [1, 26, 16],\n      [1, 26, 13],\n      [1, 26, 9],\n\n      // 2\n      [1, 44, 34],\n      [1, 44, 28],\n      [1, 44, 22],\n      [1, 44, 16],\n\n      // 3\n      [1, 70, 55],\n      [1, 70, 44],\n      [2, 35, 17],\n      [2, 35, 13],\n\n      // 4\n      [1, 100, 80],\n      [2, 50, 32],\n      [2, 50, 24],\n      [4, 25, 9],\n\n      // 5\n      [1, 134, 108],\n      [2, 67, 43],\n      [2, 33, 15, 2, 34, 16],\n      [2, 33, 11, 2, 34, 12],\n\n      // 6\n      [2, 86, 68],\n      [4, 43, 27],\n      [4, 43, 19],\n      [4, 43, 15],\n\n      // 7\n      [2, 98, 78],\n      [4, 49, 31],\n      [2, 32, 14, 4, 33, 15],\n      [4, 39, 13, 1, 40, 14],\n\n      // 8\n      [2, 121, 97],\n      [2, 60, 38, 2, 61, 39],\n      [4, 40, 18, 2, 41, 19],\n      [4, 40, 14, 2, 41, 15],\n\n      // 9\n      [2, 146, 116],\n      [3, 58, 36, 2, 59, 37],\n      [4, 36, 16, 4, 37, 17],\n      [4, 36, 12, 4, 37, 13],\n\n      // 10\n      [2, 86, 68, 2, 87, 69],\n      [4, 69, 43, 1, 70, 44],\n      [6, 43, 19, 2, 44, 20],\n      [6, 43, 15, 2, 44, 16],\n\n      // 11\n      [4, 101, 81],\n      [1, 80, 50, 4, 81, 51],\n      [4, 50, 22, 4, 51, 23],\n      [3, 36, 12, 8, 37, 13],\n\n      // 12\n      [2, 116, 92, 2, 117, 93],\n      [6, 58, 36, 2, 59, 37],\n      [4, 46, 20, 6, 47, 21],\n      [7, 42, 14, 4, 43, 15],\n\n      // 13\n      [4, 133, 107],\n      [8, 59, 37, 1, 60, 38],\n      [8, 44, 20, 4, 45, 21],\n      [12, 33, 11, 4, 34, 12],\n\n      // 14\n      [3, 145, 115, 1, 146, 116],\n      [4, 64, 40, 5, 65, 41],\n      [11, 36, 16, 5, 37, 17],\n      [11, 36, 12, 5, 37, 13],\n\n      // 15\n      [5, 109, 87, 1, 110, 88],\n      [5, 65, 41, 5, 66, 42],\n      [5, 54, 24, 7, 55, 25],\n      [11, 36, 12, 7, 37, 13],\n\n      // 16\n      [5, 122, 98, 1, 123, 99],\n      [7, 73, 45, 3, 74, 46],\n      [15, 43, 19, 2, 44, 20],\n      [3, 45, 15, 13, 46, 16],\n\n      // 17\n      [1, 135, 107, 5, 136, 108],\n      [10, 74, 46, 1, 75, 47],\n      [1, 50, 22, 15, 51, 23],\n      [2, 42, 14, 17, 43, 15],\n\n      // 18\n      [5, 150, 120, 1, 151, 121],\n      [9, 69, 43, 4, 70, 44],\n      [17, 50, 22, 1, 51, 23],\n      [2, 42, 14, 19, 43, 15],\n\n      // 19\n      [3, 141, 113, 4, 142, 114],\n      [3, 70, 44, 11, 71, 45],\n      [17, 47, 21, 4, 48, 22],\n      [9, 39, 13, 16, 40, 14],\n\n      // 20\n      [3, 135, 107, 5, 136, 108],\n      [3, 67, 41, 13, 68, 42],\n      [15, 54, 24, 5, 55, 25],\n      [15, 43, 15, 10, 44, 16],\n\n      // 21\n      [4, 144, 116, 4, 145, 117],\n      [17, 68, 42],\n      [17, 50, 22, 6, 51, 23],\n      [19, 46, 16, 6, 47, 17],\n\n      // 22\n      [2, 139, 111, 7, 140, 112],\n      [17, 74, 46],\n      [7, 54, 24, 16, 55, 25],\n      [34, 37, 13],\n\n      // 23\n      [4, 151, 121, 5, 152, 122],\n      [4, 75, 47, 14, 76, 48],\n      [11, 54, 24, 14, 55, 25],\n      [16, 45, 15, 14, 46, 16],\n\n      // 24\n      [6, 147, 117, 4, 148, 118],\n      [6, 73, 45, 14, 74, 46],\n      [11, 54, 24, 16, 55, 25],\n      [30, 46, 16, 2, 47, 17],\n\n      // 25\n      [8, 132, 106, 4, 133, 107],\n      [8, 75, 47, 13, 76, 48],\n      [7, 54, 24, 22, 55, 25],\n      [22, 45, 15, 13, 46, 16],\n\n      // 26\n      [10, 142, 114, 2, 143, 115],\n      [19, 74, 46, 4, 75, 47],\n      [28, 50, 22, 6, 51, 23],\n      [33, 46, 16, 4, 47, 17],\n\n      // 27\n      [8, 152, 122, 4, 153, 123],\n      [22, 73, 45, 3, 74, 46],\n      [8, 53, 23, 26, 54, 24],\n      [12, 45, 15, 28, 46, 16],\n\n      // 28\n      [3, 147, 117, 10, 148, 118],\n      [3, 73, 45, 23, 74, 46],\n      [4, 54, 24, 31, 55, 25],\n      [11, 45, 15, 31, 46, 16],\n\n      // 29\n      [7, 146, 116, 7, 147, 117],\n      [21, 73, 45, 7, 74, 46],\n      [1, 53, 23, 37, 54, 24],\n      [19, 45, 15, 26, 46, 16],\n\n      // 30\n      [5, 145, 115, 10, 146, 116],\n      [19, 75, 47, 10, 76, 48],\n      [15, 54, 24, 25, 55, 25],\n      [23, 45, 15, 25, 46, 16],\n\n      // 31\n      [13, 145, 115, 3, 146, 116],\n      [2, 74, 46, 29, 75, 47],\n      [42, 54, 24, 1, 55, 25],\n      [23, 45, 15, 28, 46, 16],\n\n      // 32\n      [17, 145, 115],\n      [10, 74, 46, 23, 75, 47],\n      [10, 54, 24, 35, 55, 25],\n      [19, 45, 15, 35, 46, 16],\n\n      // 33\n      [17, 145, 115, 1, 146, 116],\n      [14, 74, 46, 21, 75, 47],\n      [29, 54, 24, 19, 55, 25],\n      [11, 45, 15, 46, 46, 16],\n\n      // 34\n      [13, 145, 115, 6, 146, 116],\n      [14, 74, 46, 23, 75, 47],\n      [44, 54, 24, 7, 55, 25],\n      [59, 46, 16, 1, 47, 17],\n\n      // 35\n      [12, 151, 121, 7, 152, 122],\n      [12, 75, 47, 26, 76, 48],\n      [39, 54, 24, 14, 55, 25],\n      [22, 45, 15, 41, 46, 16],\n\n      // 36\n      [6, 151, 121, 14, 152, 122],\n      [6, 75, 47, 34, 76, 48],\n      [46, 54, 24, 10, 55, 25],\n      [2, 45, 15, 64, 46, 16],\n\n      // 37\n      [17, 152, 122, 4, 153, 123],\n      [29, 74, 46, 14, 75, 47],\n      [49, 54, 24, 10, 55, 25],\n      [24, 45, 15, 46, 46, 16],\n\n      // 38\n      [4, 152, 122, 18, 153, 123],\n      [13, 74, 46, 32, 75, 47],\n      [48, 54, 24, 14, 55, 25],\n      [42, 45, 15, 32, 46, 16],\n\n      // 39\n      [20, 147, 117, 4, 148, 118],\n      [40, 75, 47, 7, 76, 48],\n      [43, 54, 24, 22, 55, 25],\n      [10, 45, 15, 67, 46, 16],\n\n      // 40\n      [19, 148, 118, 6, 149, 119],\n      [18, 75, 47, 31, 76, 48],\n      [34, 54, 24, 34, 55, 25],\n      [20, 45, 15, 61, 46, 16]\n    ];\n\n    var qrRSBlock = function(totalCount, dataCount) {\n      var _this = {};\n      _this.totalCount = totalCount;\n      _this.dataCount = dataCount;\n      return _this;\n    };\n\n    var _this = {};\n\n    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {\n\n      switch(errorCorrectionLevel) {\n      case QRErrorCorrectionLevel.L :\n        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];\n      case QRErrorCorrectionLevel.M :\n        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];\n      case QRErrorCorrectionLevel.Q :\n        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];\n      case QRErrorCorrectionLevel.H :\n        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];\n      default :\n        return undefined;\n      }\n    };\n\n    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {\n\n      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);\n\n      if (typeof rsBlock == 'undefined') {\n        throw 'bad rs block @ typeNumber:' + typeNumber +\n            '/errorCorrectionLevel:' + errorCorrectionLevel;\n      }\n\n      var length = rsBlock.length / 3;\n\n      var list = [];\n\n      for (var i = 0; i < length; i += 1) {\n\n        var count = rsBlock[i * 3 + 0];\n        var totalCount = rsBlock[i * 3 + 1];\n        var dataCount = rsBlock[i * 3 + 2];\n\n        for (var j = 0; j < count; j += 1) {\n          list.push(qrRSBlock(totalCount, dataCount) );\n        }\n      }\n\n      return list;\n    };\n\n    return _this;\n  }();\n\n  //---------------------------------------------------------------------\n  // qrBitBuffer\n  //---------------------------------------------------------------------\n\n  var qrBitBuffer = function() {\n\n    var _buffer = [];\n    var _length = 0;\n\n    var _this = {};\n\n    _this.getBuffer = function() {\n      return _buffer;\n    };\n\n    _this.getAt = function(index) {\n      var bufIndex = Math.floor(index / 8);\n      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;\n    };\n\n    _this.put = function(num, length) {\n      for (var i = 0; i < length; i += 1) {\n        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);\n      }\n    };\n\n    _this.getLengthInBits = function() {\n      return _length;\n    };\n\n    _this.putBit = function(bit) {\n\n      var bufIndex = Math.floor(_length / 8);\n      if (_buffer.length <= bufIndex) {\n        _buffer.push(0);\n      }\n\n      if (bit) {\n        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );\n      }\n\n      _length += 1;\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // qrNumber\n  //---------------------------------------------------------------------\n\n  var qrNumber = function(data) {\n\n    var _mode = QRMode.MODE_NUMBER;\n    var _data = data;\n\n    var _this = {};\n\n    _this.getMode = function() {\n      return _mode;\n    };\n\n    _this.getLength = function(buffer) {\n      return _data.length;\n    };\n\n    _this.write = function(buffer) {\n\n      var data = _data;\n\n      var i = 0;\n\n      while (i + 2 < data.length) {\n        buffer.put(strToNum(data.substring(i, i + 3) ), 10);\n        i += 3;\n      }\n\n      if (i < data.length) {\n        if (data.length - i == 1) {\n          buffer.put(strToNum(data.substring(i, i + 1) ), 4);\n        } else if (data.length - i == 2) {\n          buffer.put(strToNum(data.substring(i, i + 2) ), 7);\n        }\n      }\n    };\n\n    var strToNum = function(s) {\n      var num = 0;\n      for (var i = 0; i < s.length; i += 1) {\n        num = num * 10 + chatToNum(s.charAt(i) );\n      }\n      return num;\n    };\n\n    var chatToNum = function(c) {\n      if ('0' <= c && c <= '9') {\n        return c.charCodeAt(0) - '0'.charCodeAt(0);\n      }\n      throw 'illegal char :' + c;\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // qrAlphaNum\n  //---------------------------------------------------------------------\n\n  var qrAlphaNum = function(data) {\n\n    var _mode = QRMode.MODE_ALPHA_NUM;\n    var _data = data;\n\n    var _this = {};\n\n    _this.getMode = function() {\n      return _mode;\n    };\n\n    _this.getLength = function(buffer) {\n      return _data.length;\n    };\n\n    _this.write = function(buffer) {\n\n      var s = _data;\n\n      var i = 0;\n\n      while (i + 1 < s.length) {\n        buffer.put(\n          getCode(s.charAt(i) ) * 45 +\n          getCode(s.charAt(i + 1) ), 11);\n        i += 2;\n      }\n\n      if (i < s.length) {\n        buffer.put(getCode(s.charAt(i) ), 6);\n      }\n    };\n\n    var getCode = function(c) {\n\n      if ('0' <= c && c <= '9') {\n        return c.charCodeAt(0) - '0'.charCodeAt(0);\n      } else if ('A' <= c && c <= 'Z') {\n        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;\n      } else {\n        switch (c) {\n        case ' ' : return 36;\n        case '$' : return 37;\n        case '%' : return 38;\n        case '*' : return 39;\n        case '+' : return 40;\n        case '-' : return 41;\n        case '.' : return 42;\n        case '/' : return 43;\n        case ':' : return 44;\n        default :\n          throw 'illegal char :' + c;\n        }\n      }\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // qr8BitByte\n  //---------------------------------------------------------------------\n\n  var qr8BitByte = function(data) {\n\n    var _mode = QRMode.MODE_8BIT_BYTE;\n    var _data = data;\n    var _bytes = qrcode.stringToBytes(data);\n\n    var _this = {};\n\n    _this.getMode = function() {\n      return _mode;\n    };\n\n    _this.getLength = function(buffer) {\n      return _bytes.length;\n    };\n\n    _this.write = function(buffer) {\n      for (var i = 0; i < _bytes.length; i += 1) {\n        buffer.put(_bytes[i], 8);\n      }\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // qrKanji\n  //---------------------------------------------------------------------\n\n  var qrKanji = function(data) {\n\n    var _mode = QRMode.MODE_KANJI;\n    var _data = data;\n\n    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];\n    if (!stringToBytes) {\n      throw 'sjis not supported.';\n    }\n    !function(c, code) {\n      // self test for sjis support.\n      var test = stringToBytes(c);\n      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {\n        throw 'sjis not supported.';\n      }\n    }('\\u53cb', 0x9746);\n\n    var _bytes = stringToBytes(data);\n\n    var _this = {};\n\n    _this.getMode = function() {\n      return _mode;\n    };\n\n    _this.getLength = function(buffer) {\n      return ~~(_bytes.length / 2);\n    };\n\n    _this.write = function(buffer) {\n\n      var data = _bytes;\n\n      var i = 0;\n\n      while (i + 1 < data.length) {\n\n        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);\n\n        if (0x8140 <= c && c <= 0x9FFC) {\n          c -= 0x8140;\n        } else if (0xE040 <= c && c <= 0xEBBF) {\n          c -= 0xC140;\n        } else {\n          throw 'illegal char at ' + (i + 1) + '/' + c;\n        }\n\n        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);\n\n        buffer.put(c, 13);\n\n        i += 2;\n      }\n\n      if (i < data.length) {\n        throw 'illegal char at ' + (i + 1);\n      }\n    };\n\n    return _this;\n  };\n\n  //=====================================================================\n  // GIF Support etc.\n  //\n\n  //---------------------------------------------------------------------\n  // byteArrayOutputStream\n  //---------------------------------------------------------------------\n\n  var byteArrayOutputStream = function() {\n\n    var _bytes = [];\n\n    var _this = {};\n\n    _this.writeByte = function(b) {\n      _bytes.push(b & 0xff);\n    };\n\n    _this.writeShort = function(i) {\n      _this.writeByte(i);\n      _this.writeByte(i >>> 8);\n    };\n\n    _this.writeBytes = function(b, off, len) {\n      off = off || 0;\n      len = len || b.length;\n      for (var i = 0; i < len; i += 1) {\n        _this.writeByte(b[i + off]);\n      }\n    };\n\n    _this.writeString = function(s) {\n      for (var i = 0; i < s.length; i += 1) {\n        _this.writeByte(s.charCodeAt(i) );\n      }\n    };\n\n    _this.toByteArray = function() {\n      return _bytes;\n    };\n\n    _this.toString = function() {\n      var s = '';\n      s += '[';\n      for (var i = 0; i < _bytes.length; i += 1) {\n        if (i > 0) {\n          s += ',';\n        }\n        s += _bytes[i];\n      }\n      s += ']';\n      return s;\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // base64EncodeOutputStream\n  //---------------------------------------------------------------------\n\n  var base64EncodeOutputStream = function() {\n\n    var _buffer = 0;\n    var _buflen = 0;\n    var _length = 0;\n    var _base64 = '';\n\n    var _this = {};\n\n    var writeEncoded = function(b) {\n      _base64 += String.fromCharCode(encode(b & 0x3f) );\n    };\n\n    var encode = function(n) {\n      if (n < 0) {\n        // error.\n      } else if (n < 26) {\n        return 0x41 + n;\n      } else if (n < 52) {\n        return 0x61 + (n - 26);\n      } else if (n < 62) {\n        return 0x30 + (n - 52);\n      } else if (n == 62) {\n        return 0x2b;\n      } else if (n == 63) {\n        return 0x2f;\n      }\n      throw 'n:' + n;\n    };\n\n    _this.writeByte = function(n) {\n\n      _buffer = (_buffer << 8) | (n & 0xff);\n      _buflen += 8;\n      _length += 1;\n\n      while (_buflen >= 6) {\n        writeEncoded(_buffer >>> (_buflen - 6) );\n        _buflen -= 6;\n      }\n    };\n\n    _this.flush = function() {\n\n      if (_buflen > 0) {\n        writeEncoded(_buffer << (6 - _buflen) );\n        _buffer = 0;\n        _buflen = 0;\n      }\n\n      if (_length % 3 != 0) {\n        // padding\n        var padlen = 3 - _length % 3;\n        for (var i = 0; i < padlen; i += 1) {\n          _base64 += '=';\n        }\n      }\n    };\n\n    _this.toString = function() {\n      return _base64;\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // base64DecodeInputStream\n  //---------------------------------------------------------------------\n\n  var base64DecodeInputStream = function(str) {\n\n    var _str = str;\n    var _pos = 0;\n    var _buffer = 0;\n    var _buflen = 0;\n\n    var _this = {};\n\n    _this.read = function() {\n\n      while (_buflen < 8) {\n\n        if (_pos >= _str.length) {\n          if (_buflen == 0) {\n            return -1;\n          }\n          throw 'unexpected end of file./' + _buflen;\n        }\n\n        var c = _str.charAt(_pos);\n        _pos += 1;\n\n        if (c == '=') {\n          _buflen = 0;\n          return -1;\n        } else if (c.match(/^\\s$/) ) {\n          // ignore if whitespace.\n          continue;\n        }\n\n        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );\n        _buflen += 6;\n      }\n\n      var n = (_buffer >>> (_buflen - 8) ) & 0xff;\n      _buflen -= 8;\n      return n;\n    };\n\n    var decode = function(c) {\n      if (0x41 <= c && c <= 0x5a) {\n        return c - 0x41;\n      } else if (0x61 <= c && c <= 0x7a) {\n        return c - 0x61 + 26;\n      } else if (0x30 <= c && c <= 0x39) {\n        return c - 0x30 + 52;\n      } else if (c == 0x2b) {\n        return 62;\n      } else if (c == 0x2f) {\n        return 63;\n      } else {\n        throw 'c:' + c;\n      }\n    };\n\n    return _this;\n  };\n\n  //---------------------------------------------------------------------\n  // gifImage (B/W)\n  //---------------------------------------------------------------------\n\n  var gifImage = function(width, height) {\n\n    var _width = width;\n    var _height = height;\n    var _data = new Array(width * height);\n\n    var _this = {};\n\n    _this.setPixel = function(x, y, pixel) {\n      _data[y * _width + x] = pixel;\n    };\n\n    _this.write = function(out) {\n\n      //---------------------------------\n      // GIF Signature\n\n      out.writeString('GIF87a');\n\n      //---------------------------------\n      // Screen Descriptor\n\n      out.writeShort(_width);\n      out.writeShort(_height);\n\n      out.writeByte(0x80); // 2bit\n      out.writeByte(0);\n      out.writeByte(0);\n\n      //---------------------------------\n      // Global Color Map\n\n      // black\n      out.writeByte(0x00);\n      out.writeByte(0x00);\n      out.writeByte(0x00);\n\n      // white\n      out.writeByte(0xff);\n      out.writeByte(0xff);\n      out.writeByte(0xff);\n\n      //---------------------------------\n      // Image Descriptor\n\n      out.writeString(',');\n      out.writeShort(0);\n      out.writeShort(0);\n      out.writeShort(_width);\n      out.writeShort(_height);\n      out.writeByte(0);\n\n      //---------------------------------\n      // Local Color Map\n\n      //---------------------------------\n      // Raster Data\n\n      var lzwMinCodeSize = 2;\n      var raster = getLZWRaster(lzwMinCodeSize);\n\n      out.writeByte(lzwMinCodeSize);\n\n      var offset = 0;\n\n      while (raster.length - offset > 255) {\n        out.writeByte(255);\n        out.writeBytes(raster, offset, 255);\n        offset += 255;\n      }\n\n      out.writeByte(raster.length - offset);\n      out.writeBytes(raster, offset, raster.length - offset);\n      out.writeByte(0x00);\n\n      //---------------------------------\n      // GIF Terminator\n      out.writeString(';');\n    };\n\n    var bitOutputStream = function(out) {\n\n      var _out = out;\n      var _bitLength = 0;\n      var _bitBuffer = 0;\n\n      var _this = {};\n\n      _this.write = function(data, length) {\n\n        if ( (data >>> length) != 0) {\n          throw 'length over';\n        }\n\n        while (_bitLength + length >= 8) {\n          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );\n          length -= (8 - _bitLength);\n          data >>>= (8 - _bitLength);\n          _bitBuffer = 0;\n          _bitLength = 0;\n        }\n\n        _bitBuffer = (data << _bitLength) | _bitBuffer;\n        _bitLength = _bitLength + length;\n      };\n\n      _this.flush = function() {\n        if (_bitLength > 0) {\n          _out.writeByte(_bitBuffer);\n        }\n      };\n\n      return _this;\n    };\n\n    var getLZWRaster = function(lzwMinCodeSize) {\n\n      var clearCode = 1 << lzwMinCodeSize;\n      var endCode = (1 << lzwMinCodeSize) + 1;\n      var bitLength = lzwMinCodeSize + 1;\n\n      // Setup LZWTable\n      var table = lzwTable();\n\n      for (var i = 0; i < clearCode; i += 1) {\n        table.add(String.fromCharCode(i) );\n      }\n      table.add(String.fromCharCode(clearCode) );\n      table.add(String.fromCharCode(endCode) );\n\n      var byteOut = byteArrayOutputStream();\n      var bitOut = bitOutputStream(byteOut);\n\n      // clear code\n      bitOut.write(clearCode, bitLength);\n\n      var dataIndex = 0;\n\n      var s = String.fromCharCode(_data[dataIndex]);\n      dataIndex += 1;\n\n      while (dataIndex < _data.length) {\n\n        var c = String.fromCharCode(_data[dataIndex]);\n        dataIndex += 1;\n\n        if (table.contains(s + c) ) {\n\n          s = s + c;\n\n        } else {\n\n          bitOut.write(table.indexOf(s), bitLength);\n\n          if (table.size() < 0xfff) {\n\n            if (table.size() == (1 << bitLength) ) {\n              bitLength += 1;\n            }\n\n            table.add(s + c);\n          }\n\n          s = c;\n        }\n      }\n\n      bitOut.write(table.indexOf(s), bitLength);\n\n      // end code\n      bitOut.write(endCode, bitLength);\n\n      bitOut.flush();\n\n      return byteOut.toByteArray();\n    };\n\n    var lzwTable = function() {\n\n      var _map = {};\n      var _size = 0;\n\n      var _this = {};\n\n      _this.add = function(key) {\n        if (_this.contains(key) ) {\n          throw 'dup key:' + key;\n        }\n        _map[key] = _size;\n        _size += 1;\n      };\n\n      _this.size = function() {\n        return _size;\n      };\n\n      _this.indexOf = function(key) {\n        return _map[key];\n      };\n\n      _this.contains = function(key) {\n        return typeof _map[key] != 'undefined';\n      };\n\n      return _this;\n    };\n\n    return _this;\n  };\n\n  var createDataURL = function(width, height, getPixel) {\n    var gif = gifImage(width, height);\n    for (var y = 0; y < height; y += 1) {\n      for (var x = 0; x < width; x += 1) {\n        gif.setPixel(x, y, getPixel(x, y) );\n      }\n    }\n\n    var b = byteArrayOutputStream();\n    gif.write(b);\n\n    var base64 = base64EncodeOutputStream();\n    var bytes = b.toByteArray();\n    for (var i = 0; i < bytes.length; i += 1) {\n      base64.writeByte(bytes[i]);\n    }\n    base64.flush();\n\n    return 'data:image/gif;base64,' + base64;\n  };\n\n  //---------------------------------------------------------------------\n  // returns qrcode function.\n\n  return qrcode;\n}();\n\n// multibyte support\n!function() {\n\n  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {\n    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array\n    function toUTF8Array(str) {\n      var utf8 = [];\n      for (var i=0; i < str.length; i++) {\n        var charcode = str.charCodeAt(i);\n        if (charcode < 0x80) utf8.push(charcode);\n        else if (charcode < 0x800) {\n          utf8.push(0xc0 | (charcode >> 6),\n              0x80 | (charcode & 0x3f));\n        }\n        else if (charcode < 0xd800 || charcode >= 0xe000) {\n          utf8.push(0xe0 | (charcode >> 12),\n              0x80 | ((charcode>>6) & 0x3f),\n              0x80 | (charcode & 0x3f));\n        }\n        // surrogate pair\n        else {\n          i++;\n          // UTF-16 encodes 0x10000-0x10FFFF by\n          // subtracting 0x10000 and splitting the\n          // 20 bits of 0x0-0xFFFFF into two halves\n          charcode = 0x10000 + (((charcode & 0x3ff)<<10)\n            | (str.charCodeAt(i) & 0x3ff));\n          utf8.push(0xf0 | (charcode >>18),\n              0x80 | ((charcode>>12) & 0x3f),\n              0x80 | ((charcode>>6) & 0x3f),\n              0x80 | (charcode & 0x3f));\n        }\n      }\n      return utf8;\n    }\n    return toUTF8Array(s);\n  };\n\n}();\n\n(function (factory) {\n  if (typeof define === 'function' && define.amd) {\n      define([], factory);\n  } else if (typeof exports === 'object') {\n      module.exports = factory();\n  }\n}(function () {\n    return qrcode;\n}));\n",
  indexHtml: "<!DOCTYPE html>\r\n<html lang=\"fa\" dir=\"rtl\">\r\n<head>\r\n  <meta charset=\"UTF-8\">\r\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\r\n  <meta name=\"theme-color\" content=\"#0b1018\">\r\n  <title>Amyrax Panel | مدیریت اتصال</title>\r\n  <link rel=\"icon\" type=\"image/svg+xml\" href=\"/amyrax-assets/logo.svg\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/app.css\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/users.css\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/studio.css\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/controls.css\">\r\n  <link rel=\"stylesheet\" href=\"/amyrax-assets/updates.css\">\r\n</head>\r\n<body>\r\n  <aside class=\"sidebar\" id=\"mobileDrawer\" aria-label=\"منوی اصلی\">\r\n    <a class=\"brand\" href=\"#/home\" aria-label=\"Amyrax Panel\">\r\n      <img src=\"/amyrax-assets/logo.svg\" alt=\"Amyrax\" width=\"45\" height=\"45\">\r\n      <span><strong dir=\"ltr\">Amyrax<span>Panel</span></strong><small>کنترل هوشمند اتصال</small></span>\r\n    </a>\r\n    <div class=\"sidebar-label\">فضای مدیریت</div>\r\n    <nav class=\"side-nav\"><a href=\"#/home\" class=\"side-link nav-link active\" data-page=\"home\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 10.5 12 3l9 7.5M5 9v11h5v-6h4v6h5V9\"/></svg><span>نمای کلی</span></a>\r\n<a href=\"#/subs\" class=\"side-link nav-link\" data-page=\"subs\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2\"/></svg><span>اشتراک‌ها</span></a>\r\n<a href=\"#/nodes\" class=\"side-link nav-link\" data-page=\"nodes\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 4h16v5H4zM4 15h16v5H4zM8 6.5h.01M8 17.5h.01M12 9v6\"/></svg><span>کانفیگ‌ها</span></a>\r\n<a href=\"#/studio\" class=\"side-link nav-link\" data-page=\"studio\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 7h16M4 17h16M8 4v6M16 14v6\"/></svg><span>شخصی‌سازی</span></a>\r\n<a href=\"#/users\" class=\"side-link nav-link\" data-page=\"users\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" aria-hidden=\"true\"><circle cx=\"9\" cy=\"8\" r=\"3\"/><path d=\"M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 4v3\"/></svg><span>کاربران</span></a>\r\n<a href=\"#/usage\" class=\"side-link nav-link\" data-page=\"usage\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 19V5M4 19h16M8 15V9M13 15V5M18 15v-3\"/></svg><span>مصرف ترافیک</span></a></nav>\r\n    <div class=\"sidebar-label external-label\">دسترسی سریع</div>\r\n    <a class=\"side-link\" href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"m21 3-4.5 18-6.7-5.5L6 19l1-6L3 10zM7 13 21 3M9.8 15.5 17 7\"/></svg><span>کانال تلگرام</span><span class=\"external-arrow\">↗</span></a>\r\n    <a class=\"side-link\" href=\"/amyrax/logout\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M10 5H5v14h5M9 12h12M17 8l4 4-4 4\"/></svg><span>خروج از پنل</span></a>\r\n    <div class=\"sidebar-bottom\">\r\n      <a class=\"community-mini\" href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\"><span class=\"mini-orbit\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"m21 3-4.5 18-6.7-5.5L6 19l1-6L3 10zM7 13 21 3M9.8 15.5 17 7\"/></svg></span><strong>به امیراکس بپیوندید</strong><small dir=\"ltr\">@AmyraxVPN ↗</small></a>\r\n      <div class=\"sidebar-build\"><span class=\"status-dot\"></span><span dir=\"ltr\">AMYRAX PANEL</span><span class=\"version\">v1.11.11</span></div>\r\n    </div>\r\n  </aside>\r\n  <button class=\"drawer-scrim\" id=\"drawerScrim\" aria-label=\"بستن منو\" tabindex=\"-1\"></button>\r\n  <div class=\"workspace\">\r\n    <header class=\"topbar\">\r\n      <div class=\"breadcrumb\"><button class=\"icon-button menu-toggle\" id=\"hamburgerBtn\" aria-label=\"باز کردن منو\" aria-controls=\"mobileDrawer\" aria-expanded=\"false\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 6h16M4 12h16M4 18h16\"/></svg></button><span>Amyrax</span><i>/</i><strong id=\"breadcrumbPage\">نمای کلی</strong></div>\r\n      <div class=\"top-actions\"><span class=\"connection-state\" id=\"connectionState\"><span class=\"status-dot\"></span><span id=\"connectionLabel\">در حال اتصال</span></span><span class=\"top-divider\"></span><button type=\"button\" class=\"icon-button\" id=\"updateBtn\" aria-label=\"بررسی به‌روزرسانی\" title=\"بررسی به‌روزرسانی\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M20 8a8 8 0 1 0 0 8M20 3v5h-5\"/></svg></button><button type=\"button\" class=\"icon-button\" id=\"themeToggleBtn\" data-theme=\"dark\" aria-pressed=\"false\" aria-label=\"فعال‌کردن تم گرم\" title=\"فعال‌کردن تم گرم\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2M12 20v2M2 12h2M20 12h2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42\"/></svg><span id=\"themeToggleLabel\" class=\"sr-only\">تم تیره</span></button><span class=\"avatar\" aria-label=\"مدیر پنل\">A</span></div>\r\n    </header>\r\n    <main class=\"main-content\">\r\n      <aside id=\"updateNotice\" class=\"update-notice\" hidden aria-labelledby=\"updateNoticeTitle\" aria-live=\"polite\">\r\n        <span class=\"update-notice-icon\" aria-hidden=\"true\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 8a8 8 0 1 0 0 8M20 3v5h-5\"/></svg></span>\r\n        <div class=\"update-notice-copy\"><strong id=\"updateNoticeTitle\"></strong><p id=\"updateNoticeSummary\"></p></div>\r\n        <button id=\"openUpdateDialog\" type=\"button\" class=\"button primary\">مشاهدهٔ به‌روزرسانی</button><button id=\"dismissUpdateNotice\" type=\"button\" class=\"icon-button\" aria-label=\"بعداً یادآوری شود\">×</button>\r\n      </aside>\r\n      <section class=\"page-heading\"><div><div class=\"eyebrow\" dir=\"ltr\">YOUR NETWORK, AT A GLANCE</div><h1 id=\"pageTitle\">نمای کلی پنل</h1><p id=\"pageDescription\">وضعیت اتصال، سرویس‌ها و مصرف ترافیک؛ همه در یک نگاه.</p></div><button class=\"button secondary\" id=\"refreshOverview\" aria-label=\"به‌روزرسانی آمار\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M20 8a8 8 0 1 0 0 8M20 3v5h-5\"/></svg><span>به‌روزرسانی</span></button></section>\r\n      <div id=\"viewHome\" class=\"view-page active\">\r\n        <div class=\"overview-grid\">\r\n          <section class=\"panel server-card\">\r\n            <div class=\"card-heading\"><h2>مشخصات سرور</h2><span class=\"chip neutral\" id=\"serverPlatform\">—</span></div>\r\n            <div class=\"server-identity\"><div class=\"server-symbol\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M5 3h14v7H5zM5 14h14v7H5zM8 6.5h.01M8 17.5h.01M12 6.5h4M12 17.5h4\"/></svg></div><div><strong dir=\"ltr\">Amyrax Server</strong><span id=\"overviewHost\" dir=\"ltr\">در حال دریافت اطلاعات…</span></div><span class=\"tiny-indicator\" id=\"serverIndicator\"></span></div>\r\n            <dl class=\"detail-list\"><div><dt><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0ZM12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z\"/></svg>موقعیت سرور</dt><dd id=\"homeLocation\">—</dd></div><div><dt><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18ZM12 7v5l3 2\"/></svg>زمان فعالیت پنل</dt><dd id=\"homeUptime\" dir=\"ltr\">—</dd></div><div><dt><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M8 3v4M16 3v4M6 7h12v5a6 6 0 0 1-12 0ZM12 18v3\"/></svg>پورت اتصال</dt><dd id=\"homePort\" dir=\"ltr\">—</dd></div><div><dt><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M7 7h10v10H7zM10 3v4M14 3v4M10 17v4M14 17v4M3 10h4M3 14h4M17 10h4M17 14h4\"/></svg>ظرفیت پردازنده</dt><dd id=\"overviewCores\" dir=\"ltr\">—</dd></div><div><dt><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"m12 3 9 5-9 5-9-5zM3 8v9l9 5 9-5V8M12 13v9\"/></svg>میزبانی</dt><dd id=\"overviewPlatform\" dir=\"ltr\">—</dd></div></dl>\r\n          </section>\r\n          <section class=\"panel bandwidth-card\">\r\n            <div class=\"card-heading\"><h2 title=\"نرخ ترافیک پنل در آخرین بازهٔ نمونه‌برداری؛ معمولاً یک ثانیه\">سرعت لحظه‌ای</h2><span class=\"chip\"><span class=\"status-dot\"></span>زنده</span></div>\r\n            <div class=\"speed-grid\"><div><span class=\"metric-caption\"><span class=\"teal\">↑</span> آپلود</span><strong id=\"overviewUp\" class=\"speed-value teal\" dir=\"ltr\">—</strong></div><div><span class=\"metric-caption\"><span class=\"blue\">↓</span> دانلود</span><strong id=\"overviewDown\" class=\"speed-value blue\" dir=\"ltr\">—</strong></div></div>\r\n            <div class=\"traffic-chart\"><div class=\"chart-grid\"></div><svg viewBox=\"0 0 500 108\" preserveAspectRatio=\"none\" role=\"img\" aria-label=\"نمودار نمونه‌های سرعت در ۶۰ ثانیهٔ اخیر\"><defs><linearGradient id=\"chartFade\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#46cbb3\" stop-opacity=\".18\"/><stop offset=\"1\" stop-color=\"#46cbb3\" stop-opacity=\"0\"/></linearGradient></defs><path id=\"chartArea\" fill=\"url(#chartFade)\"/><path id=\"chartUp\" fill=\"none\" stroke=\"#46cbb3\" stroke-width=\"2\" vector-effect=\"non-scaling-stroke\"/><path id=\"chartDown\" fill=\"none\" stroke=\"#579df6\" stroke-width=\"2\" vector-effect=\"non-scaling-stroke\"/></svg><span id=\"chartEmpty\">در انتظار ترافیک</span></div><div class=\"chart-axis\"><span>۶۰ ثانیهٔ اخیر</span><span>اکنون</span></div>\r\n            <div class=\"transfer-totals\"><div><span>ارسال امروز (UTC)</span><strong id=\"overviewSent\" dir=\"ltr\">—</strong></div><div><span>دریافت امروز (UTC)</span><strong id=\"overviewReceived\" dir=\"ltr\">—</strong></div></div>\r\n          </section>\r\n          <section class=\"panel resources-card\">\r\n            <div class=\"card-heading\"><h2>منابع سیستم</h2><span class=\"muted\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M7 7h10v10H7zM10 3v4M14 3v4M10 17v4M14 17v4M3 10h4M3 14h4M17 10h4M17 14h4\"/></svg></span></div>\r\n            <div class=\"memory-display\"><div class=\"memory-ring\" id=\"memoryRing\"><div><strong id=\"memoryPercent\">—</strong><small>RAM</small></div></div><div class=\"memory-text\"><span id=\"memoryScope\">حافظهٔ محیط اجرا</span><strong id=\"memoryUsed\" dir=\"ltr\">—</strong><small id=\"memoryTotal\" dir=\"ltr\">—</small></div></div>\r\n            <div class=\"resource-detail\"><span>مصرف پردازش پنل</span><strong id=\"processMemory\" dir=\"ltr\">—</strong></div><div class=\"resource-detail\"><span id=\"systemUptimeLabel\">فعالیت محیط اجرا</span><strong id=\"systemUptime\" dir=\"ltr\">—</strong></div>\r\n          </section>\r\n          <section class=\"panel engines-card\"><div class=\"card-heading\"><h2>موتورهای اتصال</h2><span id=\"engineCount\" class=\"muted\">—</span></div><div class=\"engine-list\"><div class=\"engine-item\"><span class=\"engine-icon\">S</span><span><strong dir=\"ltr\">sing-box</strong><small>پروتکل‌های اصلی</small></span><span class=\"engine-status\" id=\"engineSingbox\">—</span></div><div class=\"engine-item\"><span class=\"engine-icon violet\">X</span><span><strong dir=\"ltr\">Xray-core</strong><small>اتصال XHTTP</small></span><span class=\"engine-status\" id=\"engineXray\">—</span></div><div class=\"engine-item\"><span class=\"engine-icon amber\">C</span><span><strong dir=\"ltr\">Cloudflare Argo</strong><small>تونل امن</small></span><span class=\"engine-status\" id=\"engineArgo\">—</span></div></div></section>\r\n          <section class=\"panel summary-card\"><div class=\"card-heading\"><h2>خلاصهٔ اتصال</h2><a href=\"#/usage\" class=\"text-link\">جزئیات مصرف ←</a></div><div class=\"summary-counters\"><div><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 4h16v5H4zM4 15h16v5H4zM8 6.5h.01M8 17.5h.01M12 9v6\"/></svg><strong id=\"overviewNodes\">—</strong><span>کانفیگ موجود</span></div><div><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M2 12h5l3-8 4 16 3-8h5\"/></svg><strong id=\"overviewConnections\">—</strong><small id=\"overviewTunnels\" class=\"muted\">—</small><span title=\"هر حساب یک بار شمرده می‌شود؛ لینک مشترک یک حساب است، نه تعداد دستگاه یا نفر.\">حساب متصل</span></div><div><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 19V5M4 19h16M8 15V9M13 15V5M18 15v-3\"/></svg><strong id=\"overviewMonth\" dir=\"ltr\">—</strong><span>مصرف این ماه</span></div></div><div class=\"summary-note\"><span class=\"status-dot\"></span><span id=\"overviewUpdated\">در حال دریافت وضعیت سرور…</span></div></section>\r\n          <section class=\"panel quick-card\"><div class=\"card-heading\"><h2>شروع اتصال</h2><span class=\"step-number\">01 / 02</span></div><p>لینک اشتراک را کپی کنید و در برنامهٔ VPN خود وارد کنید.</p><a class=\"button primary wide\" href=\"#/subs\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2\"/></svg>دریافت اشتراک<span>←</span></a><a class=\"button secondary wide\" href=\"#/nodes\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 4h16v5H4zM4 15h16v5H4zM8 6.5h.01M8 17.5h.01M12 9v6\"/></svg>مشاهدهٔ کانفیگ‌ها<span>←</span></a></section>\r\n          <section class=\"panel network-card\" aria-label=\"بررسی اتصال عمومی\"><div class=\"card-heading\"><h2>بررسی اتصال عمومی</h2><span class=\"chip\" id=\"networkState\">در انتظار بررسی</span></div><p id=\"networkSummary\">آدرس عمومی، DNS، گواهی HTTPS و ورودی اتصال از سمت سرور بررسی می‌شوند.</p><p class=\"network-endpoint\" id=\"networkEndpoint\" dir=\"ltr\">—</p><ul id=\"networkChecks\"></ul><div class=\"network-actions\"><button type=\"button\" class=\"button secondary\" id=\"checkNetwork\">بررسی آدرس و اتصال</button><small>برای نتیجهٔ شبکهٔ خودتان، VPN را خاموش کنید و همین پنل و کانفیگ را با اینترنت موبایل یا ثابت آزمایش کنید.</small></div></section>\n          <section class=\"panel protocols-card\"><div class=\"card-heading\"><h2>پروتکل‌های موجود</h2><span class=\"muted\" id=\"protocolCount\">—</span></div><div id=\"protocolGrid\" class=\"protocol-grid\"><span class=\"muted\">در حال دریافت کانفیگ‌ها…</span></div><p class=\"protocol-note\">نمایش کانفیگ به معنی برقراری اتصال نیست؛ وضعیت موتور را نیز بررسی کنید.</p></section>\r\n          <a class=\"telegram-banner\" href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\"><div class=\"telegram-art\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"m21 3-4.5 18-6.7-5.5L6 19l1-6L3 10zM7 13 21 3M9.8 15.5 17 7\"/></svg></div><div><strong>همراه امیراکس، همیشه متصل</strong><span>خبرها، راهنما و به‌روزرسانی‌ها در کانال تلگرام</span></div><span class=\"telegram-handle\" dir=\"ltr\">@AmyraxVPN <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M7 17 17 7M7 7h10v10\"/></svg></span></a>\r\n        </div>\r\n      </div>\r\n            \r\n      <div id=\"viewUsage\" class=\"view-page\">\r\n        <section class=\"subs-container-card usage\">\r\n          <div class=\"section-top-row\">\r\n            <div class=\"section-title-wrap\">\r\n              <span class=\"red-bar-indicator\"></span>\r\n              <h2 class=\"section-heading\">مصرف ترافیک</h2>\r\n            </div>\r\n            <div class=\"server-status-tag usage-live\" title=\"سرعت لحظه‌ای همهٔ کانفیگ‌ها\">\r\n              <span class=\"status-dot\"></span>\r\n              <span>&uarr; <b id=\"usageLiveUp\">0 B/s</b> &nbsp; &darr; <b id=\"usageLiveDown\">0 B/s</b></span>\r\n            </div>\r\n          </div>\r\n          <p class=\"subs-caption\">\r\n            مجموع بایت‌های ثبت‌شدهٔ آپلود و دانلود کانفیگ‌ها. دورهٔ ماهانه از ساعت ۰۰:۰۰ UTC روز اول ماه آغاز می‌شود.\r\n          </p>\r\n\r\n          <p id=\"trafficUpdated\" class=\"resource-note\" role=\"status\">در حال دریافت آمار…</p>\r\n          <div class=\"usage-limit\" id=\"usageLimit\" hidden>\r\n            <div class=\"usage-limit-top\">\r\n              <span id=\"usageLimitText\">&ndash;</span>\r\n              <span id=\"usageLimitPct\">&ndash;</span>\r\n            </div>\r\n            <div class=\"usage-bar\"><div class=\"usage-bar-fill\" id=\"usageBar\"></div></div>\r\n            <div class=\"usage-limit-msg\" id=\"usageLimitMsg\"></div>\r\n          </div>\r\n\r\n          <div class=\"usage-cards\">\r\n            <div class=\"usage-card\">\r\n              <div class=\"usage-card-label\">امروز <span class=\"usage-muted\">(UTC)</span></div>\r\n              <div class=\"usage-card-total\" id=\"usageDayTotal\">&ndash;</div>\r\n              <div class=\"usage-card-split\"><span>&uarr; <b id=\"usageDayUp\">&ndash;</b></span><span>&darr; <b id=\"usageDayDown\">&ndash;</b></span></div>\r\n            </div>\r\n            <div class=\"usage-card\">\r\n              <div class=\"usage-card-label\">این ماه <span class=\"usage-muted\" id=\"usageMonthKey\"></span></div>\r\n              <div class=\"usage-card-total\" id=\"usageMonthTotal\">&ndash;</div>\r\n              <div class=\"usage-card-split\"><span>&uarr; <b id=\"usageMonthUp\">&ndash;</b></span><span>&darr; <b id=\"usageMonthDown\">&ndash;</b></span></div>\r\n            </div>\r\n            <div class=\"usage-card\">\r\n              <div class=\"usage-card-label\">کل دوره</div>\r\n              <div class=\"usage-card-total\" id=\"usageAllTotal\">&ndash;</div>\r\n              <div class=\"usage-card-split\"><span>&uarr; <b id=\"usageAllUp\">&ndash;</b></span><span>&darr; <b id=\"usageAllDown\">&ndash;</b></span></div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"usage-table-wrap\">\r\n            <table class=\"usage-table\">\r\n              <thead>\r\n                <tr><th>کانفیگ</th><th>تونل باز</th><th>امروز</th><th>آپلود ماه</th><th>دانلود ماه</th><th>مجموع ماه</th><th>کل دوره</th></tr>\r\n              </thead>\r\n              <tbody id=\"usageRows\"></tbody>\r\n              <tfoot id=\"usageFoot\"></tfoot>\r\n            </table>\r\n          </div>\r\n\r\n\r\n        </section>\r\n      </div>\r\n\r\n      \r\n      <div id=\"viewSubs\" class=\"view-page\">\r\n        <section class=\"subs-container-card unified-sub-card\">\r\n          <div class=\"section-top-row\"><div class=\"section-title-wrap\"><span class=\"red-bar-indicator\"></span><h2 class=\"section-heading\">یک لینک، همهٔ اتصال‌ها</h2></div><span class=\"badge-recommended\">اشتراک هوشمند</span></div>\r\n          <p class=\"subs-caption\">همین لینک را در اپ VPN وارد کنید؛ قالب مناسب اپ‌های شناخته‌شده به‌صورت خودکار انتخاب می‌شود. باز کردن لینک در مرورگر، صفحهٔ اشتراک و کانفیگ‌ها را نشان می‌دهد.</p>\r\n          <div class=\"unified-sub-preview\"><img src=\"/amyrax-assets/logo.svg\" width=\"60\" height=\"60\" alt=\"\"><div><strong dir=\"ltr\">Amyrax Panel</strong><p>آمار مصرف · راهنمای اپ‌ها · کپی تکی کانفیگ‌ها</p></div></div>\r\n          <label for=\"urlSubUniversal\" class=\"unified-link-label\">لینک اشتراک مشترک پنل</label>\r\n          <div class=\"sub-action-group\"><input type=\"text\" id=\"urlSubUniversal\" aria-label=\"لینک اشتراک واحد\" readonly><button type=\"button\" class=\"action-icon-button\" data-action=\"copy-input\" data-target=\"urlSubUniversal\" aria-label=\"کپی لینک\" title=\"کپی لینک\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/></svg></button><button type=\"button\" class=\"action-icon-button\" data-action=\"qr-input\" data-target=\"urlSubUniversal\" aria-label=\"کد QR اشتراک واحد\" title=\"نمایش کد QR\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z\"/></svg></button></div>\r\n          <div class=\"unified-clients\" dir=\"ltr\"><span>V2rayN / V2rayNG</span><span>FlClash</span><span>Streisand</span><span>SingBox</span><span>Shadowrocket</span></div>\r\n          <a id=\"openSubscriptionPage\" class=\"button primary\" target=\"_blank\" rel=\"noopener noreferrer\">باز کردن صفحهٔ اشتراک ↗</a>\r\n          <p class=\"subs-caption\">برای سهمیهٔ شخصی و نمایش حجم در اپ، لینک همان کاربر را از بخش <a href=\"#/users\">کاربران</a> کپی کنید. FlClash نوار حجم اشتراک نامحدود را نمایش نمی‌دهد.</p>\r\n          <p class=\"subs-caption unified-help\">لینک، دسترسی به کانفیگ‌ها را می‌دهد؛ آن را فقط با دریافت‌کنندهٔ موردنظر به اشتراک بگذارید. انتخاب دستی قالب نیز داخل صفحهٔ اشتراک در دسترس است.</p>\r\n        </section>\r\n      </div>\r\n\r\n      \r\n      <div id=\"viewStudio\" class=\"view-page\"><div id=\"studioRoot\"></div></div>\r\n      <div id=\"viewNodes\" class=\"view-page\">\r\n        <section class=\"nodes-container-card\">\r\n          <div class=\"section-top-row\">\r\n            <div class=\"section-title-wrap\">\r\n              <span class=\"red-bar-indicator\"></span>\r\n              <h2 class=\"section-heading\">کانفیگ‌های موجود</h2>\r\n            </div>\r\n            <div class=\"server-status-tag\">\r\n              <svg class=\"location-mini-svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\r\n                <path d=\"M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z\"></path>\r\n                <circle cx=\"12\" cy=\"10\" r=\"3\"></circle>\r\n              </svg>\r\n              <span id=\"nodesLocation\">در حال دریافت…</span>\r\n            </div>\r\n          </div>\r\n          <p class=\"subs-caption\">\r\n            لینک مستقیم هر کانفیگ را کپی کنید یا کد QR آن را در برنامهٔ خود اسکن کنید.\r\n          </p>\r\n\r\n          \r\n          <div id=\"nodesContainer\" class=\"nodes-grid\">\r\n            <div class=\"nodes-loading\">\r\n              <span class=\"spinner\"></span>\r\n              <span>در حال دریافت کانفیگ‌ها…</span>\r\n            </div>\r\n          </div>\r\n        </section>\r\n      </div>\r\n\r\n\r\n\r\n      <section id=\"viewUsers\" class=\"view-page\">\r\n        <div class=\"users-heading-actions\"><p class=\"muted\">کاربران مستقل؛ حجم و زمان صفر یعنی نامحدود.</p><div><button type=\"button\" id=\"restoreUsers\" class=\"button secondary\">بازیابی پشتیبان</button><a id=\"backupUsers\" class=\"button secondary\" download>پشتیبان کاربران</a><button type=\"button\" id=\"createUser\" class=\"button primary\">＋ ساخت کاربر</button></div></div>\r\n        <div class=\"users-counter-grid\"><div class=\"users-counter\"><span>کل کاربران</span><strong id=\"userTotal\">—</strong></div><div class=\"users-counter\"><span title=\"حساب دارای اعتبار؛ لزوماً متصل نیست\">حساب‌های معتبر</span><strong id=\"userActive\">—</strong></div><div class=\"users-counter\"><span>پایان حجم یا زمان</span><strong id=\"userLimited\">—</strong></div></div>\r\n        <p id=\"usersEngine\" class=\"users-service\" role=\"status\">در حال دریافت وضعیت…</p><p id=\"usersError\" class=\"users-error\" role=\"alert\" hidden></p>\r\n        <div class=\"users-toolbar\"><label class=\"users-search\"><span class=\"sr-only\">جست‌وجوی کاربر</span><input id=\"userSearch\" type=\"search\" placeholder=\"جست‌وجوی نام یا یادداشت…\" autocomplete=\"off\"></label><select data-panel-select id=\"userStatusFilter\" aria-label=\"فیلتر وضعیت کاربران\"><option value=\"all\">همهٔ کاربران</option><option value=\"active\">فعال</option><option value=\"pending\">در انتظار اولین اتصال</option><option value=\"disabled\">غیرفعال</option><option value=\"expired\">منقضی</option><option value=\"limited\">حجم تمام‌شده</option><option value=\"archived\">بایگانی</option></select><span id=\"usersResultCount\" class=\"users-result\"></span></div>\r\n        <div id=\"usersList\" class=\"users-list\"></div>\r\n      </section>\r\n    </main>\r\n    <footer class=\"footer\"><span dir=\"ltr\">Amyrax Panel <span class=\"muted\">/</span> v1.11.11</span><span>یک اتصال ساده، یک دنیای بدون مرز.</span><a href=\"https://t.me/AmyraxVPN\" target=\"_blank\" rel=\"noopener noreferrer\" dir=\"ltr\">@AmyraxVPN ↗</a></footer>\r\n  </div>\r\n  <nav class=\"mobile-nav-bar\" aria-label=\"ناوبری موبایل\"><a href=\"#/home\" class=\"mob-link active\" data-page=\"home\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 10.5 12 3l9 7.5M5 9v11h5v-6h4v6h5V9\"/></svg><span>نمای کلی</span></a>\r\n<a href=\"#/subs\" class=\"mob-link\" data-page=\"subs\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2\"/></svg><span>اشتراک‌ها</span></a>\r\n<a href=\"#/nodes\" class=\"mob-link\" data-page=\"nodes\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 4h16v5H4zM4 15h16v5H4zM8 6.5h.01M8 17.5h.01M12 9v6\"/></svg><span>کانفیگ‌ها</span></a>\r\n<a href=\"#/studio\" class=\"mob-link\" data-page=\"studio\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 7h16M4 17h16M8 4v6M16 14v6\"/></svg><span>شخصی‌سازی</span></a>\r\n<a href=\"#/users\" class=\"mob-link\" data-page=\"users\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" aria-hidden=\"true\"><circle cx=\"9\" cy=\"8\" r=\"3\"/><path d=\"M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6M18 14a5 5 0 0 1 3 4v3\"/></svg><span>کاربران</span></a>\r\n<a href=\"#/usage\" class=\"mob-link\" data-page=\"usage\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 19V5M4 19h16M8 15V9M13 15V5M18 15v-3\"/></svg><span>مصرف ترافیک</span></a></nav>\r\n    \r\n  <div id=\"qrModal\" class=\"cinema-modal-backdrop\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"qrModalTitle\">\r\n    <div class=\"cinema-modal-box\"><div class=\"cinema-modal-scroll\">\r\n      <div class=\"modal-top\">\r\n        <h3 id=\"qrModalTitle\">اسکن کد QR</h3>\r\n        <button type=\"button\" class=\"btn-close-modal\" id=\"qrCloseBtn\" aria-label=\"بستن کد QR\">&times;</button>\r\n      </div>\r\n      <div class=\"modal-center\">\r\n        <div id=\"qrcodeWrapper\"></div>\r\n        <p class=\"qr-notice\">با برنامهٔ VPN خود اسکن کنید.</p>\r\n      </div></div>\r\n    </div>\r\n  </div>\r\n\r\n\r\n\r\n  <dialog id=\"userDialog\" class=\"user-dialog\" aria-labelledby=\"userDialogTitle\">\r\n    <form id=\"userForm\"><div class=\"user-dialog-header\"><h2 id=\"userDialogTitle\">ساخت کاربر جدید</h2><button type=\"button\" class=\"icon-button\" data-close-user-dialog=\"userDialog\" aria-label=\"بستن فرم کاربر\">×</button></div>\r\n    <div class=\"user-form-grid\">\r\n      <label class=\"user-field\">نام کاربر<input id=\"user_name\" required maxlength=\"64\" autocomplete=\"off\" placeholder=\"مثلاً علی رضایی\"></label>\r\n      <label class=\"user-field\">حجم مجاز (GiB)<input id=\"user_limitGB\" type=\"number\" min=\"0\" max=\"1000000\" step=\"0.01\" value=\"0\" required><small>۰ = نامحدود؛ مجموع ارسال و دریافت همهٔ اتصال‌ها.</small></label>\r\n      <label class=\"user-field\">مدت اعتبار (روز)<input id=\"user_durationDays\" type=\"number\" min=\"0\" max=\"36500\" step=\"1\" value=\"0\" required><small>۰ = زمان نامحدود.</small></label>\r\n      <label class=\"user-field\">شروع اعتبار<select data-panel-select id=\"user_startMode\"><option value=\"now\">از زمان ساخت یا تغییر مدت</option><option value=\"first-use\">از اولین اتصال</option></select><small>باز کردن ساب، اعتبار «اولین اتصال» را شروع نمی‌کند.</small></label>\r\n      <label class=\"user-field\">بازنشانی خودکار حجم (روز)<input id=\"user_resetDays\" type=\"number\" min=\"0\" max=\"36500\" step=\"1\" value=\"0\" required><small>۰ = بدون بازنشانی خودکار. زمان اعتبار تمدید نمی‌شود.</small></label>\r\n      <label class=\"user-check\"><input id=\"user_enabled\" type=\"checkbox\" checked>کاربر فعال باشد</label>\r\n      <fieldset class=\"user-protocol-picker\"><legend>پروتکل‌های مجاز کاربر</legend><div><label class=\"user-check\"><input name=\"userProtocol\" type=\"checkbox\" value=\"vless\" checked>VLESS</label><label class=\"user-check\"><input name=\"userProtocol\" type=\"checkbox\" value=\"vmess\" checked>VMess</label><label class=\"user-check\"><input name=\"userProtocol\" type=\"checkbox\" value=\"trojan\" checked>Trojan</label><label class=\"user-check\"><input name=\"userProtocol\" type=\"checkbox\" value=\"shadowsocks\" checked>Shadowsocks</label></div></fieldset>\r\n      <label class=\"user-field full\">یادداشت خصوصی مدیر<textarea id=\"user_note\" maxlength=\"500\" placeholder=\"توضیحات یا مشخصات سفارش\"></textarea><small>در صفحهٔ اشتراک نمایش داده نمی‌شود.</small></label>\r\n    </div><p class=\"user-expiry\" id=\"userCurrentExpiry\"></p><p>تغییر مدت اعتبارِ شروع‌شده، زمان را از لحظهٔ ذخیره محاسبه می‌کند. برای افزودن روز به اعتبار باقی‌مانده، از «تمدید اعتبار» استفاده کنید.</p><p class=\"users-error\" id=\"userFormError\" role=\"alert\" hidden></p>\r\n    <div class=\"user-dialog-actions\"><button type=\"button\" class=\"button secondary\" data-close-user-dialog=\"userDialog\">انصراف</button><button id=\"saveUser\" type=\"submit\" class=\"button primary\">ذخیرهٔ کاربر</button></div></form>\r\n  </dialog>\r\n  <dialog id=\"userActionDialog\" class=\"user-dialog user-action-dialog\" aria-labelledby=\"userActionTitle\"><form id=\"userActionForm\"><div class=\"user-dialog-header\"><h2 id=\"userActionTitle\"></h2><button type=\"button\" class=\"icon-button\" data-close-user-dialog=\"userActionDialog\" aria-label=\"بستن عملیات کاربر\">×</button></div><p id=\"userActionDescription\"></p><label class=\"user-field\" id=\"userRenewField\" hidden>روزهای تمدید (۰ = نامحدود)<input id=\"userRenewDays\" type=\"number\" value=\"30\" min=\"0\" max=\"36500\" step=\"1\" required></label><p id=\"userActionError\" class=\"users-error\" role=\"alert\" hidden></p><div class=\"user-dialog-actions\"><button type=\"button\" class=\"button secondary\" data-close-user-dialog=\"userActionDialog\">انصراف</button><button id=\"confirmUserAction\" class=\"button primary\" type=\"submit\">اعمال تغییر</button></div></form></dialog>\r\n\r\n  <dialog id=\"userImportDialog\" class=\"user-dialog\" aria-labelledby=\"userImportTitle\"><form id=\"userImportForm\">\r\n    <div class=\"user-dialog-header\"><h2 id=\"userImportTitle\">بازیابی پشتیبان کاربران</h2><button type=\"button\" class=\"icon-button\" data-close-user-dialog=\"userImportDialog\" aria-label=\"بستن بازیابی\">×</button></div>\r\n    <p>کاربران فعلی حفظ می‌شوند. حساب‌ها یا کلیدهای تکراری رد می‌شوند و نام تکراریِ حساب جدید متمایز می‌شود. مصرف، زمان اعتبار و لینک حساب‌های جدید از فایل بازیابی می‌شوند.</p>\r\n    <label class=\"user-field\">فایل پشتیبان JSON<input id=\"userBackupFile\" type=\"file\" accept=\".json,application/json\"><small>پشتیبان Amyrax، حداکثر ۱۶ مگابایت.</small></label>\r\n    <button type=\"button\" id=\"previewUserImport\" class=\"button secondary\">بررسی فایل</button>\r\n    <div id=\"userImportPreview\" hidden><p id=\"userImportSummary\" role=\"status\"></p><ul id=\"userImportRows\" class=\"import-rows\"></ul></div>\r\n    <p id=\"userImportError\" class=\"users-error\" role=\"alert\" hidden></p>\r\n    <div class=\"user-dialog-actions\"><button type=\"button\" class=\"button secondary\" data-close-user-dialog=\"userImportDialog\">بستن</button><button id=\"confirmUserImport\" class=\"button primary\" type=\"submit\" disabled>افزودن کاربران جدید</button></div>\r\n  </form></dialog>\r\n\r\n  <dialog id=\"updateDialog\" class=\"update-dialog\" aria-labelledby=\"updateDialogTitle\" aria-describedby=\"updateDialogStatus\">\r\n    <div class=\"update-dialog-header\"><h2 id=\"updateDialogTitle\">به‌روزرسانی Amyrax</h2><button id=\"closeUpdateDialog\" type=\"button\" class=\"icon-button\" aria-label=\"بستن به‌روزرسانی\">×</button></div>\r\n    <div class=\"update-version-grid\"><div><small>نسخهٔ فعلی</small><strong id=\"updateCurrentVersion\" dir=\"ltr\">—</strong></div><div><small>آخرین نسخه</small><strong id=\"updateLatestVersion\" dir=\"ltr\">—</strong></div></div>\r\n    <p id=\"updateDialogStatus\" class=\"update-dialog-status\" role=\"status\" aria-live=\"polite\">در حال بررسی نسخه…</p>\r\n    <p class=\"update-data-note\">رمز، کاربران، لینک‌های اشتراک و کانفیگ‌های شخصی حفظ می‌شوند. نسخهٔ جدید ابتدا آماده می‌شود؛ اگر اجرا نشود، پنل به نسخهٔ قبلی برمی‌گردد.</p>\r\n    <div class=\"update-dialog-actions\"><button id=\"installUpdate\" type=\"button\" class=\"button primary\" disabled>به‌روزرسانی پنل</button><button id=\"checkUpdate\" type=\"button\" class=\"button secondary\">بررسی دوباره</button></div>\r\n    <div class=\"update-dialog-footer\"><span id=\"updateCheckedAt\"></span><a id=\"updateReleaseLink\" href=\"https://github.com/AmyraxVPN-Main/Amyrax-Panel/releases\" target=\"_blank\" rel=\"noopener noreferrer\">توضیحات نسخه ↗</a></div>\r\n  </dialog>\r\n  <div id=\"amyraxToast\" class=\"cinema-toast\" role=\"status\" aria-live=\"polite\"></div>\r\n  <script src=\"/amyrax-assets/vendor/qrcode.js\"></script>\r\n  <script src=\"/amyrax-assets/app.js\"></script>\r\n  <script src=\"/amyrax-assets/updates.js\"></script>\r\n  <script src=\"/amyrax-assets/controls.js\"></script>\r\n  <script src=\"/amyrax-assets/users.js\"></script>\r\n  <script src=\"/amyrax-assets/studio.js\"></script>\r\n</body>\r\n</html>\r\n",
  appCss: "\r\n@font-face{font-family:Vazir;src:url('/amyrax-assets/fonts/Vazir.woff2') format('woff2');font-weight:400;font-display:swap}\r\n@font-face{font-family:Vazir;src:url('/amyrax-assets/fonts/Vazir-Medium.woff2') format('woff2');font-weight:500 600;font-display:swap}\r\n@font-face{font-family:Vazir;src:url('/amyrax-assets/fonts/Vazir-Bold.woff2') format('woff2');font-weight:700 900;font-display:swap}\r\n@font-face{font-family:Plasma;src:url('/amyrax-assets/fonts/Plasma-Circle-Dots.ttf') format('truetype');font-weight:700;font-display:swap;unicode-range:U+0600-06FF,U+0750-077F,U+08A0-08FF,U+200C-200F,U+FB50-FDFF,U+FE70-FEFF}\r\n:root{color-scheme:dark;--bg-color:#0c111a;--sidebar:#090e15;--card-bg:#121a25;--card-bg-subtle:#161f2c;--field:#0e1621;--border:#25303e;--card-border:var(--border);--text-white:#eef3f8;--text-gray:#b5c0cf;--text-muted:#9ba9bc;--primary-red:#38c9ad;--primary-red-hover:#51dec2;--accent-green:#38c9ad;--accent-amber:#65d8c0;--accent-blue:#579df6;--tint:rgba(56,201,173,.1);--btn-secondary-bg:#17202d;--btn-secondary-border:var(--border);--font-family:Vazir,-apple-system,BlinkMacSystemFont,\"Segoe UI\",Arial,sans-serif;--ease:cubic-bezier(.2,.8,.2,1);--red-glow:0 4px 16px #29ad9514;--radius-xl:16px;--layout-width:1440px;--layout-gutter:32px;--layout-gap:16px}\r\n[data-theme=cozy]{--bg-color:#171411;--sidebar:#12100e;--card-bg:#211d18;--card-bg-subtle:#29231c;--field:#191510;--border:#3b3228;--text-white:#f7efe4;--text-gray:#c1b39f;--text-muted:#a19380;--primary-red:#dfb276;--primary-red-hover:#edc692;--accent-green:#dfb276;--accent-amber:#dfb276;--tint:rgba(223,178,118,.1);--btn-secondary-bg:#29231c}\r\n*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg-color);color:var(--text-white);font:400 14px/1.85 var(--font-family);-webkit-font-smoothing:antialiased}button,input,a{-webkit-tap-highlight-color:transparent}button,input{font:inherit}a{color:inherit;text-decoration:none}button{cursor:pointer}button:disabled{opacity:.45;cursor:wait}button,a,input{outline-offset:4px}button:focus-visible,a:focus-visible,input:focus-visible{outline:2px solid var(--primary-red)}svg{width:20px;height:20px;flex-shrink:0;vertical-align:middle}strong{font-weight:700}h1,h2,h3,h4,p{margin:0}h1,h2,h3{font-family:Vazir,sans-serif;font-weight:700;letter-spacing:0}input{max-width:100%;min-width:0;color:var(--text-white);background:var(--field);border:1px solid var(--border);border-radius:8px;padding:11px 13px}input:focus{border-color:var(--primary-red)}[hidden]{display:none!important}.muted{color:var(--text-muted);font-size:12px}.teal{color:var(--primary-red)}.blue{color:var(--accent-blue)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\r\n.sidebar{width:234px;position:fixed;inset-block:0;right:0;background:var(--sidebar);border-left:1px solid var(--border);display:flex;flex-direction:column;padding:28px 18px 18px;z-index:40}.brand{display:flex;align-items:center;gap:12px;padding:0 9px 30px;border-bottom:1px solid #ffffff08}.brand img{object-fit:contain}.brand strong{font-family:Arial,sans-serif;display:block;font-size:19px;letter-spacing:-.5px}.brand strong span{color:var(--primary-red);margin-left:4px}.brand small{font-size:12px;color:var(--text-muted);display:block;margin-top:4px}.sidebar-label{font-size:12px;color:var(--text-muted);margin:28px 14px 12px}.side-nav{display:grid;gap:7px}.side-link{display:flex;align-items:center;gap:12px;min-height:47px;padding:10px 13px;color:var(--text-gray);border:1px solid transparent;border-radius:9px;font-size:12px;transition:background .2s,color .2s}.side-link svg{width:19px;height:19px;color:var(--text-muted)}.side-link:hover{background:var(--card-bg-subtle);color:var(--text-white)}.side-link.active{color:var(--primary-red);border-color:#3cc9ad24;background:linear-gradient(90deg,#38c9ad06,#38c9ad14)}.side-link.active svg{color:var(--primary-red)}.side-link.active:after{content:\"\";height:6px;width:6px;border-radius:50%;background:var(--primary-red);margin-right:auto}.external-arrow{margin-right:auto;color:var(--text-muted)}.sidebar-bottom{margin-top:auto;padding-top:26px}.community-mini{display:grid;grid-template-columns:35px 1fr;column-gap:9px;padding:16px 13px;border-radius:12px;border:1px solid #35c9ac20;background:linear-gradient(140deg,#38c9ad0f,transparent)}.community-mini strong{font-size:12px;align-self:end}.community-mini small{color:var(--primary-red);font:11px/1.7 Arial;text-align:right}.mini-orbit{grid-row:span 2;display:grid;place-content:center;color:var(--primary-red)}.mini-orbit svg{width:25px;height:25px}.sidebar-build{display:flex;align-items:center;gap:7px;font:9px Arial;color:var(--text-muted);padding:21px 8px 2px}.version{margin-right:auto;font-size:12px}.status-dot{display:inline-block;width:6px;height:6px;background:var(--primary-red);border-radius:50%;flex-shrink:0;box-shadow:0 0 0 3px #38c9ad12}.workspace{margin-right:234px;min-height:100vh}.topbar{height:72px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 max(var(--layout-gutter),calc((100% - var(--layout-width))/2 + var(--layout-gutter)));background:var(--sidebar)}.breadcrumb{display:flex;align-items:center;gap:12px;font-size:12px}.breadcrumb>span{font-family:Arial;color:var(--text-muted);font-size:12px}.breadcrumb i{font-style:normal;color:#455162}.breadcrumb strong{font-weight:500}.top-actions{display:flex;align-items:center;gap:14px}.connection-state{display:flex;align-items:center;gap:8px;color:var(--primary-red);font-size:12px}.connection-state.offline{color:#f0a979}.connection-state.offline .status-dot{background:#f0a979}.top-divider{height:20px;width:1px;background:var(--border)}.icon-button{border:1px solid var(--border);background:transparent;border-radius:9px;color:var(--text-gray);width:35px;height:35px;display:grid;place-items:center}.icon-button:hover{color:var(--primary-red);background:var(--tint)}.icon-button svg{width:16px;height:16px}.avatar{height:33px;width:33px;display:grid;place-items:center;background:var(--tint);color:var(--primary-red);border:1px solid #38c9ad29;border-radius:50%;font:bold 13px Arial}.menu-toggle{display:none}.main-content{width:100%;max-width:var(--layout-width);margin:auto;padding:28px var(--layout-gutter) 20px}.page-heading{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}.eyebrow{font:9px Arial;letter-spacing:1.9px;color:var(--primary-red);text-align:right;margin-bottom:9px}.page-heading h1{font-size:30px;line-height:1.5}.page-heading p{color:var(--text-muted);font-size:12px;margin-top:7px}.button{display:inline-flex;align-items:center;justify-content:center;gap:9px;border:1px solid var(--border);border-radius:8px;padding:10px 15px;font-size:12px;transition:background .18s,transform .18s}.button:hover{transform:translateY(-1px)}.button svg{height:16px;width:16px}.secondary{background:var(--btn-secondary-bg);color:var(--text-gray)}.primary{background:var(--primary-red);border-color:var(--primary-red);color:#071b18;font-weight:700}.primary:hover{background:var(--primary-red-hover)}.wide{display:flex;width:100%;min-height:41px}.wide>span:last-child{margin-right:auto}.wide svg{margin-left:3px}.view-page{display:none}.view-page.active{display:block;animation:appear .2s ease-out}.overview-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:var(--layout-gap);align-items:stretch}.panel{border:1px solid var(--border);border-radius:14px;background:var(--card-bg);min-width:0;padding:20px}.card-heading{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:20px}.card-heading h2{font-size:17px;line-height:1.5;font-weight:700}.chip{display:inline-flex;align-items:center;gap:6px;border-radius:5px;color:var(--primary-red);font-size:12px;padding:2px 7px;background:var(--tint);border:1px solid #3cc9ad16}.chip.neutral{color:var(--text-gray);background:var(--field);border-color:var(--border);font:10px Arial;padding:4px 7px}.server-identity{display:flex;align-items:center;gap:12px;margin-bottom:20px}.server-symbol{height:43px;width:43px;display:grid;place-items:center;border:1px solid #38c9ad29;border-radius:11px;background:#38c9ad09;color:var(--primary-red)}.server-symbol svg{width:24px;height:24px}.server-identity strong{font:600 15px Arial;display:block}.server-identity div>span{display:block;color:var(--text-muted);font:10px Arial;margin-top:8px;max-width:165px;overflow:hidden;text-overflow:ellipsis}.tiny-indicator{margin-right:auto;width:6px;height:6px;border-radius:50%;background:var(--text-muted)}.detail-list{margin:0}.detail-list>div{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-top:1px solid #ffffff07}.detail-list dt{color:var(--text-muted);font-size:12px;display:flex;align-items:center;gap:7px;white-space:nowrap}.detail-list dt svg{width:13px;height:13px}.detail-list dd{margin:0;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:55%}.speed-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.metric-caption{display:block;color:var(--text-muted);font-size:12px}.metric-caption>span{font:17px Arial;margin-left:5px}.speed-value{display:block;text-align:right;font:600 24px/1.5 Arial;margin-top:6px;letter-spacing:-.8px}.traffic-chart{height:92px;margin-top:18px;position:relative;direction:ltr}.traffic-chart>svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}.chart-grid{position:absolute;inset:0;background:repeating-linear-gradient(to bottom,transparent,transparent 29px,#ffffff07 30px,#ffffff07 31px)}#chartEmpty{position:absolute;inset:0;display:grid;place-content:center;font-size:12px;color:var(--text-muted)}.chart-axis{display:flex;justify-content:space-between;color:var(--text-muted);font-size:12px;margin-top:5px;direction:ltr}.transfer-totals{border-top:1px solid var(--border);margin-top:19px;padding-top:13px;display:grid;grid-template-columns:1fr 1fr;gap:14px}.transfer-totals span{display:block;color:var(--text-muted);font-size:12px}.transfer-totals strong{display:block;font:600 15px Arial;margin-top:7px;text-align:right}.memory-display{display:flex;align-items:center;gap:18px;margin:23px 0}.memory-ring{--pct:0;flex-shrink:0;width:94px;height:94px;border-radius:50%;background:conic-gradient(var(--primary-red) calc(var(--pct)*1%),#2b3542 0);padding:5px;direction:ltr;transform:rotate(-90deg)}.memory-ring>div{width:100%;height:100%;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--card-bg);transform:rotate(90deg)}.memory-ring strong{font:600 20px Arial}.memory-ring small{font:9px Arial;letter-spacing:1px;color:var(--text-muted);margin-top:5px}.memory-text>span{font-size:12px;color:var(--text-muted)}.memory-text strong{font:600 19px Arial;display:block;margin:8px 0 5px;text-align:right}.memory-text small{font:10px Arial;display:block;color:var(--text-muted);text-align:right}.resource-detail{display:flex;justify-content:space-between;gap:10px;font-size:12px;padding:8px 0;border-top:1px solid #ffffff07;color:var(--text-muted)}.resource-detail strong{color:var(--text-gray);font-weight:500}.resource-note{font-size:12px;color:var(--text-muted);line-height:1.8;margin-top:7px}.engine-list{display:grid;gap:15px}.engine-item{display:flex;align-items:center;gap:11px}.engine-icon{width:34px;height:34px;background:#38c9ad0b;border:1px solid #38c9ad19;color:var(--primary-red);border-radius:8px;display:grid;place-content:center;font:600 14px Arial}.engine-icon.violet{color:#b393fa;background:#b393fa0a;border-color:#b393fa21}.engine-icon.amber{color:#e4b46c;background:#e4b46c0a;border-color:#e4b46c21}.engine-item strong{font:500 12px Arial;display:block}.engine-item small{color:var(--text-muted);font-size:12px;display:block;margin-top:3px}.engine-status{font-size:12px;color:#9aa5b3;margin-right:auto;padding:2px 7px;border-radius:4px;background:#ffffff04;border:1px solid #ffffff08}.engine-status.running{color:var(--primary-red);background:var(--tint);border-color:#38c9ad20}.text-link{color:var(--primary-red);font-size:12px}.summary-counters{display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px;padding:5px 0 17px}.summary-counters>div{background:var(--card-bg-subtle);border:1px solid var(--border);border-radius:9px;display:flex;flex-direction:column;align-items:center;text-align:center;padding:15px 3px}.summary-counters svg{color:var(--primary-red);width:19px;height:19px;margin-bottom:10px}.summary-counters>div:nth-child(2) svg{color:var(--accent-blue)}.summary-counters>div:nth-child(3) svg{color:#b393fa}.summary-counters strong{font:600 23px Arial;letter-spacing:-.5px;line-height:1.4}.summary-counters>div:nth-child(3) strong{font-size:18px;padding:4px 0}.summary-counters span{color:var(--text-muted);font-size:12px;margin-top:6px;white-space:nowrap}.summary-note{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text-muted);padding-top:6px}.quick-card p{font-size:12px;color:var(--text-muted);line-height:2;margin-bottom:18px}.step-number{font:9px Arial;color:var(--text-muted)}.quick-card .button+.button{margin-top:9px}.protocols-card{grid-column:1/-1;padding-bottom:13px}.protocols-card .card-heading{margin-bottom:16px}.protocol-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.protocol-item{display:flex;align-items:center;gap:9px;min-height:46px;border:1px solid var(--border);border-radius:8px;padding:9px 12px;background:var(--field);direction:ltr;font:600 11px Arial}.protocol-item>span:last-child{font:9px Vazir;color:var(--text-muted);margin-left:auto}.protocol-note{font-size:12px;color:var(--text-muted);margin-top:13px}.telegram-banner{grid-column:1/-1;display:flex;align-items:center;gap:15px;padding:18px 23px;border:1px solid #38c9ad24;border-radius:13px;background:linear-gradient(105deg,#38c9ad03,#38c9ad0e);position:relative;overflow:hidden}.telegram-art{height:43px;width:43px;display:grid;place-items:center;border-radius:12px;color:var(--primary-red);background:var(--tint);border:1px solid #38c9ad21}.telegram-art svg{width:23px;height:23px}.telegram-banner strong{font-family:Vazir,sans-serif;font-size:17px;display:block}.telegram-banner div>span{color:var(--text-muted);font-size:12px;display:block;margin-top:5px}.telegram-handle{margin-right:auto;color:var(--primary-red);font:600 12px Arial;display:flex;align-items:center;gap:9px}.telegram-handle svg{width:15px;height:15px}.footer{display:flex;justify-content:space-between;gap:15px;color:var(--text-muted);font-size:12px;padding:16px var(--layout-gutter) 24px;max-width:var(--layout-width);margin:auto}.footer a{color:var(--text-muted)}.footer>span:first-child{font:10px Arial}\r\n\r\n.subs-container-card,.nodes-container-card{background:var(--card-bg);border:1px solid var(--border);padding:20px;border-radius:14px}.section-top-row,.section-title-wrap{display:flex;align-items:center;gap:12px}.section-top-row{justify-content:space-between;flex-wrap:wrap;margin-bottom:16px}.section-title-wrap{min-width:0}.section-heading{font-size:20px}.red-bar-indicator{width:3px;height:17px;border-radius:3px;background:var(--primary-red)}.server-status-tag{display:flex;align-items:center;gap:8px;color:var(--primary-red);font-size:12px;direction:ltr}.server-status-tag svg{width:15px;height:15px}.subs-caption{font-size:12px;color:var(--text-muted);margin-bottom:23px;line-height:2}.proto-selector-wrap{display:flex;gap:18px;align-items:center;flex-wrap:wrap;background:var(--field);padding:14px 17px;border-radius:10px;border:1px solid var(--border);margin-bottom:18px}.proto-label{font-size:12px;color:var(--text-muted)}.proto-toggle-group{display:flex;gap:6px;direction:ltr}.proto-btn{border:1px solid var(--border);border-radius:7px;padding:8px 13px;font-size:12px;color:var(--text-muted);background:transparent}.proto-btn.active{background:var(--tint);color:var(--primary-red);border-color:#38c9ad40}.v2rayng-notice-banner{display:flex;align-items:center;gap:12px;color:var(--text-gray);background:#579df60a;border:1px solid #579df622;border-radius:9px;padding:14px;font-size:12px;line-height:2;margin-bottom:22px}.notice-icon{color:var(--accent-blue)}.server-metrics-strip{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--border);border-radius:10px;padding:15px 10px;margin-bottom:24px;gap:10px}.metric-box{display:flex;flex-direction:column;text-align:center;gap:6px;min-width:0}.metric-label{font-size:12px;color:var(--text-muted)}.metric-val{font-size:12px;direction:ltr;word-break:break-word}.sub-items-list{display:grid;gap:14px}.sub-row-card{padding:17px;border:1px solid var(--border);border-radius:10px;background:var(--field)}.sub-meta-header{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:13px;direction:ltr}.sub-client-name{font:500 12px Arial}.sub-meta-header>span{font-size:12px;color:var(--primary-red)}.sub-compat-badge{margin-left:auto;color:var(--text-muted)!important;font:10px Arial}.sub-action-group{display:flex;gap:8px;direction:ltr}.sub-action-group input{flex:1;font:11px Consolas,monospace;min-width:0;background:var(--card-bg-subtle)}.btn-copy,.btn-qr,.btn-download,.btn-node-copy,.btn-node-qr,.btn-node-dl,.usage-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--border);border-radius:7px;font-size:12px;padding:9px 13px;background:var(--card-bg-subtle);color:var(--text-gray);white-space:nowrap}.btn-copy,.btn-node-copy{background:var(--tint);color:var(--primary-red);border-color:#38c9ad25}.btn-copy:hover,.btn-node-copy:hover{background:#38c9ad20}.nodes-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.node-item-card{min-width:0;border:1px solid var(--border);background:var(--field);border-radius:11px;padding:18px}.node-card-header{display:flex;justify-content:space-between;gap:8px;align-items:flex-start;direction:ltr}.node-card-title-group{min-width:0}.proto-badge{font:bold 10px Arial;display:inline-block;border-radius:4px;color:var(--primary-red);background:var(--tint);padding:5px 7px}.badge-proto-vmess{color:#b99af8;background:#b99af80d}.badge-proto-trojan{color:#e8ae7d;background:#e8ae7d0d}.node-remark-title{font:500 12px/1.7 Arial;margin-top:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.node-badges-group{display:flex;gap:5px}.node-badge-tag{font:9px Arial;color:var(--text-muted);border:1px solid var(--border);border-radius:4px;padding:4px 5px}.node-card-meta{color:var(--text-muted);font-size:12px;margin:12px 0;display:grid;gap:5px}.node-location-tag{display:flex;align-items:center;gap:5px}.loc-icon{width:13px;height:13px}.node-uri-input{width:100%;font:11px/1.6 Consolas,monospace;direction:ltr;padding:10px;background:var(--card-bg)}.node-actions-row{display:flex;gap:8px;margin-top:13px}.btn-action-svg{width:13px;height:13px}.no-nodes-msg,.nodes-loading{grid-column:1/-1;color:var(--text-muted);text-align:center;padding:40px 10px}.usage-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px;margin:23px 0}.usage-card{padding:20px;border:1px solid var(--border);border-radius:10px;background:var(--field)}.usage-card-label{font-size:12px;color:var(--text-muted)}.usage-card-total{font:600 28px Arial;direction:ltr;text-align:right;margin:13px 0;color:var(--primary-red)}.usage-card-split{display:flex;gap:17px;color:var(--text-muted);font:10px Arial;direction:ltr;justify-content:flex-end}.usage-table-wrap{width:100%;overflow:auto;border:1px solid var(--border);border-radius:10px}.usage-table{border-collapse:collapse;width:100%;white-space:nowrap;font-size:12px}.usage-table td,.usage-table th{padding:13px 15px;text-align:right;border-bottom:1px solid var(--border)}.usage-table th{font-weight:500;color:var(--text-muted);background:var(--field)}.usage-table td{direction:ltr}.usage-table tfoot{color:var(--primary-red)}.usage-dot{width:6px;height:6px;display:inline-block;border-radius:50%;margin-left:8px}.usage-pill{font:10px Arial;color:var(--text-muted)}.usage-pill.on{color:var(--primary-red)}.usage-note{font-size:12px;color:var(--text-muted);line-height:2;margin-top:23px}.usage-fa{font-family:Vazir,sans-serif;margin-top:7px}.usage-actions{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:15px;margin-top:20px}.usage-sync{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text-muted);flex-wrap:wrap}.usage-sync input{width:120px;direction:ltr;padding:8px}.usage-btn-soft{color:#e9ad87}.usage-foot-meta{font-size:12px;color:var(--text-muted);margin-top:16px;overflow-wrap:anywhere}.usage-limit{margin-top:18px;border:1px solid var(--border);border-radius:9px;padding:15px}.usage-limit-top{display:flex;justify-content:space-between;font-size:12px}.usage-bar{height:6px;background:var(--field);border-radius:8px;margin:12px 0;overflow:hidden;direction:ltr}.usage-bar-fill{height:100%;background:var(--primary-red)}.usage-limit-msg{font-size:12px;color:var(--text-muted)}.usage-limit.is-warn{border-color:#dfb276}.usage-limit.is-over{border-color:#ec6a7c}.usage-nav-dot{width:5px;height:5px;display:inline-block;border-radius:50%;background:#dfb276;margin-right:7px}.usage-nav-dot.over{background:#ec6a7c}\r\n.cinema-modal-backdrop{display:none;position:fixed;inset:0;background:#020711cc;backdrop-filter:blur(5px);z-index:100;align-items:center;justify-content:center;padding:20px}.cinema-modal-backdrop.active{display:flex}.cinema-modal-box{background:var(--card-bg);border:1px solid var(--border);border-radius:15px;padding:24px;width:380px;max-width:100%}.modal-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;gap:15px}.modal-top h3{font-size:15px}.btn-close-modal{background:none;color:var(--text-gray);border:0;font-size:27px}.modal-center{text-align:center}#qrcodeWrapper{background:#fff;padding:16px;border-radius:10px;display:inline-block}#qrcodeWrapper img{max-width:100%;height:auto;display:block}.qr-notice{font-size:12px;color:var(--text-muted);margin-top:15px}.cinema-toast{position:fixed;bottom:28px;left:50%;transform:translate(-50%,15px);opacity:0;pointer-events:none;background:var(--card-bg-subtle);border:1px solid #38c9ad44;padding:12px 22px;border-radius:10px;font-size:12px;z-index:200;transition:.2s;max-width:90%;text-align:center;box-shadow:0 10px 45px #0007}.cinema-toast.show{transform:translate(-50%,0);opacity:1}.mobile-nav-bar,.drawer-scrim{display:none}.spinner{display:inline-block;width:14px;height:14px;border:2px solid var(--border);border-top-color:var(--primary-red);border-radius:50%;animation:spin 1s linear infinite;margin-left:8px}.busy svg{animation:spin 1s linear infinite}\r\n.unified-sub-card{width:100%}.unified-sub-preview{display:flex;align-items:center;gap:19px;margin:20px 0;padding:20px;border:1px solid var(--border);border-radius:16px;background:linear-gradient(110deg,#38c9ad09,#2e74cd07)}.unified-sub-preview strong{display:block;text-align:right;font:700 24px Arial;color:var(--text-white)}.unified-sub-preview p{font-size:12px;color:var(--text-muted);margin-top:10px}.unified-link-label{display:block;margin:20px 0 8px;font-size:12px;color:var(--text-muted)}.unified-clients{display:flex;flex-wrap:wrap;gap:8px;margin:17px 0 25px;justify-content:flex-end}.unified-clients span{border:1px solid var(--border);border-radius:8px;padding:5px 9px;color:var(--text-gray);font:12px Arial}.unified-help{margin-top:18px}.unified-sub-card .sub-action-group input{min-width:0}#qrcodeWrapper svg{display:block;width:240px;max-width:100%;height:auto;stroke:none;fill:#000}\r\n\r\n.auth-body{min-height:100vh;display:grid;place-items:center;padding:35px 24px;background:radial-gradient(ellipse at 30% 10%,#38c9ad0a,transparent 60%),var(--bg-color)}.auth-layout{width:900px;max-width:100%;display:grid;grid-template-columns:1fr 1fr;border:1px solid var(--border);border-radius:22px;background:var(--card-bg);overflow:hidden;box-shadow:0 25px 100px #0003}.auth-brand{background:linear-gradient(140deg,#38c9ad0b,transparent),var(--sidebar);padding:50px 38px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;border-left:1px solid var(--border)}.auth-brand img{width:158px;height:158px;margin-bottom:24px}.auth-brand h2{font:600 27px Arial;letter-spacing:-1px}.auth-brand h2 span{color:var(--primary-red)}.auth-brand p{font-size:12px;color:var(--text-muted);margin-top:13px}.auth-brand a{margin-top:35px;font:12px Arial;color:var(--primary-red)}.auth-form{padding:48px 37px}.auth-eyebrow{color:var(--primary-red);font-size:12px;margin-bottom:9px}.auth-form h1{font-size:26px}.auth-sub{font-size:12px;color:var(--text-muted);margin:12px 0 28px;line-height:2}.auth-field{display:block;margin-top:17px}.auth-field>span{font-size:12px;display:block;margin-bottom:7px;color:var(--text-gray)}.auth-field input{width:100%;height:46px;direction:ltr}.auth-field input::placeholder{font-size:12px;color:var(--text-muted)}.auth-form .primary{margin-top:24px;width:100%;min-height:44px}.auth-foot{margin-top:20px;font-size:12px;color:var(--text-muted);text-align:center}.auth-alert{font-size:12px;padding:11px;color:#f4b6a6;background:#ec6a7c0c;border:1px solid #ec6a7c35;border-radius:8px}.auth-bottom{font-size:12px;color:var(--text-muted);text-align:center;margin-top:20px}.auth-form .auth-show{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--text-muted);margin-top:12px}.auth-show input{accent-color:var(--primary-red)}\r\n@keyframes spin{to{transform:rotate(360deg)}}@keyframes appear{from{opacity:.5;transform:translateY(4px)}to{opacity:1;transform:none}}\r\n@media(min-width:1550px){.traffic-chart{height:110px}.summary-counters>div{padding:21px 3px}.sidebar{width:248px}.workspace{margin-right:248px}}\r\n@media(max-width:1200px){.sidebar{width:204px;padding-inline:12px}.brand{gap:9px;padding-inline:5px}.brand strong{font-size:17px}.workspace{margin-right:204px}:root{--layout-gutter:24px}.overview-grid{grid-template-columns:1fr 1fr}.resources-card{grid-column:1;grid-row:2}.engines-card{grid-column:2;grid-row:2}.summary-card,.quick-card{grid-row:3}.protocol-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.community-mini{padding:13px 8px}.community-mini strong{font-size:12px}.summary-counters>div{padding:18px 3px}.footer>span:nth-child(2){display:none}}\r\n@media(max-width:850px){.sidebar{transform:translateX(100%);transition:transform .22s ease;width:234px;box-shadow:-20px 0 70px #0006}.sidebar.open{transform:none}.workspace{margin-right:0}.menu-toggle{display:grid}.drawer-scrim.open{display:block;position:fixed;inset:0;background:#0008;border:0;z-index:35}.topbar{height:64px}.mobile-nav-bar{position:fixed;bottom:0;right:0;left:0;background:var(--sidebar);border-top:1px solid var(--border);z-index:30;display:grid;grid-template-columns:repeat(4,1fr);padding:9px 15px calc(9px + env(safe-area-inset-bottom))}.mob-link{display:flex;flex-direction:column;align-items:center;gap:4px;color:var(--text-muted);font-size:12px;min-height:43px;justify-content:center}.mob-link svg{width:18px;height:18px}.mob-link.active{color:var(--primary-red)}.footer{padding-bottom:90px}.cinema-toast{bottom:85px}.protocol-grid{grid-template-columns:repeat(2,minmax(0,1fr))}:root{--layout-gutter:20px}.page-heading{margin-bottom:23px}.page-heading h1{font-size:25px}.auth-layout{width:730px}.auth-form{padding:38px 28px}.auth-brand{padding:38px 28px}}\r\n@media(max-width:560px){:root{--layout-gutter:16px;--layout-gap:16px}.main-content{padding-top:24px}.top-actions{gap:9px}.connection-state{font-size:12px}.top-divider,.avatar{display:none}.breadcrumb{gap:8px}.page-heading{align-items:flex-start;gap:10px}.page-heading h1{font-size:24px}.page-heading p{font-size:12px;max-width:235px;line-height:1.9}.eyebrow{font-size:12px;letter-spacing:1.2px}.page-heading>.button{font-size:0;padding:10px;margin-top:20px}.page-heading>.button svg{width:16px}.page-heading>.button>span{display:none}.overview-grid{display:flex;flex-direction:column;gap:var(--layout-gap)}.panel{padding:16px}.card-heading h2{font-size:17px}.card-heading{margin-bottom:20px}.speed-value{font-size:27px}.traffic-chart{height:105px}.memory-display{justify-content:center;gap:28px}.protocol-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.protocol-item{padding:10px 8px;font-size:12px;gap:7px}.telegram-banner{padding:17px;gap:12px;flex-wrap:wrap}.telegram-banner strong{font-size:16px}.telegram-banner div>span{font-size:12px}.telegram-handle{padding-right:55px;margin-right:0;font-size:12px}.footer{flex-wrap:wrap;gap:8px;font-size:12px}.footer>span:first-child{font-size:12px}.subs-container-card,.nodes-container-card{padding:16px}.section-heading{font-size:17px}.server-status-tag{font-size:12px}.section-top-row{gap:8px}.subs-caption{font-size:12px}.proto-selector-wrap{padding:12px;gap:10px}.proto-toggle-group{width:100%}.proto-btn{flex:1;font-size:12px;padding:9px 5px}.v2rayng-notice-banner{font-size:12px;padding:12px}.server-metrics-strip{grid-template-columns:1fr 1fr;gap:15px}.sub-row-card{padding:13px}.sub-action-group{flex-wrap:wrap}.sub-action-group input{flex:1 0 100%}.sub-action-group button,.sub-action-group a{flex:1;min-height:39px}.sub-meta-header{gap:7px}.sub-client-name{font-size:12px}.sub-compat-badge{width:100%;margin:0}.nodes-grid{grid-template-columns:1fr}.node-item-card{padding:15px}.usage-cards{grid-template-columns:1fr;gap:10px}.usage-card{padding:17px}.usage-card-total{font-size:26px}.usage-actions{align-items:stretch}.usage-sync>span{width:100%}.usage-sync input{flex:1}.usage-actions>.usage-btn{width:100%}.auth-layout{grid-template-columns:1fr;width:430px}.auth-brand{border-left:0;border-bottom:1px solid var(--border);padding:28px}.auth-brand img{width:78px;height:78px;margin-bottom:15px}.auth-brand h2{font-size:23px}.auth-brand p{font-size:12px;margin-top:9px}.auth-brand a{margin-top:15px;font-size:12px}.auth-form{padding:28px}.auth-form h1{font-size:24px}.auth-sub{margin-bottom:21px}.auth-body{padding:22px 16px}.top-actions .icon-button{width:32px;height:32px}}\r\n@media(prefers-reduced-motion:reduce){*,*:before,*:after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}\r\n\r\n.protocol-item strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\r\n\r\n\r\n.row-actions{display:inline-flex;align-items:center;gap:8px;flex-shrink:0}\r\n.action-icon-button{display:inline-flex;align-items:center;justify-content:center;flex:0 0 44px;width:44px;height:44px;min-height:44px;padding:0;border:1px solid #3b3c3f;border-radius:12px;background:linear-gradient(145deg,#2e2f32,#2d3034);color:#fff;cursor:pointer;line-height:0;appearance:none;-webkit-appearance:none;transition:background .15s,transform .12s}\r\n.action-icon-button svg{display:block;width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}\r\n.action-icon-button:hover{background:#383a3e}\r\n.action-icon-button:active{transform:scale(.94);background:#404247}\r\n.action-icon-button:disabled{opacity:.45;cursor:default}\r\n\r\n.sub-action-group .action-icon-button{flex:0 0 44px}\r\n\r\n\r\n.view-page,.workspace,.usage-sync{min-width:0}\r\n.nodes-grid{grid-template-columns:repeat(auto-fit,minmax(min(100%,310px),1fr))}\r\n.node-item-card{display:flex;flex-direction:column}.node-actions-row{margin-top:auto;padding-top:12px}.node-actions-row>*{min-height:44px;flex:1}\r\n.button.danger{background:#ed8e7014;border-color:#ed8e7060;color:#ffb8a9}.button.danger:hover{background:#ed8e7026}\r\n.badge-recommended{font-size:11px;color:var(--primary-red);background:var(--tint);border:1px solid #38c9ad30;border-radius:8px;padding:4px 10px}\r\n.unified-sub-card .subs-caption:last-child{margin-bottom:0}.unified-sub-card #openSubscriptionPage{margin-bottom:16px}\r\n.unified-sub-preview>div{min-width:0}.unified-sub-preview img{flex-shrink:0}\r\n.usage-cards{gap:var(--layout-gap)}.usage-actions .usage-btn{min-height:44px}\r\n@media(max-width:560px){.unified-sub-preview{gap:12px;padding:16px}.unified-sub-preview img{width:44px;height:44px}.unified-sub-preview strong{font-size:21px}.usage-sync{width:100%}.topbar{gap:12px}.connection-state{font-size:11px}.top-actions{flex-shrink:0}.section-title-wrap{gap:8px}.cinema-modal-box{max-height:calc(100dvh - 40px);overflow:auto}}\r\n\r\n.cinema-modal-box{padding:8px;overflow:hidden;max-height:calc(100dvh - 40px)}\r\n.cinema-modal-scroll{padding:16px;max-height:calc(100dvh - 58px)}\r\n\r\n\r\n.server-identity span,.detail-list dd{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}.detail-list dd{max-width:60%}.resource-detail{gap:12px}.resource-detail strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}.summary-counters small{font-size:10px}.resources-card .memory-text{min-width:0}.memory-text strong{font-size:clamp(18px,2vw,24px)}\r\n\n.network-card{grid-column:1/-1;min-width:0}.network-card p{color:var(--text-muted);font-size:13px;line-height:1.9;margin:0 0 10px}.network-endpoint{overflow-wrap:anywhere;text-align:left}.network-card ul{margin:12px 0;padding-inline-start:20px;display:grid;gap:8px;font-size:12px;line-height:1.9}.network-card li[data-state=error]{color:#f29292}.network-card li[data-state=warning]{color:#e1ba7b}.network-card li[data-state=ok]{color:var(--accent-green)}.network-actions{display:flex;align-items:center;gap:16px;flex-wrap:wrap}.network-actions small{flex:1 1 240px;color:var(--text-muted);font-size:11px;line-height:1.9}\n",
  usersJs: "(() => {\n  const $=id=>document.getElementById(id), base='/' + (location.pathname.split('/').filter(Boolean)[0] || 'amyrax') + '/api/users';\n  const statuses={active:'فعال',pending:'در انتظار اولین اتصال',disabled:'غیرفعال',expired:'منقضی',limited:'حجم تمام‌شده',archived:'بایگانی'};\n  const fa=new Intl.NumberFormat('fa-IR');let users=[],editing=null,busy=false,currentAction=null;\n  const node=(tag,cls,value)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=value;return e;};\n  const bytes=n=>amyraxBytes(n);\n  const date=n=>n?new Date(n).toLocaleString('fa-IR',{dateStyle:'medium',timeStyle:'short'}):'—';\n  async function api(path='',method='GET',body){\n    const data=await amyraxRequestJson(base+path,{method,headers:method==='GET'?{}:{'Content-Type':'application/json','X-Amyrax-Req':'1'},...(body?{body:JSON.stringify(body)}:{})});\n    if(!data.ok)throw new Error(data.error||'دریافت اطلاعات ناموفق بود.');return data;\n  }\n  function render(){\n    const shown=users.filter(u=>{\n      const q=$('userSearch').value.trim().toLowerCase(),filter=$('userStatusFilter').value;\n      return (u.name.toLowerCase().includes(q)||u.note.toLowerCase().includes(q))&&(filter==='all'?u.status!=='archived':u.status===filter);\n    });\n    $('userTotal').textContent=fa.format(users.filter(u=>!u.archivedAt).length);\n    $('userActive').textContent=fa.format(users.filter(u=>['active','pending'].includes(u.status)).length);\n    $('userLimited').textContent=fa.format(users.filter(u=>['expired','limited'].includes(u.status)).length);\n    AmyraxControls.close();\n    $('usersList').replaceChildren();\n    for(const u of shown){\n      const card=node('article','user-card');const head=node('div','user-card-head');const name=node('div','user-name');\n      const identity=node('div','user-identity-meta');identity.append(node('span','user-status user-status-'+u.status,statuses[u.status]),node('small','',date(u.createdAt)));name.append(node('h3','',u.name),identity);\n      const headActions=node('div','user-head-actions');\n      head.append(name,headActions);card.append(head);\n      if(u.note)card.append(node('p','user-note',u.note));\n      const metrics=node('dl','user-metrics');\n      for(const [label,value] of [['مصرف / حجم',bytes(u.usedBytes)+' / '+(u.limitGB?fa.format(u.limitGB)+' GiB':'نامحدود')],['پایان اعتبار',u.expiresAt?date(u.expiresAt):u.durationDays?'پس از اولین اتصال':'نامحدود']]){const m=node('div');m.append(node('dt','',label),node('dd','',value));metrics.append(m);}card.append(metrics);\n      const progress=node('div','user-progress');progress.setAttribute('aria-label','مصرف سهمیه');const fill=node('span');fill.style.width=(u.limitBytes?Math.min(100,u.usedBytes/u.limitBytes*100):0)+'%';progress.append(fill);card.append(progress);\n      const meta=node('div','user-card-meta'),protocols=node('div','user-protocols');u.protocols.forEach(p=>protocols.append(node('span','',p.toUpperCase())));meta.append(protocols,node('span','user-connections',fa.format(u.activeConnections)+' اتصال باز'));card.append(meta);\n      const buttons=node('div','user-card-buttons');\n      const button=(label,action)=>{const b=node('button','button secondary',label);b.type='button';b.addEventListener('click',action);return b;};\n      buttons.append(button('ویرایش',()=>openEditor(u)),button('کپی ساب',()=>copyTextToClipboard(u.subscriptionUrl)),button('QR',()=>openQr(u.subscriptionUrl,u.name)));\n      const link=node('a','button secondary','صفحهٔ اشتراک ↗');link.href=u.subscriptionUrl;link.target='_blank';link.rel='noopener noreferrer';buttons.append(link);card.append(buttons);\n      const actions=AmyraxControls.menu({label:'عملیات بیشتر',ariaLabel:'عملیات '+u.name,className:'user-actions',\n        options:()=>[['toggle',u.enabled?'غیرفعال کردن':'فعال کردن'],['renew','تمدید اعتبار'],['reset','بازنشانی مصرف'],['disconnect','قطع اتصال‌های فعلی'],['rotate-link','تعویض لینک ساب'],['rotate-credentials','تعویض مشخصات اتصال'],[u.archivedAt?'restore':'archive',u.archivedAt?'بازیابی کاربر':'بایگانی کاربر'],['delete','حذف دائمی کاربر']].map(([value,label])=>({value,label,danger:value==='delete'})),\n        onSelect:action=>openAction(u,action)});\n      headActions.append(actions);$('usersList').append(card);\n    }\n    if(!shown.length)$('usersList').append(node('div','users-empty',users.length?'کاربری با این فیلتر پیدا نشد.':'اولین کاربر را بسازید؛ حجم و زمان صفر یعنی نامحدود.'));\n    $('usersResultCount').textContent=fa.format(shown.length)+' کاربر';\n  }\n  async function load(preserveInteraction=false){\n    if(busy)return;busy=true;\n    try{const d=await api();users=d.items;if(!preserveInteraction||(!AmyraxControls.isOpen()&&!document.activeElement?.closest('.user-actions')))render();$('usersError').hidden=true;$('usersEngine').textContent=d.storageError?'ذخیرهٔ مصرف ناموفق است؛ اتصال کاربران تا رفع مشکل متوقف شده.':d.engine.message;$('usersEngine').dataset.status=d.storageError?'error':d.engine.status;}\n    catch(e){$('usersError').textContent=e.message;$('usersError').hidden=false;}\n    finally{busy=false;}\n  }\n  function openEditor(u=null){\n    editing=u;$('userForm').reset();$('userFormError').hidden=true;$('userDialogTitle').textContent=u?'ویرایش '+u.name:'ساخت کاربر جدید';\n    for(const key of ['name','note','limitGB','durationDays','resetDays','startMode'])$('user_'+key).value=u?.[key]??({limitGB:0,durationDays:0,resetDays:0,startMode:'now'}[key]??'');\n    AmyraxControls.sync($('user_startMode'));\n    $('user_enabled').checked=u?.enabled??true;\n    document.querySelectorAll('[name=\"userProtocol\"]').forEach(e=>e.checked=u?u.protocols.includes(e.value):true);\n    $('userCurrentExpiry').textContent=u?'اعتبار فعلی: '+(u.expiresAt?date(u.expiresAt):u.durationDays?'در انتظار اولین اتصال':'نامحدود'):'';\n    $('userDialog').showModal();$('user_name').focus();\n  }\n  $('userForm').addEventListener('submit',async e=>{\n    e.preventDefault();const b=$('saveUser');if(b.disabled)return;b.disabled=true;const label=b.textContent;b.textContent='در حال پردازش…';$('userFormError').hidden=true;\n    const input={name:$('user_name').value.trim(),note:$('user_note').value.trim(),enabled:$('user_enabled').checked,startMode:$('user_startMode').value,protocols:[...document.querySelectorAll('[name=\"userProtocol\"]:checked')].map(e=>e.value)};\n    for(const k of ['limitGB','durationDays','resetDays'])input[k]=Number($('user_'+k).value);\n    if(editing)input.revision=editing.revision;\n    try{await api(editing?'/'+editing.id:'',editing?'PATCH':'POST',input);$('userDialog').close();showToast(editing?'کاربر به‌روز شد.':'کاربر ساخته شد.');await load();}\n    catch(err){$('userFormError').textContent=err.message;$('userFormError').hidden=false;}\n    finally{b.disabled=false;b.textContent=label;}\n  });\n  function openAction(u,action){\n    const messages={toggle:u.enabled?'اتصال‌های این کاربر قطع می‌شوند و تا فعال‌سازی دوباره، اتصال تازه پذیرفته نمی‌شود.':'کاربر دوباره فعال می‌شود؛ حجم و زمان قبلی حفظ می‌شوند.',renew:'روزهای واردشده به اعتبار باقی‌مانده اضافه می‌شود. صفر یعنی زمان نامحدود.',reset:'مصرف سهمیه صفر می‌شود؛ مصرف کل تاریخی حفظ می‌شود.',disconnect:'اتصال‌های باز قطع می‌شوند. کاربر فعال می‌تواند دوباره متصل شود.', 'rotate-link':'لینک ساب قبلی باطل می‌شود. کانفیگ‌های دریافت‌شده همچنان معتبر می‌مانند.', 'rotate-credentials':'کانفیگ‌های قبلی باطل و اتصال‌های باز قطع می‌شوند؛ کاربر باید ساب را در اپ به‌روز کند.',archive:'لینک و اتصال کاربر غیرفعال می‌شود. اطلاعات در بایگانی قابل بازیابی است.',restore:'کاربر از بایگانی بازمی‌گردد؛ حجم و اعتبار قبلی حفظ می‌شوند.'};\n    messages.delete='کاربر «'+u.name+'» و سابقهٔ مصرفش برای همیشه حذف می‌شوند. لینک اشتراک و تمام کانفیگ‌های او باطل و اتصال‌های باز قطع می‌شوند. این کار قابل بازگشت نیست؛ برای نگهداری اطلاعات، از بایگانی استفاده کنید.';\n    currentAction={u,action};$('userActionTitle').textContent=action==='delete'?'حذف دائمی کاربر':u.name;$('userActionDescription').textContent=messages[action];$('userRenewField').hidden=action!=='renew';$('userRenewDays').disabled=action!=='renew';$('userRenewDays').value=30;$('userActionError').hidden=true;\n    $('confirmUserAction').textContent=action==='delete'?'حذف دائمی':'اعمال تغییر';$('confirmUserAction').classList.toggle('danger',action==='delete');$('confirmUserAction').classList.toggle('primary',action!=='delete');\n    $('userActionDialog').showModal();\n  }\n  $('userActionForm').addEventListener('submit',async e=>{\n    e.preventDefault();if(!currentAction)return;const b=$('confirmUserAction');if(b.disabled)return;b.disabled=true;const {u,action}=currentAction;\n    try{await api('/'+u.id+(['toggle','delete'].includes(action)?'':'/actions'),action==='delete'?'DELETE':action==='toggle'?'PATCH':'POST',action==='delete'?{revision:u.revision}:action==='toggle'?{enabled:!u.enabled,revision:u.revision}:{action,revision:u.revision,...(action==='renew'?{days:Number($('userRenewDays').value)}:{})});$('userActionDialog').close();showToast(action==='delete'?'کاربر حذف شد.':'تغییرات اعمال شد.');await load();}\n    catch(err){$('userActionError').textContent=err.message;$('userActionError').hidden=false;}\n    finally{b.disabled=false;}\n  });\n  $('createUser').addEventListener('click',()=>openEditor());$('userSearch').addEventListener('input',render);$('userStatusFilter').addEventListener('change',render);\n  document.querySelectorAll('[data-close-user-dialog]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.closeUserDialog).close()));\n  $('backupUsers').href=base+'/backup';\n  let importBackup=null,importPreview=null,importBusy=false;\n  const clearImport=()=>{importBackup=null;importPreview=null;$('userImportPreview').hidden=true;$('confirmUserImport').disabled=true;$('userImportError').hidden=true;};\n  const importError=e=>{$('userImportError').textContent=e.message;$('userImportError').hidden=false;};\n  function importState(busy){importBusy=busy;$('userBackupFile').disabled=busy;$('previewUserImport').disabled=busy;$('confirmUserImport').disabled=busy||!importPreview?.added;$('userImportDialog').querySelectorAll('[data-close-user-dialog]').forEach(b=>b.disabled=busy);}\n  $('restoreUsers').addEventListener('click',()=>{clearImport();$('userImportForm').reset();$('userImportDialog').showModal();});\n  $('userBackupFile').addEventListener('change',clearImport);\n  $('previewUserImport').addEventListener('click',async()=>{\n    if(importBusy)return;clearImport();importState(true);\n    try{\n      const file=$('userBackupFile').files[0];if(!file)throw new Error('فایل پشتیبان را انتخاب کنید.');\n      if(file.size>16*1024*1024)throw new Error('حجم فایل بیشتر از ۱۶ مگابایت است.');\n      try{importBackup=JSON.parse(await file.text());}catch(_){throw new Error('فایل JSON معتبر نیست.');}\n      importPreview=await api('/import/preview','POST',{backup:importBackup});\n      $('userImportSummary').textContent=fa.format(importPreview.added)+' حساب جدید · '+fa.format(importPreview.skipped)+' تکراری (حفظ اطلاعات فعلی) · '+fa.format(importPreview.renamed)+' نام متمایز';\n      $('userImportRows').replaceChildren();\n      for(const row of importPreview.rows.slice(0,100))$('userImportRows').append(node('li','',row.name+' — '+(row.action==='skip'?'رد: '+row.reason:row.action==='rename'?'افزودن با نام '+row.newName:'افزودن')));\n      if(importPreview.rows.length>100)$('userImportRows').append(node('li','', 'نمایش ۱۰۰ ردیف اول از '+fa.format(importPreview.total)+' ردیف؛ خلاصه شامل همهٔ حساب‌هاست.'));\n      $('userImportPreview').hidden=false;\n    }catch(e){importPreview=null;importError(e);}finally{importState(false);}\n  });\n  $('userImportForm').addEventListener('submit',async e=>{\n    e.preventDefault();if(importBusy||!importPreview?.added)return;importState(true);$('userImportError').hidden=true;\n    try{const result=await api('/import','POST',{backup:importBackup,fingerprint:importPreview.fingerprint});$('userImportDialog').close();showToast(fa.format(result.added)+' کاربر بازیابی شد؛ اطلاعات کاربران قبلی حفظ شد.');clearImport();await load();}\n    catch(error){importPreview=null;importError(error);}finally{importState(false);}\n  });\n  $('userImportDialog').addEventListener('cancel',e=>{if(importBusy)e.preventDefault();});\n  $('userImportDialog').addEventListener('close',()=>{if(!importBusy)clearImport();});\n  const active=()=>navigator.onLine!==false&&$('viewUsers').classList.contains('active')&&document.visibilityState==='visible';\n  window.addEventListener('online',()=>{if(active())load();});\n  window.addEventListener('hashchange',()=>{if(active())load();});window.addEventListener('amyrax-refresh',()=>{if(active())load();});\n  setInterval(()=>{if(active()&&!$('userDialog').open&&!$('userActionDialog').open&&!$('userImportDialog').open&&!AmyraxControls.isOpen()&&!document.activeElement?.closest('.am-dropdown'))load(true);},5000);\n  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{if(active())load();});else if(active())load();\n})();\n",
  usersCss: ".users-toolbar,.users-heading-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.users-heading-actions{justify-content:space-between;margin-bottom:16px}.users-heading-actions>div{display:flex;gap:10px;flex-wrap:wrap}.users-counter-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:16px}.users-counter{padding:14px 16px;border:1px solid var(--border);border-radius:16px;background:var(--card-bg)}.users-counter span{display:block;color:var(--text-muted);font-size:12px}.users-counter strong{font-size:26px;line-height:1.4;display:block;margin-top:4px;color:var(--primary-red)}.users-toolbar{padding:12px;background:var(--card-bg);border:1px solid var(--border);border-radius:14px;margin:16px 0}.users-search{flex:1;min-width:180px}.users-search input{width:100%}.users-toolbar select{min-width:160px}.users-toolbar input,.users-toolbar select,.user-actions,.user-dialog input,.user-dialog textarea,.user-dialog select{background:var(--field);color:var(--text-white);border:1px solid var(--border);border-radius:10px;padding:11px 12px;font:inherit;min-width:0;max-width:100%}.users-result{font-size:12px;color:var(--text-muted)}.users-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,340px),1fr));gap:16px;align-items:stretch}.user-card{display:flex;flex-direction:column;container-type:inline-size;padding:16px;border-radius:14px;border:1px solid var(--border);background:linear-gradient(140deg,#38c9ad05,transparent),var(--card-bg);min-width:0}.user-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.user-name{min-width:0}.user-name h3{font-size:16px;overflow-wrap:anywhere}.user-name small{font-size:11px;color:var(--text-muted)}.user-head-actions{display:flex;align-items:center;gap:8px;flex-shrink:0}.user-status{border-radius:999px;padding:3px 8px;background:var(--field);font-size:11px;flex-shrink:0;color:var(--text-muted);border:1px solid var(--border)}.user-status-active{color:#6de3c5;border-color:#38c9ad40}.user-status-pending{color:#8fc8ff}.user-status-expired,.user-status-limited{color:#f6ad9f;border-color:#ed8e7030}.user-note{color:var(--text-muted);font-size:12px;line-height:1.9;overflow-wrap:anywhere;margin-top:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.user-metrics{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:auto 0 12px;padding-top:12px}.user-metrics>div{min-width:0}.user-metrics>div+div{border-inline-start:1px solid var(--border);padding-inline-start:12px}.user-metrics dt{font-size:11px;color:var(--text-muted)}.user-metrics dd{font-size:13px;margin:4px 0 0;overflow-wrap:anywhere}.user-progress{height:5px;background:var(--field);border-radius:8px;overflow:hidden;direction:ltr}.user-progress span{display:block;height:100%;background:var(--primary-red)}.user-card-meta{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:12px 0}.user-connections{font-size:11px;color:var(--text-muted)}.user-protocols{display:flex;gap:6px;flex-wrap:wrap}.user-protocols span{font:10px Arial;padding:5px 7px;background:var(--field);border-radius:6px;color:var(--text-muted)}.user-card-buttons{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.user-card-buttons>*{min-width:0;min-height:44px;padding:8px 4px;font-size:11px;white-space:nowrap}.user-actions{font-size:12px}.users-empty{grid-column:1/-1;padding:50px 24px;text-align:center;color:var(--text-muted);border:1px dashed var(--border);border-radius:18px}.users-service{font-size:12px;line-height:2;padding:12px 16px;background:var(--field);border:1px solid var(--border);border-radius:12px;color:var(--text-muted)}.users-service[data-status=ready]{color:var(--primary-red)}.users-service[data-status=error],.users-error{color:#f6b3a4}.users-error{padding:12px;border:1px solid #ed8e7040;background:#ed8e700b;border-radius:10px;margin:12px 0}.user-dialog{width:680px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 32px);overflow:auto;padding:28px;color:var(--text-white);background:var(--card-bg);border:1px solid var(--border);border-radius:24px;font-family:var(--font-family);overscroll-behavior:contain}.user-dialog::backdrop{background:#02070bbd;backdrop-filter:blur(8px)}.user-dialog-header{display:flex;justify-content:space-between;gap:16px;align-items:center;margin-bottom:22px}.user-dialog-header h2{font-size:21px;overflow-wrap:anywhere}.user-dialog p{font-size:12px;line-height:2;color:var(--text-muted)}.user-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.user-field{display:flex;flex-direction:column;gap:8px;font-size:13px;min-width:0}.user-field small{font-size:11px;color:var(--text-muted);line-height:1.9}.user-field input,.user-field select,.user-field textarea{width:100%;min-height:44px}.user-field.full{grid-column:1/-1}.user-field textarea{resize:vertical;min-height:75px}.user-check{display:flex;gap:9px;align-items:center;font-size:13px}.user-check input{accent-color:var(--primary-red);width:18px;height:18px;min-height:0}.user-protocol-picker{border:1px solid var(--border);border-radius:12px;padding:14px;grid-column:1/-1}.user-protocol-picker legend{font-size:13px;padding:0 7px}.user-protocol-picker>div{display:grid;grid-template-columns:1fr 1fr;gap:14px}.user-dialog-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:24px;flex-wrap:wrap}.user-dialog-actions .button{min-height:44px;padding-inline:22px}.user-expiry{padding-top:10px}.user-action-dialog{width:440px}.user-action-dialog .user-field{margin-top:16px}.user-dialog [hidden],#viewUsers [hidden]{display:none!important}\r\n@container(max-width:330px){.user-card-buttons{grid-template-columns:repeat(2,minmax(0,1fr))}}\r\n@media(max-width:850px){.mobile-nav-bar{grid-template-columns:repeat(5,minmax(0,1fr));padding-inline:6px}.mob-link{font-size:11px}}\r\n@media(max-width:650px){.users-list{grid-template-columns:1fr}.users-counter-grid{gap:8px}.users-counter{padding:13px 9px}.users-counter span{font-size:11px}.users-counter strong{font-size:25px}.users-toolbar>*{width:100%;flex-basis:100%}.user-card{padding:14px}.user-form-grid{grid-template-columns:1fr}.user-dialog{padding:20px}.user-dialog-header h2{font-size:19px} .user-dialog-actions>*{flex:1}.user-protocol-picker>div{grid-template-columns:1fr}.user-dialog input,.user-dialog textarea,.user-dialog select{font-size:16px}}\r\n\r\n.user-identity-meta{display:flex;align-items:center;gap:6px 10px;flex-wrap:wrap;margin-top:6px}.user-identity-meta small{font-size:10px}\r\n@media(max-width:650px){.users-toolbar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px}.users-search{grid-column:1/-1;min-width:0}.users-result{width:auto;white-space:nowrap}.user-name h3{font-size:15px}.users-heading-actions>div{width:100%;display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.users-counter strong{line-height:1.4}}\r\n\r\n\r\n.user-dialog{padding:8px;overflow:hidden}\r\n.user-dialog>form{padding:20px;max-height:calc(100dvh - 50px)}\r\n@media(max-width:650px){.user-dialog>form{padding:12px}}\r\n\r\n.import-rows{max-height:220px;overflow:auto;padding:0 22px 0 8px;margin:12px 0;list-style:disc}.import-rows li{font-size:12px;line-height:1.9;overflow-wrap:anywhere;margin:7px 0}.user-field input[type=file]{font-size:12px;padding:8px;overflow:hidden}.user-field input[type=file]::file-selector-button{font:inherit;background:var(--card-bg);color:var(--text-white);border:1px solid var(--border);padding:8px;border-radius:8px;margin-inline-end:8px}#previewUserImport{margin-top:12px;min-height:44px}\r\n@media(max-width:650px){.users-heading-actions>div{grid-template-columns:repeat(2,minmax(0,1fr))}.users-heading-actions #createUser{grid-column:1/-1}.users-heading-actions .button{font-size:12px;padding-inline:8px;min-width:0}}\r\n",
  appJs: "async function amyraxRequestJson(url, options = {}) {\r\n  const { timeoutMs = 30000, signal, ...settings } = options;\r\n  const method = String(settings.method || 'GET').toUpperCase(), readOnly = method === 'GET';\r\n  const controller = new AbortController();\r\n  let timedOut = false;\r\n  const cancel = () => controller.abort();\r\n  signal?.addEventListener('abort', cancel, {once:true});\r\n  if (signal?.aborted) cancel();\r\n  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);\r\n  const uncertain = readOnly ? '' : ' نتیجهٔ عملیات مشخص نیست؛ پیش از تکرار، وضعیت را در پنل تازه‌سازی و بررسی کنید.';\r\n  const error = (code, message, status = 0, retryable = false) => Object.assign(new Error(message), {code, status, retryable});\r\n  try {\r\n    for (let attempt = 0; ; attempt++) {\r\n      try {\r\n        if (controller.signal.aborted) throw new Error('aborted');\r\n        const response = await fetch(url, {...settings, method, cache:'no-store', credentials:'same-origin', signal:controller.signal});\r\n        if (response.status === 401) throw error('AUTH_REQUIRED', 'نشست مدیریت پایان یافته است؛ دوباره وارد پنل شوید.', 401);\r\n        const text = await response.text();\r\n        let data;\r\n        try { data = JSON.parse(text); } catch (_) {}\r\n        const valid = data && typeof data === 'object' && !Array.isArray(data);\r\n        if (!response.ok) {\r\n          const message = valid && typeof data.error === 'string' ? data.error\r\n            : response.status === 503 ? 'سرور مشغول است؛ چند ثانیه بعد دوباره تلاش کنید.'\r\n            : 'دریافت پاسخ از سرور ناموفق بود (HTTP ' + response.status + ').' + uncertain;\r\n          throw error('HTTP_ERROR', message, response.status, [502,504].includes(response.status));\r\n        }\r\n        if (!valid) throw error('INVALID_RESPONSE', 'پاسخ کامل و معتبری از سرور دریافت نشد.' + uncertain, response.status, true);\r\n        return data;\r\n      } catch (failure) {\r\n        if (controller.signal.aborted) throw error(timedOut ? 'REQUEST_TIMEOUT' : 'REQUEST_CANCELLED',\r\n          (timedOut ? 'مهلت دریافت پاسخ از سرور تمام شد.' : 'دریافت پاسخ لغو شد.') + uncertain);\r\n        const failureInfo = ['AUTH_REQUIRED','HTTP_ERROR','INVALID_RESPONSE'].includes(failure.code) ? failure : error('NETWORK_ERROR', 'ارتباط با سرور قطع شد؛ اتصال را بررسی کنید.' + uncertain, 0, true);\r\n        if (!readOnly || attempt >= 1 || !failureInfo.retryable) throw failureInfo;\r\n        await new Promise(resolve => {\r\n          const finish = () => { clearTimeout(retryTimer); controller.signal.removeEventListener('abort', finish); resolve(); };\r\n          const retryTimer = setTimeout(finish, 300);\r\n          controller.signal.addEventListener('abort', finish, {once:true});\r\n          if (controller.signal.aborted) finish();\r\n        });\r\n      }\r\n    }\r\n  } finally {\r\n    clearTimeout(timer); signal?.removeEventListener('abort', cancel);\r\n  }\r\n}\r\n\r\nlet panelData = null;\r\n\r\nfunction showToast(text) {\r\n  const toast = document.getElementById('amyraxToast');\r\n  if (!toast) return;\r\n  toast.innerText = text;\r\n  toast.classList.add('show');\r\n  setTimeout(() => {\r\n    toast.classList.remove('show');\r\n  }, 2200);\r\n}\r\n\r\nfunction copyTextToClipboard(text) {\r\n  if (!text) return;\r\n  const successMsg = 'در کلیپ‌بورد کپی شد.';\r\n\r\n  if (navigator.clipboard && window.isSecureContext) {\r\n    navigator.clipboard.writeText(text).then(() => {\r\n      showToast(successMsg);\r\n    }).catch(() => {\r\n      fallbackCopy(text, successMsg);\r\n    });\r\n  } else {\r\n    fallbackCopy(text, successMsg);\r\n  }\r\n}\r\n\r\nfunction fallbackCopy(text, msg) {\r\n  const textArea = document.createElement('textarea');\r\n  textArea.value = text;\r\n  textArea.style.position = 'fixed';\r\n  textArea.style.opacity = '0';\r\n  document.body.appendChild(textArea);\r\n  textArea.focus();\r\n  textArea.select();\r\n  try {\r\n    document.execCommand('copy');\r\n    showToast(msg);\r\n  } catch (err) {\r\n    showToast('کپی ناموفق بود.');\r\n  }\r\n  document.body.removeChild(textArea);\r\n}\r\n\r\nfunction openQr(text, title) {\r\n  if (!text) return;\r\n  const modal = document.getElementById('qrModal');\r\n  const wrapper = document.getElementById('qrcodeWrapper');\r\n  const titleEl = document.getElementById('qrModalTitle');\r\n  if (!modal || !wrapper) return;\r\n\r\n  if (titleEl && title) {\r\n    titleEl.innerText = title;\r\n  } else if (titleEl) {\r\n    titleEl.innerText = 'اسکن کد QR';\r\n  }\r\n\r\n  try {\r\n    qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];\r\n    const code = qrcode(0, 'M'); code.addData(text); code.make();\r\n    wrapper.innerHTML = code.createSvgTag({ cellSize: 4, margin: 16, scalable: true });\r\n  } catch (_) { showToast('این کانفیگ برای QR طولانی است؛ از دکمهٔ کپی استفاده کنید.'); return; }\r\n\r\n  modal.classList.add('active');\r\n}\r\n\r\nfunction closeQr() {\r\n  document.getElementById('qrModal')?.classList.remove('active');\r\n}\r\n\r\ndocument.getElementById('qrCloseBtn')?.addEventListener('click', closeQr);\r\ndocument.getElementById('qrModal')?.addEventListener('click', (e) => {\r\n  if (e.target.id === 'qrModal') closeQr();\r\n});\r\ndocument.addEventListener('keydown', (e) => {\r\n  if (e.key === 'Escape') closeQr();\r\n});\r\n\r\nfunction applyTheme(theme) {\r\n  const isCozy = (theme === 'cozy');\r\n  const targetTheme = isCozy ? 'cozy' : 'dark';\r\n\r\n  document.documentElement.setAttribute('data-theme', targetTheme);\r\n  document.body.setAttribute('data-theme', targetTheme);\r\n\r\n  if (isCozy) {\r\n    document.body.classList.add('theme-cozy');\r\n  } else {\r\n    document.body.classList.remove('theme-cozy');\r\n  }\r\n\r\n  const toggleBtn = document.getElementById('themeToggleBtn');\r\n  const toggleLabel = document.getElementById('themeToggleLabel');\r\n  if (toggleBtn) {\r\n    const nextThemeLabel = isCozy ? 'فعال‌کردن تم تیره' : 'فعال‌کردن تم گرم';\r\n    toggleBtn.setAttribute('data-theme', targetTheme);\r\n    toggleBtn.setAttribute('aria-pressed', isCozy ? 'true' : 'false');\r\n    toggleBtn.setAttribute('aria-label', nextThemeLabel);\r\n    toggleBtn.setAttribute('title', nextThemeLabel);\r\n    toggleBtn.classList.toggle('is-cozy', isCozy);\r\n    const icon = toggleBtn.querySelector('svg');\r\n    if (icon) icon.innerHTML = isCozy\r\n      ? '<path d=\"M20.9 13a9 9 0 0 1-9.9-9.9A9 9 0 1 0 20.9 13Z\"/>'\r\n      : '<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2M12 20v2M2 12h2M20 12h2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42\"/>';\r\n  }\r\n  if (toggleLabel) {\r\n    toggleLabel.textContent = isCozy ? 'تم گرم' : 'تم تیره';\r\n  }\r\n}\r\n\r\nfunction initTheme() {\r\n  let savedTheme = 'dark';\r\n  try { savedTheme = localStorage.getItem('amyrax-theme') || 'dark'; } catch {}\r\n  applyTheme(savedTheme);\r\n}\r\n\r\nfunction toggleTheme() {\r\n  const current = document.documentElement.getAttribute('data-theme') || (document.body.classList.contains('theme-cozy') ? 'cozy' : 'dark');\r\n  const nextTheme = (current === 'cozy') ? 'dark' : 'cozy';\r\n  applyTheme(nextTheme);\r\n  try {\r\n    localStorage.setItem('amyrax-theme', nextTheme);\r\n  } catch {}\r\n  showToast(nextTheme === 'cozy' ? 'تم گرم فعال شد.' : 'تم تیره فعال شد.');\r\n}\r\n\r\ndocument.getElementById('themeToggleBtn')?.addEventListener('click', toggleTheme);\r\ninitTheme();\r\n\r\ndocument.addEventListener('click', (e) => {\r\n  if (e.target.matches('.node-uri-input')) e.target.select();\r\n  const btn = e.target.closest('button, a');\r\n  if (!btn) return;\r\n\r\n  const action = btn.getAttribute('data-action');\r\n  if (!action) return;\r\n\r\n  if (action === 'copy-input') {\r\n    const targetId = btn.getAttribute('data-target');\r\n    const input = document.getElementById(targetId);\r\n    if (input) copyTextToClipboard(input.value);\r\n  } else if (action === 'qr-input') {\r\n    const targetId = btn.getAttribute('data-target');\r\n    const input = document.getElementById(targetId);\r\n    if (input) openQr(input.value, 'کد QR اشتراک');\r\n  } else if (action === 'copy-text') {\r\n    const raw = btn.getAttribute('data-text');\r\n    if (raw) copyTextToClipboard(decodeURIComponent(raw));\r\n  } else if (action === 'qr-text') {\r\n    const raw = btn.getAttribute('data-text');\r\n    const title = btn.getAttribute('data-title') || 'اسکن کد QR';\r\n    if (raw) openQr(decodeURIComponent(raw), title);\r\n  }\r\n});\r\n\r\nfunction handleRouting() {\r\n  let hash = window.location.hash || '#/home';\r\n  if (hash === '#' || hash === '') hash = '#/home';\r\n  const page = hash.replace(/^#\\/?/, '').split('?')[0].toLowerCase() || 'home';\r\n\r\n  let validPage = 'home';\r\n  if (page === 'subs' || page === 'sub') {\r\n    validPage = 'subs';\r\n  } else if (page === 'nodes' || page === 'node') {\r\n    validPage = 'nodes';\r\n  } else if (page === 'studio') {\r\n    validPage = 'studio';\r\n  } else if (page === 'users') {\r\n    validPage = 'users';\r\n  } else if (page === 'usage' || page === 'traffic') {\r\n    validPage = 'usage';\r\n  }\r\n\r\n  document.querySelectorAll('.view-page').forEach(el => {\r\n    el.classList.remove('active');\r\n  });\r\n\r\n  let targetViewId = 'viewHome';\r\n  if (validPage === 'subs') targetViewId = 'viewSubs';\r\n  else if (validPage === 'nodes') targetViewId = 'viewNodes';\r\n  else if (validPage === 'usage') targetViewId = 'viewUsage';\r\n  else if (validPage === 'studio') targetViewId = 'viewStudio';\r\n  else if (validPage === 'users') targetViewId = 'viewUsers';\r\n\r\n  const targetView = document.getElementById(targetViewId);\r\n  if (targetView) targetView.classList.add('active');\r\n\r\n  document.querySelectorAll('.nav-link, .mob-link, .drawer-nav-item').forEach(el => {\r\n    if (el.getAttribute('data-page') === validPage) {\r\n      el.classList.add('active');\r\n    } else {\r\n      el.classList.remove('active');\r\n    }\r\n  });\r\n\r\n  amyraxPageTitle(validPage);\r\n  toggleDrawer(false);\r\n  window.scrollTo({ top: 0, behavior: 'smooth' });\r\n}\r\n\r\nwindow.addEventListener('hashchange', handleRouting);\r\n\r\nconst hamburgerBtn = document.getElementById('hamburgerBtn');\r\nconst mobileDrawer = document.getElementById('mobileDrawer');\r\n\r\nfunction toggleDrawer(open) {\r\n  if (!hamburgerBtn || !mobileDrawer) return;\r\n  const isOpen = (typeof open === 'boolean') ? open : !mobileDrawer.classList.contains('open');\r\n  mobileDrawer.classList.toggle('open', isOpen);\r\n  hamburgerBtn.classList.toggle('active', isOpen);\r\n  hamburgerBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');\r\n  document.getElementById('drawerScrim')?.classList.toggle('open', isOpen);\r\n  const smallScreen = window.matchMedia('(max-width: 850px)').matches;\r\n  mobileDrawer.inert = smallScreen && !isOpen;\r\n  mobileDrawer.setAttribute('aria-hidden', smallScreen && !isOpen ? 'true' : 'false');\r\n}\r\n\r\nhamburgerBtn?.addEventListener('click', (e) => {\r\n  e.stopPropagation();\r\n  toggleDrawer();\r\n});\r\n\r\nmobileDrawer?.querySelectorAll('a').forEach(link => {\r\n  link.addEventListener('click', () => toggleDrawer(false));\r\n});\r\n\r\ndocument.addEventListener('click', (e) => {\r\n  if (mobileDrawer?.classList.contains('open')) {\r\n    if (!mobileDrawer.contains(e.target) && !hamburgerBtn?.contains(e.target)) {\r\n      toggleDrawer(false);\r\n    }\r\n  }\r\n});\r\n\r\ndocument.addEventListener('keydown', (e) => {\r\n  if (e.key === 'Escape' && mobileDrawer?.classList.contains('open')) {\r\n    toggleDrawer(false);\r\n  }\r\n});\r\n\r\nfunction escapeHtml(str) {\r\n  if (!str) return '';\r\n  return String(str)\r\n    .replace(/&/g, '&amp;')\r\n    .replace(/</g, '&lt;')\r\n    .replace(/>/g, '&gt;')\r\n    .replace(/\"/g, '&quot;')\r\n    .replace(/'/g, '&#039;');\r\n}\r\n\r\nfunction renderNodes(nodes, locationStr) {\r\n  const container = document.getElementById('nodesContainer');\r\n  if (!container) return;\r\n\r\n  const activeNodes = (nodes || []).filter(n => {\r\n    if (!n || !n.uri) return false;\r\n    const lowerType = (n.type || '').toLowerCase();\r\n    return !lowerType.includes('hy2') && !lowerType.includes('hysteria');\r\n  });\r\n\r\n  if (activeNodes.length === 0) {\r\n    container.innerHTML = `\r\n      <div class=\"no-nodes-msg\">\r\n        <p>کانفیگی پیدا نشد. وضعیت موتورهای اتصال را بررسی کنید.</p>\r\n      </div>\r\n    `;\r\n    return;\r\n  }\r\n\r\n  let html = '';\r\n  activeNodes.forEach((node, index) => {\r\n    const rawUri = node.uri;\r\n    const name = node.name || `AmyraxVPN - Node ${index + 1}`;\r\n    const lowerType = (node.type || '').toLowerCase();\r\n\r\n    let protoLabel = 'VLESS';\r\n    let protoClass = 'badge-proto-vless';\r\n    if (lowerType.includes('vmess')) {\r\n      protoLabel = 'VMess';\r\n      protoClass = 'badge-proto-vmess';\r\n    } else if (lowerType.includes('trojan')) {\r\n      protoLabel = 'Trojan';\r\n      protoClass = 'badge-proto-trojan';\r\n    } else if (lowerType.includes('shadowsocks') || lowerType === 'ss') {\r\n      protoLabel = 'Shadowsocks';\r\n      protoClass = 'badge-proto-ss';\r\n    } else if (lowerType.includes('wireguard') || lowerType.includes('wg')) {\r\n      protoLabel = 'WireGuard';\r\n      protoClass = 'badge-proto-wg';\r\n    } else if (lowerType.includes('tuic')) {\r\n      protoLabel = 'TUIC';\r\n      protoClass = 'badge-proto-tuic';\r\n    }\r\n\r\n    let transportBadge = '';\r\n    if (lowerType.includes('ws')) {\r\n      transportBadge = '<span class=\"node-badge-tag\">WS</span>';\r\n    } else if (lowerType.includes('httpupgrade')) {\r\n      transportBadge = '<span class=\"node-badge-tag\">HTTPUpgrade</span>';\r\n    } else if (lowerType.includes('grpc')) {\r\n      transportBadge = '<span class=\"node-badge-tag\">gRPC</span>';\r\n    } else if (lowerType.includes('xhttp')) {\r\n      transportBadge = '<span class=\"node-badge-tag\">XHTTP</span>';\r\n    }\r\n\r\n    let secBadge = '';\r\n    if (lowerType.includes('reality')) {\r\n      secBadge = '<span class=\"node-badge-tag badge-reality\">Reality</span>';\r\n    } else if (lowerType.includes('tls') || lowerType.includes('shadowtls')) {\r\n      secBadge = '<span class=\"node-badge-tag badge-tls\">TLS</span>';\r\n    }\r\n\r\n    const encodedUri = encodeURIComponent(rawUri);\r\n    const encodedTitle = escapeHtml(name);\r\n\r\n    html += `\r\n      <div class=\"node-item-card\">\r\n        <div class=\"node-card-header\">\r\n          <div class=\"node-card-title-group\">\r\n            <span class=\"proto-badge ${protoClass}\">${protoLabel}</span>\r\n            <h4 class=\"node-remark-title\" title=\"${escapeHtml(name)}\">${escapeHtml(name)}</h4>\r\n          </div>\r\n          <div class=\"node-badges-group\">\r\n            ${transportBadge}\r\n            ${secBadge}\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"node-card-meta\">\r\n          <div class=\"node-location-tag\">\r\n            <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" class=\"loc-icon\">\r\n              <path d=\"M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z\"></path>\r\n              <circle cx=\"12\" cy=\"10\" r=\"3\"></circle>\r\n            </svg>\r\n            <span>${escapeHtml(locationStr || 'Global Server')}</span>\r\n          </div>\r\n          ${node.note ? `<div class=\"node-location-tag\" style=\"opacity:.85;font-size:.78rem\">${escapeHtml(node.note)}</div>` : ''}\r\n        </div>\r\n\r\n        <div class=\"node-uri-box\">\r\n          <input type=\"text\" class=\"node-uri-input\" readonly value=\"${escapeHtml(rawUri)}\">\r\n        </div>\r\n\r\n        <div class=\"node-actions-row\">\r\n          <span class=\"row-actions\" dir=\"rtl\">\r\n            <button type=\"button\" class=\"action-icon-button\" data-action=\"qr-text\" data-text=\"${encodedUri}\" data-title=\"${encodedTitle}\" aria-label=\"کد QR ${escapeHtml(node.name || node.type)}\" title=\"نمایش کد QR\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z\"/></svg></button>\r\n            <button type=\"button\" class=\"action-icon-button\" data-action=\"copy-text\" data-text=\"${encodedUri}\" aria-label=\"کپی ${escapeHtml(node.name || node.type)}\" title=\"کپی لینک\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"/></svg></button>\r\n          </span>\r\n          <span class=\"studio-actions\">${node.xrayJson ? `<button type=\"button\" class=\"studio-button\" data-action=\"copy-text\" data-text=\"${encodeURIComponent(node.xrayJson)}\">Xray ↗</button>` : ''}${node.singboxJson ? `<button type=\"button\" class=\"studio-button\" data-action=\"copy-text\" data-text=\"${encodeURIComponent(node.singboxJson)}\">sing-box ↗</button>` : ''}</span>\r\n          ${node.wgConf ? `\r\n            <a href=\"/amyrax/wg.conf\" download=\"wg0.conf\" class=\"btn-node-dl\" title=\"Download WireGuard Profile\">\r\n              <span>.conf</span>\r\n            </a>\r\n          ` : ''}\r\n        </div>\r\n      </div>\r\n    `;\r\n  });\r\n\r\n  container.innerHTML = html;\r\n}\r\n\r\nasync function loadGateData() {\r\n  try {\r\n    const pathSegments = window.location.pathname.split('/').filter(Boolean);\r\n    const pathPrefix = pathSegments[0] || 'amyrax';\r\n\r\n    const data = await amyraxRequestJson('/health');\r\n    panelData = data;\r\n    updateAmyraxOverview(data);\r\n\r\n    const pubPort = data.publicPort || window.location.port || '2705';\r\n    const serverHost = data.domain || data.host || window.location.hostname;\r\n    const locationStr = data.location || 'Global Server';\r\n\r\n    const uptimeStr = amyraxDuration(data.uptime);\r\n\r\n    const homeLocation = document.getElementById('homeLocation');\r\n    if (homeLocation) homeLocation.innerText = locationStr;\r\n\r\n    const homePort = document.getElementById('homePort');\r\n    if (homePort) homePort.innerText = pubPort;\r\n\r\n    const homeUptime = document.getElementById('homeUptime');\r\n    if (homeUptime) homeUptime.innerText = uptimeStr;\r\n\r\n    const statLocation = document.getElementById('statLocation');\r\n    if (statLocation) statLocation.innerText = locationStr;\r\n\r\n    const statPort = document.getElementById('statPort');\r\n    if (statPort) statPort.innerText = pubPort;\r\n\r\n    const statHost = document.getElementById('statHost');\r\n    if (statHost) statHost.innerText = serverHost;\r\n\r\n    const statUptime = document.getElementById('statUptime');\r\n    if (statUptime) statUptime.innerText = uptimeStr;\r\n\r\n    const nodesLocation = document.getElementById('nodesLocation');\r\n    if (nodesLocation) nodesLocation.innerText = locationStr;\r\n\r\n    const engines = [];\r\n    if (data.engines?.singbox) engines.push('sing-box');\r\n    if (data.engines?.xray) engines.push('xray');\r\n    if (data.engines?.argo) engines.push('argo');\r\n    const statEngines = document.getElementById('statEngines');\r\n    if (statEngines) statEngines.innerText = engines.join(' + ') || 'موتور فعالی نیست';\r\n\r\n    const unifiedUrl = data.subscriptionUrl;\r\n    const unifiedInput = document.getElementById('urlSubUniversal');\r\n    if (unifiedInput) unifiedInput.value = unifiedUrl || '';\r\n    const openPage = document.getElementById('openSubscriptionPage');\r\n    if (openPage && unifiedUrl) openPage.href = unifiedUrl;\r\n\r\n    renderNodes(data.nodes, locationStr);\n    if (!data.network?.checkedAt) refreshAmyraxNetwork();\r\n\r\n  } catch (err) {\r\n    console.error('Failed to load gate status:', err);\r\n    const container = document.getElementById('nodesContainer');\r\n    if (container) {\r\n      container.innerHTML = `\r\n        <div class=\"no-nodes-msg\">\r\n          <p>دریافت اطلاعات ناموفق بود. اتصال را بررسی و صفحه را تازه‌سازی کنید.</p>\r\n        </div>\r\n      `;\r\n    }\r\n  }\r\n}\r\n\r\ndocument.addEventListener('DOMContentLoaded', () => {\r\n  handleRouting();\r\n  loadGateData();\r\n});\r\n\r\n(function () {\r\n  const $=id=>document.getElementById(id);\r\n  const prefix='/' + (location.pathname.split('/').filter(Boolean)[0] || 'amyrax');\r\n  const names={'VLESS-WS':'VLESS WS','VMess-WS':'VMess WS','Trojan-WS':'Trojan WS','Shadowsocks-WS':'Shadowsocks WS','VMess-HTTPUpgrade':'VMess HTTPUpgrade','Trojan-HTTPUpgrade':'Trojan HTTPUpgrade','VLESS-gRPC':'VLESS gRPC','VLESS-XHTTP':'VLESS XHTTP','VLESS-HTTPUpgrade':'VLESS HTTPUpgrade',Other:'سایر'};\r\n  const total=e=>(e?.up||0)+(e?.down||0);\r\n  let loading=false,lastStamp=0;\r\n  function render(d){\r\n    if(!d?.ok || !d.live)return;\r\n    const stamp=Date.parse(d.now);if(stamp<lastStamp)return;lastStamp=stamp;\r\n    amyraxTraffic(d);updateAmyraxResources(d.system);\r\n    for(const [id,value] of Object.entries({usageLiveUp:d.live.upBps,usageLiveDown:d.live.downBps,usageDayTotal:d.day.total,usageDayUp:d.day.up,usageDayDown:d.day.down,usageMonthTotal:d.month.used,usageMonthUp:d.month.up,usageMonthDown:d.month.down,usageAllTotal:d.allTime.total,usageAllUp:d.allTime.up,usageAllDown:d.allTime.down}))amyraxValue(id,value,id.startsWith('usageLive'));\r\n    amyraxSet('usageMonthKey','('+d.month.key+')');\r\n    const rows=document.createDocumentFragment();\r\n    const cell=(row,value,bytes=false)=>{const td=document.createElement('td');td.textContent=bytes?amyraxBytes(value):value;if(bytes)td.title=Number(value).toLocaleString('en-US')+' bytes';row.append(td);};\r\n    for(const k of d.keys.filter(k=>['VLESS-WS','VMess-WS'].includes(k)||total(d.allTime.per[k])>0||d.active[k]>0)){\r\n      const tr=document.createElement('tr'),m=d.month.per[k]||{};\r\n      cell(tr,names[k]||k);cell(tr,d.active[k]||0);\r\n      for(const value of [total(d.day.per[k]),m.up||0,m.down||0,total(m),total(d.allTime.per[k])])cell(tr,value,true);\r\n      rows.append(tr);\r\n    }\r\n    $('usageRows').replaceChildren(rows);\r\n    const foot=document.createElement('tr');cell(foot,'مجموع');cell(foot,d.connections?.tunnels||0);\r\n    for(const value of [d.day.total,d.month.up,d.month.down,d.month.total,d.allTime.total])cell(foot,value,true);\r\n    $('usageFoot').replaceChildren(foot);\r\n    if(d.month.baseBytes){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=5;td.textContent='تعدیل ذخیره‌شدهٔ ماه';tr.append(td);cell(tr,d.month.baseBytes,true);cell(tr,'—');$('usageFoot').append(tr);}\r\n    const box=$('usageLimit');box.hidden=!d.limit;\r\n    if(d.limit){\r\n      const pct=Math.max(0,d.limit.pct);box.classList.toggle('is-warn',pct>=80);box.classList.toggle('is-over',pct>=100);\r\n      amyraxSet('usageLimitText',amyraxBytes(d.limit.used)+' / '+amyraxBytes(d.limit.bytes));amyraxSet('usageLimitPct',pct.toFixed(1)+'%');\r\n      $('usageBar').style.width=Math.min(100,pct)+'%';amyraxSet('usageLimitMsg','باقی‌مانده: '+amyraxBytes(d.limit.remaining));\r\n    }\r\n    document.querySelectorAll('[data-page=\"usage\"]').forEach(a=>{\r\n      let dot=a.querySelector('.usage-nav-dot');\r\n      if(d.limit?.pct>=80){if(!dot){dot=document.createElement('span');dot.className='usage-nav-dot';a.append(dot);}dot.classList.toggle('over',d.limit.pct>=100);}else dot?.remove();\r\n    });\r\n    amyraxSet('trafficUpdated','به‌روز: '+new Date(d.now).toLocaleTimeString('fa-IR'));\r\n  }\r\n  async function load(){\r\n    if(loading)return;loading=true;\r\n    try{render(await amyraxRequestJson(prefix+'/api/traffic',{timeoutMs:15000}));}\r\n    catch(_){for(const id of ['usageLiveUp','usageLiveDown','overviewUp','overviewDown'])amyraxSet(id,'—');amyraxSet('trafficUpdated','دریافت آمار ناموفق؛ اعداد قبلی به‌روز نیستند.');}\r\n    finally{loading=false;}\r\n  }\r\n  const active=()=>navigator.onLine!==false&&document.visibilityState==='visible'&&($('viewHome')?.classList.contains('active')||$('viewUsage')?.classList.contains('active'));\r\n  setInterval(()=>{if(active())load();},5000);\r\n  window.addEventListener('hashchange',()=>{if(active())load();});\r\n  document.addEventListener('visibilitychange',()=>{if(active())load();});\r\n  window.addEventListener('amyrax-refresh',load);\n  window.addEventListener('online',()=>{if(active())load();});\r\n  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load);else load();\r\n})();\r\n\r\nconst amyraxSet = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };\r\nfunction amyraxBytes(value, speed = false) {\r\n  if(value===null||value===undefined||!Number.isFinite(Number(value)))return '—';\r\n  let n=Math.abs(Number(value)),i=0;const units=['B','KiB','MiB','GiB','TiB'];\r\n  while(n>=1024&&i<units.length-1){n/=1024;i++;}\r\n  return (Number(value)<0?'-':'')+n.toLocaleString('en-US',{maximumFractionDigits:i?2:0})+' '+units[i]+(speed?'/s':'');\r\n}\r\nfunction amyraxValue(id,value,speed=false){\r\n  amyraxSet(id,amyraxBytes(value,speed));const e=document.getElementById(id);\r\n  if(e)e.title=value!==null&&value!==undefined&&Number.isFinite(Number(value))?Number(value).toLocaleString('en-US',{maximumFractionDigits:2})+' bytes'+(speed?'/s':''):'';\r\n}\r\nfunction amyraxDuration(seconds) {\r\n  if(seconds===null||seconds===undefined||!Number.isFinite(Number(seconds)))return '—';\r\n  const s=Math.max(0,Math.floor(seconds)),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);\r\n  return (d?d+'d ':'')+(h?h+'h ':'')+m+'m '+(s%60)+'s';\r\n}\r\nlet amyraxResourceStamp=0;\r\nfunction updateAmyraxResources(system){\r\n  if(!system||system.sampledAt<amyraxResourceStamp)return;amyraxResourceStamp=system.sampledAt;\r\n  const memory=system.memory||{};\r\n  amyraxSet('overviewCores',system.cores??'—');amyraxSet('homeUptime',amyraxDuration(system.panelUptime));\r\n  amyraxSet('systemUptime',amyraxDuration(system.uptime));amyraxSet('systemUptimeLabel',system.uptimeScope==='container'?'فعالیت محیط اجرا':'فعالیت میزبان');\r\n  amyraxSet('memoryScope',memory.scope==='host'?'حافظهٔ میزبان':'حافظهٔ محیط اجرا');\r\n  amyraxValue('processMemory',system.processRss);amyraxValue('memoryUsed',memory.used);\r\n  amyraxSet('memoryTotal',memory.total?'/ '+amyraxBytes(memory.total):'سقف در دسترس نیست');\r\n  const pct=memory.total>0&&memory.used!==null?memory.used/memory.total*100:null;\r\n  amyraxSet('memoryPercent',pct===null?'—':pct.toFixed(0)+'%');\r\n  document.getElementById('memoryRing')?.style.setProperty('--pct',pct===null?0:Math.min(100,Math.max(0,pct)));\r\n}\r\nfunction updateAmyraxOverview(data) {\r\n  if (!data || !data.ok) return;\r\n  const system = data.system || {}, memory = system.memory || {};\r\n  const enabled = data.enabled || {}, engines = data.engines || {};\r\n  const nodes = (data.nodes || []).filter(n => n && n.uri);\r\n  amyraxSet('overviewHost', data.domain || data.host || '—');\r\n  amyraxSet('serverPlatform', system.os || '—');\r\n  amyraxSet('overviewPlatform', system.platform || '—');\r\n  amyraxSet('homeLocation', data.location || '—');\r\n  amyraxSet('homePort', data.publicPort || '—');\r\n  amyraxSet('statUptime', amyraxDuration(data.uptime));\r\n  amyraxSet('overviewNodes', nodes.length);\r\n  updateAmyraxResources(system);\r\n  updateAmyraxNetwork(data.network);\r\n  const singEnabled = Object.entries(enabled).some(([key, val]) => val && !['argo', 'vlessXhttp'].includes(key));\r\n  [['engineSingbox', engines.singbox, singEnabled], ['engineXray', engines.xray, enabled.vlessXhttp], ['engineArgo', engines.argo, enabled.argo]].forEach(([id, running, configured]) => {\r\n    const el = document.getElementById(id);\r\n    if (el) { el.textContent = running ? 'در حال اجرا' : configured ? 'متوقف' : 'غیرفعال'; el.classList.toggle('running', !!running); }\r\n  });\r\n  const active = Object.values(engines).filter(Boolean).length;\r\n  amyraxSet('engineCount', active + ' / 3 فعال');\r\n  amyraxSet('statEngines', active ? Object.keys(engines).filter(key => engines[key]).join(' + ') : 'موتور فعالی نیست');\r\n  amyraxSet('connectionLabel', active ? 'سرویس فعال' : 'پنل در دسترس');\r\n  document.getElementById('connectionState')?.classList.remove('offline');\r\n  document.getElementById('serverIndicator')?.style.setProperty('background', 'var(--primary-red)');\r\n  amyraxSet('overviewUpdated', 'آخرین دریافت: ' + new Date().toLocaleTimeString('fa-IR', {hour: '2-digit', minute: '2-digit'}));\r\n  const grouped = new Map();\r\n  for (const node of nodes) {\r\n    const type = String(node.type || 'OTHER').replace(/-/g, ' ').toUpperCase();\r\n    grouped.set(type, (grouped.get(type) || 0) + 1);\r\n  }\r\n  const protocolGrid = document.getElementById('protocolGrid');\r\n  if (protocolGrid) {\r\n    protocolGrid.replaceChildren();\r\n    for (const [name, count] of grouped) {\r\n      const item = document.createElement('div'); item.className = 'protocol-item';\r\n      const dot = document.createElement('span'); dot.className = 'status-dot';\r\n      const label = document.createElement('strong'); label.textContent = name;\r\n      const total = document.createElement('span'); total.textContent = count + ' کانفیگ';\r\n      item.append(dot, label, total); protocolGrid.append(item);\r\n    }\r\n    if (!grouped.size) { const message = document.createElement('p'); message.className = 'muted'; message.textContent = 'کانفیگی در دسترس نیست.'; protocolGrid.append(message); }\r\n  }\r\n  amyraxSet('protocolCount', grouped.size + ' نوع اتصال');\r\n}\r\nfunction updateAmyraxNetwork(report) {\r\n  if (!report) return;\r\n  amyraxSet('networkState', {pending:'در انتظار بررسی',ok:'بررسی سرور موفق',warning:'نیاز به بررسی',error:'اشکال در آدرس عمومی'}[report.state] || '—');\r\n  amyraxSet('networkSummary', report.message || '');\r\n  amyraxSet('networkEndpoint', report.endpoint || 'هنوز تنظیم نشده');\r\n  const list = document.getElementById('networkChecks');\r\n  if (list) {\r\n    list.replaceChildren();\r\n    for (const check of report.checks || []) {\r\n      const item = document.createElement('li');\r\n      item.dataset.state = check.state; item.textContent = check.message;\r\n      list.append(item);\r\n    }\r\n  }\r\n}\r\nlet amyraxNetworkLoading = false;\r\nasync function refreshAmyraxNetwork() {\r\n  if (amyraxNetworkLoading || navigator.onLine === false) return;\r\n  amyraxNetworkLoading = true;\r\n  const button = document.getElementById('checkNetwork');\r\n  if (button) button.disabled = true;\r\n  try {\r\n    const prefix = '/' + (location.pathname.split('/').filter(Boolean)[0] || 'amyrax');\r\n    updateAmyraxNetwork(await amyraxRequestJson(prefix + '/api/network', {timeoutMs:30000}));\r\n  } catch (_) { amyraxSet('networkSummary', 'گزارش دریافت نشد؛ اتصال را بررسی و دوباره تلاش کنید.'); }\r\n  finally { amyraxNetworkLoading = false; if (button) button.disabled = false; }\r\n}\r\ndocument.getElementById('checkNetwork')?.addEventListener('click', refreshAmyraxNetwork);\r\nfunction amyraxTraffic(data) {\r\n  if(!data?.ok||!data.live)return;\r\n  amyraxValue('overviewUp',data.live.upBps,true);amyraxValue('overviewDown',data.live.downBps,true);\r\n  amyraxValue('overviewSent',data.day.up);amyraxValue('overviewReceived',data.day.down);amyraxValue('overviewMonth',data.month.used);\r\n  amyraxSet('overviewConnections',data.connections?.accounts??'—');\r\n  amyraxSet('overviewTunnels',(data.connections?.tunnels??0)+' تونل باز');\r\n  const points=data.live.samples||[],latest=points.at(-1)?.t||Date.parse(data.now),start=latest-60000;\r\n  const visible=points.filter(p=>p.t>=start),peak=Math.max(1,...visible.flatMap(p=>[p.upBps,p.downBps]));\r\n  const line=key=>visible.map((p,i)=>((i===0||p.t-visible[i-1].t>3500)?'M':'L')+Math.max(0,(p.t-start)*500/60000).toFixed(1)+','+(100-p[key]/peak*90).toFixed(1)).join(' ');\r\n  document.getElementById('chartUp')?.setAttribute('d',line('upBps'));document.getElementById('chartDown')?.setAttribute('d',line('downBps'));\r\n  document.getElementById('chartArea')?.setAttribute('d','');\r\n  const empty=document.getElementById('chartEmpty');if(empty)empty.hidden=visible.some(p=>p.upBps>0||p.downBps>0);\r\n}\r\nfunction amyraxPageTitle(page) {\r\n  const pages = {\r\n    home: ['نمای کلی پنل', 'وضعیت اتصال، سرویس‌ها و مصرف ترافیک؛ همه در یک نگاه.', 'نمای کلی'],\r\n    subs: ['لینک‌های اشتراک', 'یک لینک برای وارد کردن همهٔ کانفیگ‌ها در برنامهٔ دلخواه شما.', 'اشتراک‌ها'],\r\n    nodes: ['کانفیگ‌های اتصال', 'کانفیگ دلخواه را انتخاب کنید، کپی کنید یا کد QR آن را اسکن کنید.', 'کانفیگ‌ها'],\r\n    studio: ['شخصی‌سازی اتصال', 'کانفیگ پیشرفته بسازید، در اشتراک ذخیره کنید یا خروجی پنل را به سرور دیگر متصل کنید.', 'شخصی‌سازی'],\r\n    users: ['مدیریت کاربران', 'ساخت اشتراک مستقل، تعیین حجم و زمان و پیگیری مصرف هر کاربر.', 'کاربران'],\r\n    usage: ['مصرف ترافیک', 'مصرف امروز، این ماه و جزئیات ترافیک هر پروتکل را دنبال کنید.', 'ترافیک']\r\n  };\r\n  const [title, description, breadcrumb] = pages[page] || pages.home;\r\n  amyraxSet('pageTitle', title); amyraxSet('pageDescription', description); amyraxSet('breadcrumbPage', breadcrumb);\r\n  document.querySelectorAll('.nav-link,.mob-link').forEach(link => {\r\n    if (link.dataset.page === page) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');\r\n  });\r\n}\r\nlet amyraxOverviewLoading = false;\r\nasync function amyraxRefresh() {\r\n  if (amyraxOverviewLoading || navigator.onLine === false) return;\r\n  amyraxOverviewLoading = true;\r\n  const button = document.getElementById('refreshOverview');\r\n  if (button) { button.disabled = true; button.classList.add('busy'); }\r\n  try {\r\n    const data = await amyraxRequestJson('/health');\r\n    updateAmyraxOverview(data);\r\n    renderNodes(data.nodes, data.location);\r\n  } catch (error) {\r\n    if (error.status === 401) { window.location.assign('/' + (location.pathname.split('/').filter(Boolean)[0] || 'amyrax') + '/login'); return; }\r\n    if (error.status === 503) { amyraxSet('overviewUpdated', 'سرور مشغول است؛ چند ثانیه بعد دوباره تلاش کنید.'); return; }\r\n    amyraxSet('connectionLabel', 'ارتباط قطع است');\r\n    document.getElementById('connectionState')?.classList.add('offline');\r\n    amyraxSet('overviewUpdated', 'دریافت وضعیت ناموفق بود؛ دوباره تلاش کنید.');\r\n  } finally { amyraxOverviewLoading = false; if (button) { button.disabled = false; button.classList.remove('busy'); } }\r\n}\r\ndocument.getElementById('refreshOverview')?.addEventListener('click', async () => { await amyraxRefresh(); window.dispatchEvent(new Event('amyrax-refresh')); });\r\ndocument.getElementById('drawerScrim')?.addEventListener('click', () => toggleDrawer(false));\r\nsetInterval(() => { if (document.visibilityState === 'visible' && document.getElementById('viewHome')?.classList.contains('active')) amyraxRefresh(); }, 30000);\nwindow.addEventListener('online', () => { amyraxRefresh(); });\r\n\r\nwindow.addEventListener(\"resize\", () => toggleDrawer(false));\r\n",
  bgJpg: "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOTIwIiBoZWlnaHQ9IjEyMDAiIHZpZXdCb3g9IjAgMCAxOTIwIDEyMDAiPjxkZWZzPjxyYWRpYWxHcmFkaWVudCBpZD0iZyI+PHN0b3Agc3RvcC1jb2xvcj0iIzFCOEQ3QiIgc3RvcC1vcGFjaXR5PSIuMiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzFCOEQ3QiIgc3RvcC1vcGFjaXR5PSIwIi8+PC9yYWRpYWxHcmFkaWVudD48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9Ijk2IiBoZWlnaHQ9Ijk2IiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNOTYgMEgwVjk2IiBmaWxsPSJub25lIiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS1vcGFjaXR5PSIuMDI1Ii8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTkyMCIgaGVpZ2h0PSIxMjAwIiBmaWxsPSIjMDkwRDE4Ii8+PGVsbGlwc2UgY3g9IjE0MDAiIGN5PSIyMDAiIHJ4PSI5MDAiIHJ5PSI4NTAiIGZpbGw9InVybCgjZykiLz48cmVjdCB3aWR0aD0iMTkyMCIgaGVpZ2h0PSIxMjAwIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTA0MCA5MCkgc2NhbGUoMS40KSIgb3BhY2l0eT0iLjAzNSI+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIyMzUsNDE1IDI2OSw0MTUgMjQ1LDQ4NSAyMDksNDg1Ii8+PHBvbHlnb24gZmlsbD0iI0FCQjNDNCIgcG9pbnRzPSIyMzUsNDE1IDI2OSw0MTUgMjYzLDQzMyAyMjgsNDMzIi8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIzNTAsOTggMzg0LDk4IDUyNSw0ODUgNDg5LDQ4NSIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMjc4LDk4IDMxNSw5OCAyMzgsMzA5IDI3MywzMDkgMzUwLDk4IDM4NCw5OCAyOTMsMzQ1IDIyMiwzNDUgMTg3LDM1MiIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMzQ5LDE5OCA0MDQsMzQ1IDIyMiwzNDUgMjM2LDMwOSAzNTUsMzA5IDMzMSwyNDgiLz48cG9seWdvbiBmaWxsPSIjQUJCM0M0IiBwb2ludHM9IjM1MCw5OCAzODQsOTggMzczLDEyOCAzNTgsMTcwIDM0NSwxMzciLz48cG9seWdvbiBmaWxsPSIjQzZDRERBIiBwb2ludHM9IjM0OSwxOTggMzYwLDIyOCAzNDMsMjc3IDMzMSwyNDgiLz48cG9seWdvbiBmaWxsPSIjMzhDOUFEIiBwb2ludHM9IjEzOSw0ODUgMTYwLDQyOSAxNjAsNDI5IDE2MS4zNjEsNDI1LjcyMiAxNjIuNzc4LDQyMi41NTYgMTY0LjI1LDQxOS41IDE2NS43NzgsNDE2LjU1NiAxNjcuMzYxLDQxMy43MjIgMTY5LDQxMSAxNzAuNjk0LDQwOC4zODkgMTcyLjQ0NCw0MDUuODg5IDE3NC4yNSw0MDMuNSAxNzYuMTExLDQwMS4yMjIgMTc4LjAyOCwzOTkuMDU2IDE4MCwzOTcgMTgyLjAyOCwzOTUuMDU2IDE4NC4xMTEsMzkzLjIyMiAxODYuMjUsMzkxLjUgMTg4LjQ0NCwzODkuODg5IDE5MC42OTQsMzg4LjM4OSAxOTMsMzg3IDE5NS4zNjEsMzg1LjcyMiAxOTcuNzc4LDM4NC41NTYgMjAwLjI1LDM4My41IDIwMi43NzgsMzgyLjU1NiAyMDUuMzYxLDM4MS43MjIgMjA4LDM4MSAyMTAuNjk0LDM4MC4zODkgMjEzLjQ0NCwzNzkuODg5IDIxNi4yNSwzNzkuNSAyMTkuMTExLDM3OS4yMjIgMjIyLjAyOCwzNzkuMDU2IDIyNSwzNzkgNDE3LDM3OSA0NTUsNDg1IDQxOSw0ODUgMzk0LDQxNSAyMzAsNDE1IDIzMCw0MTUgMjI4LjQ3OSw0MTUuMDM4IDIyNi45ODIsNDE1LjE1MSAyMjUuNTEsNDE1LjM0IDIyNC4wNjIsNDE1LjYwNCAyMjIuNjM5LDQxNS45NDQgMjIxLjI0LDQxNi4zNiAyMTkuODY2LDQxNi44NTEgMjE4LjUxNiw0MTcuNDE4IDIxNy4xOSw0MTguMDYgMjE1Ljg4OSw0MTguNzc4IDIxNC42MTIsNDE5LjU3MSAyMTMuMzYsNDIwLjQ0IDIxMi4xMzIsNDIxLjM4NCAyMTAuOTI5LDQyMi40MDQgMjA5Ljc1LDQyMy41IDIwOC41OTYsNDI0LjY3MSAyMDcuNDY2LDQyNS45MTggMjA2LjM2LDQyNy4yNCAyMDUuMjc5LDQyOC42MzggMjA0LjIyMiw0MzAuMTExIDIwMy4xOSw0MzEuNjYgMjAyLjE4Miw0MzMuMjg0IDIwMS4xOTksNDM0Ljk4NCAyMDAuMjQsNDM2Ljc2IDE5OS4zMDYsNDM4LjYxMSAxOTguMzk2LDQ0MC41MzggMTk3LjUxLDQ0Mi41NCAxOTYuNjQ5LDQ0NC42MTggMTk1LjgxMiw0NDYuNzcxIDE5NSw0NDkgMTc1LDQ4NSIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMjc4LDM4NiAyODYsMzg2IDI4Niw0MDggMjc4LDQwOCIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMzQzLDM4NiAzNTEsMzg2IDM1MSw0MDggMzQzLDQwOCIvPjwvZz48L3N2Zz4=",
  cozybgJpg: "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOTIwIiBoZWlnaHQ9IjEyMDAiIHZpZXdCb3g9IjAgMCAxOTIwIDEyMDAiPjxkZWZzPjxyYWRpYWxHcmFkaWVudCBpZD0iZyI+PHN0b3Agc3RvcC1jb2xvcj0iI0JENzYyNyIgc3RvcC1vcGFjaXR5PSIuMiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI0JENzYyNyIgc3RvcC1vcGFjaXR5PSIwIi8+PC9yYWRpYWxHcmFkaWVudD48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9Ijk2IiBoZWlnaHQ9Ijk2IiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNOTYgMEgwVjk2IiBmaWxsPSJub25lIiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS1vcGFjaXR5PSIuMDI1Ii8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTkyMCIgaGVpZ2h0PSIxMjAwIiBmaWxsPSIjMTQwRTBDIi8+PGVsbGlwc2UgY3g9IjE0MDAiIGN5PSIyMDAiIHJ4PSI5MDAiIHJ5PSI4NTAiIGZpbGw9InVybCgjZykiLz48cmVjdCB3aWR0aD0iMTkyMCIgaGVpZ2h0PSIxMjAwIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTA0MCA5MCkgc2NhbGUoMS40KSIgb3BhY2l0eT0iLjAzNSI+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIyMzUsNDE1IDI2OSw0MTUgMjQ1LDQ4NSAyMDksNDg1Ii8+PHBvbHlnb24gZmlsbD0iI0FCQjNDNCIgcG9pbnRzPSIyMzUsNDE1IDI2OSw0MTUgMjYzLDQzMyAyMjgsNDMzIi8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIzNTAsOTggMzg0LDk4IDUyNSw0ODUgNDg5LDQ4NSIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMjc4LDk4IDMxNSw5OCAyMzgsMzA5IDI3MywzMDkgMzUwLDk4IDM4NCw5OCAyOTMsMzQ1IDIyMiwzNDUgMTg3LDM1MiIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMzQ5LDE5OCA0MDQsMzQ1IDIyMiwzNDUgMjM2LDMwOSAzNTUsMzA5IDMzMSwyNDgiLz48cG9seWdvbiBmaWxsPSIjQUJCM0M0IiBwb2ludHM9IjM1MCw5OCAzODQsOTggMzczLDEyOCAzNTgsMTcwIDM0NSwxMzciLz48cG9seWdvbiBmaWxsPSIjQzZDRERBIiBwb2ludHM9IjM0OSwxOTggMzYwLDIyOCAzNDMsMjc3IDMzMSwyNDgiLz48cG9seWdvbiBmaWxsPSIjMzhDOUFEIiBwb2ludHM9IjEzOSw0ODUgMTYwLDQyOSAxNjAsNDI5IDE2MS4zNjEsNDI1LjcyMiAxNjIuNzc4LDQyMi41NTYgMTY0LjI1LDQxOS41IDE2NS43NzgsNDE2LjU1NiAxNjcuMzYxLDQxMy43MjIgMTY5LDQxMSAxNzAuNjk0LDQwOC4zODkgMTcyLjQ0NCw0MDUuODg5IDE3NC4yNSw0MDMuNSAxNzYuMTExLDQwMS4yMjIgMTc4LjAyOCwzOTkuMDU2IDE4MCwzOTcgMTgyLjAyOCwzOTUuMDU2IDE4NC4xMTEsMzkzLjIyMiAxODYuMjUsMzkxLjUgMTg4LjQ0NCwzODkuODg5IDE5MC42OTQsMzg4LjM4OSAxOTMsMzg3IDE5NS4zNjEsMzg1LjcyMiAxOTcuNzc4LDM4NC41NTYgMjAwLjI1LDM4My41IDIwMi43NzgsMzgyLjU1NiAyMDUuMzYxLDM4MS43MjIgMjA4LDM4MSAyMTAuNjk0LDM4MC4zODkgMjEzLjQ0NCwzNzkuODg5IDIxNi4yNSwzNzkuNSAyMTkuMTExLDM3OS4yMjIgMjIyLjAyOCwzNzkuMDU2IDIyNSwzNzkgNDE3LDM3OSA0NTUsNDg1IDQxOSw0ODUgMzk0LDQxNSAyMzAsNDE1IDIzMCw0MTUgMjI4LjQ3OSw0MTUuMDM4IDIyNi45ODIsNDE1LjE1MSAyMjUuNTEsNDE1LjM0IDIyNC4wNjIsNDE1LjYwNCAyMjIuNjM5LDQxNS45NDQgMjIxLjI0LDQxNi4zNiAyMTkuODY2LDQxNi44NTEgMjE4LjUxNiw0MTcuNDE4IDIxNy4xOSw0MTguMDYgMjE1Ljg4OSw0MTguNzc4IDIxNC42MTIsNDE5LjU3MSAyMTMuMzYsNDIwLjQ0IDIxMi4xMzIsNDIxLjM4NCAyMTAuOTI5LDQyMi40MDQgMjA5Ljc1LDQyMy41IDIwOC41OTYsNDI0LjY3MSAyMDcuNDY2LDQyNS45MTggMjA2LjM2LDQyNy4yNCAyMDUuMjc5LDQyOC42MzggMjA0LjIyMiw0MzAuMTExIDIwMy4xOSw0MzEuNjYgMjAyLjE4Miw0MzMuMjg0IDIwMS4xOTksNDM0Ljk4NCAyMDAuMjQsNDM2Ljc2IDE5OS4zMDYsNDM4LjYxMSAxOTguMzk2LDQ0MC41MzggMTk3LjUxLDQ0Mi41NCAxOTYuNjQ5LDQ0NC42MTggMTk1LjgxMiw0NDYuNzcxIDE5NSw0NDkgMTc1LDQ4NSIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMjc4LDM4NiAyODYsMzg2IDI4Niw0MDggMjc4LDQwOCIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMzQzLDM4NiAzNTEsMzg2IDM1MSw0MDggMzQzLDQwOCIvPjwvZz48L3N2Zz4=",
  homeJpg: "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAwIiBoZWlnaHQ9Ijc2MCIgdmlld0JveD0iMCAwIDEyMDAgNzYwIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImJnIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIHN0b3AtY29sb3I9IiMxOTFFMzAiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwOTBDMTYiLz48L2xpbmVhckdyYWRpZW50PjxyYWRpYWxHcmFkaWVudCBpZD0iZ2xvdyI+PHN0b3Agc3RvcC1jb2xvcj0iIzM4QzlBRCIgc3RvcC1vcGFjaXR5PSIuMiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzM4QzlBRCIgc3RvcC1vcGFjaXR5PSIwIi8+PC9yYWRpYWxHcmFkaWVudD48L2RlZnM+PHJlY3Qgd2lkdGg9IjEyMDAiIGhlaWdodD0iNzYwIiBmaWxsPSJ1cmwoI2JnKSIvPjxjaXJjbGUgY3g9Ijk5MCIgY3k9IjMzMCIgcj0iNDgwIiBmaWxsPSJ1cmwoI2dsb3cpIi8+PGcgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZmZmZmZmIiBzdHJva2Utb3BhY2l0eT0iLjA2Ij48Y2lyY2xlIGN4PSI5NjAiIGN5PSIzMDAiIHI9IjI1NSIvPjxjaXJjbGUgY3g9Ijk2MCIgY3k9IjMwMCIgcj0iMzMwIi8+PC9nPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDU3NSAxOCkgc2NhbGUoMS4wNikiPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMjM1LDQxNSAyNjksNDE1IDI0NSw0ODUgMjA5LDQ4NSIvPjxwb2x5Z29uIGZpbGw9IiNBQkIzQzQiIHBvaW50cz0iMjM1LDQxNSAyNjksNDE1IDI2Myw0MzMgMjI4LDQzMyIvPjxwb2x5Z29uIGZpbGw9IiNGNkY4RkMiIHBvaW50cz0iMzUwLDk4IDM4NCw5OCA1MjUsNDg1IDQ4OSw0ODUiLz48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjI3OCw5OCAzMTUsOTggMjM4LDMwOSAyNzMsMzA5IDM1MCw5OCAzODQsOTggMjkzLDM0NSAyMjIsMzQ1IDE4NywzNTIiLz48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjM0OSwxOTggNDA0LDM0NSAyMjIsMzQ1IDIzNiwzMDkgMzU1LDMwOSAzMzEsMjQ4Ii8+PHBvbHlnb24gZmlsbD0iI0FCQjNDNCIgcG9pbnRzPSIzNTAsOTggMzg0LDk4IDM3MywxMjggMzU4LDE3MCAzNDUsMTM3Ii8+PHBvbHlnb24gZmlsbD0iI0M2Q0REQSIgcG9pbnRzPSIzNDksMTk4IDM2MCwyMjggMzQzLDI3NyAzMzEsMjQ4Ii8+PHBvbHlnb24gZmlsbD0iIzM4QzlBRCIgcG9pbnRzPSIxMzksNDg1IDE2MCw0MjkgMTYwLDQyOSAxNjEuMzYxLDQyNS43MjIgMTYyLjc3OCw0MjIuNTU2IDE2NC4yNSw0MTkuNSAxNjUuNzc4LDQxNi41NTYgMTY3LjM2MSw0MTMuNzIyIDE2OSw0MTEgMTcwLjY5NCw0MDguMzg5IDE3Mi40NDQsNDA1Ljg4OSAxNzQuMjUsNDAzLjUgMTc2LjExMSw0MDEuMjIyIDE3OC4wMjgsMzk5LjA1NiAxODAsMzk3IDE4Mi4wMjgsMzk1LjA1NiAxODQuMTExLDM5My4yMjIgMTg2LjI1LDM5MS41IDE4OC40NDQsMzg5Ljg4OSAxOTAuNjk0LDM4OC4zODkgMTkzLDM4NyAxOTUuMzYxLDM4NS43MjIgMTk3Ljc3OCwzODQuNTU2IDIwMC4yNSwzODMuNSAyMDIuNzc4LDM4Mi41NTYgMjA1LjM2MSwzODEuNzIyIDIwOCwzODEgMjEwLjY5NCwzODAuMzg5IDIxMy40NDQsMzc5Ljg4OSAyMTYuMjUsMzc5LjUgMjE5LjExMSwzNzkuMjIyIDIyMi4wMjgsMzc5LjA1NiAyMjUsMzc5IDQxNywzNzkgNDU1LDQ4NSA0MTksNDg1IDM5NCw0MTUgMjMwLDQxNSAyMzAsNDE1IDIyOC40NzksNDE1LjAzOCAyMjYuOTgyLDQxNS4xNTEgMjI1LjUxLDQxNS4zNCAyMjQuMDYyLDQxNS42MDQgMjIyLjYzOSw0MTUuOTQ0IDIyMS4yNCw0MTYuMzYgMjE5Ljg2Niw0MTYuODUxIDIxOC41MTYsNDE3LjQxOCAyMTcuMTksNDE4LjA2IDIxNS44ODksNDE4Ljc3OCAyMTQuNjEyLDQxOS41NzEgMjEzLjM2LDQyMC40NCAyMTIuMTMyLDQyMS4zODQgMjEwLjkyOSw0MjIuNDA0IDIwOS43NSw0MjMuNSAyMDguNTk2LDQyNC42NzEgMjA3LjQ2Niw0MjUuOTE4IDIwNi4zNiw0MjcuMjQgMjA1LjI3OSw0MjguNjM4IDIwNC4yMjIsNDMwLjExMSAyMDMuMTksNDMxLjY2IDIwMi4xODIsNDMzLjI4NCAyMDEuMTk5LDQzNC45ODQgMjAwLjI0LDQzNi43NiAxOTkuMzA2LDQzOC42MTEgMTk4LjM5Niw0NDAuNTM4IDE5Ny41MSw0NDIuNTQgMTk2LjY0OSw0NDQuNjE4IDE5NS44MTIsNDQ2Ljc3MSAxOTUsNDQ5IDE3NSw0ODUiLz48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjI3OCwzODYgMjg2LDM4NiAyODYsNDA4IDI3OCw0MDgiLz48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjM0MywzODYgMzUxLDM4NiAzNTEsNDA4IDM0Myw0MDgiLz48L2c+PGcgZm9udC1mYW1pbHk9IkFyaWFsLHNhbnMtc2VyaWYiPjx0ZXh0IHg9IjkwIiB5PSIxNzUiIGZpbGw9IiNBNkFGQzEiIGZvbnQtc2l6ZT0iMjMiIGxldHRlci1zcGFjaW5nPSI2Ij5TVEFZIENPTk5FQ1RFRDwvdGV4dD48dGV4dCB4PSI4NSIgeT0iMjkyIiBmaWxsPSIjRjZGOEZDIiBmb250LXNpemU9IjkxIiBmb250LXdlaWdodD0iNzAwIj5BbXlyYXg8L3RleHQ+PHRleHQgeD0iODUiIHk9IjM5MCIgZmlsbD0iIzM4QzlBRCIgZm9udC1zaXplPSI5MSIgZm9udC13ZWlnaHQ9IjcwMCI+UGFuZWw8L3RleHQ+PHRleHQgeD0iOTAiIHk9IjQ2MCIgZmlsbD0iI0E2QUZDMSIgZm9udC1zaXplPSIyNiI+WW91ciBjb25uZWN0aW9uLiBXaXRob3V0IGxpbWl0cy48L3RleHQ+PHJlY3QgeD0iODgiIHk9IjUyMiIgd2lkdGg9IjM4MCIgaGVpZ2h0PSI3MiIgcng9IjM2IiBmaWxsPSIjMzhDOUFEIi8+PHBhdGggZD0ibTExOSA1NTcgMzQtMTMtNyAyOS0xMS04LTYgNiAxLTEwIDE2LTEyLTIwIDl6IiBmaWxsPSJ3aGl0ZSIvPjx0ZXh0IHg9IjE3MSIgeT0iNTY4IiBmaWxsPSIjZmZmZmZmIiBmb250LXNpemU9IjI4IiBmb250LXdlaWdodD0iNzAwIj5AQW15cmF4VlBOPC90ZXh0PjwvZz48L3N2Zz4=",
  logo: "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDI0IiBoZWlnaHQ9IjEwMjQiIHZpZXdCb3g9IjExMCA3MCA0NDYgNDQ2IiByb2xlPSJpbWciIGFyaWEtbGFiZWw9IkFteXJheCBQYW5lbCBsb2dvIj48dGl0bGU+QW15cmF4IFBhbmVsPC90aXRsZT48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjIzNSw0MTUgMjY5LDQxNSAyNDUsNDg1IDIwOSw0ODUiLz48cG9seWdvbiBmaWxsPSIjQUJCM0M0IiBwb2ludHM9IjIzNSw0MTUgMjY5LDQxNSAyNjMsNDMzIDIyOCw0MzMiLz48cG9seWdvbiBmaWxsPSIjRjZGOEZDIiBwb2ludHM9IjM1MCw5OCAzODQsOTggNTI1LDQ4NSA0ODksNDg1Ii8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIyNzgsOTggMzE1LDk4IDIzOCwzMDkgMjczLDMwOSAzNTAsOTggMzg0LDk4IDI5MywzNDUgMjIyLDM0NSAxODcsMzUyIi8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIzNDksMTk4IDQwNCwzNDUgMjIyLDM0NSAyMzYsMzA5IDM1NSwzMDkgMzMxLDI0OCIvPjxwb2x5Z29uIGZpbGw9IiNBQkIzQzQiIHBvaW50cz0iMzUwLDk4IDM4NCw5OCAzNzMsMTI4IDM1OCwxNzAgMzQ1LDEzNyIvPjxwb2x5Z29uIGZpbGw9IiNDNkNEREEiIHBvaW50cz0iMzQ5LDE5OCAzNjAsMjI4IDM0MywyNzcgMzMxLDI0OCIvPjxwb2x5Z29uIGZpbGw9IiMzOEM5QUQiIHBvaW50cz0iMTM5LDQ4NSAxNjAsNDI5IDE2MCw0MjkgMTYxLjM2MSw0MjUuNzIyIDE2Mi43NzgsNDIyLjU1NiAxNjQuMjUsNDE5LjUgMTY1Ljc3OCw0MTYuNTU2IDE2Ny4zNjEsNDEzLjcyMiAxNjksNDExIDE3MC42OTQsNDA4LjM4OSAxNzIuNDQ0LDQwNS44ODkgMTc0LjI1LDQwMy41IDE3Ni4xMTEsNDAxLjIyMiAxNzguMDI4LDM5OS4wNTYgMTgwLDM5NyAxODIuMDI4LDM5NS4wNTYgMTg0LjExMSwzOTMuMjIyIDE4Ni4yNSwzOTEuNSAxODguNDQ0LDM4OS44ODkgMTkwLjY5NCwzODguMzg5IDE5MywzODcgMTk1LjM2MSwzODUuNzIyIDE5Ny43NzgsMzg0LjU1NiAyMDAuMjUsMzgzLjUgMjAyLjc3OCwzODIuNTU2IDIwNS4zNjEsMzgxLjcyMiAyMDgsMzgxIDIxMC42OTQsMzgwLjM4OSAyMTMuNDQ0LDM3OS44ODkgMjE2LjI1LDM3OS41IDIxOS4xMTEsMzc5LjIyMiAyMjIuMDI4LDM3OS4wNTYgMjI1LDM3OSA0MTcsMzc5IDQ1NSw0ODUgNDE5LDQ4NSAzOTQsNDE1IDIzMCw0MTUgMjMwLDQxNSAyMjguNDc5LDQxNS4wMzggMjI2Ljk4Miw0MTUuMTUxIDIyNS41MSw0MTUuMzQgMjI0LjA2Miw0MTUuNjA0IDIyMi42MzksNDE1Ljk0NCAyMjEuMjQsNDE2LjM2IDIxOS44NjYsNDE2Ljg1MSAyMTguNTE2LDQxNy40MTggMjE3LjE5LDQxOC4wNiAyMTUuODg5LDQxOC43NzggMjE0LjYxMiw0MTkuNTcxIDIxMy4zNiw0MjAuNDQgMjEyLjEzMiw0MjEuMzg0IDIxMC45MjksNDIyLjQwNCAyMDkuNzUsNDIzLjUgMjA4LjU5Niw0MjQuNjcxIDIwNy40NjYsNDI1LjkxOCAyMDYuMzYsNDI3LjI0IDIwNS4yNzksNDI4LjYzOCAyMDQuMjIyLDQzMC4xMTEgMjAzLjE5LDQzMS42NiAyMDIuMTgyLDQzMy4yODQgMjAxLjE5OSw0MzQuOTg0IDIwMC4yNCw0MzYuNzYgMTk5LjMwNiw0MzguNjExIDE5OC4zOTYsNDQwLjUzOCAxOTcuNTEsNDQyLjU0IDE5Ni42NDksNDQ0LjYxOCAxOTUuODEyLDQ0Ni43NzEgMTk1LDQ0OSAxNzUsNDg1Ii8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIyNzgsMzg2IDI4NiwzODYgMjg2LDQwOCAyNzgsNDA4Ii8+PHBvbHlnb24gZmlsbD0iI0Y2RjhGQyIgcG9pbnRzPSIzNDMsMzg2IDM1MSwzODYgMzUxLDQwOCAzNDMsNDA4Ii8+PC9zdmc+",
  vazirmatnWoff2: "",
};

const AMYRAX_ASSET_VERSION = AMYRAX_VERSION + '-' + crypto.createHash('sha256')
  .update(EMBEDDED_ASSETS.appJs + EMBEDDED_ASSETS.appCss + EMBEDDED_ASSETS.subscriptionJs + EMBEDDED_ASSETS.subscriptionCss + EMBEDDED_ASSETS.qrJs + EMBEDDED_ASSETS.controlsJs + EMBEDDED_ASSETS.controlsCss + EMBEDDED_ASSETS.usersJs + EMBEDDED_ASSETS.usersCss + EMBEDDED_ASSETS.studioJs + EMBEDDED_ASSETS.studioCss)
  .digest('hex').slice(0, 10);

class AssetManager {
  static getIndexHtml() { return EMBEDDED_ASSETS.indexHtml; }
  static getAppCss() { return EMBEDDED_ASSETS.appCss; }
  static getAppJs() { return EMBEDDED_ASSETS.appJs; }
  static getSubscriptionHtml() { return EMBEDDED_ASSETS.subscriptionHtml; }

  static inlineDocument(html) {
    const styles = { 'studio.css':'studioCss', 'app.css':'appCss', 'users.css':'usersCss', 'controls.css':'controlsCss', 'subscription.css':'subscriptionCss' };
    const scripts = { 'studio.js':'studioJs', 'app.js':'appJs', 'users.js':'usersJs', 'controls.js':'controlsJs', 'subscription.js':'subscriptionJs', 'vendor/qrcode.js':'qrJs' };
    html = html.replace(/<link\b[^>]*rel="stylesheet"[^>]*href="\/amyrax-assets\/([^"?]+)(?:\?[^\"]*)?"[^>]*>/g, (tag,file) => styles[file]
      ? '<style data-amyrax-style="'+file+'">'+EMBEDDED_ASSETS[styles[file]].replace(/<\/style/gi,'<\\/style')+'</style>' : tag);
    const deferred = [];
    html = html.replace(/<script defer src="\/amyrax-assets\/([^"?]+)(?:\?[^\"]*)?"><\/script>/g, (tag,file) => {
      if (!scripts[file]) return tag;
      deferred.push(file); return '';
    });
    const scriptTag = file => '<script data-amyrax-script="'+file+'">'+EMBEDDED_ASSETS[scripts[file]].replace(/<\/script/gi,'<\\/script')+'</script>';
    html = html.replace(/<script src="\/amyrax-assets\/([^"?]+)(?:\?[^\"]*)?"><\/script>/g, (tag,file) => scripts[file] ? scriptTag(file) : tag);
    if (deferred.length) html = html.replace('</body>', () => deferred.map(scriptTag).join('\n')+'\n</body>');
    return html.replaceAll('/amyrax-assets/logo.svg','data:image/svg+xml;base64,'+EMBEDDED_ASSETS.logo);
  }

  static sendDocument(req,res,html) {
    res.type('html');
    res.setHeader('Cache-Control','private, no-store');
    res.setHeader('X-Content-Type-Options','nosniff');
    const nonce = crypto.randomBytes(18).toString('base64');
    const policy = res.getHeader('Content-Security-Policy') || "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'";
    res.setHeader('Content-Security-Policy',policy.replace("script-src 'self'", "script-src 'self' 'nonce-"+nonce+"'"));
    const body = Buffer.from(this.inlineDocument(html).replace(/<script\b/g, '<script nonce="'+nonce+'"'));
    return this.sendBuffer(req,res,body);
  }

  static sendJson(req,res,data) {
    res.setHeader('Content-Type','application/json; charset=utf-8');
    return this.sendBuffer(req,res,Buffer.from(JSON.stringify(data)));
  }

  static sendBuffer(req,res,body) {
    res.vary('Accept-Encoding');
    if (body.length < 1024 || !req.acceptsEncodings('gzip')) return res.send(body);
    return new Promise(resolve => {
      zlib.gzip(body,(error,compressed) => {
        if (res.destroyed || res.writableEnded) return resolve();
        try {
          if (!error && compressed.length < body.length) {
            res.setHeader('Content-Encoding','gzip');
            res.send(compressed);
          } else res.send(body);
          resolve();
        } catch (failure) { res.destroy(failure); resolve(); }
      });
    });
  }

  static _assetCandidates(filename) {
    const dirs = [
      path.join(process.cwd(), 'assets'),
      path.join(process.cwd()),
      path.join(__dirname, 'assets'),
      path.join(__dirname),
      path.join(__dirname, '..', 'assets')
    ];
    const list = [];
    const baseNoExt = filename.replace(/\.[^.]+$/, '');
    const ext = path.extname(filename);
    const variations = [
      filename,
      filename.toLowerCase(),
      filename.toUpperCase(),
      baseNoExt.toLowerCase() + ext.toLowerCase(),
      baseNoExt.toLowerCase() + ext.toUpperCase()
    ];
    for (const d of dirs) {
      for (const v of variations) {
        const full = path.join(d, v);
        if (!list.includes(full)) list.push(full);
      }
    }
    return list;
  }

  static _readFileCandidate(filenames) {
    const names = Array.isArray(filenames) ? filenames : [filenames];
    for (const name of names) {
      for (const p of this._assetCandidates(name)) {
        try {
          if (fs.existsSync(p)) {
            const buf = fs.readFileSync(p);
            if (buf && buf.length > 0) return buf;
          }
        } catch (_) {}
      }
    }
    return null;
  }

  static getBgJpg() {
    const buf = this._readFileCandidate(['bg.svg', 'bg.svg']);
    if (buf) return buf;
    if (EMBEDDED_ASSETS.bgJpg) {
      return Buffer.from(EMBEDDED_ASSETS.bgJpg, 'base64');
    }
    return null;
  }

  static getCozyBgJpg() {
    const buf = this._readFileCandidate(['cozybg.svg', 'cozybg.svg', 'cozy-bg.svg']);
    if (buf) return buf;
    if (EMBEDDED_ASSETS.cozybgJpg) {
      return Buffer.from(EMBEDDED_ASSETS.cozybgJpg, 'base64');
    }
    return null;
  }

  static getHomeJpg() {
    const buf = this._readFileCandidate(['home.svg']);
    if (buf) return buf;
    if (EMBEDDED_ASSETS.homeJpg) {
      return Buffer.from(EMBEDDED_ASSETS.homeJpg, 'base64');
    }
    return null;
  }

  static getLogo() {
    const buf = this._readFileCandidate(['logo.svg']);
    if (buf) return buf;
    if (EMBEDDED_ASSETS.logo) {
      return Buffer.from(EMBEDDED_ASSETS.logo, 'base64');
    }
    return null;
  }

  static getBgPng() { return this.getBgJpg(); }
  static getCozyBgPng() { return this.getCozyBgJpg(); }
  static getHomePng() { return this.getHomeJpg(); }
  static getLogoPng() { return this.getLogo(); }
}

function parseClientHello(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 42) {
    return { sni: null, alpn: [] };
  }

  try {
    if (buf[0] !== 0x16 || buf[1] !== 0x03) {
      return { sni: null, alpn: [] };
    }

    let offset = 5;
    if (buf[offset] !== 0x01) {
      return { sni: null, alpn: [] };
    }

    offset += 1 + 3 + 2 + 32;
    if (offset >= buf.length) return { sni: null, alpn: [] };

    const sessionIdLen = buf[offset];
    offset += 1 + sessionIdLen;
    if (offset + 2 > buf.length) return { sni: null, alpn: [] };

    const cipherSuitesLen = buf.readUInt16BE(offset);
    offset += 2 + cipherSuitesLen;
    if (offset + 1 > buf.length) return { sni: null, alpn: [] };

    const compMethodsLen = buf[offset];
    offset += 1 + compMethodsLen;
    if (offset + 2 > buf.length) return { sni: null, alpn: [] };

    const extTotalLen = buf.readUInt16BE(offset);
    offset += 2;
    const extLimit = Math.min(offset + extTotalLen, buf.length);

    let sni = null;
    const alpn = [];

    while (offset + 4 <= extLimit) {
      const extType = buf.readUInt16BE(offset);
      const extLen = buf.readUInt16BE(offset + 2);
      offset += 4;

      if (extType === 0x0000 && !sni) {
        if (offset + 2 <= extLimit) {
          const sniListLen = buf.readUInt16BE(offset);
          let sniOffset = offset + 2;
          const sniLimit = Math.min(sniOffset + sniListLen, extLimit);

          while (sniOffset + 3 <= sniLimit) {
            const nameType = buf[sniOffset];
            const nameLen = buf.readUInt16BE(sniOffset + 1);
            sniOffset += 3;

            if (nameType === 0x00 && sniOffset + nameLen <= buf.length) {
              sni = buf.toString('utf8', sniOffset, sniOffset + nameLen);
              break;
            }
            sniOffset += nameLen;
          }
        }
      } else if (extType === 0x0010) {
        if (offset + 2 <= extLimit) {
          const alpnListLen = buf.readUInt16BE(offset);
          let aOffset = offset + 2;
          const aLimit = Math.min(aOffset + alpnListLen, extLimit);
          while (aOffset + 1 <= aLimit) {
            const pLen = buf[aOffset];
            aOffset++;
            if (aOffset + pLen <= aLimit) {
              alpn.push(buf.toString('utf8', aOffset, aOffset + pLen));
            }
            aOffset += pLen;
          }
        }
      }

      offset += extLen;
    }

    return { sni, alpn };
  } catch {
    return { sni: null, alpn: [] };
  }
}

function parseClientHelloSni(buf) {
  return parseClientHello(buf).sni;
}

function parseClientHelloAlpn(buf) {
  return parseClientHello(buf).alpn;
}

const ANSI = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  teal: '\x1b[38;5;79m',
  electric: '\x1b[38;5;39m',
  navy: '\x1b[38;5;25m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  magenta: '\x1b[35m',
  white: '\x1b[37m'
};

class Logger {
  static quiet = false;
  static get verbose() { return process.env.AMYRAX_LOG_LEVEL === 'debug'; }
  static line(level,message,color=ANSI.teal) {
    const time = new Date().toISOString().slice(11,19);
    console.log(ANSI.dim+time+ANSI.reset+' '+color+level.padEnd(6)+ANSI.reset+' '+message);
  }
  static banner() {
    if (this.quiet) return;
    console.log('\n'+ANSI.bold+ANSI.teal+'  AMYRAX'+ANSI.reset+' / PANEL  '+ANSI.dim+'v'+AMYRAX_VERSION+ANSI.reset+'\n');
  }
  static renewNotice() {}
  static info(message) { if (!this.quiet && this.verbose) this.line('INFO',message,ANSI.cyan); }
  static success(message) { if (!this.quiet && this.verbose) this.line('OK',message,ANSI.green); }
  static step(message) { if (!this.quiet) this.line('SETUP',message); }
  static warn(message) { this.line('WARN',message,ANSI.yellow); }
  static error(message) { this.line('ERROR',message,ANSI.red); }
  static item(label,value) { this.info(label+': '+value); }
  static section(title) { this.info(title); }
  static ready(url,config,engines) {
    this.line('READY', amyraxOnRailway() && !NetworkSupport.publicHost(url) ? 'Railway service ready. Generate Domain in Settings -> Networking, then open /' + config.panelPath : url);
    this.line('CORE',Object.entries(engines).filter(([,running])=>running).map(([name])=>name).join(' / ') || 'No connection engine is running',ANSI.cyan);
    this.line('DATA',config.paths.dataDir,ANSI.dim);
    this.line('SOCIAL','https://t.me/AmyraxVPN',ANSI.dim);
    console.log('');
  }
}

function amyraxOnReplit() {
  return !!(process.env.REPLIT_DEPLOYMENT || process.env.REPL_ID || process.env.REPLIT_DOMAINS || process.env.REPLIT_DEV_DOMAIN);
}
function amyraxOnRailway() {
  return !!(process.env.RAILWAY_PROJECT_ID || process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_SERVICE_ID || process.env.RAILWAY_PUBLIC_DOMAIN);
}
function amyraxOnEdgeHost() { return amyraxOnReplit() || amyraxOnRailway(); }
function amyraxPlatformName() { return amyraxOnReplit() ? 'Replit' : (amyraxOnRailway() ? 'Railway' : (process.env.P_SERVER_UUID || NetworkSupport.botDomain(process.env.DOMAIN) ? 'Bot-Hosting' : 'Self-hosted')); }
function amyraxReplitDomain() {
  if (!process.env.REPLIT_DEPLOYMENT) return '';
  const list = String(process.env.REPLIT_DOMAINS || '').split(',').map((d) => normalizeHost(d)).filter(Boolean);
  return list.find((d) => !d.endsWith('.replit.app') && !d.endsWith('.replit.dev')) || list.find((d) => d.endsWith('.replit.app')) || '';
}
function amyraxIsPlatformHost(h) { return NetworkSupport.edgeDomain(h) || String(h || '').endsWith('.replit.dev'); }
function normalizeHost(v) { return NetworkSupport.host(v); }
function isIpLiteral(h) { return !!net.isIP(normalizeHost(h)); }
const DEFAULT_CONFIG = {
  brand: 'Amyrax Panel',
  product: 'Amyrax Panel',
  tagline: 'Connect with AmyraxVPN.',
  sponsorUrl: "",
  sponsorName: "",
  publicPort: parseInt(process.env.PORT || process.env.SERVER_PORT || '8080', 10) || 8080,
  panelPath: 'amyrax',
  dataDirHint: '/data',
  uuid: '',
  domain: '',
  forceHost: '',
  publicBaseUrl: process.env.PUBLIC_BASE_URL || process.env.SUB_BASE_URL || '',
  subBase: process.env.SUB_BASE || '',
  forceHttps: process.env.FORCE_HTTPS === 'true' || amyraxOnRailway(),
  allowLocalHostLinks: false,
  subscriptionName: 'کاربر اصلی',
  sniHy2: 'www.google.com',
  massProxyUrl: 'https://www.gstatic.com',
  enable: {
    hysteria2: false,
    vlessWs: amyraxOnRailway(),
    vlessWsTls: false,
    vlessHttpUpgrade: !amyraxOnRailway(),
    vlessXhttp: !amyraxOnRailway(),
    vlessGrpc: !amyraxOnRailway(),
    trojanWs: true,
    trojanGrpcTls: false,
    trojanWsTls: false,
    trojanHttpUpgrade: !amyraxOnRailway(),
    vmessHttpUpgrade: !amyraxOnRailway(),
    vlessHttpUpgradeTls: false,
    vmessHttpUpgradeTls: false,
    trojanHttpUpgradeTls: false,
    vmessGrpc: !amyraxOnRailway(),
    vmessGrpcTls: false,
    trojanGrpc: !amyraxOnRailway(),
    vlessXhttpTls: false,
    vlessXhttpStream: !amyraxOnRailway(),
    vlessXhttpStreamTls: false,
    vlessGrpcTls: false,
    vmessWsTls: false,
    vmessWs: true,
    reality: true,
    shadowTlsVless: false,
    shadowsocks: !amyraxOnRailway(),
    wireguard: true,
    tuic: false,
    socks: false,
    httpProxy: false,
    argo: false
  },
  argo: {
    domain: '',
    auth: '',
    localPort: 8001
  },
  reality: {
    target: 'www.microsoft.com',
    targetPort: 443,
    shortId: ''
  },
  shadowTls: {
    sni: 'www.microsoft.com',
    password: ''
  },
  shadowsocks: {
    method: 'aes-256-gcm',
    password: ''
  },
  wireguard: {
    port: 51820,
    serverIp: '10.66.66.1/24',
    clientIp: '10.66.66.2/32',
    mtu: 1420
  },
  tuic: {
    port: 8443,
    congestionController: 'bbr'
  },
  socks: {
    user: '',
    pass: ''
  },
  httpProxy: {
    user: '',
    pass: ''
  },
  singBoxVersion: '1.11.15',
  xrayVersion: '25.3.6',
  panelToken: '',
  cpuLimitPercent: null,
  quietConsoleAfterMs: 180000,
  channelUrl: 'https://t.me/AmyraxVPN'
};

function resolveDataDir(hint = '/data') {
  const tryDir = (dir) => {
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.accessSync(dir, fs.constants.W_OK);
      const probe = path.join(dir, '.amyrax-write-test');
      fs.writeFileSync(probe, 'ok'); fs.unlinkSync(probe);
      return true;
    } catch { return false; }
  };
  const explicit = process.env.AMYRAX_DATA_DIR || process.env.FILE_PATH;
  if (explicit) {
    const dir = UpgradeSupport.dataPath(explicit);
    if (!tryDir(dir)) throw new Error('AMYRAX_DATA_DIR is not writable: '+dir);
    resolveDataDir.info = {dir,source:'AMYRAX_DATA_DIR'};
    return dir;
  }
  if (hint && hint !== '/data') {
    const dir = UpgradeSupport.dataPath(hint);
    if (!tryDir(dir)) throw new Error('Configured data directory is not writable: '+dir);
    resolveDataDir.info = {dir,source:'configured data'};
    return dir;
  }
  const railwayVolume = process.env.RAILWAY_VOLUME_MOUNT_PATH;
  if (railwayVolume) {
    const dir = UpgradeSupport.dataPath(railwayVolume);
    if (!tryDir(dir)) throw new Error('Railway volume is not writable: ' + dir);
    resolveDataDir.info = {dir, source:'Railway volume (RAILWAY_VOLUME_MOUNT_PATH)'};
    return dir;
  }
  const candidates = [
    [process.env.RAILWAY_VOLUME_MOUNT_PATH, 'Railway volume (RAILWAY_VOLUME_MOUNT_PATH)'],
    [hint, 'default ' + hint],
    [path.join(process.cwd(), 'amyrax-data'), './amyrax-data fallback'],
    [path.join(__dirname, 'amyrax-data'), 'app-dir amyrax-data fallback'],
    [path.join(os.tmpdir(), 'amyrax-data'), 'temp-dir fallback']
  ];
  const oldDirs = UpgradeSupport.previousDataDirectories(process.cwd(),__dirname,os.tmpdir());
  for (const oldDir of oldDirs) {
    if (fs.existsSync(oldDir) && fs.existsSync(path.join(path.dirname(oldDir),'amyrax-data'))) {
      throw new Error('Two data stores exist. Set AMYRAX_DATA_DIR explicitly before starting.');
    }
  }
  const existing = [...candidates.map(([dir])=>dir), ...oldDirs].filter(Boolean).find(dir =>
    ['auth.json','state.json','users.json','traffic.json'].some(name=>fs.existsSync(path.join(dir,name))));
  if (existing) {
    const dir = UpgradeSupport.dataPath(existing);
    if (!tryDir(dir)) throw new Error('Existing Amyrax data directory is not writable: '+dir);
    resolveDataDir.info = {dir,source:'saved data'};
    return dir;
  }
  for (const [dir, source] of candidates) {
    if (dir && tryDir(dir)) { resolveDataDir.info = { dir, source }; return dir; }
  }
  const dir = path.join(os.tmpdir(), 'amyrax-data');
  resolveDataDir.info = { dir, source: 'temp-dir fallback (not writable?)' };
  return dir;
}

function buildConfig(userOverrides = {}) {
  const cfg = JSON.parse(JSON.stringify(DEFAULT_CONFIG));

  if (userOverrides && typeof userOverrides === 'object') {
    for (const [key, val] of Object.entries(userOverrides)) {
      if (val !== undefined && val !== null) {
        if (typeof val === 'object' && !Array.isArray(val) && cfg[key] && typeof cfg[key] === 'object') {
          cfg[key] = { ...cfg[key], ...val };
        } else {
          cfg[key] = val;
        }
      }
    }
  }

  const env = process.env;
  const parseBool = (v, defaultVal) => (v !== undefined ? v === '1' || v === 'true' : defaultVal);

  if (env.PORT || env.SERVER_PORT || env.SB_PORT) {
    const portValue = env.PORT || env.SERVER_PORT || env.SB_PORT;
    if (!/^\d+$/.test(portValue) || Number(portValue) < 1 || Number(portValue) > 65535) throw new Error('PORT / SERVER_PORT must be between 1 and 65535.');
    cfg.publicPort = Number(portValue);
  }
  if (env.UUID || env.SB_UUID) cfg.uuid = env.UUID || env.SB_UUID;
  if (env.DOMAIN || env.SB_DOMAIN) cfg.domain = env.DOMAIN || env.SB_DOMAIN;
  if (env.FORCE_HOST || env.CFIP) cfg.forceHost = env.FORCE_HOST || env.CFIP;
  if (env.ALLOW_LOCALHOST_LINKS !== undefined) cfg.allowLocalHostLinks = parseBool(env.ALLOW_LOCALHOST_LINKS, false);
  if (env.PANEL_PATH || env.SUB_PATH) cfg.panelPath = (env.PANEL_PATH || env.SUB_PATH).replace(/^\//, '');
  cfg.panelPath = UpgradeSupport.panel(cfg.panelPath);
  if (env.SUBSCRIPTION_NAME) cfg.subscriptionName = env.SUBSCRIPTION_NAME;
  if (env.PANEL_TOKEN) cfg.panelToken = env.PANEL_TOKEN;
  if (env.SNI_HY2 || env.SB_SNI) cfg.sniHy2 = env.SNI_HY2 || env.SB_SNI;
  if (env.MASS_PROXY_URL || env.SB_MASS_PROXY) cfg.massProxyUrl = env.MASS_PROXY_URL || env.SB_MASS_PROXY;

  if (env.ENABLE_HYSTERIA2 !== undefined) cfg.enable.hysteria2 = parseBool(env.ENABLE_HYSTERIA2, cfg.enable.hysteria2);
  if (env.ENABLE_VLESS_WS !== undefined) cfg.enable.vlessWs = parseBool(env.ENABLE_VLESS_WS, cfg.enable.vlessWs);
  if (env.ENABLE_HTTPUPGRADE !== undefined) cfg.enable.vlessHttpUpgrade = parseBool(env.ENABLE_HTTPUPGRADE, cfg.enable.vlessHttpUpgrade);
  if (env.ENABLE_XHTTP !== undefined) cfg.enable.vlessXhttp = parseBool(env.ENABLE_XHTTP, cfg.enable.vlessXhttp);
  else if (amyraxOnReplit()) cfg.enable.vlessXhttp = true;
  if (env.XRAY_VERSION) cfg.xrayVersion = String(env.XRAY_VERSION).trim().replace(/^v/i, '');
  if (env.ENABLE_REALITY !== undefined) cfg.enable.reality = parseBool(env.ENABLE_REALITY, cfg.enable.reality);
  if (env.ENABLE_VLESS_GRPC !== undefined) cfg.enable.vlessGrpc = parseBool(env.ENABLE_VLESS_GRPC, cfg.enable.vlessGrpc);
  if (env.ENABLE_TROJAN_WS !== undefined || env.ENABLE_TROJAN !== undefined) {
    cfg.enable.trojanWs = parseBool(env.ENABLE_TROJAN_WS !== undefined ? env.ENABLE_TROJAN_WS : env.ENABLE_TROJAN, cfg.enable.trojanWs);
  }
  if (env.ENABLE_SHADOWTLS_VLESS !== undefined) cfg.enable.shadowTlsVless = parseBool(env.ENABLE_SHADOWTLS_VLESS, cfg.enable.shadowTlsVless);
  if (env.ENABLE_SS !== undefined) cfg.enable.shadowsocks = parseBool(env.ENABLE_SS, cfg.enable.shadowsocks);
  if (env.ENABLE_WIREGUARD !== undefined || env.ENABLE_WG !== undefined) {
    cfg.enable.wireguard = parseBool(env.ENABLE_WIREGUARD !== undefined ? env.ENABLE_WIREGUARD : env.ENABLE_WG, cfg.enable.wireguard);
  }
  if (env.ENABLE_TUIC !== undefined) cfg.enable.tuic = parseBool(env.ENABLE_TUIC, cfg.enable.tuic);
  if (env.ENABLE_SOCKS !== undefined) cfg.enable.socks = parseBool(env.ENABLE_SOCKS, cfg.enable.socks);
  if (env.ENABLE_HTTP_PROXY !== undefined) cfg.enable.httpProxy = parseBool(env.ENABLE_HTTP_PROXY, cfg.enable.httpProxy);
  if (env.ENABLE_ARGO !== undefined) cfg.enable.argo = parseBool(env.ENABLE_ARGO, cfg.enable.argo);

  if (env.WG_PORT) cfg.wireguard.port = parseInt(env.WG_PORT, 10);
  if (env.WG_SERVER_IP) cfg.wireguard.serverIp = env.WG_SERVER_IP;
  if (env.WG_CLIENT_IP) cfg.wireguard.clientIp = env.WG_CLIENT_IP;

  if (env.TUIC_PORT) cfg.tuic.port = parseInt(env.TUIC_PORT, 10);
  if (env.TUIC_CC) cfg.tuic.congestionController = env.TUIC_CC;

  if (env.ARGO_DOMAIN) cfg.argo.domain = env.ARGO_DOMAIN;
  if (env.ARGO_AUTH) cfg.argo.auth = env.ARGO_AUTH;
  if (env.ARGO_PORT) cfg.argo.localPort = parseInt(env.ARGO_PORT, 10);

  if (env.REALITY_TARGET) cfg.reality.target = env.REALITY_TARGET;
  if (env.REALITY_TARGET_PORT) cfg.reality.targetPort = parseInt(env.REALITY_TARGET_PORT, 10);
  if (env.REALITY_SHORT_ID) cfg.reality.shortId = env.REALITY_SHORT_ID;

  if (env.SHADOWTLS_SNI) cfg.shadowTls.sni = env.SHADOWTLS_SNI;
  if (env.SHADOWTLS_PASSWORD) cfg.shadowTls.password = env.SHADOWTLS_PASSWORD;

  if (env.SS_METHOD) cfg.shadowsocks.method = env.SS_METHOD;
  if (env.SS_PASSWORD) cfg.shadowsocks.password = env.SS_PASSWORD;

  if (env.CPU_LIMIT_PERCENT) cfg.cpuLimitPercent = parseInt(env.CPU_LIMIT_PERCENT, 10);

  const domainInput = cfg.domain;
  for (const key of ['domain', 'forceHost']) {
    if (cfg[key] && !normalizeHost(cfg[key])) throw new Error((key === 'domain' ? 'DOMAIN' : 'FORCE_HOST') + ' must contain a valid hostname or IP address.');
  }
  cfg.domain = normalizeHost(cfg.domain) || amyraxReplitDomain() || normalizeHost(env.RAILWAY_PUBLIC_DOMAIN) || normalizeHost(env.RAILWAY_STATIC_URL) || '';
  cfg.forceHost = normalizeHost(cfg.forceHost) || '';
  if (!Number.isInteger(cfg.publicPort) || cfg.publicPort < 1 || cfg.publicPort > 65535) throw new Error('Public port must be between 1 and 65535.');
  if (env.LINK_PORT && (!/^\d+$/.test(env.LINK_PORT) || Number(env.LINK_PORT) < 1 || Number(env.LINK_PORT) > 65535)) throw new Error('LINK_PORT must be between 1 and 65535.');
  cfg.clientMtu = env.CLIENT_MTU === undefined ? 1400 : Number(env.CLIENT_MTU);
  if (!Number.isInteger(cfg.clientMtu) || cfg.clientMtu < 1280 || cfg.clientMtu > 1500) throw new Error('CLIENT_MTU must be between 1280 and 1500.');
  if (env.PUBLIC_BASE_URL || env.SUB_BASE_URL) cfg.publicBaseUrl = env.PUBLIC_BASE_URL || env.SUB_BASE_URL;
  if (env.SUB_BASE) cfg.subBase = env.SUB_BASE;
  if (env.FORCE_HTTPS !== undefined) cfg.forceHttps = parseBool(env.FORCE_HTTPS, false);
  if (!cfg.subBase && !cfg.publicBaseUrl) cfg.publicBaseUrl = NetworkSupport.configuredOrigin(domainInput, cfg);
  if (cfg.subBase || cfg.publicBaseUrl) NetworkSupport.origin(cfg, cfg.domain || cfg.forceHost);


  for (const key of Object.keys(cfg.enable)) if (!TransportSupport.variants.some(v=>v[3]===key)) cfg.enable[key] = false;

  cfg.shadowsocks.method = 'aes-256-gcm';
  cfg.transportState = { grpc: 0, xhttp: 0 };
  const dataDir = resolveDataDir(cfg.dataDirHint);
  const paths = {
    dataDir,
    stateFile: path.join(dataDir, 'state.json'),
    binDir: path.join(dataDir, 'bin'),
    certDir: path.join(dataDir, 'cert'),
    certPath: path.join(dataDir, 'cert', 'cert.pem'),
    keyPath: path.join(dataDir, 'cert', 'key.pem'),
    singboxBin: path.join(dataDir, 'bin', os.platform() === 'win32' ? 'sing-box.exe' : 'sing-box'),
    singboxConfig: path.join(dataDir, 'sing-box.json'),
    singboxLog: path.join(dataDir, 'sing-box.log'),
    xrayBin: path.join(dataDir, 'bin', os.platform() === 'win32' ? 'xray.exe' : 'xray'),
    xrayConfig: path.join(dataDir, 'xray.json'),
    xrayLog: path.join(dataDir, 'xray.log'),
    cloudflaredBin: path.join(dataDir, 'bin', os.platform() === 'win32' ? 'cloudflared.exe' : 'cloudflared'),
    cloudflaredLog: path.join(dataDir, 'cloudflared.log')
  };

  return {
    ...cfg,
    paths
  };
}

function findFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const address = srv.address();
      const port = typeof address === 'object' && address ? address.port : null;
      srv.close((err) => {
        if (err) return reject(err);
        if (!port) return reject(new Error('Failed to resolve ephemeral port'));
        resolve(port);
      });
    });
  });
}

async function allocatePorts(count = 1) {
  const ports = [];
  for (let i = 0; i < count; i++) {
    const p = await findFreePort();
    ports.push(p);
  }
  return count === 1 ? ports[0] : ports;
}

function deriveX25519PublicKey(privBase64) {
  try {
    if (!privBase64 || typeof privBase64 !== 'string') return null;
    const privBuf = Buffer.from(privBase64.trim(), 'base64');
    if (privBuf.length !== 32) return null;
    const pkcs8 = Buffer.concat([Buffer.from('302e020100300506032b656e04220420', 'hex'), privBuf]);
    const keyObj = crypto.createPrivateKey({ key: pkcs8, format: 'der', type: 'pkcs8' });
    return crypto.createPublicKey(keyObj).export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
  } catch {
    return null;
  }
}

class StateManager {
  constructor(paths, initialConfig) {
    this.paths = paths;
    this.config = initialConfig;
    this.state = {
      uuid: '',
      hy2Password: '',
      hy2ObfsPassword: '',
      realityPrivateKey: '',
      realityPublicKey: '',
      realityShortId: '',
      shadowTlsPassword: '',
      shadowsocksPassword: '',
      wireguardPrivateKey: '',
      wireguardPublicKey: '',
      wireguardClientPrivateKey: '',
      wireguardClientPublicKey: '',
      publicIp: '',
      links: [],
      clashYaml: '',
      singboxJson: '',
      xrayJson: '',
      base64Sub: '',
      updatedAt: null
    };
  }

  loadOrCreate() {
    try {
      fs.mkdirSync(this.paths.dataDir, { recursive: true });
      if (fs.existsSync(this.paths.stateFile)) {
        const raw = fs.readFileSync(this.paths.stateFile, 'utf8');
        const parsed = JSON.parse(raw);
        this.state = { ...this.state, ...parsed };
      }
    } catch (err) {
      Logger.warn(`Failed to read existing state.json: ${err.message}. Generating fresh state.`);
    }

    if (this.config.uuid) {
      this.state.uuid = this.config.uuid;
    } else if (!this.state.uuid) {
      this.state.uuid = crypto.randomUUID();
    }

    this.state.hy2Password = this.state.uuid;
    if (!this.state.hy2ObfsPassword) {
      this.state.hy2ObfsPassword = crypto.randomBytes(8).toString('hex');
    }

    if (this.config.shadowTls.password) {
      this.state.shadowTlsPassword = this.config.shadowTls.password;
    } else if (!this.state.shadowTlsPassword) {
      this.state.shadowTlsPassword = crypto.randomBytes(12).toString('hex');
    }

    if (this.config.shadowsocks.password) {
      this.state.shadowsocksPassword = this.config.shadowsocks.password;
    } else if (!this.state.shadowsocksPassword) {
      this.state.shadowsocksPassword = crypto.randomBytes(16).toString('base64url');
    }

    if (!(this.config.enable && this.config.enable.reality)) {
      this.state.realityShortId = '';
    } else if (this.config.reality.shortId) {
      this.state.realityShortId = this.config.reality.shortId;
    } else if (!this.state.realityShortId) {
      this.state.realityShortId = crypto.randomBytes(4).toString('hex');
    }

    if (this.config.enable && this.config.enable.wireguard) {
    const isValidKey = (k) => typeof k === 'string' && k.trim().length >= 40;
    let srvPriv = this.state.wireguardPrivateKey;
    let srvPub = this.state.wireguardPublicKey;
    let cliPriv = this.state.wireguardClientPrivateKey;
    let cliPub = this.state.wireguardClientPublicKey;

    if (!isValidKey(srvPriv) || !isValidKey(srvPub)) {
      try {
        const srv = crypto.generateKeyPairSync('x25519');
        srvPriv = srv.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64');
        srvPub = srv.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
      } catch (err) {
        Logger.warn(`Failed to generate WireGuard server keypair: ${err.message}`);
      }
    } else {
      const derived = deriveX25519PublicKey(srvPriv);
      if (derived) srvPub = derived;
    }

    if (!isValidKey(cliPriv) || !isValidKey(cliPub)) {
      try {
        const cli = crypto.generateKeyPairSync('x25519');
        cliPriv = cli.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64');
        cliPub = cli.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
      } catch (err) {
        Logger.warn(`Failed to generate WireGuard client keypair: ${err.message}`);
      }
    } else {
      const derived = deriveX25519PublicKey(cliPriv);
      if (derived) cliPub = derived;
    }

    this.state.wireguardPrivateKey = srvPriv;
    this.state.wireguardPublicKey = srvPub;
    this.state.wireguardClientPrivateKey = cliPriv;
    this.state.wireguardClientPublicKey = cliPub;
    } else {
      this.state.wireguardPrivateKey = '';
      this.state.wireguardPublicKey = '';
      this.state.wireguardClientPrivateKey = '';
      this.state.wireguardClientPublicKey = '';
    }

    this.save();
    return this.state;
  }

  setRealityKeys(privateKey, publicKey) {
    this.state.realityPrivateKey = privateKey;
    this.state.realityPublicKey = publicKey;
    this.save();
  }

  setWireGuardKeys(serverPriv, serverPub, clientPriv, clientPub) {
    this.state.wireguardPrivateKey = serverPriv;
    this.state.wireguardPublicKey = serverPub;
    this.state.wireguardClientPrivateKey = clientPriv;
    this.state.wireguardClientPublicKey = clientPub;
    this.save();
  }

  setLinks(links, clashYaml = '', singboxJson = '', xrayJson = '') {
    this.state.links = links;
    this.state.clashYaml = clashYaml;
    this.state.singboxJson = singboxJson;
    this.state.xrayJson = xrayJson;
    this.state.base64Sub = Buffer.from(links.join('\n')).toString('base64');
    this.save();
  }

  setPublicIp(ip) {
    this.state.publicIp = ip;
    this.save();
  }

  save() {
    try {
      this.state.updatedAt = new Date().toISOString();
      fs.mkdirSync(this.paths.dataDir, { recursive: true });
      fs.writeFileSync(this.paths.stateFile, JSON.stringify(this.state, null, 2), 'utf8');
    } catch (err) {
      Logger.warn(`Could not save state.json: ${err.message}`);
    }
  }
}

StateManager.deriveX25519PublicKey = deriveX25519PublicKey;

function getNormalizedArch() {
  const arch = os.arch();
  if (arch === 'arm64' || arch === 'aarch64') {
    return { sb: 'arm64', xray: 'arm64-v8a', cf: 'arm64' };
  }
  return { sb: 'amd64', xray: '64', cf: 'amd64' };
}

function checkDiskSpaceMb(dir) {
  if (os.platform() !== 'linux') return 1024;  
  try {
    const res = spawnSync('df', ['-m', dir], { encoding: 'utf8', timeout: 3000 });
    if (res.status === 0 && res.stdout) {
      const lines = res.stdout.trim().split('\n');
      if (lines.length >= 2) {
        const parts = lines[1].trim().split(/\s+/);
        const avail = parseInt(parts[3], 10);
        if (!isNaN(avail)) return avail;
      }
    }
  } catch {
  }
  return null;
}

async function downloadToFile(url, destPath) {
  const tempPath = `${destPath}.tmp_${crypto.randomBytes(8).toString('hex')}`;
  let lastError;
  for (let attempt = 0; attempt < 3; attempt++) {
    const controller = new AbortController();
    const deadline = setTimeout(() => controller.abort(), 180000);
    let stream;
    try {
      const response = await axios({method:'get', url, responseType:'stream', timeout:60000,
        signal:controller.signal, headers:{'User-Agent':'AmyraxPanel/' + AMYRAX_VERSION}});
      stream = response.data;
      await pipeline(stream, fs.createWriteStream(tempPath), {signal:controller.signal});
      if (!fs.statSync(tempPath).size) throw new Error('Downloaded file is empty');
      fs.renameSync(tempPath, destPath);
      if (os.platform() !== 'win32') fs.chmodSync(destPath, 0o755);
      return true;
    } catch (error) {
      lastError = error; stream?.destroy();
      try { fs.unlinkSync(tempPath); } catch {}
      const status = error.response?.status;
      if (status && status < 500 && status !== 408 && status !== 429) break;
      if (['EACCES','EPERM','ENOSPC'].includes(error.code)) break;
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 500 * 2 ** attempt));
    } finally { clearTimeout(deadline); }
  }
  throw lastError;
}

function extractFromZip(zipPath, wantNames) {
  const buf = fs.readFileSync(zipPath);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('zip: end of central directory not found');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let k = 0; k < count; k++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('zip: bad central directory');
    const method = buf.readUInt16LE(off + 10);
    const crc = buf.readUInt32LE(off + 16) >>> 0;
    const csize = buf.readUInt32LE(off + 20);
    const usize = buf.readUInt32LE(off + 24);
    const nlen = buf.readUInt16LE(off + 28), elen = buf.readUInt16LE(off + 30), clen = buf.readUInt16LE(off + 32);
    const lho = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nlen);
    off += 46 + nlen + elen + clen;
    const base = name.split('/').pop();
    if (!wantNames.includes(base)) continue;
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('zip: bad local header');
    const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('zip: unsupported compression method ' + method);
    if (data.length !== usize) throw new Error('zip: size mismatch for ' + base);
    if (typeof zlib.crc32 === 'function' && (zlib.crc32(data) >>> 0) !== crc) throw new Error('zip: CRC mismatch for ' + base);
    return { name: base, data };
  }
  return null;
}

async function fetchSha256Digest(url) {
  try {
    const r = await axios.get(url + '.dgst', { timeout: 20000, responseType: 'text', headers: { 'User-Agent': 'AmyraxPanel/1.0' } });
    const m = /SHA2?-?256[^=]*=\s*([0-9a-f]{64})/i.exec(String(r.data || ''));
    return m ? m[1].toLowerCase() : null;
  } catch (_) {
    return null;
  }
}

class BinaryManager {
  constructor(config) {
    this.config = config;
    this.paths = config.paths;
    this.arch = getNormalizedArch();
  }

  ensureDirectories() {
    fs.mkdirSync(this.paths.dataDir, { recursive: true });
    fs.mkdirSync(this.paths.binDir, { recursive: true });
    fs.mkdirSync(this.paths.certDir, { recursive: true });
  }

  seedBundledBinary(name, version) {
    const directory = process.env.AMYRAX_BUNDLED_BIN_DIR;
    if (!directory) return;
    let temporary;
    try {
      const manifest = JSON.parse(fs.readFileSync(path.join(directory, 'manifest.json'), 'utf8'));
      const cached = manifest.binaries?.[name];
      if (manifest.platform !== os.platform() || manifest.arch !== os.arch() || cached?.version !== version) return;
      const destination = name === 'sing-box' ? this.paths.singboxBin : this.paths.xrayBin;
      const bundled = path.join(directory, path.basename(destination));
      const digest = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
      if (digest(bundled) !== cached.sha256) throw new Error('Bundled binary checksum mismatch');
      if (fs.existsSync(destination) && digest(destination) === cached.sha256) return;
      temporary = destination + '.bundled-' + process.pid;
      fs.copyFileSync(bundled, temporary);
      if (os.platform() !== 'win32') fs.chmodSync(temporary, 0o755);
      fs.renameSync(temporary, destination);
    } catch (error) {
      if (temporary) { try { fs.unlinkSync(temporary); } catch {} }
      Logger.warn('Bundled ' + name + ' cache unavailable; using the normal installer: ' + error.message);
    }
  }

  async ensureSingBox() {
    this.ensureDirectories();
    const bin = this.paths.singboxBin;
    if (!process.env.SB_URL) this.seedBundledBinary('sing-box', this.config.singBoxVersion || '1.11.15');

    if (fs.existsSync(bin)) {
      try {
        const stat = fs.statSync(bin);
        if (stat.size > 1024 * 1024) {
          if (os.platform() !== 'win32') fs.chmodSync(bin, 0o755);
          return true;
        }
      } catch {}
    }

    const freeMb = checkDiskSpaceMb(this.paths.binDir);
    if (freeMb !== null && freeMb < 40) {
      Logger.warn(`Low disk space (~${freeMb}MB free). sing-box download might fail with ENOSPC.`);
    }

    const ver = this.config.singBoxVersion || '1.11.15';
    const osType = os.platform() === 'win32' ? 'windows' : 'linux';
    const ext = osType === 'windows' ? 'zip' : 'tar.gz';
    const tarName = `sing-box-${ver}-${osType}-${this.arch.sb}.${ext}`;
    const url = process.env.SB_URL || `https://github.com/SagerNet/sing-box/releases/download/v${ver}/${tarName}`;
    const archivePath = path.join(this.paths.binDir, tarName);

    Logger.step(`Downloading sing-box v${ver} (${osType}-${this.arch.sb})...`);

    try {
      await downloadToFile(url, archivePath);

      if (osType === 'linux') {
        const extDir = path.join(this.paths.binDir, `sb_extract_${Date.now()}`);
        fs.mkdirSync(extDir, { recursive: true });
        const tarRes = spawnSync('tar', ['-xzf', archivePath, '-C', extDir]);
        if (tarRes.status !== 0) throw new Error(`tar extraction failed: ${tarRes.stderr}`);

        const files = fs.readdirSync(extDir);
        let foundBin = null;
        for (const f of files) {
          const sub = path.join(extDir, f);
          if (fs.statSync(sub).isDirectory()) {
            const candidate = path.join(sub, 'sing-box');
            if (fs.existsSync(candidate)) {
              foundBin = candidate;
              break;
            }
          }
        }

        if (!foundBin && fs.existsSync(path.join(extDir, 'sing-box'))) {
          foundBin = path.join(extDir, 'sing-box');
        }

        if (!foundBin) throw new Error('sing-box binary not found in archive');

        fs.copyFileSync(foundBin, bin);
        fs.chmodSync(bin, 0o755);

        try {
          fs.unlinkSync(archivePath);
          fs.rmSync(extDir, { recursive: true, force: true });
        } catch {}
      }

      if (osType === 'windows') {
        const entry = extractFromZip(archivePath, ['sing-box.exe']);
        if (!entry) throw new Error('sing-box.exe not found in archive');
        fs.writeFileSync(bin,entry.data);
        fs.unlinkSync(archivePath);
      }
      const probe = spawnSync(bin,['version'],{encoding:'utf8',windowsHide:true,timeout:10000});
      if (probe.status !== 0) throw new Error('Installed sing-box binary is not runnable');
      Logger.success('sing-box engine installed successfully.');
      return true;
    } catch (err) {
      Logger.error(`sing-box installation error: ${err.message}`);
      return false;
    }
  }

  async ensureXray() {
    this.ensureDirectories();
    const bin = this.paths.xrayBin;
    const want = String(process.env.XRAY_VERSION || this.config.xrayVersion || '').trim().replace(/^v/i, '');
    if (!process.env.XRAY_URL) this.seedBundledBinary('xray', want);
    const probe = () => {
      try {
        const r = spawnSync(bin, ['version'], { encoding: 'utf8', timeout: 15000 });
        const m = /Xray\s+v?(\d+\.\d+\.\d+)/.exec(r.stdout || '');
        return r.status === 0 && m ? m[1] : null;
      } catch (_) { return null; }
    };

    if (fs.existsSync(bin)) {
      if (os.platform() !== 'win32') { try { fs.chmodSync(bin, 0o755); } catch (_) {} }
      const have = probe();
      if (have && (!want || want === have)) {
        Logger.success(`Xray-core ${have} ready (cached in ${this.paths.binDir}).`);
        return true;
      }
      if (have) Logger.info(`Xray-core ${have} cached but XRAY_VERSION=${want} requested - downloading.`);
      else Logger.warn('Cached Xray-core binary is not runnable - re-downloading.');
    }

    const freeMb = checkDiskSpaceMb(this.paths.binDir);
    if (freeMb !== null && freeMb < 60) {
      Logger.warn(`Low disk space (~${freeMb}MB free). Xray-core download might fail.`);
    }

    const osType = os.platform() === 'win32' ? 'windows' : 'linux';
    const zipName = `Xray-${osType}-${this.arch.xray}.zip`;
    const url = process.env.XRAY_URL || (want
      ? `https://github.com/XTLS/Xray-core/releases/download/v${want}/${zipName}`
      : `https://github.com/XTLS/Xray-core/releases/latest/download/${zipName}`);
    const exeName = osType === 'windows' ? 'xray.exe' : 'xray';
    Logger.step(`Downloading Xray-core ${want ? 'v' + want : '(latest stable)'} (${osType}-${this.arch.xray})...`);

    for (let attempt = 1; attempt <= 3; attempt++) {
      const archivePath = path.join(this.paths.binDir, `${zipName}.${Date.now()}`);
      const tmpBin = bin + '.new';
      try {
        await downloadToFile(url, archivePath);
        if (!process.env.XRAY_URL) {
          const expected = await fetchSha256Digest(url);
          const actual = crypto.createHash('sha256').update(fs.readFileSync(archivePath)).digest('hex');
          if (expected && expected !== actual) throw new Error('SHA-256 mismatch (download corrupted)');
          if (expected) Logger.info('Xray-core archive SHA-256 verified.');
          else Logger.warn('Xray-core .dgst not available; skipped SHA-256 check.');
        }
        const entry = extractFromZip(archivePath, [exeName]);
        if (!entry) throw new Error(exeName + ' not found in archive');
        fs.writeFileSync(tmpBin, entry.data);
        if (os.platform() !== 'win32') fs.chmodSync(tmpBin, 0o755);
        fs.renameSync(tmpBin, bin);
        const ver = probe();
        if (!ver) throw new Error('downloaded binary does not run');
        Logger.success(`Xray-core ${ver} installed (${osType}-${this.arch.xray}).`);
        return true;
      } catch (err) {
        Logger.warn(`Xray-core download attempt ${attempt}/3 failed: ${err.message}`);
        await new Promise(r => setTimeout(r, 2000 * attempt));
      } finally {
        try { fs.unlinkSync(archivePath); } catch (_) {}
        try { if (fs.existsSync(tmpBin)) fs.unlinkSync(tmpBin); } catch (_) {}
      }
    }
    Logger.error('Xray-core unavailable - VLESS-XHTTP disabled for this run.');
    return false;
  }

  async ensureCloudflared() {
    this.ensureDirectories();
    const bin = this.paths.cloudflaredBin;

    if (fs.existsSync(bin)) {
      try {
        if (fs.statSync(bin).size > 1024 * 1024) {
          if (os.platform() !== 'win32') fs.chmodSync(bin, 0o755);
          return true;
        }
      } catch {}
    }

    const url = os.platform() === 'win32'
      ? `https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-${this.arch.cf === 'arm64' ? 'arm64' : 'amd64'}.exe`
      : `https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${this.arch.cf}`;

    Logger.step('Downloading optional Cloudflare Argo tunnel agent (cloudflared)...');

    try {
      await downloadToFile(url, bin);
      if (os.platform() !== 'win32') fs.chmodSync(bin, 0o755);
      Logger.success('cloudflared installed successfully.');
      return true;
    } catch (err) {
      Logger.warn(`Optional cloudflared download skipped: ${err.message}. Argo tunnel will be inactive.`);
      return false;
    }
  }
}

function asn1(tag, ...children) {
  const content = Buffer.concat(children);
  let len;
  if (content.length < 128) {
    len = Buffer.from([content.length]);
  } else if (content.length < 256) {
    len = Buffer.from([0x81, content.length]);
  } else if (content.length < 65536) {
    len = Buffer.from([0x82, (content.length >> 8) & 0xff, content.length & 0xff]);
  } else {
    len = Buffer.from([0x83, (content.length >> 16) & 0xff, (content.length >> 8) & 0xff, content.length & 0xff]);
  }
  return Buffer.concat([Buffer.from([tag]), len, content]);
}

function seq(...ch) { return asn1(0x30, ...ch); }
function int(val) { return asn1(0x02, Buffer.isBuffer(val) ? val : Buffer.from([val])); }
function oid(bytes) { return asn1(0x06, Buffer.from(bytes)); }
function utf8(str) { return asn1(0x0c, Buffer.from(str, 'utf8')); }
function utcTime(d) {
  const pad = n => String(n).padStart(2, '0');
  const s = String(d.getUTCFullYear()).slice(2) + pad(d.getUTCMonth() + 1) + pad(d.getUTCDate()) + pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + pad(d.getUTCSeconds()) + 'Z';
  return asn1(0x17, Buffer.from(s, 'ascii'));
}

function generateSelfSignedCert(commonName = 'localhost') {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const spkiDer = publicKey.export({ type: 'spki', format: 'der' });

  const sigAlg = seq(oid([0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x0b]), Buffer.from([0x05, 0x00]));
  const name = seq(asn1(0x31, seq(oid([0x55, 0x04, 0x03]), utf8(commonName))));
  const now = new Date();
  const notAfter = new Date(now.getTime() + 365 * 24 * 3600 * 1000);
  const validity = seq(utcTime(now), utcTime(notAfter));
  const serial = crypto.randomBytes(8);
  serial[0] &= 0x7f;  

  const tbs = seq(
    asn1(0xa0, int(2)),  
    int(serial),
    sigAlg,
    name,
    validity,
    name,
    spkiDer
  );

  const sig = crypto.sign('sha256', tbs, privateKey);
  const bitSig = Buffer.concat([Buffer.from([0x00]), sig]);
  const certDer = seq(tbs, sigAlg, asn1(0x03, bitSig));
  const certPem = '-----BEGIN CERTIFICATE-----\n' + certDer.toString('base64').match(/.{1,64}/g).join('\n') + '\n-----END CERTIFICATE-----\n';
  const keyPem = privateKey.export({ type: 'pkcs8', format: 'pem' });

  return { certPem, keyPem };
}

function ensureTlsCertificates(certPath, keyPath, sni = 'localhost') {
  try {
    if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
      const c = fs.readFileSync(certPath, 'utf8');
      const k = fs.readFileSync(keyPath, 'utf8');
      if (c.includes('BEGIN CERTIFICATE') && k.includes('PRIVATE KEY')) {
        return { cert: c, key: k };
      }
    }
  } catch (_) {}

  const certDir = path.dirname(certPath);
  try {
    fs.mkdirSync(certDir, { recursive: true });
  } catch (_) {}

  try {
    const res = spawnSync('openssl', [
      'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
      '-subj', `/CN=${sni}`,
      '-keyout', keyPath,
      '-out', certPath,
      '-days', '365'
    ], { timeout: 15000 });
    if (res.status === 0 && fs.existsSync(certPath) && fs.existsSync(keyPath)) {
      return {
        cert: fs.readFileSync(certPath, 'utf8'),
        key: fs.readFileSync(keyPath, 'utf8')
      };
    }
  } catch (_) {}

  try {
    const { certPem, keyPem } = generateSelfSignedCert(sni);
    fs.writeFileSync(keyPath, keyPem, 'utf8');
    fs.writeFileSync(certPath, certPem, 'utf8');
    return { cert: certPem, key: keyPem };
  } catch (err) {
    Logger.error(`Failed to generate TLS cert: ${err.message}`);
    return null;
  }
}

class SingBoxEngine {
  constructor(config, stateManager, allocatedPorts) {
    this.config = config;
    this.paths = config.paths;
    this.stateManager = stateManager;
    this.ports = allocatedPorts;
    this.process = null;
  }

  generateRealityKeys() {
    if (!(this.config.enable && this.config.enable.reality)) return;
    const state = this.stateManager.state;
    if (state.realityPrivateKey && state.realityPublicKey) {
      return;
    }

    if (fs.existsSync(this.paths.singboxBin)) {
      try {
        const res = spawnSync(this.paths.singboxBin, ['generate', 'reality-keypair'], {
          encoding: 'utf8',
          timeout: 10000
        });
        const privMatch = /PrivateKey:\s*(\S+)/i.exec(res.stdout || '');
        const pubMatch = /PublicKey:\s*(\S+)/i.exec(res.stdout || '');

        if (privMatch && pubMatch) {
          this.stateManager.setRealityKeys(privMatch[1], pubMatch[1]);
          Logger.success('Generated fresh REALITY keypair.');
          return;
        }
      } catch (_) {}
    }

    try {
      const kp = crypto.generateKeyPairSync('x25519');
      const priv = kp.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64url');
      const pub = kp.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64url');
      this.stateManager.setRealityKeys(priv, pub);
      Logger.success('Generated fresh REALITY keypair via crypto.');
    } catch (err) {
      Logger.warn(`Reality keygen error: ${err.message}.`);
    }
  }

  buildJsonConfig() {
    const state = this.stateManager.state;
    const enable = this.config.enable;
    const wsPath = '/Telegram=@AmyraxVPN';
    const vmessPath = '/Telegram=@AmyraxVPN';
    const huPath = '/Telegram=@AmyraxVPN';

    const inbounds = [];

    if (TransportSupport.variants.some(([protocol,,,flag])=>protocol==='vmess'&&enable[flag]) && this.ports.vmessWs) {
      inbounds.push({type:'vmess',tag:'vmess-ws-in',listen:'127.0.0.1',listen_port:this.ports.vmessWs,users:[{uuid:state.uuid,alterId:0}]});
    }
    if (TransportSupport.variants.some(([protocol,,,flag])=>protocol==='vless'&&enable[flag]) && this.ports.vlessWs) {
      inbounds.push({type:'vless',tag:'vless-ws-in',listen:'127.0.0.1',listen_port:this.ports.vlessWs,users:[{uuid:state.uuid,flow:''}]});
    }

    if (enable.vlessHttpUpgrade && this.ports.vlessHu) {
      inbounds.push({
        type: 'vless',
        tag: 'vless-hu-in',
        listen: '127.0.0.1',
        listen_port: this.ports.vlessHu,
        users: [
          { uuid: state.uuid, flow: '' }
        ],
        tls: { enabled: false },
        transport: {
          type: 'httpupgrade',
          path: huPath
        }
      });
    }

    if (enable.reality && this.ports.reality && state.realityPrivateKey) {
      inbounds.push({
        type: 'vless',
        tag: 'vless-reality-in',
        listen: '127.0.0.1',
        listen_port: this.ports.reality,
        users: [
          { uuid: state.uuid, flow: 'xtls-rprx-vision' }
        ],
        tls: {
          enabled: true,
          server_name: this.config.reality.target || 'www.microsoft.com',
          alpn: ['http/1.1'],
          reality: {
            enabled: true,
            handshake: {
              server: this.config.reality.target || 'www.microsoft.com',
              server_port: this.config.reality.targetPort || 443
            },
            private_key: state.realityPrivateKey,
            short_id: [state.realityShortId]
          }
        }
      });
    }

    if (enable.shadowTlsVless && this.ports.shadowTls) {
      inbounds.push(
        {
          type: 'shadowtls',
          tag: 'shadowtls-in',
          listen: '127.0.0.1',
          listen_port: this.ports.shadowTls,
          version: 3,
          users: [
            { name: 'amyrax-user', password: state.shadowTlsPassword }
          ],
          handshake: {
            server: this.config.shadowTls.sni || 'www.microsoft.com',
            server_port: 443
          },
          strict_mode: true,
          detour: 'vless-shadowtls-detour'
        },
        {
          type: 'vless',
          tag: 'vless-shadowtls-detour',
          listen: '127.0.0.1',
          listen_port: 0,
          users: [
            { uuid: state.uuid, flow: '' }
          ]
        }
      );
    }

    if (enable.shadowsocks && this.ports.shadowsocks) {
      inbounds.push({
        type: 'shadowsocks',
        tag: 'ss-in',
        listen: '127.0.0.1',
        listen_port: this.ports.shadowsocks,
        method: 'aes-256-gcm',
        network: 'tcp',
        password: state.shadowsocksPassword
      });
    }

    if (enable.socks && this.ports.socks) {
      inbounds.push({
        type: 'socks',
        tag: 'socks-in',
        listen: '127.0.0.1',
        listen_port: this.ports.socks,
        users: this.config.socks.user
          ? [{ username: this.config.socks.user, password: this.config.socks.pass }]
          : []
      });
    }

    if (enable.httpProxy && this.ports.httpProxy) {
      inbounds.push({
        type: 'http',
        tag: 'http-in',
        listen: '127.0.0.1',
        listen_port: this.ports.httpProxy,
        users: this.config.httpProxy.user
          ? [{ username: this.config.httpProxy.user, password: this.config.httpProxy.pass }]
          : []
      });
    }

    if (this.ports.trojanWs) {
      inbounds.push({type:'trojan',tag:'trojan-in',listen:'127.0.0.1',listen_port:this.ports.trojanWs,users:[{password:state.uuid}]});
    }

    if (enable.trojanGrpcTls && this.ports.trojanGrpcTls) {
      ensureTlsCertificates(this.paths.certPath, this.paths.keyPath, this.config.domain || 'www.google.com');
      inbounds.push({
        type: 'trojan',
        tag: 'trojan-grpc-tls-in',
        listen: '127.0.0.1',
        listen_port: this.ports.trojanGrpcTls,
        users: [
          { password: state.uuid }
        ],
        tls: {
          enabled: true,
          server_name: this.config.domain || 'www.google.com',
          alpn: ['h2'],
          certificate_path: this.paths.certPath,
          key_path: this.paths.keyPath
        },
        transport: {
          type: 'grpc',
          service_name: 'Telegram=@AmyraxVPN'
        }
      });
    }

    if (enable.vlessGrpc && this.ports.vlessGrpc) {
      inbounds.push({
        type: 'vless',
        tag: 'vless-grpc-in',
        listen: '127.0.0.1',
        listen_port: this.ports.vlessGrpc,
        users: [
          { uuid: state.uuid, flow: '' }
        ],
        tls: { enabled: false },
        transport: {
          type: 'grpc',
          service_name: 'Telegram=@AmyraxVPN'
        }
      });
    }

    if (enable.tuic && this.config.tuic) {
      inbounds.push({
        type: 'tuic',
        tag: 'tuic-in',
        listen: '::',
        listen_port: this.config.tuic.port || 8443,
        users: [
          { uuid: state.uuid, password: state.uuid }
        ],
        congestion_controller: this.config.tuic.congestionController || 'bbr',
        tls: {
          enabled: true,
          server_name: this.config.sniHy2 || 'www.google.com',
          alpn: ['h3'],
          certificate_path: this.paths.certPath,
          key_path: this.paths.keyPath
        }
      });
    }

    const cfg = {
      log: {
        level: 'info',
        timestamp: true
      },
      inbounds,
      outbounds: [
        { type: 'direct', tag: 'direct' },
        { type: 'block', tag: 'block' }
      ],
      route: {
        final: 'direct'
      }
    };

    const outboundRoute = ConfigStudio.singboxRoute(this.config);
    cfg.outbounds = outboundRoute.outbounds; cfg.route = outboundRoute.route;

    if (enable.wireguard && this.config.wireguard && state.wireguardPrivateKey && state.wireguardClientPublicKey) {
      const wgPort = (this.config.wireguard && this.config.wireguard.port) || 51820;
      cfg.endpoints = [
        {
          type: 'wireguard',
          tag: 'wg-in',
          system: false,
          name: 'amyrax-wg0',
          mtu: this.config.wireguard.mtu || 1420,
          address: [this.config.wireguard.serverIp || '10.66.66.1/24'],
          private_key: state.wireguardPrivateKey,
          listen_port: wgPort,
          peers: [
            {
              public_key: state.wireguardClientPublicKey,
              allowed_ips: [this.config.wireguard.clientIp || '10.66.66.2/32']
            }
          ]
        }
      ];
    }

    return cfg;
  }

  testConfigSync(cfgObj) {
    const tmpFile = path.join(this.paths.dataDir, `test-check-${Date.now()}.json`);
    try {
      fs.writeFileSync(tmpFile, JSON.stringify(cfgObj, null, 2), 'utf8');
      const res = spawnSync(this.paths.singboxBin, ['check', '-c', tmpFile], {
        encoding: 'utf8',
        timeout: 8000
      });
      try { fs.unlinkSync(tmpFile); } catch {}
      return {
        ok: res.status === 0,
        error: (res.stderr || res.stdout || '').trim()
      };
    } catch (err) {
      try { fs.unlinkSync(tmpFile); } catch {}
      return { ok: false, error: err.message };
    }
  }

  validateAndSanitize(configData) {
    let check = this.testConfigSync(configData);
    if (check.ok) return configData;

    Logger.warn(`sing-box initial check reported: ${check.error}. Running resilience auto-fix...`);

    if (configData.endpoints && configData.endpoints.length > 0) {
      delete configData.endpoints;
      check = this.testConfigSync(configData);
      if (check.ok) {
        Logger.warn('sing-box validated after omitting endpoints. Core engines running.');
        return configData;
      }
    }

    const optionalTags = ['tuic-in', 'vless-grpc-in', 'trojan-ws-in', 'socks-in', 'http-in', 'shadowtls-in', 'vless-shadowtls-detour'];
    for (const tag of optionalTags) {
      const idx = configData.inbounds.findIndex(ib => ib.tag === tag);
      if (idx !== -1) {
        configData.inbounds.splice(idx, 1);
        check = this.testConfigSync(configData);
        if (check.ok) {
          Logger.warn(`sing-box validated after stripping ${tag}. Continuing with stable inbounds.`);
          return configData;
        }
      }
    }

    const coreTags = ['hy2-in', 'vless-ws-in', 'vless-reality-in', 'ss-in'];
    configData.inbounds = configData.inbounds.filter(ib => coreTags.includes(ib.tag));
    check = this.testConfigSync(configData);
    if (check.ok) {
      Logger.warn('sing-box validated with minimum core inbounds (Hysteria2, VLESS-WS, REALITY, Shadowsocks).');
      return configData;
    }

    return null;
  }

  start() {
    if (!fs.existsSync(this.paths.singboxBin)) {
      Logger.warn('sing-box executable missing. Core engine skipped.');
      return false;
    }

    ensureTlsCertificates(this.paths.certPath, this.paths.keyPath, this.config.sniHy2);
    this.generateRealityKeys();

    let configData = this.buildJsonConfig();
    configData = this.validateAndSanitize(configData);

    if (!configData) {
      Logger.error('sing-box validation failed completely even after auto-fix attempts.');
      return false;
    }

    fs.writeFileSync(this.paths.singboxConfig, JSON.stringify(configData, null, 2), 'utf8');
    Logger.success('sing-box configuration validated.');

    this._spawn();
    this._probeInbounds(configData);
    return true;
  }

  _spawn() {
    try {
      if (fs.existsSync(this.paths.singboxLog) && fs.statSync(this.paths.singboxLog).size > 5 * 1024 * 1024) {
        fs.truncateSync(this.paths.singboxLog, 0);
      }
    } catch (_) {}
    const logFd = fs.openSync(this.paths.singboxLog, 'a');
    this.process = spawn(this.paths.singboxBin, ['run', '-c', this.paths.singboxConfig], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: false
    });
    Logger.info(`sing-box started (pid ${this.process.pid})`);
    let windowStart = Date.now();
    let printed = 0;
    const onData = (buf) => {
      try { fs.writeSync(logFd, buf); } catch (_) {}
      const text = buf.toString('utf8').replace(/\x1b\[[0-9;]*m/g, '');
      for (const line of text.split('\n')) {
        if (!/FATAL|ERROR|WARN|panic/i.test(line)) continue;
        if (Date.now() - windowStart > 60000) { windowStart = Date.now(); printed = 0; }
        if (++printed <= 15) Logger.info('sing-box: ' + line.trim().slice(0, 300));
      }
    };
    this.process.stdout.on('data', onData);
    this.process.stderr.on('data', onData);

    this.process.on('error', (err) => {
      Logger.error(`sing-box process error: ${err.message}`);
    });

    this.process.on('exit', (code, sig) => {
      try { fs.closeSync(logFd); } catch {}
      if (this._stopping) return;
      Logger.warn(`sing-box exited with code ${code} (${sig || 'none'})`);
      this._restarts = (this._restarts || 0) + 1;
      if (this._restarts <= 20) {
        const delay = Math.min(30000, 1000 * this._restarts);
        Logger.warn(`Restarting sing-box in ${delay / 1000}s (attempt ${this._restarts})...`);
        setTimeout(() => { if (!this._stopping) this._spawn(); }, delay);
      } else {
        Logger.error('sing-box keeps crashing; giving up. Check sing-box.log in the data directory.');
      }
    });
  }

  _probeInbounds(configData) {
    const list = (configData.inbounds || []).filter(ib => ib.listen_port && ib.listen === '127.0.0.1');
    setTimeout(() => {
      if (this._stopping) return;
      for (const ib of list) {
        const sock = net.connect(ib.listen_port, '127.0.0.1');
        sock.setTimeout(3000);
        sock.once('connect', () => { Logger.success(`sing-box inbound ${ib.tag} listening on 127.0.0.1:${ib.listen_port}`); sock.destroy(); });
        sock.once('error', (e) => { Logger.error(`sing-box inbound ${ib.tag} NOT listening on :${ib.listen_port} (${e.message})`); });
        sock.once('timeout', () => { Logger.error(`sing-box inbound ${ib.tag} probe timeout on :${ib.listen_port}`); sock.destroy(); });
      }
    }, 2500);
  }

  stop() {
    this._stopping = true;
    if (this.process && !this.process.killed) {
      try {
        this.process.kill('SIGTERM');
      } catch {}
    }
  }
}

class XrayEngine {
  constructor(config, stateManager, localPort) {
    this.config = config;
    this.paths = config.paths;
    this.stateManager = stateManager;
    this.port = localPort;
    this.process = null;
  }

  static xhttpPath() {
    return '/Telegram=@AmyraxVPN';
  }

  buildConfig() {
    const state = this.stateManager.state;
    return {
      log: { loglevel: 'warning' },
      inbounds: [
        {
          tag: 'vless-xhttp-in',
          listen: '127.0.0.1',
          port: this.port,
          protocol: 'vless',
          settings: { clients: [{ id: state.uuid, level: 0 }], decryption: 'none' },
          streamSettings: {
            network: 'xhttp',
            security: 'none',  
            xhttpSettings: { path: XrayEngine.xhttpPath(), mode: 'auto' }
          }
        }
      ],
      outbounds: [
        { protocol: 'freedom', tag: 'direct' },
        { protocol: 'blackhole', tag: 'block' }
      ]
    };
  }

  start() {
    if (!fs.existsSync(this.paths.xrayBin)) return false;
    fs.writeFileSync(this.paths.xrayConfig, JSON.stringify(this.buildConfig(), null, 2), 'utf8');
    try {
      const t = spawnSync(this.paths.xrayBin, ['run', '-test', '-c', this.paths.xrayConfig], { encoding: 'utf8', timeout: 20000 });
      if (t.status !== 0) {
        Logger.error('Xray config test failed: ' + String(t.stdout || t.stderr || '').replace(/\x1b\[[0-9;]*m/g, '').trim().split('\n').slice(-3).join(' | '));
        return false;
      }
    } catch (err) {
      Logger.warn('Xray config test could not run: ' + err.message);
    }
    this._spawn();
    this._probe();
    return true;
  }

  _spawn() {
    try {
      if (fs.existsSync(this.paths.xrayLog) && fs.statSync(this.paths.xrayLog).size > 5 * 1024 * 1024) fs.truncateSync(this.paths.xrayLog, 0);
    } catch (_) {}
    const logFd = fs.openSync(this.paths.xrayLog, 'a');
    this.process = spawn(this.paths.xrayBin, ['run', '-c', this.paths.xrayConfig], { stdio: ['ignore', 'pipe', 'pipe'], detached: false });
    Logger.info(`Xray-core started (pid ${this.process.pid}), VLESS-XHTTP on 127.0.0.1:${this.port}`);
    let windowStart = Date.now();
    let printed = 0;
    const onData = (buf) => {
      try { fs.writeSync(logFd, buf); } catch (_) {}
      const text = buf.toString('utf8').replace(/\x1b\[[0-9;]*m/g, '');
      for (const line of text.split('\n')) {
        if (!/\[(Warning|Error)\]|panic|failed to/i.test(line)) continue;
        if (/is deprecated|Please migrate/i.test(line)) continue;
        if (Date.now() - windowStart > 60000) { windowStart = Date.now(); printed = 0; }
        if (++printed <= 15) Logger.info('xray: ' + line.trim().slice(0, 300));
      }
    };
    this.process.stdout.on('data', onData);
    this.process.stderr.on('data', onData);
    this.process.on('error', (err) => Logger.error(`Xray process error: ${err.message}`));
    this.process.on('exit', (code, sig) => {
      try { fs.closeSync(logFd); } catch (_) {}
      if (this._stopping) return;
      Logger.warn(`Xray-core exited with code ${code} (${sig || 'none'})`);
      this._restarts = (this._restarts || 0) + 1;
      if (this._restarts <= 20) {
        const delay = Math.min(30000, 1000 * this._restarts);
        Logger.warn(`Restarting Xray-core in ${delay / 1000}s (attempt ${this._restarts})...`);
        setTimeout(() => { if (!this._stopping) this._spawn(); }, delay);
      } else {
        Logger.error('Xray-core keeps crashing; giving up. See xray.log in the data directory.');
      }
    });
  }

  _probe() {
    setTimeout(() => {
      const sock = net.connect(this.port, '127.0.0.1');
      sock.setTimeout(3000);
      sock.once('connect', () => { Logger.success(`xray inbound vless-xhttp-in listening on 127.0.0.1:${this.port} (path ${XrayEngine.xhttpPath()})`); sock.destroy(); });
      sock.once('error', (e) => Logger.error(`xray inbound vless-xhttp-in NOT listening on :${this.port} (${e.message})`));
      sock.once('timeout', () => { Logger.error(`xray inbound probe timeout on :${this.port}`); sock.destroy(); });
    }, 2500);
  }

  stop() {
    this._stopping = true;
    if (this.process && !this.process.killed) {
      try { this.process.kill('SIGTERM'); } catch (_) {}
    }
  }
}

class ArgoTunnel {
  constructor(config, targetPort) {
    this.config = config;
    this.paths = config.paths;
    this.targetPort = targetPort;
    this.process = null;
    this.tunnelDomain = '';
  }

  async discoverDomain(timeoutMs = 45000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      for (const p of [2000, 2001, 2002]) {
        try {
          const resp = await axios.get(`http://127.0.0.1:${p}/quicktunnel`, { timeout: 1500 });
          if (resp.data && resp.data.hostname) {
            return resp.data.hostname.replace(/^https?:\/\//, '').trim().toLowerCase();
          }
        } catch {}
      }

      if (fs.existsSync(this.paths.cloudflaredLog)) {
        try {
          const logContent = fs.readFileSync(this.paths.cloudflaredLog, 'utf8');
          const match = logContent.match(/https?:\/\/([a-z0-9-]+\.trycloudflare\.com)/i);
          if (match) {
            return match[1].toLowerCase();
          }
        } catch {}
      }

      await new Promise(r => setTimeout(r, 2000));
    }
    return null;
  }

  async start() {
    if (!this.config.enable.argo || !fs.existsSync(this.paths.cloudflaredBin)) {
      return null;
    }

    if (this.config.argo.auth && this.config.argo.domain) {
      this.tunnelDomain = this.config.argo.domain;
      Logger.success(`Cloudflare named tunnel active: ${this.tunnelDomain}`);
      return this.tunnelDomain;
    }

    Logger.step('Launching Cloudflare Argo Quick Tunnel...');
    const logFd = fs.openSync(this.paths.cloudflaredLog, 'a');

    this.process = spawn(this.paths.cloudflaredBin, [
      'tunnel', '--no-autoupdate', '--metrics', '127.0.0.1:2000',
      '--url', `http://127.0.0.1:${this.targetPort}`
    ], {
      stdio: ['ignore', logFd, logFd],
      detached: false
    });

    this.process.on('exit', () => {
      try { fs.closeSync(logFd); } catch {}
    });

    this.tunnelDomain = await this.discoverDomain();
    if (this.tunnelDomain) {
      Logger.success(`Argo Quick Tunnel ready: ${this.tunnelDomain}`);
    } else {
      Logger.warn('Argo tunnel domain could not be resolved within timeout.');
    }

    return this.tunnelDomain;
  }

  stop() {
    if (this.process && !this.process.killed) {
      try { this.process.kill('SIGTERM'); } catch {}
    }
  }
}


function isLocalAddress(host) {
  return !NetworkSupport.publicHost(host);
}

function isValidNode(node, options = {}) {
  if (!node || !node.uri || typeof node.uri !== 'string') return false;

  const { allowLocalHostLinks = false, compatMode = 'v2ray' } = options;
  const uri = node.uri.trim();

  try {
    const scheme = uri.split('://')[0].toLowerCase();

    if (scheme === 'vmess') {
      try {
        const rawJson = Buffer.from(uri.replace(/^vmess:\/\//i, ''), 'base64').toString('utf8');
        const vConf = JSON.parse(rawJson);
        if (!vConf.add || !vConf.port || !vConf.id) return false;
        if (!allowLocalHostLinks && isLocalAddress(vConf.add)) return false;
        return true;
      } catch {
        return false;
      }
    }

    const parsed = new URL(uri);

    if (!allowLocalHostLinks && isLocalAddress(parsed.hostname)) {
      return false;
    }

    if (compatMode === 'v2ray') {
      const allowedSchemes = ['vless', 'vmess', 'trojan', 'ss'];
      if (!allowedSchemes.includes(scheme)) {
        return false;
      }
    }

    if (scheme === 'vless') {
      const uuid = parsed.username;
      if (!uuid || uuid.length < 8) return false;

      const security = parsed.searchParams.get('security');
      if (security === 'reality') {
        const pbk = parsed.searchParams.get('pbk');
        const sid = parsed.searchParams.get('sid');
        const sni = parsed.searchParams.get('sni');
        if (!pbk || !sid || !sni) return false;
      }

      const type = parsed.searchParams.get('type');
      if (type === 'ws') {
        const pathVal = parsed.searchParams.get('path');
        if (!pathVal) return false;
      }

      if (type === 'grpc') {
        const serviceName = parsed.searchParams.get('serviceName');
        if (!serviceName) return false;
      }


    }

    if (scheme === 'trojan') {
      if (!parsed.username) return false;
    }

    if (scheme === 'ss') {
      if (!parsed.username && !parsed.hostname) return false;
    }

    return true;
  } catch {
    return false;
  }
}




function urlSafeEncode(str) {
  return encodeURIComponent(str);
}

function yamlSafeQuote(str) {
  return `"${String(str).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function deriveX25519PublicKey(privBase64) {
  try {
    if (!privBase64 || typeof privBase64 !== 'string') return null;
    const privBuf = Buffer.from(privBase64.trim(), 'base64');
    if (privBuf.length !== 32) return null;
    const pkcs8 = Buffer.concat([Buffer.from('302e020100300506032b656e04220420', 'hex'), privBuf]);
    const keyObj = crypto.createPrivateKey({ key: pkcs8, format: 'der', type: 'pkcs8' });
    return crypto.createPublicKey(keyObj).export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
  } catch {
    return null;
  }
}

// BEGIN NODE PRESENTATION
function createNodePresentation({ axios }) {
  const net = require('net'), dns = require('dns').promises;
  const cache = new Map(), pending = new Map();
  const unknown = () => ({ country: 'Unknown', code: '', flag: '🌐' });
  const publicIp = ip => {
    if (net.isIP(ip) === 4) {
      const [a, b] = ip.split('.').map(Number);
      return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127));
    }
    return net.isIP(ip) === 6 && !/^(::|fc|fd|fe[89ab])/i.test(ip);
  };
  const cached = host => cache.get(host)?.value || unknown();
  async function resolve(host) {
    host = String(host || '').replace(/^\[|\]$/g, '').toLowerCase();
    if (cache.get(host)?.until > Date.now()) return cached(host);
    if (pending.has(host)) return pending.get(host);
    const job = (async () => {
      let value = unknown(), ip = host;
      try {
        if (!net.isIP(ip)) {
          let timer;
          try { ip = (await Promise.race([dns.lookup(host), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('DNS timeout')), 1500); })])).address; }
          finally { clearTimeout(timer); }
        }
        if (publicIp(ip)) {
          for (const url of ['https://freeipapi.com/api/json/', 'https://ipwho.is/']) {
            try {
              const { data } = await axios.get(url + encodeURIComponent(ip), { timeout: 2000, maxContentLength: 16384 });
              const code = String(data.countryCode || data.country_code || '').toUpperCase();
              if (!/^[A-Z]{2}$/.test(code) || ['XX', 'ZZ'].includes(code)) continue;
              const country = new Intl.DisplayNames(['en'], { type: 'region' }).of(code);
              if (!country || country === code) continue;
              value = { code, country, flag: String.fromCodePoint(...[...code].map(c => 127397 + c.charCodeAt(0))) }; break;
            } catch {}
          }
        }
      } catch {}
      if (cache.size >= 256) cache.delete(cache.keys().next().value);
      cache.set(host, { value, until: Date.now() + (value.code ? 6 * 3600000 : 300000) });
      return value;
    })();
    pending.set(host, job);
    try { return await job; } finally { pending.delete(host); }
  }
  function nameNodes(nodes, username, location) {
    const user = String(username || 'کاربر اصلی').replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, '').trim() || 'کاربر اصلی';
    const place = location || unknown();
    return nodes.map((node, i) => {
      const name = `${user} · ${place.flag} ${place.country}${nodes.length > 1 ? ' ' + (i + 1) : ''}`;
      const previous = node.name; node.name = name;
      if (node.uri.startsWith('vmess://')) {
        const config = JSON.parse(Buffer.from(node.uri.slice(8), 'base64').toString('utf8'));
        config.ps = name; node.uri = 'vmess://' + Buffer.from(JSON.stringify(config)).toString('base64');
      } else node.uri = node.uri.split('#')[0] + '#' + encodeURIComponent(name);
      if (node.clash) node.clash.name = name;
      for (const ob of node.singboxOutbound || []) if (ob.tag === previous) ob.tag = name;
      if (node.singboxOutbound) node.singboxJson = JSON.stringify(node.singboxOutbound, null, 2);
      return node;
    });
  }
  return { resolve, cached, nameNodes };
}


// END NODE PRESENTATION
const NodePresentation = createNodePresentation({ axios });

// BEGIN TRANSPORT SUPPORT
function createTransportSupport({ Logger }) {
  const fs = require('fs'), path = require('path'), net = require('net');
  const { spawn, execFile } = require('child_process');
  const variants = [
    ['vless','xhttp',false,'vlessXhttpStream','stream-up'],
    ['vless','httpupgrade',false,'vlessHttpUpgrade'],
    ['vmess','httpupgrade',false,'vmessHttpUpgrade'],
    ['vless','xhttp',false,'vlessXhttp','packet-up'],
    ['shadowsocks','ws',false,'shadowsocks'],
    ['vless','ws',false,'vlessWs'],
    ['vmess','ws',false,'vmessWs'],
    ['trojan','ws',false,'trojanWs'],
    ['trojan','httpupgrade',false,'trojanHttpUpgrade'],
    ['vmess','grpc',false,'vmessGrpc'],
    ['trojan','grpc',false,'trojanGrpc'],
    ['vless','grpc',false,'vlessGrpc']
  ];
  function nodes(g) {
    const result = [], host = g.host.replace(/^\[|\]$/g,''), address = net.isIP(host) === 6 ? '['+host+']' : host;
    for (const [protocol, transport, nativeTls, flag, mode] of variants) {
      if (!g.config.enable[flag]) continue;
      if (g.edgeTls && (transport === 'grpc' || protocol === 'shadowsocks')) continue;
      if (['grpc','xhttp'].includes(transport) && !g.config.transportState?.[transport]) continue;
      const tls = nativeTls || g.edgeTls;
      const kind = {vless:'VLESS',vmess:'VMess',trojan:'Trojan',shadowsocks:'Shadowsocks'}[protocol];
      const type = kind + '-' + {ws:'WS',httpupgrade:'HTTPUpgrade',grpc:'gRPC',xhttp:'XHTTP'}[transport] + (mode==='stream-up'?'-Stream':'') + (tls?'-TLS':'');
      const name = type, wsHost = g.customWsHost || (tls ? g.tlsOpt.wsHost : host);
      const alpn = [transport === 'grpc' || (transport==='xhttp'&&tls) ? 'h2' : 'http/1.1'];
      const password = protocol === 'shadowsocks' ? (g.state.shadowsocksPassword || g.state.uuid) : g.state.uuid;
      const ob = {type:protocol,tag:name,server:host,server_port:g.port,connect_timeout:'15s'};
      const clash = {name,type:protocol === 'shadowsocks'?'ss':protocol,server:host,port:g.port};
      if (['vless','vmess'].includes(protocol)) { ob.uuid=g.state.uuid;clash.uuid=g.state.uuid; }
      else { ob.password=password;clash.password=password; }
      if (protocol === 'vmess') { ob.security='auto';ob.alter_id=0;clash.cipher='auto';clash.alterId=0; }
      if (tls) {
        ob.tls={...g._sbTls(),alpn};g._clashTls(clash,protocol==='trojan'?'sni':'servername');clash.alpn=alpn;
      } else clash.tls=false;
      if (transport === 'grpc') {
        ob.transport={type:'grpc',service_name:g.grpcService};clash.network='grpc';clash['grpc-opts']={'grpc-service-name':g.grpcService};
      } else {
        ob.transport={type:transport,path:g.wsPath,...(transport==='httpupgrade'?{host:wsHost}:{headers:{Host:wsHost}})};
        clash.network=transport;clash['ws-opts']={path:g.wsPath,headers:{Host:wsHost}};
      }
      let uri;
      if (protocol === 'vmess') {
        uri='vmess://'+Buffer.from(JSON.stringify({v:'2',ps:name,add:host,port:String(g.port),id:g.state.uuid,aid:'0',scy:'auto',net:transport,type:transport==='grpc'?'gun':'none',host:wsHost,path:transport==='grpc'?g.grpcService:g.wsPath,tls:tls?'tls':'',...(tls?{sni:g.tlsOpt.sni,alpn:alpn.join(','),fp:g.tlsOpt.fp,insecure:g.insecure?'1':'0'}:{})})).toString('base64');
      } else if (protocol === 'shadowsocks') {
        const opts='mode=websocket;host='+wsHost+';path='+g.wsPath+';mux=0';
        uri='ss://'+Buffer.from('aes-256-gcm:'+password).toString('base64url')+'@'+address+':'+g.port+'?plugin='+encodeURIComponent('v2ray-plugin;'+opts)+'#'+encodeURIComponent(name);
        delete ob.transport;delete ob.tls;ob.method='aes-256-gcm';ob.plugin='v2ray-plugin';ob.plugin_opts=opts;
        delete clash.network;delete clash['ws-opts'];delete clash.tls;clash.cipher='aes-256-gcm';clash.plugin='v2ray-plugin';
        clash['plugin-opts']={mode:'websocket',tls:false,host:wsHost,path:g.wsPath,mux:false};
      } else {
        const q=new URLSearchParams({...(protocol==='vless'?{encryption:'none'}:{}),security:tls?'tls':'none',type:transport});
        if (tls) {q.set('sni',g.tlsOpt.sni);q.set('alpn',alpn.join(','));if(g.tlsOpt.fp)q.set('fp',g.tlsOpt.fp);if(g.insecure){q.set('insecure','1');q.set('allowInsecure','1');}}
        if (transport==='grpc') {q.set('serviceName',g.grpcService);q.set('mode','gun');}
        else {q.set('host',wsHost);q.set('path',g.wsPath);if(transport==='xhttp')q.set('mode',mode);}
        uri=protocol+'://'+encodeURIComponent(password)+'@'+address+':'+g.port+'?'+q+'#'+encodeURIComponent(name);
      }
      result.push({name,type,protocol,transport,tls,mode,label:type,compat:true,uri,
        clash: transport==='httpupgrade'||transport==='xhttp'||(protocol==='trojan'&&!tls)?null:clash,
        singboxOutbound:transport==='xhttp'?undefined:[ob],
        singboxJson:transport==='xhttp'?undefined:JSON.stringify([ob],null,2)});
    }
    return result;
  }
  function forClient(nodes, userAgent, client = '') {
    if (client==='streisand' || (client!=='v2rayng'&&/streisand/i.test(userAgent))) return nodes.filter(n=>['ws','grpc'].includes(n.transport)&&n.protocol!=='shadowsocks'&&(n.protocol!=='trojan'||n.tls));
    if (client==='v2rayng' || /v2rayng/i.test(userAgent)) return nodes.filter(n=>n.protocol!=='shadowsocks');
    if (/hiddify/i.test(userAgent)) return nodes.filter(n=>n.transport!=='xhttp'&&n.protocol!=='shadowsocks');
    return nodes;
  }
  async function tlsFrontend(config, gateway, handler, certs) {
    const http=require('http'), http2=require('http2');
    const panel=http.createServer(handler),panelPort=await listen(panel),sessions=new Set(),sockets=new Set();
    const server=http2.createSecureServer({...certs,allowHTTP1:true},(req,res)=>{
      if(req.httpVersionMajor!==2){handler(req,res);return;}
      const headers=Object.fromEntries(Object.entries(req.headers).filter(([k])=>!k.startsWith(':')&&k!=='connection'));
      headers.host=req.headers[':authority']||'localhost';
      headers['x-forwarded-proto']='https';
      let upstream;
      let pathname;try{pathname=decodeURIComponent(String(req.url).split('?')[0]);}catch{pathname='';}
      const isGrpc=String(req.headers['content-type']||'').startsWith('application/grpc') && /^\/Telegram=@AmyraxVPN\/(?:Tun|TunMulti)$/.test(pathname);
      if(isGrpc) {
        const port=config.transportState?.grpc;
        if(!port){res.writeHead(503);res.end();return;}
        const session=req.stream.session;
        if(!session.amyraxUpstream||session.amyraxPort!==port||session.amyraxUpstream.destroyed){
          session.amyraxUpstream?.close();session.amyraxPort=port;
          session.amyraxUpstream=http2.connect('http://127.0.0.1:'+port);
          session.amyraxUpstream.on('error',()=>{if(!session.destroyed)session.destroy();});
        }
        upstream=session.amyraxUpstream.request({':path':req.url,':method':req.method,...headers});
        upstream.on('response',h=>{if(res.destroyed)return;res.writeHead(h[':status']||200,Object.fromEntries(Object.entries(h).filter(([k])=>!k.startsWith(':'))));upstream.pipe(res);});
        upstream.on('trailers',h=>{if(!res.destroyed)res.addTrailers(h);});
      } else {
        upstream=http.request({host:'127.0.0.1',port:panelPort,path:req.url,method:req.method,headers,agent:false},reply=>{
          const out=Object.fromEntries(Object.entries(reply.headers).filter(([k])=>!['connection','keep-alive','transfer-encoding','upgrade'].includes(k)));
          if(res.destroyed){reply.destroy();return;}
          res.writeHead(reply.statusCode,out);res.flushHeaders();reply.on('error',()=>res.destroy());reply.pipe(res);
        });
      }
      upstream.on('error',()=>{if(!res.headersSent){res.writeHead(502);res.end();}else res.destroy();});
      req.on('error',()=>upstream.destroy());req.pipe(upstream);
      res.on('close',()=>{if(!res.writableFinished)upstream.destroy();});
    });
    server.on('session',session=>{sessions.add(session);session.on('error',()=>{});session.on('close',()=>{sessions.delete(session);session.amyraxUpstream?.destroy();});});
    server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));});
    server.on('upgrade',(req,socket,head)=>gateway.handleUpgrade(req,socket,head));
    server.closeAllConnections=()=>{for(const s of sessions)s.destroy();for(const s of sockets)s.destroy();panel.closeAllConnections();panel.close();};
    server.on('close',()=>server.closeAllConnections());
    return server;
  }
  const listen = server => new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',()=>resolve(server.address().port));});
  const freePort = async()=>{const server=net.createServer();const port=await listen(server);await new Promise(r=>server.close(r));return port;};
  class Bridge {
    constructor(config,gateway) {this.config=config;this.gateway=gateway;this.servers=[];this.sockets=new Set();config.transportState ||= {grpc:0,xhttp:0};}
    async start() {
      const state=this.config.transportState;
      state.grpc=0;state.xhttp=0;
      const inbounds=[],ports={};
      try {
        for(const network of ['grpc','xhttp']) {
          if(!variants.some(([,transport,,flag])=>transport===network&&this.config.enable[flag]))continue;
          const server=net.createServer(socket=>{this.sockets.add(socket);socket.once('close',()=>this.sockets.delete(socket));this.gateway.accept(socket,network==='grpc'?'gRPC':'XHTTP');});
          this.servers.push(server);const destination=await listen(server);const port=await freePort();ports[network]=port;
          inbounds.push({listen:'127.0.0.1',port,protocol:'dokodemo-door',tag:network,settings:{address:'127.0.0.1',port:destination,network:'tcp'},streamSettings:{network,security:'none',...(network==='grpc'?{grpcSettings:{serviceName:'Telegram=@AmyraxVPN'}}:{xhttpSettings:{path:'/Telegram=@AmyraxVPN',mode:'auto'}})}});
        }
        if(!inbounds.length)return false;
        this.file=path.join(this.config.paths.dataDir,'transports.json');
        fs.writeFileSync(this.file,JSON.stringify({log:{loglevel:'warning'},inbounds,outbounds:[{protocol:'freedom'}]}),{mode:0o600});
        await new Promise((resolve,reject)=>execFile(this.config.paths.xrayBin,['run','-test','-c',this.file],{windowsHide:true,timeout:15000,maxBuffer:262144},error=>error?reject(error):resolve()));
        this.process=spawn(this.config.paths.xrayBin,['run','-c',this.file],{windowsHide:true,stdio:['ignore','ignore','pipe']});
        this.process.stderr.on('data',()=>{});
        let failed=false;const failure=()=>{failed=true;state.grpc=0;state.xhttp=0;if(!this.stopped){Logger.warn('Transport engine stopped; gRPC and XHTTP subscriptions are temporarily hidden.');clearTimeout(this.retry);this.retry=setTimeout(()=>{this.cleanup();this.start();},5000);this.retry.unref();}};
        this.process.once('error',failure);this.process.once('exit',failure);
        for(const port of Object.values(ports)) {
          let ready=false;const deadline=Date.now()+10000;
          while(!ready&&!failed&&!this.stopped&&Date.now()<deadline) {
            ready=await new Promise(resolve=>{const s=net.connect(port,'127.0.0.1');const done=value=>{s.destroy();resolve(value);};s.setTimeout(300,()=>done(false));s.once('connect',()=>done(true));s.once('error',()=>done(false));});
            if(!ready)await new Promise(r=>setTimeout(r,50));
          }
          if(!ready)throw new Error('Transport listener did not become ready');
        }
        Object.assign(state,ports);Logger.success('gRPC and XHTTP transports ready.');return true;
      } catch(error) {Logger.warn('Additional transports unavailable: '+error.message.split('\n')[0]);this.cleanup();return false;}
    }
    cleanup() {if(this.process){this.process.removeAllListeners('exit');this.process.removeAllListeners('error');this.process.on('error',()=>{});this.process.kill();this.process=null;}for(const s of this.sockets)s.destroy();for(const s of this.servers)s.close();this.servers=[];this.config.transportState.grpc=0;this.config.transportState.xhttp=0;}
    stop() {this.stopped=true;clearTimeout(this.retry);this.cleanup();}
  }
  return {nodes,forClient,tlsFrontend,Bridge,variants};
}


// END TRANSPORT SUPPORT
const TransportSupport = createTransportSupport({ Logger });

// BEGIN CONFIG STUDIO
function createConfigStudio({ LinkGenerator, TransportSupport, Logger }) {
  const fs = require('fs'), path = require('path'), crypto = require('crypto'), net = require('net');
  const { spawn, execFile } = require('child_process');
  const clone = value => JSON.parse(JSON.stringify(value));
  const fail = (message, status = 400) => { throw Object.assign(new Error(message), { status }); };
  const fingerprints = ['', 'chrome', 'firefox', 'safari', 'edge', 'ios', 'android', 'random', 'randomized', '360', 'qq'];
  const defaultPath = '/Telegram=@AmyraxVPN';
  function host(value) {
    if (typeof value !== 'string') fail('آدرس سرور معتبر نیست.');
    value = value.trim().replace(/^\[|\]$/g, '').toLowerCase();
    if (!value || value.length > 253 || (!net.isIP(value) && !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(value))) fail('دامنه یا IP را بدون https و مسیر وارد کنید.');
    return value;
  }
  function port(value) { if (!Number.isInteger(value) || value < 1 || value > 65535) fail('پورت باید بین ۱ و ۶۵۵۳۵ باشد.'); return value; }
  function label(value) {
    if (typeof value !== 'string' || !value.trim() || value.length > 80 || /[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/.test(value)) fail('نام کانفیگ معتبر نیست (حداکثر ۸۰ نویسه).');
    return value.trim();
  }
  function stream(protocol, transport, security, values) {
    if (!['tcp', 'ws', 'grpc', 'httpupgrade', 'xhttp'].includes(transport)) fail('این نوع انتقال پشتیبانی نمی‌شود.');
    if (!['none', 'tls', 'reality'].includes(security)) fail('این نوع امنیت پشتیبانی نمی‌شود.');
    const s = { network: transport, security };
    if (security === 'tls') s.tlsSettings = { serverName: values.sni || values.host, allowInsecure: values.insecure === '1', ...(values.fp ? { fingerprint: values.fp } : {}), ...(values.alpn ? { alpn: values.alpn.split(',') } : {}) };
    if (security === 'reality') {
      if (!values.pbk || !values.sni) fail('برای Reality کلید عمومی و SNI لازم است.');
      s.realitySettings = { serverName: values.sni, fingerprint: values.fp || 'chrome', publicKey: values.pbk, shortId: values.sid || '', spiderX: values.spx || '/' };
    }
    if (transport === 'ws') s.wsSettings = { path: values.path || '/', headers: { Host: values.host || values.sni || '' } };
    if (transport === 'httpupgrade') s.httpupgradeSettings = { path: values.path || '/', host: values.host || values.sni || '' };
    if (transport === 'grpc') s.grpcSettings = { serviceName: values.serviceName || '', multiMode: values.mode === 'multi' };
    if (transport === 'xhttp') s.xhttpSettings = { path: values.path || '/', host: values.host || values.sni || '', mode: values.mode || 'auto' };
    return s;
  }
  function fromUri(input, tag = 'amyrax-upstream') {
    let ob;
    if (input.startsWith('vmess://')) {
      let v; try { v = JSON.parse(Buffer.from(input.slice(8), 'base64').toString('utf8')); } catch { fail('لینک VMess معتبر نیست.'); }
      ob = { protocol: 'vmess', settings: { vnext: [{ address: host(v.add), port: port(Number(v.port)), users: [{ id: v.id, alterId: Number(v.aid || 0), security: v.scy || 'auto' }] }] }, streamSettings: stream('vmess', v.net || 'tcp', v.tls === 'tls' ? 'tls' : 'none', { ...v, serviceName: v.path, insecure: String(v.insecure || '0') }) };
    } else {
      let u; try { u = new URL(input); } catch { fail('لینک اتصال معتبر نیست.'); }
      const protocol = u.protocol.slice(0, -1), address = host(u.hostname), endpointPort = port(Number(u.port));
      const values = Object.fromEntries(u.searchParams); values.host ||= address;
      const credential = decodeURIComponent(u.username);
      if (protocol === 'ss') {
        let credentials = credential.includes(':') ? credential : Buffer.from(credential, 'base64').toString('utf8');
        const split = credentials.indexOf(':'); if (split < 1) fail('کلید Shadowsocks معتبر نیست.');
        ob = { protocol: 'shadowsocks', settings: { servers: [{ address, port: endpointPort, method: credentials.slice(0, split), password: credentials.slice(split + 1) }] } };
        if (values.plugin) {
          if (!values.plugin.startsWith('v2ray-plugin;')) fail('این افزونهٔ Shadowsocks پشتیبانی نمی‌شود.');
          const opts = Object.fromEntries(values.plugin.split(';').slice(1).map(p => { const i = p.indexOf('='); return i < 0 ? [p, '1'] : [p.slice(0, i), p.slice(i + 1)]; }));
          ob.streamSettings = stream('shadowsocks', 'ws', opts.tls ? 'tls' : 'none', { host: opts.host || address, path: opts.path || '/', sni: opts.host || address });
        }
      } else if (['vless', 'trojan'].includes(protocol)) {
        ob = { protocol, settings: protocol === 'vless' ? { vnext: [{ address, port: endpointPort, users: [{ id: credential, encryption: values.encryption || 'none', ...(values.flow ? { flow: values.flow } : {}) }] }] } : { servers: [{ address, port: endpointPort, password: credential }] }, streamSettings: stream(protocol, values.type || 'tcp', values.security || (protocol === 'trojan' ? 'tls' : 'none'), { ...values, insecure: values.insecure || values.allowInsecure }) };
      } else fail('لینک VLESS، VMess، Trojan یا Shadowsocks لازم است.');
    }
    ob.tag = tag; return ob;
  }
  function outbound(input) {
    if (typeof input !== 'string' || !input.trim() || input.length > 16000) fail('لینک یا Outbound JSON را وارد کنید.');
    input = input.trim();
    if (!input.startsWith('{')) return fromUri(input);
    let value; try { value = JSON.parse(input); } catch { fail('JSON معتبر نیست.'); }
    if (value.outbounds) { if (!Array.isArray(value.outbounds) || value.outbounds.length !== 1) fail('فقط یک Outbound در JSON وارد کنید.'); value = value.outbounds[0]; }
    if (!['vless', 'vmess', 'trojan', 'shadowsocks', 'socks', 'http'].includes(value.protocol) || !value.settings || Object.keys(value).some(k => !['protocol', 'tag', 'settings', 'streamSettings', 'mux'].includes(k))) fail('یک Outbound استاندارد Xray لازم است؛ اتصال زنجیره‌ای وابسته به detour پذیرفته نمی‌شود.');
    value = clone(value); value.tag = 'amyrax-upstream'; return value;
  }
  function singboxRoute(config) {
    const egress = config.configStudio?.egress;
    if (!egress?.enabled) return { outbounds: [{ type: 'direct', tag: 'direct' }], route: { final: 'direct' } };
    if (!config.configStudio.egressPort) return { outbounds: [{ type: 'block', tag: 'egress-unavailable' }], route: { final: 'egress-unavailable' } };
    return { outbounds: [{ type: 'socks', tag: 'amyrax-upstream', server: '127.0.0.1', server_port: config.configStudio.egressPort, version: '5' }], route: { final: 'amyrax-upstream' } };
  }
  class Studio {
    constructor(config, stateManager) {
      this.config = config; this.stateManager = stateManager; this.file = path.join(config.paths.dataDir, 'custom-configs.json');
      this.profiles = []; this.revision = 0; this.egress = { enabled: false }; this.pendingEgress = this.egress;
      try {
        if (fs.existsSync(this.file)) {
          const saved = JSON.parse(fs.readFileSync(this.file, 'utf8'));
          if (saved.version !== 1 || !Array.isArray(saved.profiles) || !Number.isSafeInteger(saved.revision) || saved.revision < 0) throw new Error();
          const ids = new Set();
          for (const p of saved.profiles) {
            if (!/^[\da-f]{8}(-[\da-f]{4}){3}-[\da-f]{12}$/.test(p.id) || ids.has(p.id) || !Number.isSafeInteger(p.revision) || p.revision < 1) throw new Error();
            this.validate(p); ids.add(p.id);
          }
          if (typeof saved.egress?.enabled !== 'boolean') throw new Error();
          if (saved.egress.enabled) { label(saved.egress.name); outbound(saved.egress.input); }
          this.profiles = saved.profiles; this.revision = saved.revision; this.egress = saved.egress; this.pendingEgress = clone(saved.egress);
        }
      } catch { this.loadError = 'فایل کانفیگ‌های سفارشی معتبر نیست؛ custom-configs.json را بررسی کنید.'; this.egress = { enabled: true }; Logger.error(this.loadError); }
    }
    available() { if (this.loadError) fail(this.loadError, 503); }
    persist(profiles, egress = this.pendingEgress) {
      this.available();
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      const fd = fs.openSync(tmp, 'w', 0o600);
      try { fs.writeFileSync(fd, JSON.stringify({ version: 1, revision: this.revision + 1, profiles, egress })); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(tmp, this.file); this.revision++; this.profiles = profiles; this.pendingEgress = egress;
    }
    generator(accountId, resolvedHost, active = true) {
      if (accountId === 'shared') return new LinkGenerator(this.config, this.stateManager.state, resolvedHost);
      const manager = this.config.userManager, u = manager?.find(accountId);
      if (!u || u.archivedAt) fail('حساب انتخاب‌شده موجود نیست.', 404);
      if (active && !manager.permitted(u)) fail('این حساب اکنون اجازهٔ اتصال ندارد.', 403);
      return manager.generator(u, resolvedHost);
    }
    validate(p) {
      if (!p || typeof p !== 'object' || Array.isArray(p)) fail('اطلاعات کانفیگ معتبر نیست.');
      if (typeof p.accountId !== 'string' || (p.accountId !== 'shared' && !/^[\da-f]{8}(-[\da-f]{4}){3}-[\da-f]{12}$/.test(p.accountId))) fail('حساب معتبر نیست.');
      label(p.name); if (typeof p.variant !== 'string' || !/^(VLESS|VMess|Trojan|Shadowsocks)-(WS|HTTPUpgrade|gRPC|XHTTP)(-Stream)?(-TLS)?$/.test(p.variant)) fail('نوع کانفیگ معتبر نیست.');
      for (const k of ['server', 'sni', 'host']) { if (typeof p[k] !== 'string') fail('آدرس معتبر نیست.'); if (p[k]) host(p[k]); }
      if (p.port !== null) port(p.port);
      if (!fingerprints.includes(p.fingerprint)) fail('اثر انگشت TLS معتبر نیست.');
      if (typeof p.enabled !== 'boolean' || typeof p.path !== 'string') fail('تنظیم کانفیگ معتبر نیست.');
      if (p.path && (!/^\/[A-Za-z0-9/_.=@-]{1,180}$/.test(p.path) || p.path.includes('..') || ['/sub', '/assets', '/.well-known', '/amyrax-assets', '/' + this.config.panelPath.replace(/^\//, ''), '/health', '/healthz'].some(v => p.path === v || p.path.startsWith(v + '/')))) fail('مسیر اتصال باید با / شروع شود و با مسیرهای پنل تداخل نداشته باشد.');
      return p;
    }
    build(p, g) {
      this.validate(p);
      if (['PROXY', 'DIRECT', 'REJECT', 'direct', 'block', 'dns-out', '🛡️ Amyrax Panel', '⚡ Auto Select', '🟢 Direct', '🚫 Block'].includes(p.name)) fail('این نام برای گروه‌های خروجی رزرو شده است؛ نام دیگری انتخاب کنید.');
      const original = TransportSupport.nodes(g).find(n => n.type === p.variant);
      if (!original) fail('این پروتکل یا انتقال روی سرور یا حساب انتخاب‌شده فعال نیست.');
      if (p.path && !['ws', 'httpupgrade'].includes(original.transport) && p.path !== defaultPath) fail('مسیر دلخواه فعلاً برای WS و HTTPUpgrade قابل ساخت است؛ gRPC و XHTTP از مسیر فعال سرور استفاده می‌کنند.');
      if (p.variant.startsWith('Shadowsocks') && p.server && p.server !== g.host && !p.host) fail('برای Shadowsocks با آدرس جایگزین، Host سرور را هم وارد کنید.');
      const copy = Object.assign(Object.create(Object.getPrototypeOf(g)), g);
      copy.host = p.server || g.host; copy.port = p.port || g.port;
      copy.tlsOpt = { ...g.tlsOpt, sni: p.sni || g.tlsOpt.sni, wsHost: p.host || g.tlsOpt.wsHost, fp: p.fingerprint };
      copy.wsPath = p.path || defaultPath;
      copy.customWsHost = p.host || (original.tls ? g.tlsOpt.wsHost : g.host);
      const n = TransportSupport.nodes(copy).find(n => n.type === p.variant); n.name = p.name; n.customId = p.id || null;
      if (n.uri.startsWith('vmess://')) { const v = JSON.parse(Buffer.from(n.uri.slice(8), 'base64').toString()); v.ps = p.name; n.uri = 'vmess://' + Buffer.from(JSON.stringify(v)).toString('base64'); }
      else n.uri = n.uri.split('#')[0] + '#' + encodeURIComponent(p.name);
      if (n.clash) n.clash.name = p.name;
      for (const ob of n.singboxOutbound || []) ob.tag = p.name;
      if (n.singboxOutbound) n.singboxJson = JSON.stringify(n.singboxOutbound, null, 2);
      n.xrayJson = JSON.stringify(fromUri(n.uri, p.name), null, 2); return n;
    }
    nodes(g) {
      if (this.loadError) return [];
      const id = g.config.profileAccountId || 'shared';
      return this.profiles.filter(p => p.accountId === id && p.enabled).flatMap(p => { try { return [this.build(p, g)]; } catch { return []; } });
    }
    options(g) { return TransportSupport.nodes(g).map(n => ({ value: n.type, protocol: n.protocol, transport: n.transport, tls: n.tls })); }
    fields(input, accountId) {
      const keys = ['accountId', 'name', 'variant', 'server', 'port', 'sni', 'host', 'path', 'fingerprint', 'enabled', 'revision'];
      if (!input || Object.keys(input).some(k => !keys.includes(k))) fail('تنظیم ناشناخته در کانفیگ.');
      if (accountId && input.accountId !== accountId) fail('فقط کانفیگ حساب خودتان قابل تغییر است.', 403);
      return this.validate({ accountId: input.accountId, name: input.name, variant: input.variant, server: input.server || '', port: input.port ?? null, sni: input.sni || '', host: input.host || '', path: input.path || '', fingerprint: input.fingerprint ?? 'chrome', enabled: input.enabled ?? true });
    }
    save(input, resolvedHost, scope, id) {
      this.available(); const old = id && this.profiles.find(p => p.id === id);
      if (id && (!old || (scope && old.accountId !== scope))) fail('کانفیگ پیدا نشد.', 404);
      if (old && old.revision !== input.revision) fail('کانفیگ تغییر کرده؛ فهرست را تازه کنید.', 409);
      const p = this.fields(input, scope); this.build(p, this.generator(p.accountId, resolvedHost, false));
      if (this.generator(p.accountId,resolvedHost,false).getAllNodes({compat:'full'}).some(n=>!n.customId&&n.name===p.name)) fail('نام با کانفیگ خودکار تکراری است؛ نام دیگری انتخاب کنید.',409);
      p.id = id || crypto.randomUUID(); p.revision = (old?.revision || 0) + 1;
      if (this.profiles.some(x => x.id !== id && x.accountId === p.accountId && x.name === p.name)) fail('نام کانفیگ در این حساب تکراری است.', 409);
      this.persist(id ? this.profiles.map(x => x.id === id ? p : x) : [...this.profiles, p]); return p;
    }
    remove(id, revision, scope) {
      this.available(); const old = this.profiles.find(p => p.id === id);
      if (!old || (scope && old.accountId !== scope)) fail('کانفیگ پیدا نشد.', 404);
      if (old.revision !== revision) fail('کانفیگ تغییر کرده؛ فهرست را تازه کنید.', 409);
      this.persist(this.profiles.filter(p => p.id !== id));
    }
    pathAccounts(p) {
      if (p === defaultPath) return undefined;
      return new Set(this.profiles.filter(c => c.enabled && (c.path || defaultPath) === p && /-(WS|HTTPUpgrade)/.test(c.variant)).map(c => c.accountId));
    }
    egressConfig(ob, listenPort) { return { log: { loglevel: 'warning' }, inbounds: [{ listen: '127.0.0.1', port: listenPort, protocol: 'socks', settings: { auth: 'noauth', udp: true } }], outbounds: [ob] }; }
    async checkEgress(input, name, enabled, binary) {
      if (typeof enabled !== 'boolean') fail('وضعیت Outbound معتبر نیست.');
      if (!enabled) return { enabled: false };
      name = label(name); const ob = outbound(input);
      const targets = ob.settings.vnext || ob.settings.servers;
      if (!Array.isArray(targets) || targets.length !== 1) fail('یک سرور خروجی مستقل لازم است.');
      const destination = host(targets[0].address), destinationPort = port(targets[0].port);
      if (['localhost', '0.0.0.0', '::', '::1'].includes(destination) || /^127\./.test(destination) || ([this.config.domain, this.stateManager.state.publicHost].includes(destination) && destinationPort === this.config.publicPort)) fail('سرور خروجی نباید به همین پنل برگردد.');
      const file = path.join(this.config.paths.dataDir, 'egress-check-' + crypto.randomBytes(6).toString('hex') + '.json');
      try {
        fs.writeFileSync(file, JSON.stringify(this.egressConfig(ob, 10808)), { mode: 0o600 });
        await new Promise((resolve, reject) => execFile(binary, ['run', '-test', '-c', file], { windowsHide: true, timeout: 15000, maxBuffer: 262144 }, error => error ? reject(Object.assign(new Error('Outbound توسط Xray پذیرفته نشد؛ تنظیمات و نسخهٔ هسته را بررسی کنید.'), { status: 400 })) : resolve()));
      } finally { try { fs.unlinkSync(file); } catch {} }
      return { enabled: true, name, input: input.trim() };
    }
    async startEgress() {
      if (!this.egress.enabled || this.loadError) return;
      const listener = net.createServer(); await new Promise((r, j) => { listener.once('error', j); listener.listen(0, '127.0.0.1', r); });
      this.egressPort = listener.address().port; await new Promise(r => listener.close(r));
      const file = path.join(this.config.paths.dataDir, 'egress-runtime.json'); this.egressFile = file;
      fs.writeFileSync(file, JSON.stringify(this.egressConfig(outbound(this.egress.input), this.egressPort)), { mode: 0o600 });
      await new Promise((r, j) => execFile(this.config.paths.xrayBin, ['run', '-test', '-c', file], { windowsHide: true, timeout: 15000 }, error => error ? j(error) : r()));
      this.launchEgress();
    }
    launchEgress() {
      if (this.stopped) return;
      const child = this.egressProcess = spawn(this.config.paths.xrayBin, ['run', '-c', this.egressFile], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
      child.stderr.on('data', () => {});
      const failed = () => { if (this.stopped || this.egressProcess !== child) return; clearTimeout(this.egressRetry); this.egressRetry = setTimeout(() => this.launchEgress(), 3000); this.egressRetry.unref(); };
      child.on('error', failed); child.on('exit', failed);
    }
    stop() { this.stopped = true; clearTimeout(this.egressRetry); this.egressProcess?.kill(); }
  }
  return { Studio, fromUri, outbound, singboxRoute, fingerprints };
}


// END CONFIG STUDIO

class LinkGenerator {
  constructor(config, state, resolvedHost) {
    this.config = config;
    this.state = state;
    this.host = config.forceHost || resolvedHost || config.domain || '127.0.0.1';
   
    const endpoint = NetworkSupport.linkEndpoint(config, this.host);
    this.host = endpoint.host;
    this.port = endpoint.port;
    this.edgeTls = endpoint.tls;
    this.insecure = !this.edgeTls;
    this.tlsOpt = LinkGenerator.tlsOptions((config.forceHost && config.domain) ? config.domain : endpoint.sni || this.host);
    this.prefix = '';
    this.location = NodePresentation.cached(this.host);
    this.wsPath = '/Telegram=@AmyraxVPN';
    this.vmessPath = '/Telegram=@AmyraxVPN';
    this.huPath = '/Telegram=@AmyraxVPN';
    this.xhPath = '/Telegram=@AmyraxVPN';
    this.trPath = '/Telegram=@AmyraxVPN';
    this.grpcService = 'Telegram=@AmyraxVPN';
  }

  async prepare() { this.location = await NodePresentation.resolve(this.host); return this; }

  static tlsOptions(defaultSni) {
    const env = process.env;
    const warnOnce = (k, m) => { LinkGenerator._warned = LinkGenerator._warned || {}; if (!LinkGenerator._warned[k]) { LinkGenerator._warned[k] = 1; Logger.warn(m); } };
    const FP = ['chrome', 'firefox', 'safari', 'edge', 'ios', 'android', 'random', 'randomized', '360', 'qq'];
    let fp = env.LINK_FP === undefined ? 'chrome' : String(env.LINK_FP).trim().toLowerCase();
    if (fp === 'none' || fp === 'off' || fp === 'false') fp = '';
    if (fp && !FP.includes(fp)) { warnOnce('fp', 'LINK_FP="' + fp + '" is not supported; using chrome. Allowed: ' + FP.join(', ') + ', none'); fp = 'chrome'; }
    const alpnRaw = env.LINK_ALPN === undefined ? 'http/1.1' : String(env.LINK_ALPN).trim();
    const alpn = /^(none|off|false)?$/i.test(alpnRaw) ? [] : alpnRaw.split(',').map(x => x.trim()).filter(Boolean);
    if (alpn.includes('h2') || alpn.includes('h3')) warnOnce('alpn', 'LINK_ALPN contains h2/h3: WebSocket links only work over http/1.1.');
    const CIPHERS = [
      'TLS_AES_128_GCM_SHA256', 'TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256',
      'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256', 'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384', 'TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256',
      'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256', 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384', 'TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256',
      'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA', 'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA', 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA', 'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
      'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256', 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
      'TLS_RSA_WITH_AES_128_GCM_SHA256', 'TLS_RSA_WITH_AES_256_GCM_SHA384', 'TLS_RSA_WITH_AES_128_CBC_SHA', 'TLS_RSA_WITH_AES_256_CBC_SHA'
    ];
    const ciphers = [];
    for (const c of String(env.TLS_CIPHERS || '').split(',').map(x => x.trim().toUpperCase()).filter(Boolean)) {
      if (CIPHERS.includes(c)) { if (!ciphers.includes(c)) ciphers.push(c); } else warnOnce('c_' + c, 'TLS_CIPHERS: unknown cipher suite "' + c + '" ignored.');
    }
    const sni = normalizeHost(env.LINK_SNI) || defaultSni;
    const wsHost = normalizeHost(env.LINK_HOST) || sni;
    return { fp, alpn, ciphers, sni, wsHost };
  }

  _uriTls() {
    const o = this.tlsOpt;
    let q = '&sni=' + encodeURIComponent(o.sni);
    if (o.fp) q += '&fp=' + encodeURIComponent(o.fp);
    if (o.alpn.length) q += '&alpn=' + encodeURIComponent(o.alpn.join(','));
    if (this.insecure) q += '&allowInsecure=1';
    return q;
  }

  _sbTls() {
    const o = this.tlsOpt;
    const t = { enabled: true, server_name: o.sni, insecure: this.insecure };
    if (o.alpn.length) t.alpn = o.alpn.slice();
    if (o.fp) t.utls = { enabled: true, fingerprint: o.fp };
    if (o.ciphers.length) t.cipher_suites = o.ciphers.slice();
    return t;
  }

  _clashTls(obj, sniKey = 'servername') {
    const o = this.tlsOpt;
    obj.tls = true;
    obj[sniKey] = o.sni;
    obj['skip-cert-verify'] = this.insecure;
    if (o.fp) obj['client-fingerprint'] = o.fp === 'randomized' ? 'random' : o.fp;
    if (o.alpn.length) obj.alpn = o.alpn.slice();
    return obj;
  }

  generateHysteria2() {
    return null;  
  }

  generateVlessWs() {
    if (!this.config.enable.vlessWs) return null;
    if (this.edgeTls) return null;  
    const name = 'AmyraxVPN - WS';
    const clashProxy = {
      name,
      type: 'vless',
      server: this.host,
      port: this.port,
      uuid: this.state.uuid,
      network: 'ws',
      tls: false,
      'ws-opts': {
        path: this.wsPath,
        headers: { Host: this.host }
      }
    };
    const sbOutbound = {
      type: 'vless',
      tag: name,
      server: this.host,
      server_port: this.port,
      uuid: this.state.uuid,
      transport: {
        type: 'ws',
        path: this.wsPath,
        headers: { Host: this.host }
      }
    };
    return {
      name,
      type: 'VLESS-WS',
      label: 'WebSocket Direct / CDN',
      compat: true,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=none&type=ws&host=${this.host}&path=${urlSafeEncode(this.wsPath)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateVlessWsTls() {
    if (!this.config.enable.vlessWsTls) return null;
    const name = 'AmyraxVPN - WS-TLS';
    const o = this.tlsOpt;
    const clashProxy = this._clashTls({
      name, type: 'vless', server: this.host, port: this.port, uuid: this.state.uuid, network: 'ws',
      'ws-opts': { path: this.wsPath, headers: { Host: o.wsHost } }
    });
    const sbOutbound = {
      type: 'vless', tag: name, server: this.host, server_port: this.port, uuid: this.state.uuid,
      tls: this._sbTls(),
      transport: { type: 'ws', path: this.wsPath, headers: { Host: o.wsHost } }
    };
    return {
      name,
      type: 'VLESS-WS-TLS',
      label: 'CDN Cloudflare Compatible',
      compat: true,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=tls${this._uriTls()}&type=ws&host=${encodeURIComponent(o.wsHost)}&path=${urlSafeEncode(this.wsPath)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateVmessWsTls() {
    if (!this.config.enable.vmessWsTls) return null;
    const name = 'AmyraxVPN - VMess-WS-TLS';
    const o = this.tlsOpt;
    const vmessConfig = {
      v: '2', ps: name, add: this.host, port: String(this.port), id: this.state.uuid, aid: '0', scy: 'auto',
      net: 'ws', type: 'none', host: o.wsHost, path: this.vmessPath, tls: 'tls', sni: o.sni
    };
    if (o.alpn.length) vmessConfig.alpn = o.alpn.join(',');
    if (o.fp) vmessConfig.fp = o.fp;
    const uri = 'vmess://' + Buffer.from(JSON.stringify(vmessConfig)).toString('base64');
    const clashProxy = this._clashTls({
      name, type: 'vmess', server: this.host, port: this.port, uuid: this.state.uuid, alterId: 0, cipher: 'auto', network: 'ws',
      'ws-opts': { path: this.vmessPath, headers: { Host: o.wsHost } }
    });
    const sbOutbound = {
      type: 'vmess', tag: name, server: this.host, server_port: this.port, uuid: this.state.uuid, alter_id: 0, security: 'auto',
      tls: this._sbTls(),
      transport: { type: 'ws', path: this.vmessPath, headers: { Host: o.wsHost } }
    };
    return {
      name,
      type: 'VMess-WS-TLS',
      label: 'Classic Universal Client',
      compat: true,
      uri,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateVmessWs() {
    if (!this.config.enable.vmessWs) return null;
    if (this.edgeTls) return null;  
    const name = 'AmyraxVPN - VMess-WS';
    const vmessConfig = {
      v: '2',
      ps: name,
      add: this.host,
      port: String(this.port),
      id: this.state.uuid,
      aid: '0',
      scy: 'auto',
      net: 'ws',
      type: 'none',
      host: this.host,
      path: this.vmessPath,
      tls: 'none'
    };
    const uri = 'vmess://' + Buffer.from(JSON.stringify(vmessConfig)).toString('base64');
    const clashProxy = {
      name,
      type: 'vmess',
      server: this.host,
      port: this.port,
      uuid: this.state.uuid,
      alterId: 0,
      cipher: 'auto',
      network: 'ws',
      tls: false,
      'ws-opts': {
        path: this.vmessPath,
        headers: { Host: this.host }
      }
    };
    const sbOutbound = {
      type: 'vmess',
      tag: name,
      server: this.host,
      server_port: this.port,
      uuid: this.state.uuid,
      alter_id: 0,
      security: 'auto',
      transport: {
        type: 'ws',
        path: this.vmessPath,
        headers: { Host: this.host }
      }
    };
    return {
      name,
      type: 'VMess-WS',
      label: 'VMess WebSocket Direct',
      compat: true,
      uri,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateVlessHttpUpgrade() {
    if (!this.config.enable.vlessHttpUpgrade) return null;
    if (this.edgeTls) {
      const name = 'AmyraxVPN - HTTPUpgrade-TLS';
      const o = this.tlsOpt;
      const sbOutbound = {
        type: 'vless', tag: name, server: this.host, server_port: this.port, uuid: this.state.uuid,
        tls: this._sbTls(),
        transport: { type: 'httpupgrade', path: this.huPath, host: o.wsHost }
      };
      return {
        name,
        type: 'VLESS-HTTPUpgrade-TLS',
        compat: false,
        uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=tls${this._uriTls()}&type=httpupgrade&host=${encodeURIComponent(o.wsHost)}&path=${urlSafeEncode(this.huPath)}#${urlSafeEncode(name)}`,
        clash: this._clashTls({
          name, type: 'vless', server: this.host, port: this.port, uuid: this.state.uuid, network: 'httpupgrade',
          'httpupgrade-opts': { path: this.huPath, host: o.wsHost }
        }),
        singboxOutbound: [sbOutbound],
        singboxJson: JSON.stringify([sbOutbound], null, 2)
      };
    }
    const name = 'AmyraxVPN - HTTPUpgrade';
    const clashProxy = {
      name,
      type: 'vless',
      server: this.host,
      port: this.port,
      uuid: this.state.uuid,
      network: 'httpupgrade',
      tls: false,
      'httpupgrade-opts': {
        path: this.huPath,
        host: this.host
      }
    };
    const sbOutbound = {
      type: 'vless',
      tag: name,
      server: this.host,
      server_port: this.port,
      uuid: this.state.uuid,
      transport: {
        type: 'httpupgrade',
        path: this.huPath,
        host: this.host
      }
    };
    return {
      name,
      type: 'VLESS-HTTPUpgrade',
      compat: false,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=none&type=httpupgrade&path=${urlSafeEncode(this.huPath)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateReality() {
    if (!this.config.enable.reality) return null;
    if (!this.state.realityPublicKey || !this.state.realityPrivateKey || this.state.realityPublicKey.length < 10) {
      try {
        const kp = crypto.generateKeyPairSync('x25519');
        this.state.realityPrivateKey = kp.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64url');
        this.state.realityPublicKey = kp.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64url');
        this.state.realityShortId = this.state.realityShortId || crypto.randomBytes(4).toString('hex');
      } catch (_) {
        return null;
      }
    }
    const name = 'AmyraxVPN - Reality';
    const target = String(this.config.reality.target || 'www.microsoft.com').replace(/[\[\]]/g, '').trim();
    const shortId = this.state.realityShortId || '12345678';
    const clashProxy = {
      name,
      type: 'vless',
      server: this.host,
      port: this.port,
      uuid: this.state.uuid,
      flow: 'xtls-rprx-vision',
      tls: true,
      'reality-opts': {
        'public-key': this.state.realityPublicKey,
        'short-id': shortId
      },
      'client-fingerprint': 'chrome',
      servername: target
    };
    const sbOutbound = {
      type: 'vless',
      tag: name,
      server: this.host,
      server_port: this.port,
      uuid: this.state.uuid,
      flow: 'xtls-rprx-vision',
      tls: {
        enabled: true,
        server_name: target,
        reality: {
          enabled: true,
          public_key: this.state.realityPublicKey,
          short_id: shortId
        },
        utls: { enabled: true, fingerprint: 'chrome' }
      }
    };
    return {
      name,
      type: 'VLESS-REALITY',
      label: 'Anti-blocking / Web traffic',
      compat: true,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=reality&sni=${target}&fp=chrome&pbk=${this.state.realityPublicKey}&sid=${shortId}&type=tcp&flow=xtls-rprx-vision#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateShadowTls() {
    if (!this.config.enable.shadowTlsVless || !this.state.shadowTlsPassword) return null;
    const name = 'AmyraxVPN - ShadowTLS';
    const sni = String(this.config.shadowTls.sni || 'www.microsoft.com').replace(/[\[\]]/g, '').trim();
    const clashProxy = {
      name,
      type: 'shadow-tls',
      server: this.host,
      port: this.port,
      password: this.state.shadowTlsPassword,
      version: 3,
      sni
    };
    const sbOutbounds = [
      {
        type: 'shadowtls',
        tag: name,
        server: this.host,
        server_port: this.port,
        version: 3,
        password: this.state.shadowTlsPassword,
        tls: {
          enabled: true,
          server_name: sni
        },
        detour: `${name}-detour`
      },
      {
        type: 'vless',
        tag: `${name}-detour`,
        server: this.host,
        server_port: this.port,
        uuid: this.state.uuid
      }
    ];
    return {
      name,
      type: 'ShadowTLS-VLESS',
      compat: false,  
      uri: `shadowtls://${this.state.shadowTlsPassword}@${this.host}:${this.port}?sni=${sni}&version=3#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: sbOutbounds,
      singboxJson: JSON.stringify(sbOutbounds, null, 2),
      note: 'Use Hiddify, sing-box, or Clash Meta'
    };
  }

  generateShadowsocks() {
    if (!this.config.enable.shadowsocks || !this.state.shadowsocksPassword) return null;
    const name = 'AmyraxVPN - Shadowsocks';
    const method = this.config.shadowsocks.method || 'aes-256-gcm';
    const auth = Buffer.from(`${method}:${this.state.shadowsocksPassword}`).toString('base64');
    const clashProxy = {
      name,
      type: 'ss',
      server: this.host,
      port: this.port,
      cipher: method,
      password: this.state.shadowsocksPassword
    };
    const sbOutbound = {
      type: 'shadowsocks',
      tag: name,
      server: this.host,
      server_port: this.port,
      method,
      password: this.state.shadowsocksPassword
    };
    return {
      name,
      type: 'Shadowsocks',
      compat: true,
      uri: `ss://${auth}@${this.host}:${this.port}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  _getOrGenerateWgKeys() {
    let clientPriv = this.state && this.state.wireguardClientPrivateKey;
    let clientPub = this.state && this.state.wireguardClientPublicKey;
    let serverPriv = this.state && this.state.wireguardPrivateKey;
    let serverPub = this.state && this.state.wireguardPublicKey;

    const isValidBase64Key = (k) => typeof k === 'string' && k.trim().length >= 40;

    if (!isValidBase64Key(clientPriv)) {
      try {
        const kp = crypto.generateKeyPairSync('x25519');
        clientPriv = kp.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64');
        clientPub = kp.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
      } catch (_) {
        const raw = crypto.randomBytes(32);
        raw[0] &= 248; raw[31] &= 127; raw[31] |= 64;
        clientPriv = raw.toString('base64');
        clientPub = deriveX25519PublicKey(clientPriv) || crypto.randomBytes(32).toString('base64');
      }
    } else {
      const derived = deriveX25519PublicKey(clientPriv);
      if (derived) clientPub = derived;
    }

    if (!isValidBase64Key(serverPriv)) {
      try {
        const kp = crypto.generateKeyPairSync('x25519');
        serverPriv = kp.privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64');
        serverPub = kp.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64');
      } catch (_) {
        const raw = crypto.randomBytes(32);
        raw[0] &= 248; raw[31] &= 127; raw[31] |= 64;
        serverPriv = raw.toString('base64');
        serverPub = deriveX25519PublicKey(serverPriv) || crypto.randomBytes(32).toString('base64');
      }
    } else {
      const derived = deriveX25519PublicKey(serverPriv);
      if (derived) serverPub = derived;
    }

    if (this.state) {
      this.state.wireguardClientPrivateKey = clientPriv;
      this.state.wireguardClientPublicKey = clientPub;
      this.state.wireguardPrivateKey = serverPriv;
      this.state.wireguardPublicKey = serverPub;
    }

    return { clientPriv, clientPub, serverPub };
  }

  generateWireGuard() {
    try {
      if (!this.config || !this.config.enable || !this.config.enable.wireguard) return null;

      const keys = this._getOrGenerateWgKeys();
      const clientPrivateKey = keys.clientPriv;
      const serverPublicKey = keys.serverPub;

      if (!clientPrivateKey || !serverPublicKey) return null;

      const name = 'AmyraxVPN - WireGuard';
      const port = (this.config.wireguard && this.config.wireguard.port) || this.port || 51820;
      const clientIp = (this.config.wireguard && this.config.wireguard.clientIp) || '10.66.66.2/32';
      const ifaceAddress = clientIp.endsWith('/32') ? clientIp.replace('/32', '/24') : clientIp;
      const mtu = (this.config.wireguard && this.config.wireguard.mtu) || 1420;

      const wgConf = [
        '[Interface]',
        `PrivateKey = ${clientPrivateKey}`,
        `Address = ${ifaceAddress}`,
        'DNS = 1.1.1.1, 8.8.8.8',
        `MTU = ${mtu}`,
        '',
        '[Peer]',
        `PublicKey = ${serverPublicKey}`,
        `Endpoint = ${this.host}:${port}`,
        'AllowedIPs = 0.0.0.0/0, ::/0',
        'PersistentKeepalive = 25'
      ].join('\n') + '\n';

      const clashProxy = {
        name,
        type: 'wireguard',
        server: this.host,
        port,
        ip: clientIp.replace(/\/.*$/, ''),
        'public-key': serverPublicKey,
        'private-key': clientPrivateKey,
        udp: true,
        'remote-dns-resolve': true,
        dns: ['1.1.1.1', '8.8.8.8'],
        mtu
      };

      const sbOutbound = {
        type: 'wireguard',
        tag: name,
        server: this.host,
        server_port: port,
        local_address: [clientIp],
        private_key: clientPrivateKey,
        peer_public_key: serverPublicKey,
        mtu
      };

      const rawUri = `wireguard://${encodeURIComponent(clientPrivateKey)}@${this.host}:${port}?publickey=${encodeURIComponent(serverPublicKey)}&address=${encodeURIComponent(clientIp)}&mtu=${mtu}#${urlSafeEncode(name)}`;

      return {
        name,
        type: 'WireGuard',
        compat: false,
        uri: rawUri,
        wgConf,
        clash: clashProxy,
        singboxOutbound: [sbOutbound],
        singboxJson: JSON.stringify([sbOutbound], null, 2),
        note: 'WireGuard .conf / Clash Meta / Sing-box'
      };
    } catch (err) {
      console.warn(`[WARN] WireGuard generation failed: ${err.message}. Skipping.`);
      return null;
    }
  }

  generateTuic() {
    if (!this.config.enable.tuic) return null;
    const name = 'AmyraxVPN - TUIC';
    const port = this.config.tuic.port || 8443;
    const sni = this.config.sniHy2 || 'www.google.com';
    const cc = this.config.tuic.congestionController || 'bbr';

    const clashProxy = {
      name,
      type: 'tuic',
      server: this.host,
      port,
      uuid: this.state.uuid,
      password: this.state.uuid,
      alpn: ['h3'],
      sni,
      'skip-cert-verify': true,
      'congestion-controller': cc,
      udp: true
    };

    const sbOutbound = {
      type: 'tuic',
      tag: name,
      server: this.host,
      server_port: port,
      uuid: this.state.uuid,
      password: this.state.uuid,
      congestion_controller: cc,
      tls: {
        enabled: true,
        server_name: sni,
        alpn: ['h3'],
        insecure: true
      }
    };

    return {
      name,
      type: 'TUIC',
      compat: false,
      uri: `tuic://${this.state.uuid}:${this.state.uuid}@${this.host}:${port}?congestion_control=${cc}&alpn=h3&sni=${sni}&allow_insecure=1#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  static xhttpOptions() {
    const MODES = ['auto', 'packet-up', 'stream-up', 'stream-one'];
    let mode = String(process.env.XHTTP_MODE || 'packet-up').trim().toLowerCase();
    if (!MODES.includes(mode)) mode = 'packet-up';
    const raw = process.env.XHTTP_ALPN === undefined ? 'h2' : String(process.env.XHTTP_ALPN).trim();
    const alpn = /^(none|off|false)?$/i.test(raw) ? [] : raw.split(',').map(x => x.trim()).filter(Boolean);
    return { mode, alpn };
  }

  generateXhttp() {
    if (!this.config.enable.vlessXhttp) return null;
    if (this.config.xhttpPort === null) return null;  
    if (this.edgeTls) {
      const name = 'AmyraxVPN - XHTTP-TLS';
      const o = this.tlsOpt;
      const x = LinkGenerator.xhttpOptions();
      let q = '&sni=' + encodeURIComponent(o.sni);
      if (o.fp) q += '&fp=' + encodeURIComponent(o.fp);
      if (x.alpn.length) q += '&alpn=' + encodeURIComponent(x.alpn.join(','));
      return {
        name,
        type: 'VLESS-XHTTP-TLS',
        label: 'VLESS-XHTTP-TLS',
        note: 'VLESS-XHTTP-TLS (Xray clients: v2rayNG, v2rayN, Hiddify w/ xray core)',
        compat: true,  
        uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=tls${q}&type=xhttp&host=${encodeURIComponent(o.wsHost)}&path=${urlSafeEncode(this.xhPath)}&mode=${x.mode}#${urlSafeEncode(name)}`,
        clash: null
      };
    }
    const name = 'AmyraxVPN - XHTTP';
    return {
      name,
      type: 'VLESS-XHTTP',
      compat: false,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=none&type=xhttp&path=${urlSafeEncode(this.xhPath)}&mode=auto#${urlSafeEncode(name)}`,
      clash: null
    };
  }

  generateArgo(argoDomain) {
    if (!this.config.enable.argo || !argoDomain) return null;
    const name = 'AmyraxVPN - Argo';
    const clashProxy = {
      name,
      type: 'vless',
      server: argoDomain,
      port: 443,
      uuid: this.state.uuid,
      network: 'ws',
      tls: true,
      servername: argoDomain,
      'ws-opts': {
        path: this.wsPath,
        headers: { Host: argoDomain }
      }
    };
    const sbOutbound = {
      type: 'vless',
      tag: name,
      server: argoDomain,
      server_port: 443,
      uuid: this.state.uuid,
      tls: {
        enabled: true,
        server_name: argoDomain
      },
      transport: {
        type: 'ws',
        path: this.wsPath,
        headers: { Host: argoDomain }
      }
    };
    return {
      name,
      type: 'VLESS-Argo',
      compat: true,
      uri: `vless://${this.state.uuid}@${argoDomain}:443?encryption=none&security=tls&sni=${argoDomain}&type=ws&host=${argoDomain}&path=${urlSafeEncode(this.wsPath)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateTrojanWs() {
    if (!this.config.enable.trojanWs) return null;
    if (this.edgeTls) {
      const name = 'AmyraxVPN - Trojan-WS-TLS';
      const o = this.tlsOpt;
      const sbOutbound = {
        type: 'trojan', tag: name, server: this.host, server_port: this.port, password: this.state.uuid,
        tls: this._sbTls(),
        transport: { type: 'ws', path: this.trPath, headers: { Host: o.wsHost } }
      };
      return {
        name,
        type: 'Trojan-WS-TLS',
        label: 'Trojan WebSocket TLS',
        compat: true,
        uri: `trojan://${this.state.uuid}@${this.host}:${this.port}?security=tls${this._uriTls()}&type=ws&host=${encodeURIComponent(o.wsHost)}&path=${urlSafeEncode(this.trPath)}#${urlSafeEncode(name)}`,
        clash: this._clashTls({
          name, type: 'trojan', server: this.host, port: this.port, password: this.state.uuid, network: 'ws',
          'ws-opts': { path: this.trPath, headers: { Host: o.wsHost } }
        }, 'sni'),
        singboxOutbound: [sbOutbound],
        singboxJson: JSON.stringify([sbOutbound], null, 2)
      };
    }
    const name = 'AmyraxVPN - Trojan-WS';
    const trPath = this.trPath;
    const clashProxy = {
      name,
      type: 'trojan',
      server: this.host,
      port: this.port,
      password: this.state.uuid,
      network: 'ws',
      tls: false,
      'ws-opts': {
        path: trPath,
        headers: { Host: this.host }
      }
    };
    const sbOutbound = {
      type: 'trojan',
      tag: name,
      server: this.host,
      server_port: this.port,
      password: this.state.uuid,
      transport: {
        type: 'ws',
        path: trPath,
        headers: { Host: this.host }
      }
    };
    return {
      name,
      type: 'Trojan-WS',
      label: 'Trojan WebSocket Direct',
      compat: true,
      uri: `trojan://${this.state.uuid}@${this.host}:${this.port}?security=none&type=ws&host=${this.host}&path=${urlSafeEncode(trPath)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateTrojanGrpcTls() {
    if (!this.config.enable.trojanGrpcTls) return null;
    const name = 'AmyraxVPN - gRPC';
    const sni = this.config.domain || this.host;
    const serviceName = this.grpcService;
    const clashProxy = {
      name,
      type: 'trojan',
      server: this.host,
      port: this.port,
      password: this.state.uuid,
      network: 'grpc',
      tls: true,
      sni: sni,
      'skip-cert-verify': true,
      alpn: ['h2'],
      'grpc-opts': {
        'grpc-service-name': serviceName
      }
    };
    const sbOutbound = {
      type: 'trojan',
      tag: name,
      server: this.host,
      server_port: this.port,
      password: this.state.uuid,
      tls: {
        enabled: true,
        server_name: sni,
        alpn: ['h2'],
        insecure: true
      },
      transport: {
        type: 'grpc',
        service_name: serviceName
      }
    };
    return {
      name,
      type: 'Trojan-gRPC-TLS',
      label: 'CDN gRPC Alternative',
      compat: true,
      uri: `trojan://${this.state.uuid}@${this.host}:${this.port}?security=tls&sni=${sni}&alpn=h2&type=grpc&serviceName=${urlSafeEncode(serviceName)}&fp=chrome&allowInsecure=1#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  generateVlessGrpc() {
    if (!this.config.enable.vlessGrpc) return null;
    const name = 'AmyraxVPN - VLESS-gRPC';
    const serviceName = this.grpcService;
    const clashProxy = {
      name,
      type: 'vless',
      server: this.host,
      port: this.port,
      uuid: this.state.uuid,
      network: 'grpc',
      tls: false,
      'grpc-opts': {
        'grpc-service-name': serviceName
      }
    };
    const sbOutbound = {
      type: 'vless',
      tag: name,
      server: this.host,
      server_port: this.port,
      uuid: this.state.uuid,
      transport: {
        type: 'grpc',
        service_name: serviceName
      }
    };
    return {
      name,
      type: 'VLESS-gRPC',
      label: 'gRPC Direct',
      compat: true,
      uri: `vless://${this.state.uuid}@${this.host}:${this.port}?encryption=none&security=none&type=grpc&serviceName=${urlSafeEncode(serviceName)}#${urlSafeEncode(name)}`,
      clash: clashProxy,
      singboxOutbound: [sbOutbound],
      singboxJson: JSON.stringify([sbOutbound], null, 2)
    };
  }

  getAllNodes(options = {}) {
    let argoDomain = null;
    let compat = 'v2ray';
    let allowLocalHost = this.config.allowLocalHostLinks || false;

    if (typeof options === 'string') {
      argoDomain = options;
    } else if (options && typeof options === 'object') {
      argoDomain = options.argoDomain || null;
      if (options.compat) compat = options.compat;
      if (options.allowLocalHostLinks !== undefined) allowLocalHost = options.allowLocalHostLinks;
    }

    const all = TransportSupport.nodes(this);
    const valid = all.filter(node => isValidNode(node, { allowLocalHostLinks: allowLocalHost, compatMode: compat }));
    return [...NodePresentation.nameNodes(valid, this.config.subscriptionName, this.location), ...(this.config.configStudio?.nodes(this) || [])];
  }

  buildClashMetaYaml(nodes) {
    const proxyLines = [];
    const proxyNames = [];

    for (const node of nodes) {
      if (!node.clash) continue;
      proxyNames.push(node.clash.name);
      proxyLines.push(`  - name: ${yamlSafeQuote(node.clash.name)}`);
      proxyLines.push(`    type: ${node.clash.type}`);
      proxyLines.push(`    server: ${yamlSafeQuote(node.clash.server)}`);
      proxyLines.push(`    port: ${node.clash.port}`);

      if (node.clash.plugin) {
        proxyLines.push('    plugin: ' + node.clash.plugin);
        proxyLines.push('    plugin-opts:');
        for (const [key,value] of Object.entries(node.clash['plugin-opts'])) proxyLines.push('      ' + key + ': ' + (typeof value === 'boolean' ? value : yamlSafeQuote(value)));
      }
      if (node.clash.password) proxyLines.push(`    password: ${yamlSafeQuote(node.clash.password)}`);
      if (node.clash.uuid) proxyLines.push(`    uuid: ${yamlSafeQuote(node.clash.uuid)}`);
      if (node.clash.alterId !== undefined) proxyLines.push(`    alterId: ${node.clash.alterId}`);
      if (node.clash.sni) proxyLines.push(`    sni: ${yamlSafeQuote(node.clash.sni)}`);
      if (node.clash.servername) proxyLines.push(`    servername: ${yamlSafeQuote(node.clash.servername)}`);
      if (node.clash['skip-cert-verify'] !== undefined) proxyLines.push(`    skip-cert-verify: ${node.clash['skip-cert-verify']}`);
      if (node.clash.obfs) proxyLines.push(`    obfs: ${node.clash.obfs}`);
      if (node.clash['obfs-password']) proxyLines.push(`    obfs-password: ${yamlSafeQuote(node.clash['obfs-password'])}`);
      if (node.clash.alpn) proxyLines.push(`    alpn: [${node.clash.alpn.map(yamlSafeQuote).join(', ')}]`);
      if (node.clash.network) proxyLines.push(`    network: ${node.clash.network}`);
      if (node.clash.tls !== undefined) proxyLines.push(`    tls: ${node.clash.tls}`);
      if (node.clash.flow) proxyLines.push(`    flow: ${node.clash.flow}`);
      if (node.clash['client-fingerprint']) proxyLines.push(`    client-fingerprint: ${node.clash['client-fingerprint']}`);

      if (node.clash.ip) proxyLines.push(`    ip: ${yamlSafeQuote(node.clash.ip)}`);
      if (node.clash['public-key']) proxyLines.push(`    public-key: ${yamlSafeQuote(node.clash['public-key'])}`);
      if (node.clash['private-key']) proxyLines.push(`    private-key: ${yamlSafeQuote(node.clash['private-key'])}`);
      if (node.clash.udp !== undefined) proxyLines.push(`    udp: ${node.clash.udp}`);
      if (node.clash['remote-dns-resolve'] !== undefined) proxyLines.push(`    remote-dns-resolve: ${node.clash['remote-dns-resolve']}`);
      if (node.clash.dns) proxyLines.push(`    dns: [${node.clash.dns.map(yamlSafeQuote).join(', ')}]`);
      if (node.clash.mtu) proxyLines.push(`    mtu: ${node.clash.mtu}`);
      if (node.clash['congestion-controller']) proxyLines.push(`    congestion-controller: ${yamlSafeQuote(node.clash['congestion-controller'])}`);

      if (node.clash['reality-opts']) {
        proxyLines.push(`    reality-opts:`);
        proxyLines.push(`      public-key: ${yamlSafeQuote(node.clash['reality-opts']['public-key'])}`);
        proxyLines.push(`      short-id: ${yamlSafeQuote(node.clash['reality-opts']['short-id'])}`);
      }

      if (node.clash['ws-opts']) {
        proxyLines.push(`    ws-opts:`);
        proxyLines.push(`      path: ${yamlSafeQuote(node.clash['ws-opts'].path)}`);
        if (node.clash['ws-opts'].headers) {
          proxyLines.push(`      headers:`);
          for (const [k, v] of Object.entries(node.clash['ws-opts'].headers)) {
            proxyLines.push(`        ${k}: ${yamlSafeQuote(v)}`);
          }
        }
      }

      if (node.clash['httpupgrade-opts']) {
        proxyLines.push(`    httpupgrade-opts:`);
        proxyLines.push(`      path: ${yamlSafeQuote(node.clash['httpupgrade-opts'].path)}`);
        proxyLines.push(`      host: ${yamlSafeQuote(node.clash['httpupgrade-opts'].host)}`);
      }

      if (node.clash['grpc-opts']) {
        proxyLines.push(`    grpc-opts:`);
        proxyLines.push(`      grpc-service-name: ${yamlSafeQuote(node.clash['grpc-opts']['grpc-service-name'])}`);
      }

      if (node.clash.cipher) proxyLines.push(`    cipher: ${node.clash.cipher}`);
      if (node.clash.version) proxyLines.push(`    version: ${node.clash.version}`);
    }

    const proxiesBlock = proxyLines.join('\n');
    const proxyListStr = proxyNames.length
      ? proxyNames.map(name => `      - ${yamlSafeQuote(name)}`).join('\n')
      : '      - REJECT';

    return `mode: rule
mixed-port: 7890
ipv6: true
log-level: warning
tcp-concurrent: true
unified-delay: true
keep-alive-idle: 60
keep-alive-interval: 30

profile:
  store-selected: true

tun:
  enable: true
  stack: mixed
  mtu: ${this.config.clientMtu || 1400}
  dns-hijack:
    - "any:53"
    - "tcp://any:53"
  auto-route: true
  auto-detect-interface: true
  strict-route: true

dns:
  enable: true
  listen: ":1053"
  ipv6: true
  nameserver:
    - "https://1.1.1.1/dns-query#PROXY"
    - "https://8.8.8.8/dns-query#PROXY"
  proxy-server-nameserver:
    - "system"
    - "1.1.1.1"
    - "8.8.8.8"

sniffer:
  enable: true
  override-destination: true
  sniff:
    HTTP:
      ports: [80, "8080-8880"]
    TLS:
      ports: [443, 8443]
    QUIC:
      ports: [443, 8443]

proxies:${proxiesBlock ? '\n' + proxiesBlock : ' []'}

proxy-groups:
  - name: "PROXY"
    type: select
    proxies:
      - "Fastest"
${proxyListStr}

  - name: "Fastest"
    type: url-test
    url: https://www.gstatic.com/generate_204
    interval: 180
    timeout: 10000
    tolerance: 100
    lazy: true
    max-failed-times: 3
    proxies:
${proxyListStr}

rules:
  - MATCH,PROXY
`;
  }

  buildSingBoxClientJson(nodes) {
    const outbounds = [];
    const endpoints = [];
    const proxyTags = [];

    for (const node of nodes) {
      if (node.singboxOutbound && Array.isArray(node.singboxOutbound)) {
        for (const ob of node.singboxOutbound) {
          if (ob.type === 'wireguard') {
            endpoints.push({
              type: 'wireguard', tag: ob.tag,
              address: ob.local_address, private_key: ob.private_key, mtu: ob.mtu,
              peers: [{
                address: ob.server, port: ob.server_port, public_key: ob.peer_public_key,
                allowed_ips: ['0.0.0.0/0', '::/0']
              }]
            });
          } else if (ob.type === 'tuic' && ob.congestion_controller !== undefined) {
            const { congestion_controller, ...outbound } = ob;
            outbounds.push({ ...outbound, congestion_control: congestion_controller });
          } else outbounds.push(ob);
        }
        proxyTags.push(node.name);
      }
    }

    const allOutbounds = [];

    if (proxyTags.length > 0) {
      allOutbounds.push(
        {
          type: 'selector',
          tag: '🛡️ Amyrax Panel',
          outbounds: ['⚡ Auto Select', ...proxyTags],
          default: '⚡ Auto Select',
          interrupt_exist_connections: false
        },
        {
          type: 'urltest',
          tag: '⚡ Auto Select',
          outbounds: [...proxyTags],
          url: 'https://www.gstatic.com/generate_204',
          interval: '3m',
          tolerance: 100,
          idle_timeout: '30m',
          interrupt_exist_connections: false
        }
      );
    }

    allOutbounds.push(...outbounds);
    allOutbounds.push(
      { type: 'direct', tag: 'direct' },
      { type: 'block', tag: 'block' }
    );

    return JSON.stringify({
      log: { level: 'warn' },
      dns: {
        servers: [
          { type: 'https', tag: 'dns-proxy', server: '1.1.1.1', detour: proxyTags.length ? '🛡️ Amyrax Panel' : 'block' },
          { type: 'local', tag: 'dns-bootstrap' }
        ],
        final: 'dns-proxy',
        strategy: 'prefer_ipv4'
      },
      inbounds: [{
        type: 'tun', tag: 'tun-in',
        address: ['172.19.0.1/30', 'fdfe:dcba:9876::1/126'],
        mtu: this.config.clientMtu || 1400, auto_route: true, strict_route: true, stack: 'mixed'
      }],
      outbounds: allOutbounds,
      ...(endpoints.length ? { endpoints } : {}),
      route: {
        rules: [{ action: 'sniff' }, { protocol: 'dns', action: 'hijack-dns' }],
        default_domain_resolver: 'dns-bootstrap',
        auto_detect_interface: true,
        final: proxyTags.length ? '🛡️ Amyrax Panel' : 'block'
      }
    }, null, 2);
  }
}

function subscriptionFormat(req) {
  const aliases = { auto: 'auto', html: 'html', info: 'info', clash: 'clash', flclash: 'clash', mihomo: 'clash', singbox: 'singbox', 'sing-box': 'singbox', raw: 'raw', base64: 'base64', v2rayng: 'base64', streisand: 'base64' };
  if (req.query.format !== undefined) {
    if (typeof req.query.format !== 'string') return null;
    const key = req.query.format.toLowerCase();
    const explicit = Object.hasOwn(aliases,key) ? aliases[key] : null;
    if (!explicit) return null;
    if (explicit !== 'auto') return explicit;
  }
  const ua = String(req.get('user-agent') || '').toLowerCase();
  if (/hiddify/.test(ua)) return 'base64';
  if (/flclash|clash|mihomo|\bstash\b/.test(ua)) return 'clash';
  if (/streisand/.test(ua)) return 'base64';
  if (/v2rayn|v2rayng|nekobox|nekoray|shadowrocket|\bhapp\b/.test(ua)) return 'base64';
  if (/sing-box|singbox|\bsfa[\/ ]|\bsfi[\/ ]|\bsfm[\/ ]/.test(ua)) return 'singbox';
  if (/(?:text\/html|application\/xhtml\+xml)/i.test(String(req.get('accept') || ''))) return 'html';
  return 'base64';
}

const ConfigStudio = createConfigStudio({ LinkGenerator, TransportSupport, Logger });

// BEGIN USER MANAGEMENT
function createUserManagement({ LinkGenerator, Logger, AmyraxTraffic, ConfigStudio }) {
  const fs = require('fs'), path = require('path'), crypto = require('crypto'), net = require('net');
  const { spawn, execFile } = require('child_process');
  const DAY = 86400000, GiB = 1073741824;
  const protocols = { vless: 'VLESS', vmess: 'VMess', trojan: 'Trojan', shadowsocks: 'Shadowsocks' };
  const storedProtocols = { ...protocols, trojan: true, httpupgrade: true };
  const secret = () => crypto.randomBytes(24).toString('hex');
  const fail = (message, status = 400) => { const e = new Error(message); e.status = status; throw e; };
  const numeric = (value, label, max) => {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > max) fail(label + ' باید عددی بین صفر و ' + max + ' باشد.');
    return value;
  };
  const text = (value, label, max, required = false) => {
    if (typeof value !== 'string' || value.length > max || (required ? /[\u0000-\u001f\u007f]/ : /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/).test(value) || (required && !value.trim())) fail(label + ' معتبر نیست.');
    return value.trim();
  };
  class UserManager {
    constructor(config, stateManager) {
      this.config = config; this.stateManager = stateManager;
      this.file = path.join(config.paths.dataDir, 'users.json');
      this.users = []; this.connections = new Map(); this.targets = new Map(); this.generations = new Set();
      this.engine = { status: 'idle', message: 'با اولین کاربر، سرویس اتصال کاربران راه‌اندازی می‌شود.' };
      this.running = false; this.dirty = false; this.revision = 0;
      try {
        if (fs.existsSync(this.file)) {
          const saved = JSON.parse(fs.readFileSync(this.file, 'utf8'));
          if (saved.version !== 1 || !Array.isArray(saved.users)) throw new Error('Invalid user database');
          const ids = new Set(), keys = new Set(), credentials = new Set([stateManager.state.uuid]);
          for (const u of saved.users) {
            if (!u || !/^[0-9a-f-]{36}$/.test(u.id) || !/^[0-9a-f-]{36}$/.test(u.uuid) || !/^[0-9a-f]{48}$/.test(u.token) || !/^[0-9a-f]{48}$/.test(u.routeKey) || ids.has(u.id) || credentials.has(u.uuid) || keys.has(u.token) || keys.has(u.routeKey)) throw new Error('Invalid user record');
            this.validate(u, u);
            for (const n of ['up', 'down', 'lifetimeUp', 'lifetimeDown']) if (!Number.isSafeInteger(u[n]) || u[n] < 0) throw new Error('Invalid traffic counters');
            for (const n of ['createdAt', 'updatedAt', 'quotaStartedAt']) if (!Number.isFinite(u[n]) || u[n] <= 0) throw new Error('Invalid timestamps');
            if (u.expiresAt !== null && (!Number.isFinite(u.expiresAt) || u.expiresAt <= 0)) throw new Error('Invalid expiration');
            if (!u.history || typeof u.history !== 'object' || Array.isArray(u.history) || Object.entries(u.history).some(([k,v])=>!Number.isFinite(Number(k)) || !v || !Number.isSafeInteger(v.up) || !Number.isSafeInteger(v.down) || v.up<0 || v.down<0 || (v.spanMinutes !== undefined && ![30,60].includes(v.spanMinutes)))) throw new Error('Invalid usage history');
            ids.add(u.id); credentials.add(u.uuid); keys.add(u.token); keys.add(u.routeKey);
          }
          this.users = saved.users;
        }
      } catch (e) {
        this.loadError = 'فایل کاربران خوانده نشد؛ فایل users.json را بررسی یا از نسخهٔ پشتیبان بازیابی کنید.';
        this.engine = { status: 'error', message: this.loadError };
        Logger.error('User database could not be loaded; managed connections remain closed.');
      }
      this.timer = setInterval(() => this.tick(), 1000); this.timer.unref();
    }
    available() { if (this.loadError) fail(this.loadError, 503); }
    validate(input, current = {}, skipUnique = false) {
      if (!input || typeof input !== 'object' || Array.isArray(input)) fail('اطلاعات کاربر معتبر نیست.');
      const allowed = ['name','note','enabled','limitGB','durationDays','startMode','resetDays','protocols','revision'];
      const out = {};
      for (const key of Object.keys(input)) {
        if (!allowed.includes(key)) { if (input === current) continue; fail('تنظیم ناشناخته: ' + key); }
        const v = input[key];
        if (key === 'name' || key === 'note') out[key] = text(v, key === 'name' ? 'نام کاربر' : 'یادداشت', key === 'name' ? 64 : 500, key === 'name');
        if (['limitGB','durationDays','resetDays'].includes(key)) out[key] = numeric(v, key, key === 'limitGB' ? 1000000 : 36500);
        if (key === 'enabled') { if (typeof v !== 'boolean') fail('وضعیت کاربر معتبر نیست.'); out[key] = v; }
        if (key === 'startMode') { if (!['now','first-use'].includes(v)) fail('زمان شروع اعتبار معتبر نیست.'); out[key] = v; }
        if (key === 'protocols') {
          if (!Array.isArray(v) || !v.length || v.length > 5 || v.some(p => !Object.hasOwn(input === current ? storedProtocols : protocols,p)) || new Set(v).size !== v.length) fail('حداقل یک پروتکل معتبر انتخاب کنید.');
          out[key] = v.slice();
        }
      }
      if (!skipUnique && out.name && this.users.some(u => u.id !== current.id && u.name.toLowerCase() === out.name.toLowerCase())) fail('نام کاربر تکراری است.',409);
      return out;
    }
    planImport(backup, reservedToken = '') {
      this.available();
      if(!backup || backup.version!==1 || !Array.isArray(backup.users)) fail('فایل پشتیبان نسخهٔ ۱ با فهرست کاربران لازم است.');
      const fields=['id','uuid','token','routeKey','name','note','enabled','limitGB','durationDays','startMode','resetDays','protocols','revision','createdAt','updatedAt','firstConnectedAt','lastConnectedAt','expiresAt','archivedAt','quotaStartedAt','up','down','lifetimeUp','lifetimeDown','history'];
      const inputIds=new Set(),inputKeys=new Set(),inputUUIDs=new Set();
      const records=backup.users.map((raw,index)=>{
        const invalid=()=>fail('اطلاعات ردیف '+(index+1)+' پشتیبان معتبر نیست؛ هیچ کاربری اضافه نشد.');
        if(!raw || typeof raw!=='object' || Array.isArray(raw) || Object.keys(raw).some(k=>!fields.includes(k)) || fields.some(k=>!Object.hasOwn(raw,k)))invalid();
        if(['id','uuid','token','routeKey'].some(k=>typeof raw[k]!=='string')||!/^[\da-f]{8}(-[\da-f]{4}){3}-[\da-f]{12}$/i.test(raw.id) || !/^[\da-f]{8}(-[\da-f]{4}){3}-[\da-f]{12}$/i.test(raw.uuid) || !/^[a-f0-9]{48}$/.test(raw.token) || !/^[a-f0-9]{48}$/.test(raw.routeKey))invalid();
        this.validate(raw,raw,true);
        if(!raw.name.trim() || !Number.isSafeInteger(raw.revision) || raw.revision<1)invalid();
        for(const key of ['up','down','lifetimeUp','lifetimeDown'])if(!Number.isSafeInteger(raw[key])||raw[key]<0)invalid();
        if(!Number.isSafeInteger(raw.up+raw.down)||!Number.isSafeInteger(raw.lifetimeUp+raw.lifetimeDown))invalid();
        for(const key of ['createdAt','updatedAt','quotaStartedAt','firstConnectedAt','lastConnectedAt','expiresAt','archivedAt']){
          const value=raw[key],nullable=['firstConnectedAt','lastConnectedAt','expiresAt','archivedAt'].includes(key);
          if(!(nullable&&value===null)&&(!Number.isSafeInteger(value)||value<=0||value>8640000000000000))invalid();
        }
        if(!raw.history || typeof raw.history!=='object' || Array.isArray(raw.history) || Object.keys(raw.history).length>512)invalid();
        const history=Object.create(null);
        for(const [key,value] of Object.entries(raw.history)){
          if(!/^\d+$/.test(key)||!Number.isSafeInteger(Number(key))||Number(key)<=0||Number(key)>8640000000000000||!value||!Number.isSafeInteger(value.up)||!Number.isSafeInteger(value.down)||value.up<0||value.down<0||!Number.isSafeInteger(value.up+value.down)||(value.spanMinutes!==undefined&&![30,60].includes(value.spanMinutes)))invalid();
          history[key]={up:value.up,down:value.down,...(value.spanMinutes===undefined?{}:{spanMinutes:value.spanMinutes})};
        }
        const id=raw.id.toLowerCase(),uuid=raw.uuid.toLowerCase();
        if(inputIds.has(id)||inputUUIDs.has(uuid)||inputKeys.has(raw.token)||inputKeys.has(raw.routeKey)||raw.token===raw.routeKey)fail('شناسه یا کلید تکراری داخل فایل پشتیبان است؛ هیچ کاربری اضافه نشد.');
        inputIds.add(id);inputUUIDs.add(uuid);inputKeys.add(raw.token);inputKeys.add(raw.routeKey);
        return {...Object.fromEntries(fields.map(key=>[key,raw[key]])),id,uuid,name:raw.name.trim(),history,protocols:raw.protocols.slice()};
      });
      const ids=new Set(this.users.map(u=>u.id.toLowerCase()));
      const uuids=new Set([this.stateManager.state.uuid,...this.users.map(u=>u.uuid)].filter(Boolean).map(s=>s.toLowerCase()));
      const keys=new Set([reservedToken,...this.users.flatMap(u=>[u.token,u.routeKey])].filter(Boolean));
      const names=new Set(this.users.map(u=>u.name.toLowerCase())),additions=[],rows=[];
      let skipped=0,renamed=0;
      for(const u of records){
        if(ids.has(u.id)||uuids.has(u.uuid)||keys.has(u.token)||keys.has(u.routeKey)){
          skipped++;rows.push({name:u.name,action:'skip',reason:'حساب یا کلید از قبل وجود دارد؛ اطلاعات فعلی حفظ می‌شود.'});continue;
        }
        const original=u.name;let suffix=1;
        while(names.has(u.name.toLowerCase())){const tail=' (بازیابی '+(suffix++)+')';u.name=original.slice(0,64-tail.length)+tail;}
        if(u.name!==original)renamed++;
        additions.push(u);rows.push({name:original,newName:u.name,action:u.name===original?'add':'rename'});
        ids.add(u.id);uuids.add(u.uuid);keys.add(u.token);keys.add(u.routeKey);names.add(u.name.toLowerCase());
      }
      const fingerprint=crypto.createHash('sha256').update(JSON.stringify({reservedToken,shared:this.stateManager.state.uuid,current:this.users.map(u=>[u.id,u.uuid,u.token,u.routeKey,u.name]),records})).digest('hex');
      return {additions,summary:{total:records.length,added:additions.length,skipped,renamed,rows,fingerprint}};
    }
    importBackup(backup, fingerprint, reservedToken = '') {
      const plan=this.planImport(backup,reservedToken);
      if(typeof fingerprint!=='string'||fingerprint!==plan.summary.fingerprint)fail('اطلاعات کاربران یا فایل تغییر کرده؛ پیش‌نمایش بازیابی را دوباره بررسی کنید.',409);
      if(plan.additions.length){const merged=[...this.users,...plan.additions];this.persist(merged);this.users=merged;this.schedule();}
      return plan.summary;
    }
    persist(users = this.users) {
      fs.mkdirSync(path.dirname(this.file), { recursive:true });
      const tmp = this.file + '.tmp';
      const fd = fs.openSync(tmp, 'w', 0o600);
      try { fs.writeFileSync(fd, JSON.stringify({ version:1, users })); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(tmp, this.file); this.dirty = false; this.storageError = false;
    }
    find(id) { this.available(); const u = this.users.find(u => u.id === id); if (!u) fail('کاربر پیدا نشد.',404); return u; }
    byToken(token) { if (this.loadError) return null; return this.users.find(u => !u.archivedAt && u.token === token); }
    status(u, now = Date.now()) {
      if (u.archivedAt) return 'archived';
      if (!u.enabled) return 'disabled';
      if (u.expiresAt && now >= u.expiresAt) return 'expired';
      if (u.limitGB > 0 && u.up + u.down >= Math.floor(u.limitGB * GiB)) return 'limited';
      return u.durationDays > 0 && !u.expiresAt ? 'pending' : 'active';
    }
    permitted(u) { return !this.storageError && ['active','pending'].includes(this.status(u)); }
    create(input) {
      this.available();
      const fields = this.validate(input);
      if (!fields.name) fail('نام کاربر الزامی است.');
      const now = Date.now();
      const u = { id:crypto.randomUUID(), uuid:crypto.randomUUID(), token:secret(), routeKey:secret(), name:'', note:'', enabled:true, limitGB:0, durationDays:0, startMode:'now', resetDays:0, protocols:Object.keys(protocols), ...fields, revision:1, createdAt:now, updatedAt:now, firstConnectedAt:null, lastConnectedAt:null, expiresAt:null, archivedAt:null, quotaStartedAt:now, up:0, down:0, lifetimeUp:0, lifetimeDown:0, history:{} };
      if (u.durationDays > 0 && u.startMode === 'now') u.expiresAt = now + u.durationDays * DAY;
      this.persist([...this.users,u]); this.users.push(u); this.schedule(); return u;
    }
    update(id, input) {
      const old = this.find(id);
      if (input.revision !== old.revision) fail('این کاربر در جای دیگری تغییر کرده؛ فهرست را تازه کنید.',409);
      const fields = this.validate(input,old), now = Date.now();
      const u = {...old,...fields,revision:old.revision+1,updatedAt:now};
      if (fields.durationDays !== undefined && fields.durationDays !== old.durationDays || fields.startMode !== undefined && fields.startMode !== old.startMode) {
        u.expiresAt = u.durationDays === 0 || (u.startMode === 'first-use' && !u.firstConnectedAt) ? null : now + u.durationDays * DAY;
      }
      if (fields.resetDays !== undefined && fields.resetDays !== old.resetDays) u.quotaStartedAt = now;
      const users = this.users.map(x => x.id === id ? u : x); this.persist(users); this.users = users;
      const changedProtocols=JSON.stringify(old.protocols)!==JSON.stringify(u.protocols);
      if(!this.permitted(u)||changedProtocols)this.disconnect(id);
      if(changedProtocols) { this.targets.delete(id); this.schedule(); }
      return u;
    }
    remove(id, input) {
      const old = this.find(id);
      if (input?.revision !== old.revision) fail('اطلاعات کاربر تغییر کرده؛ فهرست را تازه کنید.',409);
      const remaining = this.users.filter(u => u.id !== id);
      this.persist(remaining); this.users = remaining;
      this.disconnect(id); this.connections.delete(id); this.targets.delete(id);
      this.schedule();
      return id;
    }
    action(id, input) {
      const old = this.find(id);
      if (input.revision !== old.revision) fail('اطلاعات کاربر تغییر کرده؛ فهرست را تازه کنید.',409);
      const u = {...old, revision:old.revision+1, updatedAt:Date.now()};
      switch (input.action) {
        case 'reset': u.up = 0; u.down = 0; u.quotaStartedAt = Date.now(); break;
        case 'renew': {
          const days = numeric(input.days,'مدت تمدید',36500); u.durationDays = days;
          u.expiresAt = days === 0 ? null : Math.max(Date.now(),u.expiresAt || 0) + days * DAY; u.startMode='now'; break;
        }
        case 'rotate-link': u.token = secret(); break;
        case 'rotate-credentials': u.uuid = crypto.randomUUID(); u.routeKey = secret(); break;
        case 'archive': u.archivedAt = Date.now(); break;
        case 'restore': u.archivedAt = null; break;
        case 'disconnect': break;
        default: fail('عملیات شناخته نشد.');
      }
      const users = this.users.map(x => x.id === id ? u : x); this.persist(users); this.users=users;
      if (input.action !== 'rotate-link') this.disconnect(id);
      if (['rotate-credentials','restore','archive'].includes(input.action)) { this.targets.delete(id); this.schedule(); }
      return u;
    }
    publicUser(u, url) {
      return {...u, protocols:u.protocols.filter(p=>Object.hasOwn(protocols,p)), routeKey:undefined, uuid:undefined, token:undefined, history:undefined, status:this.status(u), usedBytes:u.up+u.down, limitBytes:Math.floor(u.limitGB*GiB), activeConnections:this.connections.get(u.id)?.size || 0, subscriptionUrl:url};
    }
    traffic(u) {
      const now = Date.now(), today = new Date().toISOString().slice(0,10);
      const hourly = Object.entries(u.history).filter(([t])=>Number(t)>=now-8*DAY).map(([t,v])=>({at:Number(t),up:v.up,down:v.down,total:v.up+v.down,spanMinutes:v.spanMinutes||60}));
      return {ok:true,day:{total:hourly.filter(h=>new Date(h.at).toISOString().startsWith(today)).reduce((s,h)=>s+h.total,0)},month:{up:u.up,used:u.up+u.down},allTime:{total:u.lifetimeUp+u.lifetimeDown},limit:{bytes:Math.floor(u.limitGB*GiB),gb:u.limitGB,remaining:u.limitGB ? Math.max(0,u.limitGB*GiB-u.up-u.down):null},history:{since:new Date(u.createdAt).toISOString(),hours:Object.fromEntries(hourly.map(h=>[new Date(h.at).toISOString().slice(0,16),{up:h.up,down:h.down,spanMinutes:h.spanMinutes}]))},since:new Date(u.createdAt).toISOString()};
    }
    generator(u,host) {
      const enable = Object.fromEntries(Object.keys(this.config.enable).map(k=>[k,false]));
      const groups={vless:['vlessWs','vlessWsTls','vlessHttpUpgrade','vlessHttpUpgradeTls','vlessGrpc','vlessGrpcTls','vlessXhttp','vlessXhttpTls','vlessXhttpStream','vlessXhttpStreamTls'],vmess:['vmessWs','vmessWsTls','vmessHttpUpgrade','vmessHttpUpgradeTls','vmessGrpc','vmessGrpcTls'],trojan:['trojanWs','trojanWsTls','trojanHttpUpgrade','trojanHttpUpgradeTls','trojanGrpc','trojanGrpcTls'],shadowsocks:['shadowsocks']};
      for(const [protocol,flags] of Object.entries(groups))for(const flag of flags)enable[flag]=u.protocols.includes(protocol)&&this.config.enable[flag];
      const generator = new LinkGenerator({...this.config,enable,subscriptionName:u.name,profileAccountId:u.id},{...this.stateManager.state,uuid:u.uuid,shadowsocksPassword:u.uuid},host);
      return generator;
    }
    tick() {
      if (this.loadError || this.stopped) return;
      const now=Date.now();
      for (const u of this.users) {
        if (u.resetDays > 0 && now >= u.quotaStartedAt + u.resetDays*DAY) {
          u.quotaStartedAt += Math.floor((now-u.quotaStartedAt)/(u.resetDays*DAY))*u.resetDays*DAY; u.up=0;u.down=0;this.dirty=true;
        }
        if (!this.permitted(u)) this.disconnect(u.id);
      }
      if (this.dirty) { try { this.persist(); } catch (_) { this.storageError=true; for(const id of this.connections.keys()) this.disconnect(id); } }
    }
    disconnect(id) { for(const c of this.connections.get(id) || []) c.close(); }
    charge(id, direction, bytes) {
      const u=this.users.find(u=>u.id===id);
      if (!u || !this.permitted(u)) return false;
      if (u.limitGB > 0) bytes = Math.min(bytes,Math.max(0,Math.floor(u.limitGB*GiB)-u.up-u.down));
      if (!bytes) { this.disconnect(id); return 0; }
      const now=Date.now();
      if (!u.firstConnectedAt) { u.firstConnectedAt=now; if(u.durationDays>0 && u.startMode==='first-use' && !u.expiresAt) u.expiresAt=now+u.durationDays*DAY; }
      u.lastConnectedAt=now;u[direction]+=bytes;u[direction==='up'?'lifetimeUp':'lifetimeDown']+=bytes;
      const hour=String(Math.floor(now/1800000)*1800000); u.history[hour] ||= {up:0,down:0,spanMinutes:30};u.history[hour][direction]+=bytes;
      for(const t of Object.keys(u.history)) if(Number(t)<now-8*DAY) delete u.history[t];
      this.dirty=true; return bytes;
    }
    start() {this.running=true;this.schedule();}
    schedule() {
      this.revision++;if(!this.running||this.loadError||this.stopped){if(!this.loadError&&this.users.length)this.engine={status:'offline',message:'اطلاعات ذخیره شد؛ سرویس اتصال در این اجرای آزمایشی فعال نیست.'};return;}
      if(this.users.some(u=>!u.archivedAt))this.engine={status:'applying',message:'در حال اعمال تنظیمات اتصال کاربران…'};
      if(this.building){this.rebuildAgain=true;return;}
      this.scheduledAt ||= Date.now();
      const delay=Math.min(750,Math.max(0,2000-(Date.now()-this.scheduledAt)));
      clearTimeout(this.buildTimer);this.buildTimer=setTimeout(()=>{this.scheduledAt=0;this.rebuild();},delay);this.buildTimer.unref();
    }
    async freePort() {
      return new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});
    }
    async rebuild() {
      if(this.stopped||this.building)return;
      this.building=true;this.rebuildAgain=false;const revision=this.revision;
      let child=null,file=null;
      try {
        const users=this.users.filter(u=>!u.archivedAt);
        if(!users.length){this.targets=new Map();this.engine={status:'idle',message:'هنوز کاربری ساخته نشده است.'};this.currentGeneration=null;this.retire();return;}
        if(!fs.existsSync(this.config.paths.singboxBin)) throw new Error('موتور sing-box نصب یا راه‌اندازی نشده است.');
        this.engine={status:'applying',message:'در حال اعمال تنظیمات اتصال کاربران…'};
        const generation=secret().slice(0,12),targets=new Map(),inbounds=[],ports=new Set();
        for(const u of users){const entries={};for(const p of u.protocols.filter(p=>Object.hasOwn(protocols,p))){let port;do{port=await this.freePort();}while(ports.has(port));ports.add(port);
          entries[p]={port,generation};inbounds.push({type:p,tag:u.id+'-'+p,listen:'127.0.0.1',listen_port:port,...(p==='shadowsocks'?{method:'aes-256-gcm',password:u.uuid,network:'tcp'}:{users:[{name:u.id,...(p==='trojan'?{password:u.uuid}:{uuid:u.uuid,...(p==='vmess'?{alterId:0}:{})})}]})});
        }targets.set(u.id,entries);}
        file=path.join(this.config.paths.dataDir,'users-engine-'+generation+'.json');
        fs.writeFileSync(file,JSON.stringify({log:{level:'error',timestamp:true},inbounds,...(ConfigStudio?ConfigStudio.singboxRoute(this.config):{outbounds:[{type:'direct',tag:'direct'}],route:{final:'direct'}})}),{mode:0o600});
        await new Promise((resolve,reject)=>{
          this.checkProcess=execFile(this.config.paths.singboxBin,['check','-c',file],{windowsHide:true,encoding:'utf8',timeout:15000,maxBuffer:256*1024},error=>{
            this.checkProcess=null;
            if(error)reject(new Error('اعتبارسنجی موتور کاربران ناموفق بود؛ نسخهٔ sing-box را بررسی کنید.'));else resolve();
          });
        });
        if(this.stopped||revision!==this.revision){fs.unlinkSync(file);return;}
        child=spawn(this.config.paths.singboxBin,['run','-c',file],{windowsHide:true,stdio:['ignore','ignore','pipe']});
        let exited=false;child.once('error',()=>{exited=true;});child.once('exit',()=>{exited=true;});child.stderr.on('data',()=>{});
        const deadline=Date.now()+10000;
        for(const port of ports){
          let ready=false;
          while(!ready && !exited && Date.now()<deadline && !this.stopped){
            ready=await new Promise(resolve=>{const s=net.connect(port,'127.0.0.1');let done=false;const finish=v=>{if(done)return;done=true;s.destroy();resolve(v);};s.setTimeout(300,()=>finish(false));s.on('connect',()=>finish(true));s.on('error',()=>finish(false));});
            if(!ready) await new Promise(resolve=>setTimeout(resolve,50));
          }
          if(!ready) throw new Error('سرویس اتصال کاربران آماده نشد.');
        }
        if(this.stopped||revision!==this.revision){child.kill();fs.unlinkSync(file);return;}
        const gen={id:generation,child,file};this.generations.add(gen);this.currentGeneration=generation;this.targets=targets;
        this.engine={status:'ready',message:'سرویس اتصال کاربران آماده است.'};
        child.on('exit',()=>{this.generations.delete(gen);try{fs.unlinkSync(file);}catch(_){}if(this.currentGeneration===generation&&!this.stopped){this.targets.clear();this.engine={status:'error',message:'موتور کاربران متوقف شد؛ تلاش مجدد…'};clearTimeout(this.retryTimer);this.retryTimer=setTimeout(()=>this.schedule(),5000);this.retryTimer.unref();}});
        this.retire();
      } catch(e) {
        if(child)child.kill();if(file)try{fs.unlinkSync(file);}catch(_){}
        if(!this.stopped){this.engine={status:'error',message:e.message};Logger.warn('Managed-user engine setup failed.');}
      } finally {this.building=false;if(this.rebuildAgain&&!this.stopped)this.schedule();}
    }
    retire() {
      const active=new Set([...this.connections.values()].flatMap(s=>[...s].map(c=>c.generation)));
      for(const g of this.generations) if(g.id!==this.currentGeneration&&!active.has(g.id)){this.generations.delete(g);g.child.kill();try{fs.unlinkSync(g.file);}catch(_){}}
    }
    stop() {
      this.stopped=true;this.running=false;clearInterval(this.timer);clearTimeout(this.buildTimer);clearTimeout(this.retryTimer);
      this.checkProcess?.kill();
      for(const id of this.connections.keys())this.disconnect(id);
      for(const g of this.generations)g.child.kill();
      if(!this.loadError&&this.dirty)try{this.persist();}catch(_){}
    }
  }
  UserManager.protocols=protocols;
  return UserManager;
}

// END USER MANAGEMENT


// BEGIN SYSTEM METRICS
function createSystemMetrics(options = {}) {
  const fs = options.fs || require('fs'), os = options.os || require('os'), proc = options.process || process;
  const path = require('path').posix;
  const read = file => { try { return fs.readFileSync(file,'utf8').trim(); } catch { return ''; } };
  const exists = file => { try { return fs.existsSync(file); } catch { return false; } };
  const number = text => /^\d+$/.test(text) && Number.isSafeInteger(Number(text)) ? Number(text) : null;
  const linux = os.platform() === 'linux';
  let ticks = options.clockTicks || null, cached = null, cachedAt = 0;
  if (linux && !ticks && !options.fs) {
    require('child_process').execFile('getconf',['CLK_TCK'],{windowsHide:true,timeout:1000,maxBuffer:1024},(error,stdout) => {
      if (!error && number(stdout.trim()) > 0) { ticks = number(stdout.trim()); cachedAt = 0; }
    });
  }
  const decode = value => value.replace(/\\([0-7]{3})/g,(_,n)=>String.fromCharCode(parseInt(n,8)));
  function groups(controller) {
    const memberships = read('/proc/self/cgroup').split('\n').map(line => {
      const [id,controllers,...rest] = line.split(':'); return {id,controllers:controllers?.split(',') || [],dir:rest.join(':')};
    });
    const results = [];
    for (const line of read('/proc/self/mountinfo').split('\n')) {
      const [left,right] = line.split(' - '); if (!right) continue;
      const fields = left.split(' '), extra = right.split(' '), v2 = extra[0] === 'cgroup2';
      if (!v2 && !(extra[0] === 'cgroup' && extra[2]?.split(',').includes(controller))) continue;
      const member = memberships.find(m => v2 ? m.id === '0' : m.controllers.includes(controller));
      if (!member) continue;
      const root = decode(fields[3]), mount = decode(fields[4]);
      let relative = member.dir === root ? '' : member.dir.startsWith(root.replace(/\/$/,'')+'/') ? member.dir.slice(root.length) : member.dir === '/' ? '' : null;
      if (relative === null || relative.split('/').includes('..')) continue;
      let dir = path.join(mount,relative);
      while (dir === mount || dir.startsWith(mount+'/')) {
        results.push({dir,v2}); if (dir === mount) break; dir = path.dirname(dir);
      }
    }
    if (!results.length) {
      if (exists('/sys/fs/cgroup/cgroup.controllers')) results.push({dir:'/sys/fs/cgroup',v2:true});
      else results.push({dir:'/sys/fs/cgroup/'+controller,v2:false});
    }
    return results;
  }
  const memoryGroups = linux ? groups('memory') : [], cpuGroups = linux ? groups('cpu') : [];
  const containerHint = linux && (exists('/.dockerenv') || exists('/run/.containerenv') || /docker|kubepods|containerd|lxc|libpod/.test(read('/proc/1/cgroup')));
  return {
    snapshot() {
      const now = Date.now(); if (cached && now-cachedAt < 1000) return cached;
      const hostTotal = os.totalmem(), hostUsed = Math.max(0,hostTotal-os.freemem());
      const processRss = proc.memoryUsage().rss;
      let allocation = null, groupUsage = null;
      for (const {dir,v2} of memoryGroups) {
        const total = number(read(dir+'/'+(v2?'memory.max':'memory.limit_in_bytes')));
        const used = number(read(dir+'/'+(v2?'memory.current':'memory.usage_in_bytes')));
        if (groupUsage === null && used !== null) groupUsage = used;
        if (total > 0 && total < hostTotal && (!allocation || total < allocation.total)) allocation = {total,used};
      }
      const constrained = typeof proc.constrainedMemory === 'function' ? proc.constrainedMemory() : 0;
      if (constrained > 0 && constrained < hostTotal && (!allocation || constrained < allocation.total)) allocation = {total:constrained,used:groupUsage};
      const scoped = !!allocation || containerHint;
      const memory = allocation ? {...allocation,scope:'allocation'} : containerHint ? {total:null,used:groupUsage,scope:'container'} : {total:hostTotal,used:hostUsed,scope:'host'};
      let cores = os.availableParallelism ? os.availableParallelism() : os.cpus().length;
      for (const {dir,v2} of cpuGroups) {
        const values = v2 ? read(dir+'/cpu.max').split(/\s+/) : [read(dir+'/cpu.cfs_quota_us'),read(dir+'/cpu.cfs_period_us')];
        const quota = number(values[0]), period = number(values[1]);
        if (quota > 0 && period > 0) cores = Math.min(cores,quota/period);
      }
      let uptime = scoped ? null : os.uptime(), uptimeScope = scoped ? 'container' : 'host';
      if (scoped && ticks) {
        const stat = read('/proc/1/stat'), close = stat.lastIndexOf(')');
        const start = close >= 0 ? number(stat.slice(close+2).split(/\s+/)[19]) : null;
        const boot = Number(read('/proc/uptime').split(' ')[0]);
        if (start !== null && Number.isFinite(boot) && boot >= start/ticks) uptime = boot-start/ticks;
      }
      cachedAt = now;
      cached = {os:os.platform(),arch:os.arch(),cores:Math.round(cores*100)/100,processRss,memory,uptime,uptimeScope,panelUptime:proc.uptime(),sampledAt:now};
      return cached;
    }
  };
}


// END SYSTEM METRICS

function createHttpPanel(config, stateManager, engineStatusGetter, resolvedHostGetter) {
  const app = express();
  const systemMetrics = createSystemMetrics();
  config.networkDiagnostics ||= new NetworkSupport.Diagnostics(config);
  const networkDiagnostics = config.networkDiagnostics;
  app.get('/healthz', (req, res) => {
    const engines = engineStatusGetter();
    const enabled = TransportSupport.variants.filter(([, , , flag]) => config.enable[flag]);
    const needsXray = enabled.some(([, transport]) => ['grpc','xhttp'].includes(transport));
    const ready = config.startupReady === true && (!enabled.length || engines.singbox)
      && (!needsXray || engines.xray) && (!config.enable.argo || engines.argo);
    res.setHeader('Cache-Control', 'no-store');
    res.status(ready ? 200 : 503).json({ok:!!ready});
  });
  app.get('/.well-known/amyrax-connectivity', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const challenge = req.query.challenge;
    if (typeof challenge !== 'string' || !/^[a-f0-9]{32}$/.test(challenge)) return res.status(400).json({ok:false});
    return res.json({ok:true,proof:networkDiagnostics.proof(challenge)});
  });

  const panelPath = config.panelPath.replace(/^\//, '') || 'amyrax';
  config.learnedPublicOrigin ||= stateManager.state.publicOrigin || '';
  const pinnedDomain = NetworkSupport.publicHost(config.domain) && (process.env.DOMAIN || process.env.SB_DOMAIN || amyraxOnRailway() || (!isIpLiteral(config.domain) && !amyraxIsPlatformHost(config.domain))) ? config.domain : '';
  if (pinnedDomain && normalizeHost(config.learnedPublicOrigin) !== pinnedDomain) config.learnedPublicOrigin = '';
  app.use((req,res,next)=>UpgradeSupport.redirect(req,res,next,panelPath));
  const UserManager = createUserManagement({ LinkGenerator, Logger, AmyraxTraffic, ConfigStudio });
  const users = config.userManager || (config.userManager = new UserManager(config, stateManager));
  const studio = config.configStudio || (config.configStudio = new ConfigStudio.Studio(config, stateManager));

  const AMYRAX_XHTTP_PATH = XrayEngine.xhttpPath();
  const AMYRAX_HOP = new Set(['connection', 'keep-alive', 'proxy-connection', 'upgrade', 'te', 'trailer', 'proxy-authorization']);
  let amyraxXhttpLogged = 0;
  app.use((req, res, next) => {
    let p = String(req.url || '').split('?')[0];
    try { p = decodeURIComponent(p); } catch (_) {}
    if (!(p === AMYRAX_XHTTP_PATH || p.startsWith(AMYRAX_XHTTP_PATH + '/'))) return next();
    const port = config.transportState?.xhttp;
    if (!port) { res.statusCode = 404; return res.end(); }

    for (const sock of [req.socket]) { try { sock.setTimeout(0); sock.setNoDelay(true); sock.setKeepAlive(true, 10000); } catch (_) {} }
    const headers = {};
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const k = req.rawHeaders[i];
      if (AMYRAX_HOP.has(k.toLowerCase())) continue;
      headers[k] = headers[k] === undefined ? req.rawHeaders[i + 1] : [].concat(headers[k], req.rawHeaders[i + 1]);
    }
    const up = http.request({ host: '127.0.0.1', port, method: req.method, path: req.url, headers, agent: false });
    up.on('socket', (sk) => { try { sk.setTimeout(0); sk.setNoDelay(true); } catch (_) {} });
    up.on('response', (pr) => {
      const out = {};
      for (let i = 0; i < pr.rawHeaders.length; i += 2) {
        const k = pr.rawHeaders[i];
        if (AMYRAX_HOP.has(k.toLowerCase())) continue;
        out[k] = out[k] === undefined ? pr.rawHeaders[i + 1] : [].concat(out[k], pr.rawHeaders[i + 1]);
      }
      res.removeHeader('X-Powered-By');
      res.writeHead(pr.statusCode, pr.statusMessage, out);
      if (typeof res.flushHeaders === 'function') res.flushHeaders();

      pr.pipe(res);
      pr.on('error', () => { try { res.destroy(); } catch (_) {} });
    });
    up.on('error', () => {
      if (!res.headersSent) { res.statusCode = 502; res.end(); } else { try { res.destroy(); } catch (_) {} }
    });

    req.pipe(up);
    req.on('error', () => { try { up.destroy(); } catch (_) {} });
    res.on('close', () => { if (!res.writableFinished) { try { up.destroy(); } catch (_) {} } });
  });

  const amyraxAuthFile = path.join(stateManager.paths.dataDir, 'auth.json');
  const amyraxLoadAuth = () => { try { return JSON.parse(fs.readFileSync(amyraxAuthFile, 'utf8')) || {}; } catch (_) { return {}; } };
  const amyraxSaveAuth = (a) => {
    try {
      fs.mkdirSync(path.dirname(amyraxAuthFile), { recursive: true });
      fs.writeFileSync(amyraxAuthFile, JSON.stringify(a, null, 2), { encoding: 'utf8', mode: 0o600 });
    } catch (err) { Logger.warn('Could not save auth.json: ' + err.message); }
  };
  (function amyraxInitAuth() {
    const a = amyraxLoadAuth();
    if (process.env.RESET_PANEL_PASSWORD === 'true') {
      delete a.hash; delete a.salt; a.secret = '';
      Logger.warn('Panel password was reset. Open the panel to create a new one, then delete RESET_PANEL_PASSWORD.');
    }
    if (!a.secret) a.secret = crypto.randomBytes(32).toString('hex');
    const envTok = String(process.env.SUB_TOKEN || '').trim();
    if (envTok) a.subToken = envTok;
    if (!a.subToken) a.subToken = crypto.randomBytes(18).toString('base64url');
    const envPw = String(process.env.PANEL_PASSWORD || '');
    if (envPw && process.env.RESET_PANEL_PASSWORD !== 'true') {
      const same = a.hash && a.salt && crypto.scryptSync(envPw, String(a.salt), 64).toString('hex') === a.hash;
      if (!same) {
        if (envPw.length < 8) Logger.warn('PANEL_PASSWORD is shorter than 8 characters - ignored.');
        else { a.salt = crypto.randomBytes(16).toString('hex'); a.hash = crypto.scryptSync(envPw, a.salt, 64).toString('hex'); Logger.info('Panel password set from PANEL_PASSWORD secret.'); }
      }
    }
    amyraxSaveAuth(a);
  })();
  const amyraxHash = (pw, salt) => crypto.scryptSync(String(pw), String(salt), 64).toString('hex');
  const amyraxSafeEq = (a, b) => { const x = Buffer.from(String(a)); const y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
  const amyraxSign = (secret, v) => crypto.createHmac('sha256', secret).update(String(v)).digest('hex');
  const amyraxCookies = (req) => {
    const out = {};
    String(req.headers.cookie || '').split(';').forEach((p) => {
      const i = p.indexOf('=');
      if (i > 0) { try { out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (_) {} }
    });
    return out;
  };
  const amyraxIsHttps = (req) => req.secure || String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';
  const AMYRAX_SESSION_DAYS = 30;
  const amyraxSetSession = (req, res, a) => {
    const exp = String(Date.now() + AMYRAX_SESSION_DAYS * 86400000);
    const val = exp + '.' + amyraxSign(a.secret, exp);
    res.setHeader('Set-Cookie', 'amyrax_session=' + val + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + (AMYRAX_SESSION_DAYS * 86400) + (amyraxIsHttps(req) ? '; Secure' : ''));
  };
  const amyraxHasSession = (req) => {
    const a = amyraxLoadAuth();
    if (!a.hash || !a.secret) return false;
    const parts = String(UpgradeSupport.cookie(amyraxCookies(req))).split('.');
    if (parts.length !== 2 || !parts[0] || !parts[1] || Number(parts[0]) < Date.now()) return false;
    return amyraxSafeEq(parts[1], amyraxSign(a.secret, parts[0]));
  };
  const amyraxFails = new Map();
  const amyraxIp = (req) => String(req.headers['x-forwarded-for'] || (req.socket && req.socket.remoteAddress) || '').split(',')[0].trim();
  const amyraxBlocked = (ip) => { const r = amyraxFails.get(ip); return !!r && r.count >= 8 && Date.now() - r.first < 15 * 60000; };
  const amyraxFail = (ip) => { const r = amyraxFails.get(ip); if (!r || Date.now() - r.first > 15 * 60000) amyraxFails.set(ip, { count: 1, first: Date.now() }); else r.count++; };
  const amyraxEsc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const amyraxPage = (mode, msg) => {
    const setup = mode === 'setup';
    const field = (name, label, placeholder, min = 8) => '<label class="auth-field"><span>' + label + '</span><input type="password" name="' + name + '" required minlength="' + min + '" placeholder="' + placeholder + '" autocomplete="' + (setup ? 'new-password' : 'current-password') + '"></label>';
    const messages = {
      'Too many attempts, try again in 15 minutes.': 'تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقهٔ دیگر دوباره تلاش کنید.',
      'Wrong setup key.': 'کلید راه‌اندازی صحیح نیست.',
      'Password must be at least 8 characters.': 'رمز عبور باید حداقل ۸ نویسه داشته باشد.',
      'Passwords do not match.': 'رمز عبور و تکرار آن یکسان نیستند.',
      'Wrong password.': 'رمز عبور صحیح نیست.'
    };
    return '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">' +
      '<title>' + (setup ? 'راه‌اندازی' : 'ورود') + ' | Amyrax Panel</title><link rel="icon" type="image/svg+xml" href="/amyrax-assets/logo.svg"><link rel="stylesheet" href="/amyrax-assets/app.css?v=' + AMYRAX_VERSION + '"><link rel="stylesheet" href="/amyrax-assets/controls.css?v=' + AMYRAX_ASSET_VERSION + '">' +
      '<script>try{if(localStorage.getItem("amyrax-theme")==="cozy")document.documentElement.setAttribute("data-theme","cozy");}catch(e){}</script></head><body class="auth-body"><div><div class="auth-layout">' +
      '<section class="auth-brand"><img src="/amyrax-assets/logo.svg" alt="Amyrax Panel"><h2 dir="ltr">Amyrax <span>Panel</span></h2><p>یک اتصال ساده، یک دنیای بدون مرز.</p><a href="https://t.me/AmyraxVPN" target="_blank" rel="noopener noreferrer" dir="ltr">@AmyraxVPN ↗</a></section>' +
      '<form class="auth-form" method="post" action="/' + panelPath + '/login"><div class="auth-eyebrow">' + (setup ? 'شروع یک اتصال تازه' : 'خوش برگشتید') + '</div><h1>' + (setup ? 'راه‌اندازی پنل' : 'ورود به پنل') + '</h1><p class="auth-sub">' + (setup ? 'برای شروع، یک رمز عبور امن برای پنل خود انتخاب کنید.' : 'برای مدیریت اتصال‌ها، رمز عبور پنل را وارد کنید.') + '</p>' +
      (msg ? '<div class="auth-alert" role="alert">' + amyraxEsc(messages[msg] || msg) + '</div>' : '') +
      (setup && process.env.SETUP_KEY ? field('setup_key', 'کلید راه‌اندازی', 'SETUP_KEY', 1) : '') +
      field('password', 'رمز عبور', setup ? 'حداقل ۸ نویسه' : 'رمز عبور شما', setup ? 8 : 1) + (setup ? field('confirm', 'تکرار رمز عبور', 'رمز عبور را دوباره وارد کنید') : '') +
      '<label class="auth-show"><input type="checkbox" id="showPassword">نمایش رمز عبور</label><button class="button primary" type="submit">' + (setup ? 'ساخت رمز و ورود' : 'ورود به Amyrax Panel') + ' <span>←</span></button><div class="auth-foot">دسترسی خصوصی · مدیریت ساده</div></form></div>' +
      '<div class="auth-bottom">Amyrax Panel · مدیریت اتصال</div></div><script>document.getElementById("showPassword").addEventListener("change",function(){document.querySelectorAll(".auth-field input").forEach(function(el){el.type=document.getElementById("showPassword").checked?"text":"password";});});</script></body></html>';
  };

  const amyraxSendPage = (req, res, mode, msg, code) => {
    res.status(code || 200);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    return AssetManager.sendDocument(req,res,amyraxPage(mode,msg));
  };
  app.get('/' + panelPath + '/login', (req, res) => {
    const a = amyraxLoadAuth();
    if (a.hash && amyraxHasSession(req)) return res.redirect(302, '/' + panelPath);
    amyraxSendPage(req,res, a.hash ? 'login' : 'setup', '');
  });
  app.post('/' + panelPath + '/login', express.urlencoded({ extended: false, limit: '10kb' }), (req, res) => {
    const a = amyraxLoadAuth();
    const ip = amyraxIp(req);
    const b = req.body || {};
    const mode = a.hash ? 'login' : 'setup';
    if (amyraxBlocked(ip)) return amyraxSendPage(req,res, mode, 'Too many attempts, try again in 15 minutes.', 429);
    if (!a.hash) {
      if (process.env.SETUP_KEY && !amyraxSafeEq(String(b.setup_key || ''), process.env.SETUP_KEY)) { amyraxFail(ip); return amyraxSendPage(req,res, 'setup', 'Wrong setup key.', 401); }
      const pw = String(b.password || '');
      if (pw.length < 8) return amyraxSendPage(req,res, 'setup', 'Password must be at least 8 characters.', 400);
      if (pw !== String(b.confirm || '')) return amyraxSendPage(req,res, 'setup', 'Passwords do not match.', 400);
      a.salt = crypto.randomBytes(16).toString('hex');
      a.hash = amyraxHash(pw, a.salt);
      a.secret = crypto.randomBytes(32).toString('hex');
      amyraxSaveAuth(a);
      Logger.success('Panel password created.');
      amyraxSetSession(req, res, a);
      return res.redirect(302, '/' + panelPath);
    }
    if (!amyraxSafeEq(amyraxHash(String(b.password || ''), a.salt), a.hash)) { amyraxFail(ip); return amyraxSendPage(req,res, 'login', 'Wrong password.', 401); }
    amyraxFails.delete(ip);
    amyraxSetSession(req, res, a);
    return res.redirect(302, '/' + panelPath);
  });
  app.get('/' + panelPath + '/logout', (req, res) => {
    res.setHeader('Set-Cookie', ['amyrax_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0',UpgradeSupport.expiredCookie]);
    res.redirect(302, '/' + panelPath + '/login');
  });

  const authMiddleware = (req, res, next) => {
    if (amyraxHasSession(req)) return next();
    const a = amyraxLoadAuth();
    const q = typeof req.query.token === 'string' ? req.query.token : '';
    if (q && a.hash && a.subToken && amyraxSafeEq(q, a.subToken)) return next();
    if (req.method === 'GET' && (req.path === '/' || req.path === '/' + panelPath || req.path === '/' + panelPath + '/')) {
      return res.redirect(302, '/' + panelPath + '/login');
    }
    res.status(401).send('Unauthorized');
  };
  const handleRequest = handler => (req, res, next) => {
    const controller = new AbortController();
    const abort = () => controller.abort();
    req.once('aborted', abort); res.once('close', abort);
    if (req.aborted || res.destroyed) abort();
    return Promise.resolve().then(() => {
      if (!controller.signal.aborted) return handler(req, res, controller.signal);
    }).catch(error => {
      if (!controller.signal.aborted && !res.destroyed && !res.writableEnded) return next(error);
    }).finally(() => {
      req.removeListener('aborted', abort); res.removeListener('close', abort);
    });
  };

  const subscriptionUrl = (req, token) => {
    const selectedHost = getRequestHost(req);
    const authority = String(req.get('x-forwarded-host') || req.get('host') || 'localhost').split(',')[0].trim();
    const override = config.subBase || config.publicBaseUrl || config.learnedPublicOrigin;
    const canonicalHost = config.forceHost ? config.domain : selectedHost;
    const canonical = !override && NetworkSupport.publicHost(canonicalHost) && normalizeHost(authority) !== canonicalHost ? NetworkSupport.origin(config, canonicalHost).href : '';
    const base = new URL(override || canonical || ((config.forceHttps || amyraxIsHttps(req) ? 'https://' : 'http://') + authority));
    if (!['http:', 'https:'].includes(base.protocol)) throw new Error('Subscription base URL must use HTTP or HTTPS');
    base.username = ''; base.password = ''; base.search = ''; base.hash = '';
    base.pathname = base.pathname.replace(/\/$/, '') + '/sub/' + encodeURIComponent(token || req.subUser?.token || amyraxLoadAuth().subToken || '');
    return base.href;
  };

  for (const [filename, key, type] of [
    ['studio.css', 'studioCss', 'text/css'],
    ['updates.js', 'updatesJs', 'application/javascript'], ['updates.css', 'updatesCss', 'text/css'],
    ['studio.js', 'studioJs', 'application/javascript'],
    ['controls.css', 'controlsCss', 'text/css'],
    ['controls.js', 'controlsJs', 'application/javascript'],
    ['users.css', 'usersCss', 'text/css'],
    ['users.js', 'usersJs', 'application/javascript'],
    ['subscription.css', 'subscriptionCss', 'text/css'],
    ['subscription.js', 'subscriptionJs', 'application/javascript'],
    ['vendor/qrcode.js', 'qrJs', 'application/javascript']
  ]) {
    app.get('/amyrax-assets/' + filename, (req, res) => {
      res.setHeader('Content-Type', type + '; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      const local = AssetManager._readFileCandidate(filename);
      res.send(local ? local.toString('utf8') : EMBEDDED_ASSETS[key]);
    });
  }

  
  
  const candidateAssetDirs = [
    path.join(process.cwd(), 'assets'),
    path.join(__dirname, '..', '..', 'assets'),
    path.join(__dirname, 'assets')
  ];
  for (const dir of candidateAssetDirs) {
    if (fs.existsSync(dir)) {
      app.use('/assets', express.static(dir));
      app.use('/amyrax-assets', express.static(dir));
      app.use(`/${panelPath}/assets`, express.static(dir));
      break;
    }
  }

  app.get(['/amyrax-assets/app.css', '/assets/app.css', `/${panelPath}/assets/app.css`, `/${panelPath}/app.css`, '/app.css'], (req, res) => {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(AssetManager.getAppCss());
  });

  app.get(['/amyrax-assets/app.js', '/assets/app.js', `/${panelPath}/assets/app.js`, `/${panelPath}/app.js`, '/app.js'], (req, res) => {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(AssetManager.getAppJs());
  });

  for (const [name, base64] of Object.entries(EMBEDDED_FONTS)) {
    app.get(['/amyrax-assets/fonts/' + name, '/assets/fonts/' + name], (req, res) => {
      res.setHeader('Content-Type', name.endsWith('.woff2') ? 'font/woff2' : name.endsWith('.ttf') ? 'font/ttf' : 'text/plain; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(Buffer.from(base64, 'base64'));
    });
  }

  app.get([
    '/amyrax-assets/logo.svg', '/amyrax-assets/logo.jpg',
    '/assets/logo.svg', '/assets/logo.jpg',
    `/${panelPath}/assets/logo.svg`, `/${panelPath}/assets/logo.jpg`,
    `/${panelPath}/logo.svg`, `/${panelPath}/logo.jpg`,
    '/logo.svg', '/logo.jpg'
  ], (req, res) => {
    const imgBuffer = AssetManager.getLogo();
    if (imgBuffer) {
      res.setHeader('Content-Type', 'image/svg+xml');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(imgBuffer);
    } else {
      res.status(404).send('Logo not found');
    }
  });

  app.get([
    '/amyrax-assets/bg.svg', '/amyrax-assets/bg.png',
    '/assets/bg.svg', '/assets/bg.png',
    `/${panelPath}/assets/bg.svg`, `/${panelPath}/assets/bg.png`,
    `/${panelPath}/bg.svg`, `/${panelPath}/bg.png`,
    '/bg.svg', '/bg.png'
  ], (req, res) => {
    const imgBuffer = AssetManager.getBgJpg();
    if (imgBuffer) {
      res.setHeader('Content-Type', 'image/svg+xml');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(imgBuffer);
    } else {
      res.status(404).send('Background not found');
    }
  });

  app.get([
    '/amyrax-assets/cozybg.svg', '/amyrax-assets/cozybg.png',
    '/assets/cozybg.svg', '/assets/cozybg.png',
    `/${panelPath}/assets/cozybg.svg`, `/${panelPath}/assets/cozybg.png`,
    `/${panelPath}/cozybg.svg`, `/${panelPath}/cozybg.png`,
    '/cozybg.svg', '/cozybg.png'
  ], (req, res) => {
    const imgBuffer = AssetManager.getCozyBgJpg();
    if (imgBuffer) {
      res.setHeader('Content-Type', 'image/svg+xml');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(imgBuffer);
    } else {
      res.status(404).send('Cozy background not found');
    }
  });

  app.get([
    '/amyrax-assets/home.svg', '/amyrax-assets/home.png',
    '/assets/home.svg', '/assets/home.png',
    `/${panelPath}/assets/home.svg`, `/${panelPath}/assets/home.png`,
    `/${panelPath}/home.svg`, `/${panelPath}/home.png`,
    '/home.svg', '/home.png'
  ], (req, res) => {
    const imgBuffer = AssetManager.getHomeJpg();
    if (imgBuffer) {
      res.setHeader('Content-Type', 'image/svg+xml');
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(imgBuffer);
    } else {
      res.status(404).send('Home image not found');
    }
  });

  const getRequestHost = (req) => {
    const authority = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    const reqHost = normalizeHost(authority), reqOk = NetworkSupport.publicHost(reqHost);
    const explicitBaseHost = config.subBase || config.publicBaseUrl ? normalizeHost(NetworkSupport.origin(config, '').hostname) : '';
    const configuredHost = config.forceHost || explicitBaseHost || (NetworkSupport.publicHost(config.domain) && (process.env.DOMAIN || process.env.SB_DOMAIN || amyraxOnRailway() || (!isIpLiteral(config.domain) && !amyraxIsPlatformHost(config.domain))) ? config.domain : '');
    if (configuredHost) {
      if (amyraxHasSession(req) && reqOk && (reqHost === configuredHost || reqHost === config.domain)) {
        const publicOrigin = (config.forceHttps || amyraxIsHttps(req) || NetworkSupport.edgeDomain(reqHost) ? 'https://' : 'http://') + authority;
        if (stateManager.state.publicOrigin !== publicOrigin) { stateManager.state.publicOrigin = publicOrigin; config.learnedPublicOrigin = publicOrigin; stateManager.save(); }
      }
      return configuredHost;
    }
    const savedRelay = NetworkSupport.publicHost(stateManager.state.publicHost) && !isIpLiteral(stateManager.state.publicHost) && !amyraxIsPlatformHost(stateManager.state.publicHost) ? stateManager.state.publicHost : '';
    if (savedRelay && (!reqOk || isIpLiteral(reqHost) || amyraxIsPlatformHost(reqHost))) return savedRelay;
    const learnedHost = normalizeHost(config.learnedPublicOrigin);
    if (NetworkSupport.publicHost(learnedHost) && (!reqOk || (isIpLiteral(reqHost) && !isIpLiteral(learnedHost)))) return config.forceHost || learnedHost;
    if (!amyraxHasSession(req) && NetworkSupport.publicHost(learnedHost)) return learnedHost;
    if (NetworkSupport.publicHost(config.domain) && (!reqOk || (reqHost !== config.domain && amyraxIsPlatformHost(reqHost)))) return config.domain;
    if (reqOk) {
      if (amyraxHasSession(req)) {
        const publicOrigin = (config.forceHttps || amyraxIsHttps(req) || NetworkSupport.edgeDomain(reqHost) ? 'https://' : 'http://') + authority;
        if (stateManager.state.publicHost !== reqHost || stateManager.state.publicOrigin !== publicOrigin) {
          stateManager.state.publicHost = reqHost; stateManager.state.publicOrigin = publicOrigin;
          config.learnedPublicOrigin = publicOrigin; stateManager.save();
          Logger.info('Public endpoint learned from an authenticated panel visit: ' + publicOrigin);
        }
      }
      return reqHost;
    }
    if (NetworkSupport.publicHost(stateManager.state.publicHost)) return stateManager.state.publicHost;
    const resolved = resolvedHostGetter?.();
    if (NetworkSupport.publicHost(resolved)) return resolved;
    return config.allowLocalHostLinks ? reqHost || '127.0.0.1' : '';
  };

  app.get('/health', authMiddleware, handleRequest(async (req, res, signal) => {
    const engines = engineStatusGetter ? engineStatusGetter() : {};
    const host = getRequestHost(req);
    const linkGen = await new LinkGenerator(config, stateManager.state, host).prepare();
    if (signal.aborted) return;
    const allNodes = linkGen.getAllNodes({ compat: 'full', allowLocalHostLinks: config.allowLocalHostLinks });
    if (amyraxHasSession(req)) for (const u of users.users) if (users.permitted(u)) allNodes.push(...studio.nodes(users.generator(u,host)));
    const location = linkGen.location.country;

    res.json({
      ok: true,
      subToken: amyraxLoadAuth().subToken || '',
      subscriptionUrl: subscriptionUrl(req),
      brand: config.brand,
      product: config.product,
      uptime: process.uptime(),
      publicPort: config.publicPort,
      host,
      domain: (host && !isIpLiteral(host)) ? host : (config.domain || ''),
      forceHost: config.forceHost || '',
      publicBaseUrl: (process.env.PUBLIC_BASE_URL || process.env.SUB_BASE_URL) ? (config.publicBaseUrl || '')
        : ((host && !isIpLiteral(host) && linkGen.edgeTls) ? 'https://' + host : (config.publicBaseUrl || '')),
      subBase: config.subBase || '',
      forceHttps: Boolean(config.forceHttps),
      location: location || 'Global Server',
      engines,
      enabled: config.enable,
      network: networkDiagnostics.snapshot(),
      system: {platform:amyraxPlatformName(),...systemMetrics.snapshot()},
      nodes: allNodes.map(node => ({
        name: node.name,
        type: node.type,
        compat: node.compat,
        uri: node.uri,
        wgConf: node.wgConf || null,
        singboxJson: node.singboxJson || null,
        customId: node.customId || null,
        xrayJson: node.xrayJson || JSON.stringify(ConfigStudio.fromUri(node.uri, node.name), null, 2),
        note: node.note || null
      }))
    });
  }));

  const renderPanel = (req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    const host = amyraxPlatformName();
    return AssetManager.sendDocument(req,res,AssetManager.getIndexHtml().replace('Running on Replit', host === 'Self-hosted' ? host : 'Running on ' + host)
      .replace(/\/amyrax-assets\/((?:app|users|controls|studio|updates)\.(?:css|js)|vendor\/qrcode\.js)"/g, '/amyrax-assets/$1?v=' + AMYRAX_ASSET_VERSION + '"'));
  };

  app.get('/', (req,res)=>res.redirect(302,'/'+panelPath));
  const amyraxSessionOnly = (req, res, next) => (amyraxHasSession(req) ? next() : res.status(401).json({ ok: false, error: 'login required' }));
  const amyraxSameOrigin = (req, res, next) => (UpgradeSupport.requestHeader(req) === '1' ? next() : res.status(403).json({ ok: false, error: 'forbidden' }));
  const userApi = express.Router();
  userApi.use(amyraxSessionOnly, (req,res,next) => { res.setHeader('Cache-Control','no-store'); next(); });
  userApi.use((req,res,next) => req.method === 'GET' ? next() : amyraxSameOrigin(req,res,next));
  const smallUserBody=express.json({limit:'32kb'}), backupBody=express.json({limit:'16mb'});
  userApi.use((req,res,next)=>{
    if(req.method!=='POST'||!['/import','/import/preview'].includes(req.path))return smallUserBody(req,res,next);
    return backupBody(req,res,next);
  });
  const userView = (req,u) => users.publicUser(u,subscriptionUrl(req,u.token));
  userApi.get('/', handleRequest((req,res) => {
    users.available();
    return AssetManager.sendJson(req,res,{ok:true,items:users.users.map(u=>userView(req,u)),protocols:UserManager.protocols,engine:users.engine,storageError:!!users.storageError});
  }));
  userApi.get('/backup', handleRequest((req,res) => {
    users.available();
    res.setHeader('Content-Disposition','attachment; filename="Amyrax-users-backup.json"');
    res.json({version:1,exportedAt:new Date().toISOString(),users:users.users});
  }));
  userApi.post('/import/preview',handleRequest((req,res)=>res.json({ok:true,...users.planImport(req.body?.backup,amyraxLoadAuth().subToken).summary})));
  userApi.post('/import',handleRequest((req,res)=>res.json({ok:true,...users.importBackup(req.body?.backup,req.body?.fingerprint,amyraxLoadAuth().subToken)})));
  userApi.post('/', handleRequest((req,res) => res.status(201).json({ok:true,user:userView(req,users.create(req.body))})));
  userApi.patch('/:id', handleRequest((req,res) => res.json({ok:true,user:userView(req,users.update(req.params.id,req.body))})));
  userApi.delete('/:id', handleRequest((req,res) => res.json({ok:true,deletedId:users.remove(req.params.id,req.body)})));
  userApi.post('/:id/actions', handleRequest((req,res) => res.json({ok:true,user:userView(req,users.action(req.params.id,req.body))})));
  userApi.use((err,req,res,next) => {
    const expected=err.status && err.status < 500;
    res.status(err.status || 500).json({ok:false,error:expected || err.status===503 ? err.message : 'ذخیرهٔ اطلاعات ناموفق بود؛ فضای دیسک و مجوز فایل کاربران را بررسی کنید.'});
  });
  app.use(`/${panelPath}/api/users`,userApi);
  function mountStudio(prefix, authorization) {
    const api = express.Router({ mergeParams: true });
    api.use(authorization, (req,res,next) => { res.setHeader('Cache-Control','no-store'); next(); });
    api.use((req,res,next) => req.method === 'GET' ? next() : amyraxSameOrigin(req,res,next));
    api.use(express.json({limit:'24kb'}));
    const scope = () => null;
    const account = req => scope(req) || (typeof req.query.accountId === 'string' ? req.query.accountId : 'shared');
    const view = req => {
      studio.available();
      const id = account(req), g = studio.generator(id,getRequestHost(req),false);
      const options = studio.options(g);
      return {ok:true,revision:studio.revision,accountId:id,options,
        defaults:{server:g.host,port:g.port,sni:g.tlsOpt.sni,host:g.tlsOpt.wsHost,path:g.wsPath,fingerprint:g.tlsOpt.fp},
        profiles:studio.profiles.filter(p=>p.accountId===id).map(p=>{let node=null;try{node=studio.build(p,g);}catch{}return {...p,node};}),
        accounts:[{id:'shared',name:'کاربر اصلی'},...users.users.filter(u=>!u.archivedAt).map(u=>({id:u.id,name:u.name}))],egress:{...studio.pendingEgress,input:studio.pendingEgress.input||'',active:studio.egress.enabled,activeName:studio.egress.name||'',restartRequired:JSON.stringify(studio.pendingEgress)!==JSON.stringify(studio.egress)}};
    };
    api.get('/',handleRequest((req,res)=>res.json(view(req))));
    api.post('/preview',handleRequest((req,res)=>{
      const p=studio.fields(req.body,scope(req));
      return res.json({ok:true,node:studio.build(p,studio.generator(p.accountId,getRequestHost(req)))});
    }));
    api.post('/profiles',handleRequest((req,res)=>res.status(201).json({ok:true,profile:studio.save(req.body,getRequestHost(req),scope(req))})));
    api.patch('/profiles/:id',handleRequest((req,res)=>res.json({ok:true,profile:studio.save(req.body,getRequestHost(req),scope(req),req.params.id)})));
    api.delete('/profiles/:id',handleRequest((req,res)=>{studio.remove(req.params.id,req.body?.revision,scope(req));res.json({ok:true});}));
    {
      api.post('/egress/check',handleRequest(async(req,res)=>{
        if(req.body?.enabled && !await new BinaryManager(config).ensureXray()) return res.status(503).json({ok:false,error:'هستهٔ Xray برای Outbound آماده نشد.'});
        await studio.checkEgress(req.body?.input,req.body?.name,req.body?.enabled,config.paths.xrayBin);
        res.json({ok:true,message:'ساختار Outbound تأیید شد؛ اتصال واقعی باید از شبکهٔ خودتان آزموده شود.'});
      }));
      api.post('/egress',handleRequest(async(req,res)=>{
        studio.available();const revision=req.body?.revision;
        if(revision!==studio.revision) return res.status(409).json({ok:false,error:'تنظیمات تغییر کرده؛ صفحه را تازه کنید.'});
        if(req.body?.enabled && !await new BinaryManager(config).ensureXray()) return res.status(503).json({ok:false,error:'هستهٔ Xray آماده نشد.'});
        const next=await studio.checkEgress(req.body?.input,req.body?.name,req.body?.enabled,config.paths.xrayBin);
        if(revision!==studio.revision) return res.status(409).json({ok:false,error:'تنظیمات در حین بررسی تغییر کرد؛ دوباره تازه کنید.'});
        studio.persist(studio.profiles,next);res.json({ok:true,restartRequired:true});
      }));
      api.post('/egress/apply',handleRequest((req,res)=>{
        if(!amyraxRestart) return res.status(409).json({ok:false,error:'برای اعمال Outbound، پنل را از کنسول هاست دوباره راه‌اندازی کنید.'});
        res.json({ok:true});setTimeout(()=>amyraxRestart(),800);
      }));
    }
    api.use((err,req,res,next)=>res.status(err.status||500).json({ok:false,error:err.status && err.status<500 || err.status===503 ? err.message : 'ذخیره یا بررسی کانفیگ ناموفق بود؛ فایل‌ها و فضای دیسک را بررسی کنید.'}));
    app.use(prefix,api);
  }
  mountStudio(`/${panelPath}/api/studio`,amyraxSessionOnly);

  app.get(`/${panelPath}/api/network`, amyraxSessionOnly, handleRequest(async (req, res, signal) => {
    res.setHeader('Cache-Control', 'no-store');
    const report = await networkDiagnostics.check(getRequestHost(req), engineStatusGetter?.() || {});
    if (!signal.aborted) return res.json({ok:true,...report});
  }));
  app.get(`/${panelPath}/api/traffic`, amyraxSessionOnly, (req, res) => { res.setHeader('Cache-Control', 'no-store'); return AssetManager.sendJson(req,res,{...AmyraxTraffic.snapshot(),system:{platform:amyraxPlatformName(),...systemMetrics.snapshot()}}); });
  app.post(`/${panelPath}/api/traffic/reset`, amyraxSessionOnly, amyraxSameOrigin, (req, res) => {
    AmyraxTraffic.reset(); Logger.warn('Traffic counter reset from the panel.');
    res.setHeader('Cache-Control', 'no-store'); res.json(AmyraxTraffic.snapshot());
  });
  app.post(`/${panelPath}/api/traffic/baseline`, amyraxSessionOnly, amyraxSameOrigin, express.json({ limit: '2kb' }), (req, res) => {
    const gb = Number(req.body && req.body.gb);
    if (!isFinite(gb) || gb < 0 || gb > 1000000) return res.status(400).json({ ok: false, error: 'invalid value' });
    AmyraxTraffic.setMonthUsedGB(gb); Logger.info(`Traffic: this month's used amount set to ${gb} GiB from the panel.`);
    res.setHeader('Cache-Control', 'no-store'); res.json(AmyraxTraffic.snapshot());
  });

  const panelUpdater = config.panelUpdater || new PanelUpdates.Manager({current:AMYRAX_VERSION,entry:__filename,dataDir:config.paths.dataDir,repo:AMYRAX_UPDATE_REPO,
    onRestart:()=>setTimeout(()=>amyraxRestart ? amyraxRestart() : process.exit(AMYRAX_RESTART_CODE),800)});
  config.panelUpdater = panelUpdater;panelUpdater.start();
  app.get(`/${panelPath}/api/update`, amyraxSessionOnly, async (req,res)=>{
    res.setHeader('Cache-Control','no-store');await panelUpdater.check();res.json(panelUpdater.status());
  });
  app.post(`/${panelPath}/api/update/check`, amyraxSessionOnly, amyraxSameOrigin, async (req,res)=>{
    res.setHeader('Cache-Control','no-store');await panelUpdater.check(true);res.json(panelUpdater.status());
  });
  app.post(`/${panelPath}/api/update`, amyraxSessionOnly, amyraxSameOrigin, express.json({limit:'1kb'}), async (req,res)=>{
    res.setHeader('Cache-Control','no-store');
    try {await panelUpdater.check();return res.status(202).json(panelUpdater.begin(req.body?.version));}
    catch(error){return res.status(409).json({ok:false,error:error.message||'به‌روزرسانی انجام نشد.'});}
  });

  app.get(`/${panelPath}`, authMiddleware, handleRequest(renderPanel));

  const serveSubscription = formatOverride => handleRequest(async (req, res, signal) => {
    res.setHeader('Cache-Control', 'private, no-store, no-cache, max-age=0, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Subscription-Userinfo, Profile-Title, Profile-Update-Interval, Profile-Web-Page-Url, Support-Url, Content-Disposition');
    res.vary('User-Agent'); res.vary('Accept');
    const sendProfile = (type, body) => {
      const bytes = Buffer.from(body, 'utf8');
      res.setHeader('Content-Type', type + '; charset=utf-8');
      res.setHeader('Content-Length', bytes.length);
      return res.end(req.method === 'HEAD' ? undefined : bytes);
    };
    const format = typeof formatOverride === 'string' ? formatOverride : subscriptionFormat(req);
    if (!format) return res.status(400).type('text').send('Unsupported subscription format');
    const host = getRequestHost(req);
    let user = req.subUser;
    let generator = user ? users.generator(user,host) : new LinkGenerator(config, stateManager.state, host);
    await generator.prepare();
    if (signal.aborted) return;
    if (user) {
      const current = users.byToken(user.token);
      if (!current) return res.status(404).type('text').send('Subscription not found');
      if (current !== user) {
        const location = generator.location;
        generator = users.generator(current, host);
        generator.location = location;
      }
      user = current;
    }
    const requestedClient = String(req.query.client || req.query.format || '').toLowerCase();
    const nodes = user && !users.permitted(user) ? [] : TransportSupport.forClient(generator.getAllNodes({ compat: format === 'base64' || format === 'raw' ? 'v2ray' : 'full', allowLocalHostLinks: config.allowLocalHostLinks }), req.get('user-agent') || '', requestedClient);
    const url = subscriptionUrl(req);
    const traffic = user ? users.traffic(user) : AmyraxTraffic.snapshot();
    const title = user ? user.name : (config.subscriptionName || 'کاربر اصلی');
    const profileHeaders = {
      'Profile-Title': 'base64:' + Buffer.from(title).toString('base64'),
      'Profile-Update-Interval': '1',
      'Profile-Web-Page-Url': url,
      'Support-Url': 'https://t.me/AmyraxVPN'
    };
    if (traffic.ok) {
      const used = Math.max(0, Math.floor(traffic.month.used));
      const up = Math.min(used, Math.max(0, Math.floor(traffic.month.up)));
      const down = used - up;
      profileHeaders['Subscription-Userinfo'] = `upload=${up}; download=${down}; total=${Math.floor(traffic.limit?.bytes || 0)}; expire=${Math.floor((user?.expiresAt || 0) / 1000)}`;
    }
    for (const [name, value] of Object.entries(profileHeaders)) res.setHeader(name, value);
    if (format === 'html' || format === 'info') {
      const payload = {
        title, url, updatedAt: new Date().toISOString(),
        account: user ? { status:users.status(user), expiresAt:user.expiresAt, durationDays:user.durationDays, firstConnectedAt:user.firstConnectedAt, resetDays:user.resetDays, quotaStartedAt:user.quotaStartedAt } : null,
        nodes: nodes.map(n => ({ name: n.name, type: n.type, uri: n.uri, compat: n.compat, customId:n.customId||null, singboxJson:n.singboxJson||null, xrayJson:n.xrayJson||JSON.stringify(ConfigStudio.fromUri(n.uri,n.name),null,2), wgConf: n.wgConf || null })),
        traffic: traffic.ok ? { day: traffic.day.total, month: traffic.month.used, allTime: traffic.allTime.total, limit: traffic.limit, history: traffic.history, since: traffic.since } : null
      };
      if (format === 'info') return AssetManager.sendJson(req,res,payload);
      res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'");
      const json = JSON.stringify(payload).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
      return AssetManager.sendDocument(req,res,AssetManager.getSubscriptionHtml().replace('<!--SUBSCRIPTION_DATA-->', json).replaceAll('__ASSET_VERSION__', AMYRAX_ASSET_VERSION));
    }
    const extension = format === 'clash' ? '.yaml' : format.startsWith('singbox') ? '.json' : '.txt';
    const filename = title.replace(/[\u0000-\u001f\u007f/\\:*?"<>|]/g, '_').trim() || 'Subscription';
    const encodedName = encodeURIComponent(filename + (req.query.download === '1' ? extension : '')).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
    res.setHeader('Content-Disposition', (req.query.download === '1' ? 'attachment' : 'inline') + '; filename="' + encodedName + '"; filename*=UTF-8\'\'' + encodedName);
    const metadata = Object.entries(profileHeaders).map(([name, value]) => '#' + name.toLowerCase() + ': ' + value).join('\n') + '\n';
    if (format === 'clash') {
      return sendProfile('text/yaml', metadata + generator.buildClashMetaYaml(nodes));
    }
    if (format === 'singbox' || format === 'singbox-base64') {
      const json = generator.buildSingBoxClientJson(nodes);
      return format === 'singbox-base64' ? sendProfile('text/plain', Buffer.from(json).toString('base64')) : sendProfile('application/json', json);
    }
    const streisand = requestedClient === 'streisand' || /streisand/i.test(String(req.get('user-agent') || ''));
    const links = nodes.map(n => n.uri).join(streisand ? '\r\n' : '\n');
    const content = /hiddify/i.test(String(req.get('user-agent') || '')) ? metadata + links : links;
    return sendProfile('text/plain', format === 'raw' ? content : Buffer.from(content).toString('base64'));
  });
  const privateSubscription = (req, res, next) => {
    delete req.subUser;
    const a = amyraxLoadAuth();
    if (a.hash && a.subToken && amyraxSafeEq(String(req.params.subToken || ''), a.subToken)) return next();
    const user = a.hash && users.byToken(String(req.params.subToken || ''));
    if (user) { req.subUser=user; return next(); }
    res.setHeader('Cache-Control', 'no-store');
    return res.status(404).type('text').send('Subscription not found');
  };
  app.get(['/sub/:subToken', `/${panelPath}/sub/:subToken`], privateSubscription, serveSubscription());
  app.get([`/${panelPath}/sub`, '/sub'], authMiddleware, serveSubscription());

  app.get([`/${panelPath}/base64`, '/base64'], authMiddleware, serveSubscription('base64'));
  app.get(`/${panelPath}/raw`, authMiddleware, serveSubscription('raw'));
  app.get([`/${panelPath}/flclash`, `/${panelPath}/flclash.yaml`, '/flclash', `/${panelPath}/clash`, `/${panelPath}/clash.yaml`, '/clash'], authMiddleware, serveSubscription('clash'));
  app.get([`/${panelPath}/sb/raw`, `/${panelPath}/sb`, '/sb'], authMiddleware, serveSubscription('singbox'));
  app.get(`/${panelPath}/sb/base64`, authMiddleware, serveSubscription('singbox-base64'));

  app.get([`/${panelPath}/xray/raw`, `/${panelPath}/xray/base64`], authMiddleware, handleRequest((req, res) => {
    const isBase64 = req.path.endsWith('/base64');
    const jsonStr = stateManager.state.xrayJson || '{}';

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Content-Type', isBase64 ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8');
    if (isBase64) {
      res.send(Buffer.from(jsonStr).toString('base64'));
    } else {
      res.send(jsonStr);
    }
  }));

  app.get([`/${panelPath}/wg.conf`, `/${panelPath}/wireguard.conf`, '/wg.conf'], authMiddleware, handleRequest(async (req, res) => {
    try {
      const host = getRequestHost(req);
      const linkGen = await new LinkGenerator(config, stateManager.state, host).prepare();
      let wgNode = null;
      try {
        wgNode = linkGen.generateWireGuard();
      } catch (wgErr) {
        console.warn(`[WireGuard] Warning: Failed to generate WireGuard node: ${wgErr.message}`);
      }

      let conf = wgNode && wgNode.wgConf;
      if (!conf) {
        const keys = linkGen._getOrGenerateWgKeys();
        conf = [
          '[Interface]',
          `PrivateKey = ${keys.clientPriv}`,
          'Address = 10.66.66.2/32',
          'DNS = 1.1.1.1, 8.8.8.8',
          'MTU = 1420',
          '',
          '[Peer]',
          `PublicKey = ${keys.serverPub}`,
          `Endpoint = ${host}:51820`,
          'AllowedIPs = 0.0.0.0/0, ::/0',
          'PersistentKeepalive = 25'
        ].join('\n') + '\n';
      }

      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="wg0.conf"');
      res.send(conf);
    } catch (err) {
      console.warn(`[WireGuard] WireGuard endpoint error: ${err.message}`);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.status(200).send('# WireGuard configuration failed gracefully.\n');
    }
  }));

  const server = http.createServer(app);
  server.keepAliveTimeout = 120000;
  server.headersTimeout = 125000;
  server.requestTimeout = 0;  
  server.timeout = 0;
  server.once('close', () => { users.stop(); });
  server.once('close',()=>panelUpdater.stop());
  return { app, server, users };
}

// BEGIN TRAFFIC METER
function createTrafficMeter({ Logger, platformName, now = Date.now, monotonic = () => require('perf_hooks').performance.now() }) {
  const fs = require('fs'), path = require('path');
  const KEYS = ['VLESS-WS', 'VMess-WS', 'Trojan-WS', 'Shadowsocks-WS', 'VLESS-XHTTP', 'VLESS-HTTPUpgrade', 'VMess-HTTPUpgrade', 'Trojan-HTTPUpgrade', 'VLESS-gRPC', 'VMess-gRPC', 'Trojan-gRPC', 'Other'];
  const GIB = 1024 * 1024 * 1024;
  const utcDay = (d = new Date(now())) => d.toISOString().slice(0, 10);
  const utcMonth = (d = new Date(now())) => d.toISOString().slice(0, 7);
  let file = null; let st = null; let dirty = false; let lastSave = 0; let writable = false;
  const live = { up: 0, down: 0 }; let samples = [], previous = null, timer = null;
  const identities = new Map();
  const active = {};
  const warned = {};
  let prunedHour = '';
  const fresh = () => ({ v: 1, since: new Date(now()).toISOString(), historySince: new Date(now()).toISOString(), hours: {}, allTime: {}, day: { key: utcDay(), per: {} }, month: { key: utcMonth(), per: {}, baseBytes: 0 } });
  const norm = (label) => { const base=String(label).replace(/-TLS$/,''); return KEYS.includes(base) ? base : 'Other'; };
  const bump = (bucket, k, up, down) => { const e = bucket[k] || (bucket[k] = { up: 0, down: 0 }); e.up += up; e.down += down; };
  const sum = (per) => { let up = 0; let down = 0; for (const k of Object.keys(per || {})) { up += per[k].up || 0; down += per[k].down || 0; } return { up, down, total: up + down }; };
  const limitBytes = () => { const g = parseFloat(process.env.TRAFFIC_LIMIT_GB || ''); return isFinite(g) && g > 0 ? g * GIB : 0; };
  function roll() {
    if (!st) return;
    const d = utcDay(); const m = utcMonth();
    if (st.day.key !== d) { st.day = { key: d, per: {} }; dirty = true; }
    if (st.month.key !== m) { st.month = { key: m, per: {}, baseBytes: 0 }; dirty = true; for (const k of Object.keys(warned)) delete warned[k]; }
    const hour = new Date(now()).toISOString().slice(0, 13);
    if (prunedHour !== hour) {
      const oldest = new Date(now() - 8 * 86400000).toISOString().slice(0, 16);
      for (const key of Object.keys(st.hours || {})) { if (key < oldest) { delete st.hours[key]; dirty = true; } }
      prunedHour = hour;
    }
  }
  function save() {
    if (!file || !st) return;
    try {
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(st), 'utf8');
      fs.renameSync(tmp, file);
      dirty = false; lastSave = now(); writable = true;
    } catch (err) { writable = false; if (!warned.save) { warned.save = 1; Logger.warn('Could not save traffic.json: ' + err.message); } }
  }
  function checkLimit() {
    const lim = limitBytes(); if (!lim) return;
    const used = sum(st.month.per).total + (st.month.baseBytes || 0);
    const pct = used / lim * 100;
    if (pct >= 100 && !warned.p100) { warned.p100 = 1; warned.p80 = 1; Logger.warn(`Traffic: 100% of TRAFFIC_LIMIT_GB used this month (estimate). Check your host's usage page.`); }
    else if (pct >= 80 && !warned.p80) { warned.p80 = 1; Logger.warn(`Traffic: 80% of TRAFFIC_LIMIT_GB used this month (estimate).`); }
  }
  function tick() {
    const time = now(), stamp = monotonic();
    if (previous && stamp-previous.stamp >= 1000) {
      const windowSeconds = (stamp-previous.stamp)/1000;
      samples.push({t:time,upBps:(live.up-previous.up)/windowSeconds,downBps:(live.down-previous.down)/windowSeconds,windowSeconds});
      if (samples.length > 60) samples.shift();
      previous = {stamp,up:live.up,down:live.down};
    }
    roll();
    if (dirty && time - lastSave > 30000) { save(); checkLimit(); }
  }
  return {
    KEYS,
    init(dataDir) {
      clearInterval(timer); samples=[]; live.up=0;live.down=0;previous={stamp:monotonic(),up:0,down:0};
      identities.clear(); for(const key of Object.keys(active))delete active[key];
      file = path.join(dataDir, 'traffic.json');
      try { st = JSON.parse(fs.readFileSync(file, 'utf8')); if (!st || st.v !== 1) st = fresh(); } catch (_) { st = fresh(); }
      st.allTime = st.allTime || {}; st.day = st.day || { key: utcDay(), per: {} }; st.month = st.month || { key: utcMonth(), per: {}, baseBytes: 0 };
      st.hours = st.hours || {}; st.historySince = st.historySince || new Date(now()).toISOString();
      roll(); save();
      timer = setInterval(tick, 1000); timer.unref();
      process.once('exit', () => { try { save(); } catch (_) {} });
      const lim = limitBytes();
      Logger.info(`Traffic meter: ${file}${lim ? ` (limit ${(lim / GIB).toFixed(2)} GiB/month)` : ''}`);
    },
    add(label, up, down) {
      if (!Number.isSafeInteger(up) || !Number.isSafeInteger(down) || up<0 || down<0) return;
      if (!st || (!up && !down)) return;
      roll();
      const k = norm(label);
      bump(st.allTime, k, up, down); bump(st.day.per, k, up, down); bump(st.month.per, k, up, down);
      const slot = new Date(Math.floor(now() / 1800000) * 1800000).toISOString().slice(0, 16);
      const entry = st.hours[slot] || (st.hours[slot] = { up: 0, down: 0, spanMinutes: 30 });
      entry.up += up; entry.down += down;
      live.up += up; live.down += down; dirty = true;
    },
    meter(label, client, backend) {
      const k = norm(label), end = this.open(k);
      client.on('data', (b) => this.add(k, b.length, 0));
      backend.on('data', (b) => this.add(k, 0, b.length));
      client.once('close', end); backend.once('close', end);
    },
    open(label, identity = null) {
      const k = norm(label); active[k] = (active[k] || 0) + 1;
      if(identity)identities.set(identity,(identities.get(identity)||0)+1);
      let done=false;return()=>{if(done)return;done=true;active[k]=Math.max(0,(active[k]||1)-1);
        if(identity){const count=(identities.get(identity)||1)-1;if(count>0)identities.set(identity,count);else identities.delete(identity);}
      };
    },
    save,
    reset() { st = fresh(); for (const k of Object.keys(warned)) delete warned[k]; save(); },
    setMonthUsedGB(gb) { roll(); st.month.baseBytes = Math.round(gb * GIB) - sum(st.month.per).total; dirty = true; save(); checkLimit(); },
    snapshot() {
      if (!st) return { ok: false, error: 'not started' };
      tick();
      const sample = samples[samples.length-1] || {t:now(),upBps:0,downBps:0,windowSeconds:0};
      const month = sum(st.month.per); const base = st.month.baseBytes || 0;
      const lim = limitBytes(); const used = month.total + base;
      const n = new Date(now()); const next = new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth() + 1, 1));
      return {
        ok: true, keys: KEYS, platform: platformName(), now: n.toISOString(), since: st.since, persisted: writable, file: path.basename(file || ''),
        day: { key: st.day.key, per: st.day.per, ...sum(st.day.per) },
        month: { key: st.month.key, per: st.month.per, ...month, baseBytes: base, used, resetsAt: next.toISOString() },
        allTime: { per: st.allTime, ...sum(st.allTime) },
        history: { since: st.historySince, hours: { ...st.hours } },
        live: {...sample,samples:samples.map(s=>({...s}))}, active: { ...active },
        connections:{tunnels:Object.values(active).reduce((a,b)=>a+b,0),accounts:identities.size,sharedOnline:identities.has('shared'),managedOnline:identities.size-(identities.has('shared')?1:0)},
        limit: lim ? { bytes: lim, used, remaining: Math.max(0, lim - used), pct: used / lim * 100, level: used >= lim ? 'over' : (used >= lim * 0.8 ? 'warn' : 'ok') } : null
      };
    }
  };
}


// END TRAFFIC METER
const AmyraxTraffic = createTrafficMeter({ Logger, platformName: amyraxPlatformName });

// BEGIN TUNNEL GATEWAY
function createTunnelGateway({ AmyraxTraffic }) {
  const crypto = require('crypto'), net = require('net');
  const { Transform } = require('stream');
  const { WebSocketServer, createWebSocketStream } = require('ws');
  const { performance } = require('perf_hooks');
  const tunnelPath = '/Telegram=@AmyraxVPN';
  const crcTable = Array.from({ length: 256 }, (_, n) => {
    for (let i = 0; i < 8; i++) n = (n >>> 1) ^ ((n & 1) ? 0xedb88320 : 0);
    return n >>> 0;
  });
  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const b of bytes) crc = (crc >>> 8) ^ crcTable[(crc ^ b) & 255];
    return (crc ^ 0xffffffff) >>> 0;
  }
  function vmessKey(uuid) {
    const commandKey = crypto.createHash('md5').update(Buffer.from(uuid.replaceAll('-', ''), 'hex'))
      .update('c48619fe-8f02-49e0-b9e9-edf763e17e21').digest();
    const inner = data => crypto.createHmac('sha256', 'VMess AEAD KDF').update(data).digest();
    const salt = Buffer.from('AES Auth ID Encryption');
    const ipad = Buffer.alloc(64, 0x36), opad = Buffer.alloc(64, 0x5c);
    for (let i = 0; i < salt.length; i++) { ipad[i] ^= salt[i]; opad[i] ^= salt[i]; }
    return inner(Buffer.concat([opad, inner(Buffer.concat([ipad, commandKey]))])).subarray(0, 16);
  }
  function ssKey(password) {
    let previous = Buffer.alloc(0), key = Buffer.alloc(0);
    while (key.length < 32) {
      previous = crypto.createHash('md5').update(previous).update(password).digest();
      key = Buffer.concat([key, previous]);
    }
    return key.subarray(0, 32);
  }
  class TunnelGateway {
    constructor(config, ports) {
      this.config = config; this.ports = ports; this.keys = new Map();
      this.wss = new WebSocketServer({ noServer: true, clientTracking: false, perMessageDeflate: false, maxPayload: 1024 * 1024 });
    }
    candidates() {
      const manager = this.config.userManager, list = [];
      const uuid = manager?.stateManager.state.uuid || this.config.uuid;
      if (uuid) list.push({ uuid, shared: true, password: manager?.stateManager.state.shadowsocksPassword || this.config.shadowsocks.password });
      if (manager && !manager.loadError && manager.running && !manager.stopped) {
        for (const u of manager.users) if (manager.permitted(u)) list.push({ uuid: u.uuid, id: u.id, password: u.uuid });
      }
      const current = new Set(list.map(c => c.uuid));
      for (const key of this.keys.keys()) if (!current.has(key)) this.keys.delete(key);
      for (const c of list) {
        if (!this.keys.has(c.uuid)) this.keys.set(c.uuid, {
          uuid: Buffer.from(c.uuid.replaceAll('-', ''), 'hex'), vmess: vmessKey(c.uuid),
          trojan: Buffer.from(crypto.createHash('sha224').update(c.uuid).digest('hex')),
          ss: ssKey(c.password || c.uuid)
        });
        c.keys = this.keys.get(c.uuid);
      }
      return list;
    }
    target(candidate, protocol) {
      if (candidate.shared) {
        const key = {vless:'vlessWs',vmess:'vmessWs',trojan:'trojanWs',shadowsocks:'shadowsocks'}[protocol];
        return this.ports[key] ? { ...candidate, protocol, port: this.ports[key] } : null;
      }
      const manager = this.config.userManager;
      const user = manager.users.find(u => u.id === candidate.id);
      const target = manager.targets.get(candidate.id)?.[protocol];
      return user && user.uuid === candidate.uuid && manager.permitted(user) && user.protocols.includes(protocol) && target
        ? { ...candidate, ...target, protocol } : null;
    }
    identify(bytes, candidates) {
      if (bytes.length >= 58 && bytes[56] === 13 && bytes[57] === 10) {
        const candidate = candidates.find(c => c.keys.trojan.equals(bytes.subarray(0, 56)));
        if (candidate) return this.target(candidate, 'trojan');
      }
      if (bytes.length >= 17 && bytes[0] === 0) {
        const candidate = candidates.find(c => c.keys.uuid.equals(bytes.subarray(1, 17)));
        if (candidate) return this.target(candidate, 'vless');
      }
      if (bytes.length >= 16) {
        for (const c of candidates) {
          const decipher = crypto.createDecipheriv('aes-128-ecb', c.keys.vmess, null); decipher.setAutoPadding(false);
          const auth = decipher.update(bytes.subarray(0, 16));
          const timestamp = Number(auth.readBigUInt64BE(0));
          if (Math.abs(timestamp - Date.now() / 1000) <= 120 && auth.readUInt32BE(12) === crc32(auth.subarray(0, 12))) {
            return this.target(c, 'vmess');
          }
        }
      }
      if (bytes.length >= 50) {
        for (const c of candidates) {
          if (!this.target(c, 'shadowsocks')) continue;
          try {
            const key = crypto.hkdfSync('sha1', c.keys.ss, bytes.subarray(0,32), 'ss-subkey', 32);
            const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.alloc(12));
            decipher.setAuthTag(bytes.subarray(34,50));
            const length = Buffer.concat([decipher.update(bytes.subarray(32,34)),decipher.final()]).readUInt16BE();
            if (length > 0 && length <= 0x3fff) return this.target(c, 'shadowsocks');
          } catch {}
        }
      }
      return null;
    }
    accept(stream, transport, tls = false, head = Buffer.alloc(0), accounts) {
      stream.on('error', () => stream.destroy());
      const timer = setTimeout(() => stream.destroy(), 10000); timer.unref();
      stream.once('close', () => clearTimeout(timer));
      const candidates = this.candidates().filter(c=>!accounts||accounts.has(c.shared?'shared':c.id));
      let initial = Buffer.alloc(0);
      const sniff = chunk => {
        if (initial.length + chunk.length > 128 * 1024) { stream.destroy(); return; }
        initial = Buffer.concat([initial, chunk]);
        if (initial.length < 16) return;
        const target = this.identify(initial, candidates);
        if (!target) { if (initial.length >= 58) stream.destroy(); return; }
        stream.pause(); stream.removeListener('data', sniff); clearTimeout(timer);
        this.relay(stream, initial, target, tls, transport);
      };
      stream.on('data', sniff);
      if (head.length) sniff(head);
    }
    handleUpgrade(req, socket, head) {
      let pathname;
      try { pathname = decodeURIComponent(String(req.url || '').split('?')[0]); } catch { pathname = ''; }
      const accounts = this.config.configStudio?.pathAccounts(pathname);
      if ((pathname !== tunnelPath && !accounts?.size) || req.headers['sec-websocket-protocol']) {
        socket.end('HTTP/1.1 404 Not Found\r\nConnection: close\r\nContent-Length: 0\r\n\r\n'); return;
      }
      socket.setTimeout(0); socket.setNoDelay(true); socket.setKeepAlive(true, 10000);
      if (!req.headers['sec-websocket-key']) {
        if (req.method !== 'GET' || String(req.headers.upgrade).toLowerCase() !== 'websocket') { socket.destroy(); return; }
        socket.write('HTTP/1.1 101 Switching Protocols\r\nConnection: upgrade\r\nUpgrade: websocket\r\n\r\n');
        this.accept(socket, 'HTTPUpgrade', Boolean(req.socket.encrypted), head, accounts);
        return;
      }
      this.wss.handleUpgrade(req, socket, head, ws => {
        const stream = createWebSocketStream(ws);
        this.watchHeartbeat(ws);
        stream.on('error', () => stream.destroy());
        ws.on('message', (_, binary) => { if (!binary) stream.destroy(); });
        this.accept(stream, 'WS', Boolean(req.socket.encrypted), Buffer.alloc(0), accounts);
      });
    }
    watchHeartbeat(ws) {
      let missed = 0, lastTick = performance.now();
      const active = () => { missed = 0; };
      ws.on('pong',active); ws.on('message',active);
      const timer = setInterval(() => {
        if (ws.readyState !== 1) return;
        const now = performance.now();
        if (now - lastTick > 45000) missed = 0;
        lastTick = now;
        if (missed >= 2) { ws.terminate(); return; }
        missed++; ws.ping();
      },30000);
      timer.unref();
      ws.once('close',() => { clearInterval(timer); ws.removeListener('pong',active); ws.removeListener('message',active); });
    }
    relay(stream, initial, target, tls, transport = 'WS') {
      const manager = this.config.userManager, transforms = [];
      const label = {vless:'VLESS',vmess:'VMess',trojan:'Trojan',shadowsocks:'Shadowsocks'}[target.protocol] + '-' + transport + (tls ? '-TLS' : '');
      let done = () => {};
      const backend = net.connect(target.port, '127.0.0.1');
      let closed = false;
      const connection = { generation: target.generation, close() {
        if (closed) return; closed = true;
        stream.destroy(); backend.destroy(); transforms.forEach(t => t.destroy()); done();
        if (!target.shared) { manager.connections.get(target.id)?.delete(connection); manager.retire(); }
      } };
      if (!target.shared) {
        if (!manager.connections.has(target.id)) manager.connections.set(target.id, new Set());
        manager.connections.get(target.id).add(connection);
      }
      const meter = direction => new Transform({ transform(chunk, _, callback) {
        const user = target.shared ? null : manager.users.find(u => u.id === target.id);
        const allowed = target.shared ? chunk.length
          : user?.uuid === target.uuid && user.protocols.includes(target.protocol) ? manager.charge(target.id, direction, chunk.length) : 0;
        if (!allowed) { callback(new Error('Connection no longer permitted')); connection.close(); return; }
        AmyraxTraffic.add(label, direction === 'up' ? allowed : 0, direction === 'down' ? allowed : 0);
        callback(null, chunk.subarray(0, allowed));
        if (allowed < chunk.length) setImmediate(() => connection.close());
      } });
      const up = meter('up'), down = meter('down'); transforms.push(up, down);
      for (const s of [stream, backend, up, down]) s.on('error', () => connection.close());
      stream.once('close', () => connection.close());
      backend.once('close', () => { if (!backend.readableEnded) connection.close(); });
      backend.setTimeout(10000, () => connection.close());
      backend.once('connect', () => {
        if (closed) return;
        backend.setTimeout(0); backend.setNoDelay(true); backend.setKeepAlive(true, 10000);
        if (!this.target(target, target.protocol)) { connection.close(); return; }
        done = AmyraxTraffic.open(label,target.shared ? 'shared' : target.id);
        up.pipe(backend); backend.pipe(down).pipe(stream);
        up.write(initial); stream.pipe(up); stream.resume();
      });
    }
  }
  TunnelGateway.path = tunnelPath;
  return TunnelGateway;
}


// END TUNNEL GATEWAY
const TunnelGateway = createTunnelGateway({ AmyraxTraffic });

class TcpRouter {
  constructor(config, targetPorts, expressServer, expressApp) {
    this.config = config;
    this.ports = targetPorts;
    this.httpServer = expressServer;
    this.expressApp = expressApp || (expressServer && expressServer.listeners('request')[0]);
    this.server = null;
    this.httpsServer = null;
    this.internalHttpsPort = null;
    this.sockets = new Set();
  }

  pipeToBackend(clientSocket, firstChunk, targetPort, label) {
    clientSocket.setTimeout(0);
    clientSocket.setKeepAlive(true, 10000);
    clientSocket.setNoDelay(true);

    const backend = net.connect(targetPort, '127.0.0.1', () => {
      backend.setTimeout(0);
      backend.setKeepAlive(true, 10000);
      backend.setNoDelay(true);
      backend.write(firstChunk);
      if (!label.startsWith('Internal-')) {
        AmyraxTraffic.add(label, firstChunk ? firstChunk.length : 0, 0);
        AmyraxTraffic.meter(label, clientSocket, backend);
      }
      clientSocket.pipe(backend);
      backend.pipe(clientSocket);
      clientSocket.resume();
    });

    clientSocket.once('close', () => backend.destroy());
    backend.once('close', () => { if (!backend.readableEnded) clientSocket.destroy(); });
    backend.on('error', (err) => {
      const now = Date.now();
      if (!this._lastWarns) this._lastWarns = {};
      if (!this._lastWarns[label] || now - this._lastWarns[label] > 15000) {
        Logger.warn(`TCP Router: ${label} backend on :${targetPort} unreachable (${err.message})`);
        this._lastWarns[label] = now;
      }
      try { clientSocket.destroy(); } catch {}
    });

    clientSocket.on('error', () => {
      try { backend.destroy(); } catch {}
    });
  }

  attachUpgradeHandlers(server) {
    this.gateway ||= new TunnelGateway(this.config, this.ports);
    if (server.amyraxUpgradeAttached) return;
    server.amyraxUpgradeAttached = true;
    server.on('upgrade', (req, socket, head) => this.gateway.handleUpgrade(req, socket, head));
  }

  async setupInternalHttps() {
    try {
      const certs = ensureTlsCertificates(this.config.paths.certPath, this.config.paths.keyPath, this.config.domain || 'localhost');
      if (!certs || !certs.cert || !certs.key) return;

      const handler = this.expressApp || this.httpServer.listeners('request')[0];
      this.httpsServer = await TransportSupport.tlsFrontend(this.config,this.gateway,handler,certs);

      await new Promise((resolve) => {
        this.httpsServer.listen(0, '127.0.0.1', () => {
          this.internalHttpsPort = this.httpsServer.address().port;
          Logger.item('Internal HTTPS Port', this.internalHttpsPort);
          resolve();
        });
        this.httpsServer.on('error', (err) => {
          Logger.warn(`Internal HTTPS server failed to start: ${err.message}`);
          resolve();
        });
      });
    } catch (err) {
      Logger.warn(`Internal HTTPS setup error: ${err.message}`);
    }
  }

  async start() {
    this.httpServer.keepAliveTimeout = 120000;
    this.httpServer.headersTimeout = 125000;
    this.attachUpgradeHandlers(this.httpServer);

    await this.setupInternalHttps();

    this.server = net.createServer(socket => {
      this.sockets.add(socket);socket.once('close',()=>this.sockets.delete(socket));
      socket.setTimeout(10000,()=>socket.destroy());socket.setKeepAlive(true,10000);socket.setNoDelay(true);
      let initial=Buffer.alloc(0);
      const sniff=chunk=>{
        initial=Buffer.concat([initial,chunk]);
        if(initial.length<3)return;
        if(initial.subarray(0,3).toString()==='PRI'&&initial.length<24)return;
        socket.pause();socket.removeListener('data',sniff);socket.setTimeout(0);
        if(initial[0]===0x16&&initial[1]===0x03&&this.internalHttpsPort) {
          this.pipeToBackend(socket,initial,this.internalHttpsPort,'Internal-HTTPS');return;
        }
        if(initial.subarray(0,24).toString()==='PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n') {
          if(this.config.transportState?.grpc)this.pipeToBackend(socket,initial,this.config.transportState.grpc,'Internal-gRPC');
          else socket.destroy();return;
        }
        socket.unshift(initial);this.httpServer.emit('connection',socket);socket.resume();
      };
      socket.on('data',sniff);socket.on('error',()=>{});
    });

    return new Promise((resolve, reject) => {
      this.server.listen(this.config.publicPort, '0.0.0.0', () => {
        Logger.success(`Public TCP multiplexer listening on 0.0.0.0:${this.config.publicPort}`);
        resolve(this.server);
      });
      this.server.on('error', reject);
    });
  }

  stop() {
    for (const socket of this.sockets) socket.destroy();
    if (this.server) {
      try { this.server.close(); } catch {}
    }
    this.httpsServer?.closeAllConnections();
    if (this.httpsServer) {
      try { this.httpsServer.close(); } catch {}
    }
  }
}

async function resolvePublicHost(config, savedHost) {
  if (config.forceHost) return config.forceHost;
  if (config.subBase || config.publicBaseUrl) return normalizeHost(NetworkSupport.origin(config, '').hostname);
  const explicitDomain = normalizeHost(process.env.DOMAIN || process.env.SB_DOMAIN || '');
  if (config.domain && (explicitDomain || amyraxOnRailway() || !amyraxIsPlatformHost(config.domain))) return config.domain;
  const allocated = normalizeHost(process.env.SERVER_IP || process.env.P_SERVER_IP);
  if (!amyraxOnRailway() && NetworkSupport.publicHost(allocated) && isIpLiteral(savedHost) && allocated !== normalizeHost(savedHost)) return allocated;
  if (NetworkSupport.publicHost(savedHost) && (!amyraxOnRailway() || !isIpLiteral(savedHost)) && !explicitDomain && !amyraxIsPlatformHost(savedHost)) { Logger.info(`Using public domain saved from an earlier panel visit: ${savedHost}`); return savedHost; }
  if (config.domain) return config.domain;
  if (NetworkSupport.publicHost(savedHost) && (!amyraxOnRailway() || !isIpLiteral(savedHost)) && !savedHost.endsWith('.replit.dev')) { Logger.info(`Using public domain saved from an earlier panel visit: ${savedHost}`); return savedHost; }
  if (amyraxOnReplit()) {
    if (!process.env.REPLIT_DEPLOYMENT) {
      Logger.warn('Running in the Replit editor: the *.replit.dev URL is private and cannot be used for configs.');
      Logger.warn('Publish the app (Reserved VM or Autoscale) and open https://<name>.replit.app/amyrax (or your Worker address).');
    } else {
      Logger.warn('No public domain found in REPLIT_DOMAINS: links use the domain you open the panel with (saved automatically).');
    }
  } else if (amyraxOnRailway()) {
    Logger.warn('No public domain yet: Railway -> Settings -> Networking -> Generate Domain (target port ' + config.publicPort + ').');
    Logger.warn('Open the generated HTTPS domain at /' + config.panelPath + '; the panel learns it after login. The outbound server IP is not a public Railway endpoint.');
    return '127.0.0.1';
  }
  if (NetworkSupport.publicHost(allocated)) return allocated;
  const publicIp = await NetworkSupport.discoverIp();
  if (publicIp) return publicIp;
  Logger.warn('No valid public address detected. Activate a Bot-Hosting domain and open the panel with it, or set DOMAIN / PUBLIC_BASE_URL.');
  return '127.0.0.1';
}

async function prepareRuntimeBinaries(userConfig = {}) {
  const config = buildConfig({...AMYRAX_CONFIG, ...userConfig});
  const manager = new BinaryManager(config);
  if (!await manager.ensureSingBox() || !await manager.ensureXray()) throw new Error('Connection engines could not be prepared.');
  return config;
}

async function startPanel(userConfig = {}) {
  Logger.banner();
  Logger.renewNotice();

  const config = buildConfig(userConfig);
  config.startupReady = false;
  Logger.section('Configuration');
  Logger.item('Public Port', config.publicPort);
  Logger.item('Panel Path', `/${config.panelPath}`);
  Logger.item('Data Directory', config.paths.dataDir);
  {
    const dInfo = resolveDataDir.info || { source: 'unknown' };
    const onRw = !!(process.env.RAILWAY_PROJECT_ID || process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_SERVICE_ID || process.env.RAILWAY_PUBLIC_DOMAIN);
    const vol = process.env.RAILWAY_VOLUME_MOUNT_PATH;
    Logger.info(`Data directory: ${config.paths.dataDir} (${dInfo.source})`);
    if (amyraxOnReplit() && !process.env.AMYRAX_DATA_DIR) {
      Logger.warn('Replit: the published app filesystem resets on every Publish (and on Autoscale restarts).');
      Logger.warn('To keep the same configs/password, add Secrets UUID, PANEL_PASSWORD and SUB_TOKEN (all optional).');
    } else if (onRw && !vol) {
      Logger.warn('No Railway Volume attached: panel password, UUID and configs are reset on every redeploy.');
      Logger.warn('Fix (no variables needed): right-click the service -> Attach Volume (any mount path, e.g. /data).');
    } else if (onRw && vol && path.resolve(config.paths.dataDir) !== path.resolve(vol) && !path.resolve(config.paths.dataDir).startsWith(path.resolve(vol) + path.sep)) {
      Logger.warn(`Data directory is outside the attached volume (${vol}); remove AMYRAX_DATA_DIR or point it inside the volume to keep data.`);
    }
  }

  AmyraxTraffic.init(config.paths.dataDir);

  const stateMgr = new StateManager(config.paths, config);
  const state = stateMgr.loadOrCreate();
  Logger.item('UUID', state.uuid);

  const savedPublicHost = NetworkSupport.publicHost(state.publicHost) ? state.publicHost : NetworkSupport.host(state.publicOrigin);
  const resolvedHost = await resolvePublicHost(config, savedPublicHost || '');
  const previousOriginHost = normalizeHost(state.publicOrigin);
  if ((isIpLiteral(previousOriginHost) || amyraxOnRailway()) && NetworkSupport.publicHost(resolvedHost) && previousOriginHost !== resolvedHost) {
    state.publicHost = resolvedHost; state.publicOrigin = ''; config.learnedPublicOrigin = '';
    stateMgr.save();
  }
  if (NetworkSupport.publicHost(resolvedHost)) stateMgr.setPublicIp(resolvedHost);
  Logger.item('Resolved Host', resolvedHost);

  const allocatedPorts = {};
  allocatedPorts.vlessWs = await allocatePorts();
  allocatedPorts.vmessWs = await allocatePorts();
  allocatedPorts.trojanWs = await allocatePorts();
  allocatedPorts.shadowsocks = await allocatePorts();

  Logger.section('Engines & Binaries');
  const binManager = new BinaryManager(config);

  const hasSingBox = await binManager.ensureSingBox();
  if (amyraxOnRailway() && !hasSingBox) throw new Error('The Railway connection engine could not be installed. Check the deployment logs and network access.');
  config.configStudio = new ConfigStudio.Studio(config,stateMgr);
  let hasXray = false;
  if (TransportSupport.variants.some(([,transport,,flag])=>['grpc','xhttp'].includes(transport)&&config.enable[flag])) {
    hasXray = await binManager.ensureXray();
  }
  if(config.configStudio.egress.enabled && !config.configStudio.loadError) {
    try {
      if(!hasXray && !await binManager.ensureXray()) throw new Error('Missing Xray');
      await config.configStudio.startEgress();
    } catch { config.configStudio.egressPort=0; Logger.error('Outbound could not start; VPN egress remains blocked until it is fixed or disabled.'); }
  }
  let hasCloudflared = false;
  if (config.enable.argo) {
    hasCloudflared = await binManager.ensureCloudflared();
  }

  let singboxInstance = null;
  if (hasSingBox) {
    singboxInstance = new SingBoxEngine(config, stateMgr, allocatedPorts);
    const started = singboxInstance.start();
    if (amyraxOnRailway() && !started) throw new Error('The Railway connection engine could not start.');
  } else {
    Logger.warn('sing-box binary could not be started. (Mock/offline mode active).');
  }

  let xrayInstance = null;

  let argoInstance = null;
  let argoDomain = null;
  if (hasCloudflared && config.enable.argo) {
    argoInstance = new ArgoTunnel(config, config.publicPort);
    argoDomain = await argoInstance.start();
  }

  const alive = engine => !!(engine?.process && !engine.process.killed && engine.process.exitCode === null && engine.process.signalCode === null);
  const engineStatusGetter = () => ({singbox:alive(singboxInstance), xray:alive(xrayInstance), argo:alive(argoInstance)});

  const { server: expressServer, app: expressApp } = createHttpPanel(config, stateMgr, engineStatusGetter, () => resolvedHost);
  config.userManager.start();
  const tcpRouter = new TcpRouter(config, allocatedPorts, expressServer, expressApp);
  tcpRouter.attachUpgradeHandlers(expressServer);
  if (hasXray) { xrayInstance = new TransportSupport.Bridge(config,tcpRouter.gateway);await xrayInstance.start(); }
  await tcpRouter.start();
  Logger.section('Public endpoint checks');
  const networkReport = await config.networkDiagnostics.check(resolvedHost, engineStatusGetter());
  for (const check of networkReport.checks) {
    if (check.state === 'ok') Logger.info(check.message);
    else Logger.warn(check.message);
  }


  const linkGen = await new LinkGenerator(config, stateMgr.state, resolvedHost).prepare();
  const compatNodes = linkGen.getAllNodes({ compat: 'v2ray', argoDomain, allowLocalHostLinks: config.allowLocalHostLinks });
  const allNodes = linkGen.getAllNodes({ compat: 'full', argoDomain, allowLocalHostLinks: config.allowLocalHostLinks });
  const links = compatNodes.map(n => n.uri);
  const clashYaml = linkGen.buildClashMetaYaml(allNodes);
  const singboxJson = linkGen.buildSingBoxClientJson(allNodes);

  stateMgr.setLinks(links, clashYaml, singboxJson);
  config.startupReady = true;
  const readyVariants=TransportSupport.variants.filter(([, , , flag])=>config.enable[flag]);
  const readyEngines=engineStatusGetter();
  if(process.send && (!readyVariants.length||readyEngines.singbox) && (!readyVariants.some(([,transport])=>['grpc','xhttp'].includes(transport))||readyEngines.xray) && (!config.enable.argo||readyEngines.argo))
    process.send({type:'amyrax-ready',version:AMYRAX_VERSION});



  const panelBase = NetworkSupport.origin(config, resolvedHost || '127.0.0.1');
  panelBase.pathname = panelBase.pathname.replace(/\/$/, '') + '/' + config.panelPath;
  const panelUrl = panelBase.href;
  Logger.item('Link host / SNI', `${linkGen.host} / ${linkGen.tlsOpt.sni} (port ${linkGen.port}, fp=${linkGen.tlsOpt.fp || 'none'}, alpn=${linkGen.tlsOpt.alpn.join(',') || 'none'})`);
  Logger.section('Amyrax Panel Active');
  Logger.item('Host', amyraxPlatformName());
  Logger.item('Web Panel', panelUrl);
  Logger.ready(panelUrl,config,engineStatusGetter());

  const shutdown = (code) => {
    config.startupReady = false;
    Logger.info('Stopping Amyrax Panel...');
    if (singboxInstance) singboxInstance.stop();
    if (xrayInstance) xrayInstance.stop();
    if (argoInstance) argoInstance.stop();
    if (tcpRouter) tcpRouter.stop();
    config.userManager?.stop();
    config.configStudio?.stop();
    config.panelUpdater?.stop();
    try { AmyraxTraffic.save(); } catch (_) {}
    process.exit(code === AMYRAX_RESTART_CODE ? AMYRAX_RESTART_CODE : 0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  amyraxRestart = () => shutdown(AMYRAX_RESTART_CODE);

  return {
    config,
    state: stateMgr.state,
    nodes: compatNodes,
    allNodes,
    panelUrl,
    allocatedPorts,
    tcpRouter,
    singboxInstance,
    xrayInstance,
    argoInstance,
    shutdown
  };
}

if (require.main === module && !process.env.AMYRAX_SUPERVISED && process.env.AMYRAX_NO_SUPERVISOR !== 'true') {
  const launcher = new PanelUpdates.Manager({current:AMYRAX_VERSION,entry:__filename,dataDir:resolveDataDir(AMYRAX_CONFIG.dataDirHint),repo:AMYRAX_UPDATE_REPO});
  const controller = launcher.supervise({config:AMYRAX_CONFIG,args:process.argv.slice(2),onEvent:event=>{
    if(event.type==='exit')process.exit(event.code);
    if(event.type==='stopped')process.exit(0);
    if(event.type==='rollback')console.warn('[Amyrax] Update failed to start; previous version restored.');
    if(event.type==='state-error')console.warn('[Amyrax] Update store could not be read; installed version started.');
  }});
  ['SIGINT','SIGTERM'].forEach(signal=>process.on(signal,()=>controller.stop(signal)));
} else if (require.main === module) {
  let bootConfig=AMYRAX_CONFIG;
  if(process.env.AMYRAX_BOOT_CONFIG){
    const saved=JSON.parse(process.env.AMYRAX_BOOT_CONFIG);
    bootConfig={...AMYRAX_CONFIG,...saved,enable:{...AMYRAX_CONFIG.enable,...saved.enable}};
  }
  startPanel(bootConfig).catch(err => {
    console.error('[FATAL] Failed to start Amyrax Panel:', err);
    process.exit(1);
  });
}

module.exports = {
  AMYRAX_CONFIG,
  prepareRuntimeBinaries,
  startPanel
};
